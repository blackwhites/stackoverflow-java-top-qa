package task;

import java.util.ArrayList;


/**
 * Object to represent a Curl request.  Pass this object to the TaskLauncher object to make a curl request.<br/>
 * Use this object to set the various curl options<br/>
 * <p>Example:<br/>
 * <ul>
 * <li>CurlTask curlRequest = new CurlTask("https://google.com");</li>
 * <li>curlRequest.setVerbose(true);//This turns on verbose output.  Shows connection information like ssl specs used</li>
 * <li>curlRequest.setSilent(true);//This turns off the progress stats in the verbose output</li>
 * <li>curlRequest.setInsecure(true);//This ignores the servers certs</li>
 * <li>TaskLauncher taskLauncher = new TaskLauncher();//Object used to make the curl request</li>
 * <li>TaskResult curlResult = taskLauncher.launchTask(curlRequest, 300000);//pass the curl object and a timeout in milliseconds</li>
 * <li>System.out.println(curlResult.getErrOut());//Prints any information that was put in the error out stream from the curl command.  IE: the verbose information</li>
 * <li>System.out.println(curlResult.getStdOut());//Prints any information that was put in the standard out stream.  IE: the body of the response</li>
 * <li>System.out.println(curlResult.getExitValue());//Prints the exit value for that process. -0 if successful, otherwise there was an error.  If error check error stream for details.</li>
 * <li>System.out.println(curlResult.getCommand());//Prints the command used to make the curl request.</li>
 * <ul>
 * </p>
 * <p>
 * Note: There are known issues with using " and ' through the curl task.  To debug, try copying the curl command that is used into a terminal.
 * </p>
 * @author nickCoble
 *
 */
public class CurlTask extends ProcessTask{
	private boolean verbose = false;
	private boolean binaryData = false;
	private String binaryDataString="";
	private boolean asciiData =false;
	private String asciiDataString="";
	private String url = "";
	private boolean append=false;
	private boolean userAgents=false;
	private String userAgent="";
	private boolean anyAuth=false;
	private boolean useCookie =false;
	private String cookie="";
	private boolean ascii=false;
	private boolean basicAuth =false;
	private boolean cipher = false;
	private String ciphers="";
	private boolean compressed = false;
	private int connTimeOut = -1;
	private boolean writeCookieToFile=false;
	private String fileToWriteCookieTo="";
	private boolean digest=false;
	private boolean dumpHeaders = false;
	private String dumpHeadersFile="";
	private boolean addHeader=false;
	private ArrayList<String> headers=new ArrayList<>();
	private boolean includeHeaders = false;
	private boolean onlyHeaders = false;
	private boolean insecure =false;
	private boolean keyFile = false;
	private String keyFileName="";
	private boolean customParm=false;
	private String customParms="";
	private boolean silent=false;
	private boolean version=false;
	private String user ="";
	private String httpMethod ="";
	private String data ="";
	private String form = "";


	/**
	 * Object constructor
	 * @param url
	 */
	public CurlTask(String url){this.url=url;}
	
	@Override
	public String buildCommand() {
		String curlCommand = "curl";
		if(!this.validateCommand()){return null;}
		
		if(verbose){
			curlCommand += " -v";
		}
		
		if(httpMethod != null && !httpMethod.isEmpty()){
			curlCommand += " -X " + httpMethod;
		}
		
		if(data != null && !data.isEmpty()){
			curlCommand += " -d \"" + data + "\"";
		}
		
		if(form != null && !form.isEmpty()){
			curlCommand += " -F \"" + form + "\"";
		}
		
		if(binaryData){
			curlCommand += " --data-binary " + this.binaryDataString;
		}
		
		if(asciiData){
			curlCommand += " --data-ascii " + this.asciiDataString;
		}
		
		if(anyAuth){
			curlCommand += " -anyauth";
		}
		
		if(useCookie){
			curlCommand += " -b " + cookie;
		}
		
		if(ascii){
			curlCommand += " -B";
		}

		if(basicAuth){
			curlCommand += " --basic";
		}

		if(cipher){
			curlCommand += " --ciphers " + ciphers;
		}
		
		if(compressed){
			curlCommand += " --compressed";
		}

		if(connTimeOut>0){
			curlCommand += " --connect-timeout " + connTimeOut;
		}
		
		if(writeCookieToFile){
			curlCommand += " -c " + fileToWriteCookieTo;
		}

		if(digest){
			curlCommand += " --digest";
		}
		
		if(dumpHeaders){
			curlCommand += " -D " + dumpHeadersFile;
		}
		
		if(addHeader){
			for(String s: headers){
				curlCommand +=  " -H \"" + s + "\"";
			}
		}
		
		if(includeHeaders){
			curlCommand += " -i";
		}
		
		if(onlyHeaders){
			curlCommand += " --head";
		}
		
		if(insecure){
			curlCommand += " -k";
		}

		if(keyFile){
			curlCommand += " --key " + keyFileName;
		}
		
		if(customParm){
			curlCommand += " " + customParms;
		}
		
		if(silent){
			curlCommand += " -s";
		}
		
		if(version){
			curlCommand += " -V"; 
		}
		
		if(user!= null && !user.equals("")){
			curlCommand += " -u " + this.user;
		}
		
		curlCommand += " " + this.url;
		return curlCommand;
	}
	
	@Override
	public boolean validateCommand() {
		if(this.url==null || this.url.equals("")){
			return false;
		}else{
			return true;
		}
	}
	
	/**
	 * @return the httpMethod
	 */
	public String getHttpMethod() {
		return httpMethod;
	}

	/**
	 * @param httpMethod the httpMethod to set
	 */
	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	
	/**
	 * Returns if the command has verbosed turned on
	 * @return
	 */
	public boolean isVerbose() {return verbose;}

	/**
	 * Sets the verbose parameter
	 * @param verbose
	 */
	public void setVerbose(boolean verbose) {this.verbose = verbose;}

	/**
	 * Returns true if the binary data parameter is set
	 * @return
	 */
	public boolean isBinaryData() {return binaryData;}

	/**
	 * Returns the url that will be used in the curl request.
	 * @return
	 */
	public String getUrl() {return url;}

	/**
	 * Sets the url that will be used in the curl request
	 * @param url
	 */
	public void setUrl(String url) {this.url = url;}
	
	/**
	 * Returns the data-binary value used in the curl request
	 * @return
	 */
	public String getBinaryDataString() {return binaryDataString;}

	/**
	 * Sets the data-binary value used in the curl request<br/>
	 * Example: --data-binary "Some text"
	 * @param binaryDataString
	 */
	public void setBinaryDataString(String binaryDataString) {
		if(binaryDataString == null || binaryDataString.equals("")){
			this.binaryData=false;			
		}else{
			this.binaryData=true;
		}
		
		this.binaryDataString = binaryDataString;
	}

	public boolean isAsciiData() {
		return asciiData;
	}

	public String getAsciiDataString() {
		return asciiDataString;
	}

	public void setAsciiDataString(String asciiDataString) {
		if(asciiDataString == null || asciiDataString.equals("")){
			this.asciiData=false;			
		}else{
			this.asciiData=true;
		}
		this.asciiDataString = asciiDataString;
	}

	public boolean isAppend() {
		return append;
	}

	public void setAppend(boolean append) {
		this.append = append;
	}

	public boolean isUserAgents() {
		return userAgents;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		if(userAgent == null || userAgent.equals("")){
			this.userAgents=false;			
		}else{
			this.userAgents=true;
		}
		this.userAgent = userAgent;
	}

	public boolean isAnyAuth() {
		return anyAuth;
	}

	public void setAnyAuth(boolean anyAuth) {
		this.anyAuth = anyAuth;
	}

	public boolean isUseCookie() {
		return useCookie;
	}

	public String getCookie() {
		return cookie;
	}

	public void setCookie(String cookie) {
		if(cookie == null || cookie.equals("")){
			this.useCookie=false;			
		}else{
			this.useCookie=true;
		}
		this.cookie = cookie;
	}

	public boolean isAscii() {
		return ascii;
	}

	public boolean isBasicAuth() {
		return basicAuth;
	}

	public void setBasicAuth(boolean basicAuth) {
		this.basicAuth = basicAuth;
	}

	public boolean isCipher() {
		return cipher;
	}
	
	public String getCiphers() {
		return ciphers;
	}

	public void setCiphers(String ciphers) {
		if(ciphers == null || ciphers.equals("")){
			this.cipher=false;			
		}else{
			this.cipher=true;
		}
		
		this.ciphers = ciphers;
	}

	public boolean isCompressed() {
		return compressed;
	}

	public void setCompressed(boolean compressed) {
		this.compressed = compressed;
	}

	public int getConnTimeOut() {
		return connTimeOut;
	}

	public void setConnTimeOut(int connTimeOut) {
		this.connTimeOut = connTimeOut;
	}

	public boolean isWriteCookieToFile() {
		return writeCookieToFile;
	}

	public String getFileToWriteCookieTo() {
		return fileToWriteCookieTo;
	}

	public void setFileToWriteCookieTo(String fileToWriteCookieTo) {
		if(fileToWriteCookieTo == null || fileToWriteCookieTo.equals("")){
			this.writeCookieToFile=false;			
		}else{
			this.writeCookieToFile=true;
		}
		this.fileToWriteCookieTo = fileToWriteCookieTo;
	}

	public boolean isDigest() {
		return digest;
	}

	public void setDigest(boolean digest) {
		this.digest = digest;
	}

	public boolean isDumpHeaders() {
		return dumpHeaders;
	}

	public String getDumpHeadersFile() {
		return dumpHeadersFile;
	}

	public void setDumpHeadersFile(String dumpHeadersFile) {
		if(dumpHeadersFile == null || dumpHeadersFile.equals("")){
			this.dumpHeaders=false;			
		}else{
			this.dumpHeaders=true;
		}
		this.dumpHeadersFile = dumpHeadersFile;
	}

	public boolean isAddHeader() {
		return addHeader;
	}

	public ArrayList<String> getHeaders() {
		return headers;
	}

	public void setHeaders(ArrayList<String> headers) {
		if(headers == null || headers.size()==0){
			this.addHeader=false;
		}
		this.addHeader=true;
		this.headers = headers;
	}
	
	public void addHeader(String  header){
		if(header == null || header.equals("")){
			return;
		}
		this.addHeader=true;
		this.headers.add(header);
	}

	public boolean isIncludeHeaders() {
		return includeHeaders;
	}

	public void setIncludeHeaders(boolean includeHeaders) {
		this.includeHeaders = includeHeaders;
	}

	public boolean isOnlyHeaders() {
		return onlyHeaders;
	}

	public void setOnlyHeaders(boolean onlyHeaders) {
		this.onlyHeaders = onlyHeaders;
	}

	public boolean isInsecure() {
		return insecure;
	}

	public void setInsecure(boolean insecure) {
		this.insecure = insecure;
	}

	public boolean isKeyFile() {
		return keyFile;
	}

	public String getKeyFileName() {
		return keyFileName;
	}

	public void setKeyFileName(String keyFileName) {
		if(keyFileName == null || keyFileName.equals("")){
			this.keyFile=false;			
		}else{
			this.keyFile=true;
		}
		this.keyFileName = keyFileName;
	}

	public boolean isCustomParm() {
		return customParm;
	}

	public String getCustomParms() {
		return customParms;
	}

	public void setCustomParms(String customParms) {
		if(customParms == null || customParms.equals("")){
			this.customParm=false;			
		}else{
			this.customParm=true;
		}
		this.customParms = customParms;
	}

	public boolean isSilent() {
		return silent;
	}

	public void setSilent(boolean silent) {
		this.silent = silent;
	}

	public boolean isVersion() {
		return version;
	}

	public void setVersion(boolean version) {
		this.version = version;
	}
	
	public void setUserAndPW(String user, String pw){
		this.user = user + ":" + pw;
	}
	
	public String getUserAndPW(){return this.user;}

	@Override
	public ArrayList<String> getCommands() {
		if(!this.validateCommand()){return null;}

		ArrayList<String> commands = new ArrayList<>();
		commands.add("curl");
		
		if(verbose){
			commands.add("-v");
		}
		
		if(httpMethod != null && !httpMethod.isEmpty()){
			commands.add("-X "+ httpMethod);
		}
		
		if(data != null && !data.isEmpty()){
			commands.add("-d \""+ data + "\"");
		}
		
		if(form != null && !form.isEmpty()){
			commands.add("-F \""+ form + "\"");
		}
		
		if(binaryData){
			commands.add("--data-binary "+ this.binaryDataString);
		}
		
		if(asciiData){
			commands.add("--data-ascii "+ this.asciiDataString);
		}
		
		if(anyAuth){
			commands.add("-anyauth");
		}
		
		if(useCookie){
			commands.add("-b "+ cookie);
		}
		
		if(ascii){
			commands.add("-B");
		}

		if(basicAuth){
			commands.add("--basic");
		}

		if(cipher){
			commands.add("--ciphers "+ ciphers);
		}
		
		if(compressed){
			commands.add("--compressed");
		}

		if(connTimeOut>0){
			commands.add("--connect-timeout "+ connTimeOut);
		}
		
		if(writeCookieToFile){
			commands.add("-c "+ fileToWriteCookieTo);
		}

		if(digest){
			commands.add("--digest");
		}
		
		if(dumpHeaders){
			commands.add("-D "+ dumpHeadersFile);
		}
		
		if(addHeader){
			for(String s: headers){
				commands.add( "-H \""+ s + "\"");
			}
		}
		
		if(includeHeaders){
			commands.add("-i");
		}
		
		if(onlyHeaders){
			commands.add("--head");
		}
		
		if(insecure){
			commands.add("-k");
		}

		if(keyFile){
			commands.add("--key "+ keyFileName);
		}
		
		if(customParm){
			commands.add(""+ customParms);
		}
		
		if(silent){
			commands.add("-s");
		}
		
		if(version){
			commands.add("-V"); 
		}
		
		if(user!= null && !user.equals("")){
			commands.add("-u " + this.user);
		}
		
		commands.add(this.url);
		return commands;
	}
	
	//TODO
//	public RequestBean convertCurlResultToRequestBean(TaskResult curlResult){
//		if(curlResult == null){
//			return null;
//		}
//		
//		RequestBean curlRequest = new RequestBean();
//		
//		//Check for verbose output
//		if(curlResult.getErrOut().isEmpty()){
//			
//		}
//		
//		curlRequest.setServerPayLoad(curlResult.getStdOut());
//		
//		
//		return null;
//	}
}
