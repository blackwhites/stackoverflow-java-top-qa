package task;

import java.util.ArrayList;

public class TCPDumpTask extends ProcessTask {

//	private boolean printEachPacket = false;
//	private boolean printASDOT=false;
//	private int bufferSize=0;
//	private int count =0;
//	private int fileSize=0;
//	private boolean dumpAsHumanReadable=false;
//	private boolean dumpAsCProgram=false;
//	private boolean dumpAsDecimal=false;
//	private boolean printLinkLevelHeader=false;
//	private boolean printIPNumerically=false;
//	private boolean useFileAsInput=false;
//	private String inputFile="";
//	private int rotateSeconds=0;
//	private boolean interfaces=false;
//	private String interfaceName="";
//	private boolean monitorMode=false;
//	private boolean immediateMode=false;
//	private String timeStampType="";
//	private String timeStampPrecision="";
//	private boolean dontVerifyCheckSum=false;
//	private boolean bufferSTDOUT =false;
//	private String module="";
//	private String secret="";
//	private String direction="";
//	private boolean quiteOutput=false;
//	private boolean printTimeDelta=false;
//	private boolean verbose=false;
//	private boolean writeToFile=false;
//	private String fileToWriteTo="";
//	private boolean printPacketData;
//	private String expression="";
//	private String customParameters="";
	
	@Override
	public String buildCommand() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateCommand() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<String> getCommands() {
		// TODO Auto-generated method stub
		return null;
	}

}
