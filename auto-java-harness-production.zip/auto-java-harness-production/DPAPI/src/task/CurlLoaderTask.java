package task;

import java.io.File;
import java.util.ArrayList;

public class CurlLoaderTask extends ProcessTask {

	private String configFile;
	
	@Override
	public String buildCommand() {
		return  "curl-loader -f " + this.configFile;	
	}

	@Override
	public boolean validateCommand() {
		if(this.configFile == null || this.configFile.equals("")){ return false;}
		
		return true;
	}
	
	public void setConfigFile(String path, String fileName){
		this.configFile = path + File.separatorChar + fileName;
	}
	
	public String getConfigFile(){return this.configFile;}
	
	
//	//Check all possible config file properties
//	private boolean generateConFigFile(String path, String fileName, String URL, int numberOfClients, int numberOfRequests, String userName, String password){
//		return false;
//	}

	@Override
	public ArrayList<String> getCommands() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
