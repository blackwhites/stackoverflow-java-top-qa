package task;

import java.io.File;
import java.util.ArrayList;

/**
 * 
 * @author nickCoble
 *
 */
public class SoapUITestRunnerTask extends ProcessTask {
	private String pathToSoapRunner = "";
	private String soapUIRunnerName = "";
	private String projectFile="";
	private String testCaseToRun="";//	c : The TestCase to run, used to narrow down the tests to run
	private String logFile="";
	private boolean exportAll=false;//	a : Turns on exporting of all test results, not only errors
//	A : Turns on exporting of all results using folders instead of long
	private ArrayList<String> sysProperty = new ArrayList<>();//	D : Sets system property with name=value
	private String domain="";//	d : The domain to use in any authentications, overrides any domain set for any TestRequests
	private String endPoint="";//	e : The endpoint to use when invoking test-requests, overrides the endpoint set in the project file
	private String environment="";//	E : Sets which environment to use (SoapUI Pro only)
	private String reportFormat ="";//	F : Sets the format of the report specified with the -R option, for Printable reports this is one of PDF, XLS, HTML, RTF, CSV, TXT, and XML. For Data Export this is either XML or CSV (SoapUI Pro only)
	private String rootFolder ="";//	f : Specifies the root folder to which test results should be exported (see below)
	private ArrayList<String> globalProperty = new ArrayList<>();//	G : Sets global property with name=value
	private boolean htmlCoverageReport =false;//	g : Sets the output to include Coverage HTML reports ( SoapUI Pro only )
	private String hostPortToUse="";//	h : The host:port to use when invoking test-requests, overrides only the host part of the endpoint set in the project file
	private boolean dontStopOnError=false;//	I : Do not stop if error occurs, ignore them: Execution does not stop if error occurs, but no detailed information about errors are stored to the log. (If you need full information about errors, do not use this option). 
	private boolean enableSoapUIComponents=false;//	i : Enables SoapUI UI-related components, required if you use the UISupport class for prompting or displaying information
	private boolean enableJUNITReport=false;//	j : Turns on exporting of JUnit-compatible reports, see below
	private boolean xmlTestRunLog=false;//	M : Creates a Test Run Log Report in XML format
	private int maxTestStepErrors=-1;//	m : Sets the maximum number of TestStep errors to save for each
	private boolean showReportInBrowser=false;//	o : Opens the generated report in a browser (SoapUI Pro only)
	private ArrayList<String> projectProperties = new ArrayList<>();//	P : Sets project property with name=value, e.g. -Pendpoint=Value1 -PsomeOtherProperty=value2
	private String testRequestPW="";//	p : The password to use in any authentications, overrides any password set for any TestRequests
	private boolean printSummary=false;//	r : Turns on printing of a small summary report (see below)
	private String testObjectToReportOn="";//	R : Selects which report to generate for the test objects executed, for example if running the entire project, this could specify the name of a test-suite-level report that would be generated for each TestSuite. The report is saved as specified with the -F option to the folder specified with the -f option. (SoapUI Pro only)
	private boolean saveProjectAfterRun=false;//	S : Sets to save the project file after tests have been run
	private String testSuiteToRun="";//	s : The TestSuite to run, used to narrow down the tests to run
	private String soapUISettingsFile="";//	t : Sets the soapui-settings.xml file to use, required if you have custom proxy, ssl, http, etc setting
	private String testRequestUserName="";//	u : The username to use in any authentications, overrides any username set for any TestRequests
	private String soapUISettingsFilePW="";//	v : Sets password for soapui-settings.xml file
	private String wssPasswordType="";//	w : Sets the WSS password type, either 'Text' or 'Digest'
	private String projectDecryptionPW="";//	x : Sets project password for decryption if project is encrypted


	@Override
	public String buildCommand() {
		if(!this.validateCommand()){return null;}
		StringBuilder command = new StringBuilder();
		command.append(this.pathToSoapRunner + "/" + this.soapUIRunnerName);
		
//		c : The TestCase to run, used to narrow down the tests to run
		if(this.testCaseToRun!= null && !this.testCaseToRun.equals("")){
			command.append(" -c " + this.testCaseToRun);
		}
		
//		a : Turns on exporting of all test results, not only errors
		if(this.exportAll){command.append(" -a");}

		////TODO	A : Turns on exporting of all results using folders instead of long

//		D : Sets system property with name=value
		if(this.sysProperty != null && !this.sysProperty.isEmpty()){
			command.append(" -D");
			for(String s: this.sysProperty){
				command.append(" " + s);
			}
			
		}
		
//		d : The domain to use in any authentications, overrides any domain set for any TestRequests
		if(this.domain!= null && !this.domain.isEmpty()){
			command.append(" -d " + this.domain);
		}
		
		//e : The endpoint to use when invoking test-requests, overrides the endpoint set in the project file
		if(this.endPoint!=null && !this.endPoint.isEmpty()){
			command.append(" -e " + this.endPoint);
		}
		
//		E : Sets which environment to use (SoapUI Pro only)
		if(this.environment != null && !this.environment.isEmpty()){
			command.append(" -E " + this.environment);
		}
		
//		R : Selects which report to generate for the test objects executed, for example if running the entire project, 
//		this could specify the name of a test-suite-level report that would be generated for each TestSuite. 
//		The report is saved as specified with the -F option to the folder specified with the -f option. (SoapUI Pro only)
		if(this.testObjectToReportOn != null && this.testObjectToReportOn.isEmpty()){
			command.append(" -R " + this.testObjectToReportOn);
	        //		F : Sets the format of the report specified with the -R option, 
			//for Printable reports this is one of PDF, XLS, HTML, RTF, CSV, TXT, and XML. 
			//For Data Export this is either XML or CSV (SoapUI Pro only)
			if(this.reportFormat != null && !this.reportFormat.isEmpty()){
				command.append(" -F " + this.reportFormat);
			}
		}
		
//		f : Specifies the root folder to which test results should be exported (see below)
		if(this.rootFolder!=null && !this.rootFolder.isEmpty()){
			command.append(" -f " + this.rootFolder);
		}
		
//		G : Sets global property with name=value
		if(this.globalProperty!=null && !this.globalProperty.isEmpty()){
			command.append(" -G");
			for(String s: this.globalProperty){
				command.append(" " + s);
			}
		}
		
//		g : Sets the output to include Coverage HTML reports ( SoapUI Pro only )
		if(this.htmlCoverageReport){
			command.append(" -g");
		}
		
//		h : The host:port to use when invoking test-requests, overrides only the host part of the endpoint set in the project file
		if(this.hostPortToUse!=null && !this.hostPortToUse.isEmpty()){
			command.append(" -h " + this.hostPortToUse);
		}
//		I : Do not stop if error occurs, ignore them: Execution does not stop if error occurs, but no detailed information about errors are stored to the log. 
		//(If you need full information about errors, do not use this option).
		if(this.dontStopOnError){
			command.append(" -I");
		}
		
//		i : Enables SoapUI UI-related components, required if you use the UISupport class for prompting or displaying information
		if(this.enableSoapUIComponents){
			command.append(" -i");
		}
		
//		j : Turns on exporting of JUnit-compatible reports, see below
		if(this.enableJUNITReport){
			command.append(" -j");
		}
		
		//	M : Creates a Test Run Log Report in XML format
		if(this.xmlTestRunLog){
			command.append(" -M");
		}
		
//		m : Sets the maximum number of TestStep errors to save for each
		if(this.maxTestStepErrors >-1){
			command.append(" -m " + this.maxTestStepErrors);
		}
		
//		o : Opens the generated report in a browser (SoapUI Pro only)
		if(this.showReportInBrowser){
			command.append(" -o");
		}
		
		
//		P : Sets project property with name=value, e.g. -Pendpoint=Value1 -PsomeOtherProperty=value2
		if(this.projectProperties != null && !this.projectProperties.isEmpty()){
			command.append(" -p");
			for(String s: this.projectProperties){
				command.append(" " + s);
			}
		}
		
//		p : The password to use in any authentications, overrides any password set for any TestRequests
		if(this.testRequestPW!=null && !this.testRequestPW.isEmpty()){
			command.append(" -p " + this.testRequestPW);
		}
		
//		r : Turns on printing of a small summary report (see below)
		if(this.printSummary){
			command.append(" -r");
		}
		
//		S : Sets to save the project file after tests have been run
		if(this.saveProjectAfterRun){
			command.append(" -S");
		}
		
//		s : The TestSuite to run, used to narrow down the tests to run
		if(this.testSuiteToRun!=null && !this.testSuiteToRun.isEmpty()){
			command.append(" -s " + this.testSuiteToRun);
		}
		
//		t : Sets the soapui-settings.xml file to use, required if you have custom proxy, ssl, http, etc setting
		if(this.soapUISettingsFile!=null && !this.soapUISettingsFile.isEmpty()){
			command.append(" -t " + this.soapUISettingsFile);
		}
		
//		//	u : The username to use in any authentications, overrides any username set for any TestRequests
		if(this.testRequestUserName!=null && !this.testRequestUserName.isEmpty()){
			command.append(" -u " + this.testRequestUserName);
		}
//	//	v : Sets password for soapui-settings.xml file
		if(this.soapUISettingsFilePW!=null && !this.soapUISettingsFilePW.isEmpty()){
			command.append(" -v " + this.soapUISettingsFilePW);
		}
//		private String wssPasswordType="";//	w : Sets the WSS password type, either 'Text' or 'Digest'
		if(this.wssPasswordType!=null && !this.wssPasswordType.isEmpty()){
			command.append(" -w " + this.wssPasswordType);
		}	
//		private String projectDecryptionPW="";//	x : Sets project password for decryption if project is encrypted
		if(this.projectDecryptionPW!=null && !this.projectDecryptionPW.isEmpty()){
			command.append(" -x " + this.projectDecryptionPW);
		}
		
		command.append(" " + this.projectFile);
		
		return null;
	}

	@Override
	public boolean validateCommand() {
		if(this.projectFile == null || this.projectFile.equals("")){
			return false;
		}
		File p = new File(this.projectFile);
		if(!p.exists()){
			return false;
		}
		return true;
	}

	/**
	 * @return the projectFile
	 */
	public String getProjectFile() {
		return projectFile;
	}

	/**
	 * @param projectFile the projectFile to set
	 */
	public void setProjectFile(String projectFile) {
		this.projectFile = projectFile;
	}

	

	/**
	 * @return the testCase
	 */
	public String getTestCase() {
		return testCaseToRun;
	}

	/**
	 * @param testCase the testCase to set
	 */
	public void setTestCase(String testCase) {
		this.testCaseToRun = testCase;
	}

	/**
	 * @return the logFile
	 */
	public String getLogFile() {
		return logFile;
	}

	/**
	 * @param logFile the logFile to set
	 */
	public void setLogFile(String logFile) {
		this.logFile = logFile;
	}

	/**
	 * @return the exportAll
	 */
	public boolean isExportAll() {
		return exportAll;
	}

	/**
	 * @param exportAll the exportAll to set
	 */
	public void setExportAll(boolean exportAll) {
		this.exportAll = exportAll;
	}

	/**
	 * @return the sysProperty
	 */
	public ArrayList<String> getSysProperty() {
		return sysProperty;
	}

	/**
	 * @param sysProperty the sysProperty to set
	 */
	public void addSysProperty(String name, String value) {
		this.sysProperty.add(name+"="+value);
	}

	public void clearSysProperty(){
		this.sysProperty.clear();
	}
	
	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * @param domain the domain to set
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * @return the endPoint
	 */
	public String getEndPoint() {
		return endPoint;
	}

	/**
	 * @param endPoint the endPoint to set
	 */
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the reportFormat
	 */
	public String getReportFormat() {
		return reportFormat;
	}

	/**
	 * @param reportFormat the reportFormat to set
	 */
	public void setReportFormat(String reportFormat) {
		this.reportFormat = reportFormat;
	}

	/**
	 * @return the rootFolder
	 */
	public String getRootFolder() {
		return rootFolder;
	}

	/**
	 * @param rootFolder the rootFolder to set
	 */
	public void setRootFolder(String rootFolder) {
		this.rootFolder = rootFolder;
	}

	/**
	 * @return the globalProperty
	 */
	public ArrayList<String> getGlobalProperty() {
		return globalProperty;
	}

	public void addGlobalProperty(String name, String value){
		this.globalProperty.add(name+"="+value);
	}
	
	/**
	 * @param globalProperty the globalProperty to set
	 */
	public void clearGlobalProperty() {
		this.globalProperty.clear();
	}

	/**
	 * @return the htmlCoverageReport
	 */
	public boolean isHtmlCoverageReport() {
		return htmlCoverageReport;
	}

	/**
	 * @param htmlCoverageReport the htmlCoverageReport to set
	 */
	public void setHtmlCoverageReport(boolean htmlCoverageReport) {
		this.htmlCoverageReport = htmlCoverageReport;
	}

	/**
	 * @return the hostPortToUse
	 */
	public String getHostPortToUse() {
		return hostPortToUse;
	}

	/**
	 * @param hostPortToUse the hostPortToUse to set
	 */
	public void setHostPortToUse(String hostPortToUse) {
		this.hostPortToUse = hostPortToUse;
	}

	/**
	 * @return the dontStopOnError
	 */
	public boolean isDontStopOnError() {
		return dontStopOnError;
	}

	/**
	 * @param dontStopOnError the dontStopOnError to set
	 */
	public void setDontStopOnError(boolean dontStopOnError) {
		this.dontStopOnError = dontStopOnError;
	}

	/**
	 * @return the enableSoapUIComponents
	 */
	public boolean isEnableSoapUIComponents() {
		return enableSoapUIComponents;
	}

	/**
	 * @param enableSoapUIComponents the enableSoapUIComponents to set
	 */
	public void setEnableSoapUIComponents(boolean enableSoapUIComponents) {
		this.enableSoapUIComponents = enableSoapUIComponents;
	}

	/**
	 * @return the enableJUNITReport
	 */
	public boolean isEnableJUNITReport() {
		return enableJUNITReport;
	}

	/**
	 * @param enableJUNITReport the enableJUNITReport to set
	 */
	public void setEnableJUNITReport(boolean enableJUNITReport) {
		this.enableJUNITReport = enableJUNITReport;
	}

	/**
	 * @return the xmlTestRunLog
	 */
	public boolean isXmlTestRunLog() {
		return xmlTestRunLog;
	}

	/**
	 * @param xmlTestRunLog the xmlTestRunLog to set
	 */
	public void setXmlTestRunLog(boolean xmlTestRunLog) {
		this.xmlTestRunLog = xmlTestRunLog;
	}

	/**
	 * @return the maxTestStepErrors
	 */
	public int getMaxTestStepErrors() {
		return maxTestStepErrors;
	}

	/**
	 * @param maxTestStepErrors the maxTestStepErrors to set
	 */
	public void setMaxTestStepErrors(int maxTestStepErrors) {
		this.maxTestStepErrors = maxTestStepErrors;
	}

	/**
	 * @return the showReportInBrowser
	 */
	public boolean isShowReportInBrowser() {
		return showReportInBrowser;
	}

	/**
	 * @param showReportInBrowser the showReportInBrowser to set
	 */
	public void setShowReportInBrowser(boolean showReportInBrowser) {
		this.showReportInBrowser = showReportInBrowser;
	}

	/**
	 * @return the projectProperties
	 */
	public ArrayList<String> getProjectProperties() {
		return projectProperties;
	}

	/**
	 * @param projectProperties the projectProperties to set
	 */
	public void clearProjectProperties() {
		this.projectProperties.clear();
	}
	
	public void addProjectProperty(String name, String value){
		this.projectProperties.add(name + "=" + value);
	}

	/**
	 * @return the testRequestPW
	 */
	public String getTestRequestPW() {
		return testRequestPW;
	}

	/**
	 * @param testRequestPW the testRequestPW to set
	 */
	public void setTestRequestPW(String testRequestPW) {
		this.testRequestPW = testRequestPW;
	}

	/**
	 * @return the printSummary
	 */
	public boolean isPrintSummary() {
		return printSummary;
	}

	/**
	 * @param printSummary the printSummary to set
	 */
	public void setPrintSummary(boolean printSummary) {
		this.printSummary = printSummary;
	}

	/**
	 * @return the testObjectToReportOn
	 */
	public String getTestObjectToReportOn() {
		return testObjectToReportOn;
	}

	/**
	 * @param testObjectToReportOn the testObjectToReportOn to set
	 */
	public void setTestObjectToReportOn(String testObjectToReportOn) {
		this.testObjectToReportOn = testObjectToReportOn;
	}

	/**
	 * @return the saveProjectAfterRun
	 */
	public boolean isSaveProjectAfterRun() {
		return saveProjectAfterRun;
	}

	/**
	 * @param saveProjectAfterRun the saveProjectAfterRun to set
	 */
	public void setSaveProjectAfterRun(boolean saveProjectAfterRun) {
		this.saveProjectAfterRun = saveProjectAfterRun;
	}

	/**
	 * @return the testSuiteToRun
	 */
	public String getTestSuiteToRun() {
		return testSuiteToRun;
	}

	/**
	 * @param testSuiteToRun the testSuiteToRun to set
	 */
	public void setTestSuiteToRun(String testSuiteToRun) {
		this.testSuiteToRun = testSuiteToRun;
	}

	/**
	 * @return the soapUISettingsFile
	 */
	public String getSoapUISettingsFile() {
		return soapUISettingsFile;
	}

	/**
	 * @param soapUISettingsFile the soapUISettingsFile to set
	 */
	public void setSoapUISettingsFile(String soapUISettingsFile) {
		this.soapUISettingsFile = soapUISettingsFile;
	}

	/**
	 * @return the testRequestUserName
	 */
	public String getTestRequestUserName() {
		return testRequestUserName;
	}

	/**
	 * @param testRequestUserName the testRequestUserName to set
	 */
	public void setTestRequestUserName(String testRequestUserName) {
		this.testRequestUserName = testRequestUserName;
	}

	/**
	 * @return the soapUISettingsFilePW
	 */
	public String getSoapUISettingsFilePW() {
		return soapUISettingsFilePW;
	}

	/**
	 * @param soapUISettingsFilePW the soapUISettingsFilePW to set
	 */
	public void setSoapUISettingsFilePW(String soapUISettingsFilePW) {
		this.soapUISettingsFilePW = soapUISettingsFilePW;
	}

	/**
	 * @return the wssPasswordType
	 */
	public String getWssPasswordType() {
		return wssPasswordType;
	}

	/**
	 * @param wssPasswordType the wssPasswordType to set
	 */
	public void setWssPasswordType(String wssPasswordType) {
		this.wssPasswordType = wssPasswordType;
	}

	/**
	 * @return the projectDecryptionPW
	 */
	public String getProjectDecryptionPW() {
		return projectDecryptionPW;
	}

	/**
	 * @param projectDecryptionPW the projectDecryptionPW to set
	 */
	public void setProjectDecryptionPW(String projectDecryptionPW) {
		this.projectDecryptionPW = projectDecryptionPW;
	}

	@Override
	public ArrayList<String> getCommands() {
		// TODO Auto-generated method stub
		return null;
	}


	
}
