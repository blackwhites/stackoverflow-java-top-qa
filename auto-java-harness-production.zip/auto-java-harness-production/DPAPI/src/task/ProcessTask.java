package task;

import java.util.ArrayList;

/**
 * Interface for process tasks
 * @author nickCoble
 *
 */
public abstract class ProcessTask {

	public abstract String buildCommand();
	public abstract ArrayList<String> getCommands();
	public abstract boolean validateCommand();
	
	
}
