package task;

public class TaskResult {

	private String stdOut = "";
	private String errOut = "";
	private int exitValue = -1;
	private String command = "";
	
	
	
	public TaskResult(String stdOut, String errOut, int exitValue, String command) {
		super();
		this.stdOut = stdOut;
		this.errOut = errOut;
		this.exitValue = exitValue;
		this.command = command;
	}
	
	public String getStdOut() {
		return stdOut;
	}
	
	public String getErrOut() {
		return errOut;
	}
	
	public int getExitValue() {
		return exitValue;
	}
	
	public String getCommand() {
		return command;
	}
	
	public String toString(){
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("[Command]:");
		stringBuilder.append(command);
		stringBuilder.append(System.lineSeparator());
		stringBuilder.append("[Error Stream]:");
		stringBuilder.append(this.errOut);
		stringBuilder.append(System.lineSeparator());
		stringBuilder.append("[Standard Stream]:");
		stringBuilder.append(this.stdOut);
		return stringBuilder.toString();
	}

}
