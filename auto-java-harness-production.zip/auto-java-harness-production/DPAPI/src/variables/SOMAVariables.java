package variables;

public class SOMAVariables {

	public static final String KEY_PAYLOAD_DOMAIN = "{domain}";
	public static final String KEY_PAYLOAD_OBJECT_NAME = "{name}";
	public static final String KEY_PAYLOAD_OBJECT_CLASS = "{class}";
	
	public static final String ELEMENT_TAG_OPEN_START = "<";
	public static final String ELEMENT_TAG_OPEN_END = "</";
	public static final String ELEMENT_TAG_CLOSE = ">";
	public static final String ELEMENT_TAG_CLOSE_EMPTY = "/>";
	
	public static final String SOMA_URI_Default = "/service/mgmt/2004";
	public static final String SOMA_URI_Current = "/service/mgmt/current";
	public static final String STANDARD_PORT = "5550";
	public final static String somaRequestHead = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"{domain}\">";
	public final static String somaRequestFooter = "</dp:request></env:Body></env:Envelope>";
	public final static String actionRequestHeader = "<dp:do-action>";
	public final static String actionRequestFooter = "</dp:do-action>";
	public final static String getConfigRequest = "<dp:get-config class=\"{class}\" name=\"{name}\"/>";
	public final static String deleteConfigRequest = "<dp:del-config><{class} name=\"{name}\"/></dp:del-config>";
	public final static String deleteConfigRequestHeader = "<dp:del-config>";
	public final static String deleteConfigRequestFooter = "</dp:del-config>";
	public final static String setConfigRequestHeader = "<dp:set-config>";
	public final static String setConfigRequestFooter = "</dp:set-config>";
	public final static String modifyConfigRequestHeader = "<dp:modify-config>";
	public final static String modifyConfigRequestFooter = "</dp:modify-config>";
	public final static String setFileRequestHeader = "<dp:set-file name=\"{name}\">";
	public final static String setFileRequestFooter = "</dp:set-file>";
	public final static String getFileRequest = "<dp:get-file name=\"{name}\"/>";
	public final static String setFileRequest = "<dp:set-file name=\"{name}\">{content}</dp:set-file>";
	public final static String getLogRequest = "<dp:get-log name=\"{name}\"/>";
	public final static String getStatusRequest = "<dp:get-status class=\"{class}\"/>";
	public final static String getFileStoreRequest = "<dp:get-filestore location=\"{location}\"/>";
	
	public static final String KEY_RESPONSE_FAULT = "env:Fault";
	public static final String KEY_RESPONSE = "dp:response";
	public static final String KEY_TIMESTAMP = "dp:timestamp";
	public static final String KEY_RESPONSE_RESULT = "dp:result";
	public static final String KEY_RESPONSE_FILE = "dp:file";
	public static final String KEY_RESPONSE_CONFIG = "dp:config";
	public static final String KEY_RESPONSE_STATUS = "dp:status";
	public static final String KEY_RESPONSE_ERROR_LOG = "error-log";
	public static final String KEY_RESPONSE_LOG_EVENT = "log-event";
	public static final String KEY_RESPONSE_IMPORT = "dp:import";
	public static final String KEY_RESPONSE_FILESTORE = "dp:filestore";

	public static final String RESPONSE_FILE_DOES_NOT_EXIST = "<dp:result>Cannot read the specified file</dp:result>";
	public static final String RESPONSE_EMPTY_CONFIG = "<dp:config/>";
	
	public static final String STATUS_CODE_GOOD = "200";
	public static final String STATUS_MESSAGE_GOOD = "Good";
	public static final String STATUS_CODE_INTERNAL_ERROR = "500";
	
		

	
}
