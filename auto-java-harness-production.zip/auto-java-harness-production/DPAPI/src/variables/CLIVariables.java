package variables;

import java.util.regex.Pattern;

public class CLIVariables {
	public static final int SSH_STANDARD_PORT = 22;
	public static final int TELNET_STANDARD_PORT = 23;

	//Variables for general ssh commands
	public static final String pauseApacheServers = "killall -s STOP httpd";
	public static final String resumeApacheServers = "killall -s CONT httpd";
	public static final String killApacheServers = "killall -9 httpd";
	public static final String startApacheServers = "apachectl start";
	public static final String stopApacheServers = "apachectl stop";

	//RegEx to verify login sequence
	public final static Pattern loginPrompt = Pattern.compile("login:");
	public final static Pattern passwordPrompt = Pattern.compile("Password:");
	public final static Pattern domainPrompt = Pattern.compile("Domain \\(\\? for all\\):");
	public final static Pattern welcomeMessage = Pattern.compile("[\\w\\W]*Welcome[\\w\\W]*to[\\w\\W]* DataPower[\\w\\W]*Serial number:[\\w\\W]*[#|>] ");
	public final static Pattern configurationMode = Pattern.compile("co[\\s]+Global configuration mode[\\w\\d\\s-\\.,:\\[\\]_]+\\(config\\)# ");

	//Regular expressions for ISAM prompts
	public final static Pattern pdadminMode = Pattern.compile("pdadmin[\\s]+pdadmin> ");
	public final static Pattern pdadminLogin = Pattern.compile("login[\\w\\d\\s-\\.,:_]+pdadmin [\\w\\d\\s-\\.,:_]+> ");
	public final static Pattern pdadminJunctionStatus = Pattern.compile("server task [\\w\\d\\s-\\.,:_/]+pdadmin [\\w\\d\\s-\\.,:_]+> ");

	//CLI enum's
	public final static String sshConnection = "secure-shell";
	
	//CLI Responses
	public final static String SUCCESS_EXPORT_DISPLAY = "Unable to display '.+' - file is not printable";
	public final static String SUCCESS_EXEC_FILE = "Executing script.+Finished script";
	public final static String SUCCESS_COPY_SFTP ="File copy success";
	public final static String SUCCESS_COPY_FILE = "File copy success \\([0-9]+ bytes copied\\)";
	public final static String SUCCESS_DELETE_FILE = "File deletion successful";
	public final static String SUCCESS_DELETE_DIR = "Directory '.+' successfully deleted.";
	public final static String SUCCESS_CREATE_DIR = "Directory '.+' successfully created.";
	public final static String SUCCESS_MOVE_FILE="\n((?!\n).)+\\(config\\)#";//Empty response, at check append this to command sent
	public final static String SUCCESS_SHOW_DIR ="[ ]+File Name[ ]+Last Modified[ ]+Size";
	public final static String SUCCESS_IMPORT_PACKAGE = "Import package is complete.";
	public final static String SUCCESS_DOMAIN_DELETED = "Domain deleted successfully.";
	public final static String SUCCESS_USER_DELETED ="User name deleted";
	public final static String SUCCESS_OBJECT_DELETED = "Configuration deleted.";
	public final static String SUCCESS_CONFIG_SAVED = "Configuration saved successfully.";
	public final static String SUCCESS_CONFIG_MODIFIED ="Modify .+ configuration";
	public final static String CONFIG_NEW = "New .+ configuration";
	
	public final static  String PERMISSION_DENIED_CREATE_DIR = "Cannot create directory '.*' - Permission denied";
	public final static  String PERMISSION_DENIED_SHOW_DIR = "Cannot list contents of directory";
	public final static  String PERMISSION_DENIED_DELETE_DIR ="Cannot delete '.+' - 'permission denied'";
	public final static  String PERMISSION_DENIED_DELETE_FILE ="[(No permission to delete)|(Unable to delete '.+' - permission denied)]";
	public final static  String PERMISSION_DENIED_SHOW_FILE ="Unable to display '.+' - permission denied";
	public final static  String PERMISSION_DENIED_COPY_FILE ="File '.+' permission denied";
	public final static  String PERMISSION_DENIED_MOVE_FILE ="No permission to move ";
	public final static  String PERMISSION_DENIED_EXEC_FILE ="Unable to exec .+ - permission denied";
	public final static  String PERMISSION_DENIED_SWITCH_DOMAIN ="Switching domain failed: Access Denied";

	public final static  String FAIL_CREATE_DIR = "Cannot create directory.*destination URL could not be opened";
	public final static  String FAIL_DELETE_DIR_NOT_FOUND = "Cannot delete .* directory not found";
	public final static  String FAIL_NO_FILE_DIR = "No such file or directory";
	public final static  String FAIL_SHOW = "[(Sorry, could not show that.)|(No such file or directory)]";
	public final static  String FAIL_SHOW_FILE = "File '.+' not found";
	public final static  String FAIL_SHOW_FILE_INVALID_DIR = "\\QUnable to display '\\E.+\\Q' - permission denied\\E";
	public final static  String FAIL_COPY_CANNOT_READ_SCP = "URL.+destination URL could not be opened:.+File copy failed";
	public final static  String FAIL_COPY_CANNOT_READ = "((File copy failed.+[source|destination] URL could not be opened)|(No such file or directory)|(The file could not be found))";
	public final static  String FAIL_CANNOT_EXEC ="Unable to exec.+source URL could not be opened";
	public final static  String FAIL_CAN_NOT_FIND_OBJECT = "Cannot find configuration object";
	public final static  String FAIL_UNKNOWN_COMMAND_MACRO = "Unknown command or macro";
	
	public final static  String REG_LOG_TIMESTAMP_DP_ZULU = "^[\\d]{8}T[\\d]+ ";
	public final static  String REG_LOG_TIMESTAMP_DP_SYSLOG = "^[\\w]{3,4} [\\w]{3} [\\d]{1,2} [\\d]{4} [\\d]{2}:[\\d]{2}:[\\d]{2} ";
	public final static  String REGEX_LOG_TIMESTAMP_DP_NUMERIC = "^[\\d]+ ";

	
}
