package variables;

import java.util.HashMap;
import java.util.regex.Pattern;


public class RMIVariables {
	
	//Standard Variables
	public final static String STANDARD_PORT ="5554";
	public final static String STANDARD_DOMAIN_ADMIN = "default";

	//Regular expression to represent base URL's
	public final static Pattern REGEX_BASE_URL = Pattern.compile("https://[\\w\\s-\\.]*:[0-9]*/");
	//Regular expression to represent Root URL's
	public final static Pattern REGEX_ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/([\\w\\s-]+/)*");
	//Regular expression to represent generic Object URL's
	public final static Pattern REGEX_OBJECT_CLASS_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/[\\w\\s-.]+/[\\w\\s-]+/[\\w\\s-.]+");
	public final static Pattern REGEX_OBJECT_NAME_URL= Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/[\\w\\s-.]+/[\\w\\s-]+/[\\w\\s-.]+/[\\w\\s-.]+");
	public final static Pattern REGEX_PROPERTY_URL= Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/[\\w\\s-]+/[\\w\\s-]+/[\\w\\s-]+/[\\w\\s-]+/[\\w\\s-]+");
	//Regular expressions to represent the different type of config URL's
	public final static Pattern REGEX_CONFIG_ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/config/[\\w\\s-.]+/(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_CONFIG_OBJECT_CLASS_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/config/[\\w\\s-.]+/[\\w\\s-.]+");
	public final static Pattern REGEX_CONFIG_OBJECT_NAME_URL= Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/config/[\\w\\s-.]+/[\\w\\s-.]+/[\\w\\s-.]+");
	public final static Pattern REGEX_CONFIG_PROPERTY_URL= Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/config/[\\w\\s-.]+/[\\w\\s-]+/[\\w\\s-.]+/[\\w\\s-.]+(/[\\w\\s-.]+)*");
	//Regular expression for Status URL's
	public final static Pattern REGEX_STATUS_ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/status/[\\w\\s-.]+/(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_STATUS_OBJECT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/status/[\\w\\s-.]+/[\\w\\s-.]+");
	//Regular expression for Type URL's
	public final static Pattern REGEX_TYPES_ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/types/[\\w\\s-.]+/(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_TYPES_OBJECT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/types/[\\w\\s-.]+/[\\w\\s-.]+");
	//Regular expression for metadata URL's
	public final static Pattern REGEX_METADATA__ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/metadata/[\\w\\s-.]+/(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_METADATA_OBJECT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/metadata/[\\w\\s-.]+/[\\w\\s-.]+");
	public final static Pattern REGEX_METADATA_DISCOVERY_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/metadata/");
	//Regular expression for actionqueue URL's
	public final static Pattern REGEX_ACTION_ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/actionqueue/[\\w\\s-.]+/(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_ACTION_OPERATIONS_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/actionqueue/[\\w\\s-.]+/operations/[\\w\\s-.]+");
	public final static Pattern REGEX_ACTION_OPERATIONS_POST_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/actionqueue/[\\w\\s-.]+");
	//Regular expression for filestore URL's
	public final static Pattern REGEX_FILESTORE_ROOT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/filestore/[\\w\\s-.]+/(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_FILESTORE_OBJECT_URL = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/filestore/[\\w\\s-.]+/[\\w\\s-.]+(/[\\w\\s-.]+)*");
	public final static Pattern REGEX_FILESTORE_Discovery = Pattern.compile("https://[\\w\\s-:\\.]+/mgmt/filestore/");

	//Strings that represent the different type of URI's
	public final static String URI_STATUS_OBJECT = "/mgmt/status/{domain}/{object}"; 
	public final static String URI_CONFIG_OBJECT = "/mgmt/config/{domain}/{object}"; 
	public final static String URI_FILESTORE = "/mgmt/filestore/{domain}"; 
	public final static String URI_FILESTORE_CLI_LOG = "/mgmt/filestore/"+ STANDARD_DOMAIN_ADMIN +"/logtemp/cli-log"; 
	public final static String URI_FILESTORE_DEFAULT_LOG = "/mgmt/filestore/"+ STANDARD_DOMAIN_ADMIN +"/logtemp/default-log"; 
	public final static String URI_FILESTORE_LOG_TARGET = "/mgmt/filestore/{domain}/logtemp/{target}"; 
	public final static String URI_METADATA_OBJECT = "/mgmt/metadata/{domain}/{object}"; 
	public final static String URI_METADATA_OPERATIONS_OBJECT = "/mgmt/metadata/{domain}/operations/{object}"; 
	public final static String URI_ACTION_QUEUE = "/mgmt/actionqueue/{domain}";
	public final static String URI_ACTION_OPERATIONS = "/mgmt/actionqueue/{domain}/operations";
	public final static String URI_ACTION_OBJECT_SCHEMA = "/mgmt/actionqueue/{domain}/operations/{object}";
	public final static String URI_ACTION_ASYNC_STATUS = "/mgmt/actionqueue/{domain}/pending/{id}";
	public final static String URI_ACTION_ASYNC_QUEUE = "/mgmt/actionqueue/{domain}/pending";
	public final static String URI_TYPE_OBJECT = "/mgmt/types/{domain}/{object}"; 
	public final static String URL_HOSTNAME_PORT = "https://{ip}:{port}";
	public final static String URI_ROOT_CONFIG = "/mgmt/config/";
	public final static String URI_ROOT_STATUS = "/mgmt/status/";
	public final static String URI_ROOT_METADATA = "/mgmt/metadata/";
	public final static String URI_ROOT_ACTIONS = "/mgmt/actionqueue/";
	public final static String URI_ROOT_TYPES = "/mgmt/types/";

	//Variables to represent HTTP Status CODES
	public final static String STATUS_CODE_OK = "200:OK";
	public final static String STATUS_CODE_CREATED = "201:Created";
	public final static String STATUS_CODE_BADREQUEST = "400:Bad Request";
	public final static String STATUS_CODE_UNAUTH = "401:Unauthorized:";
	public final static String STATUS_CODE_FORBIDDEN = "403:Forbidden";
	public final static String STATUS_CODE_NOT_FOUND = "404:Not Found";
	public final static String STATUS_CODE_METHOD_NOT_ALLOWED = "405:Method Not Allowed";
	public final static String STATUS_CODE_CONFLICT = "409:Conflict";
	public final static String STATUS_CODE_INTERNAL_ERROR = "500:Internal Server Error";
	public final static String STATUS_CODE_NOT_IMPLEMENTED = "501:Not Implemented";
	public final static String STATUS_CODE_NUMBER_OK = "200";
	public final static String STATUS_CODE_NUMBER_CREATED = "201";
	public final static String STATUS_CODE_NUMBER_ACCEPTED = "202";
	public final static String STATUS_CODE_NUMBER_BADREQUEST = "400";
	public final static String STATUS_CODE_NUMBER_UNAUTH = "401";
	public final static String STATUS_CODE_NUMBER_FORBIDDEN = "403";
	public final static String STATUS_CODE_NUMBER_NOT_FOUND = "404";
	public final static String STATUS_CODE_NUMBER_METHOD_NOT_ALLOWED = "405";
	public final static String STATUS_CODE_NUMBER_CONFLICT = "409";
	public final static String STATUS_CODE_NUMBER_INTERNAL_ERROR = "500";
	public final static String STATUS_CODE_NUMBER_NOT_IMPLEMENTED = "501";
	public final static String STATUS_CODE_MESSAGE_OK = "OK";
	public final static String STATUS_CODE_MESSAGE_CREATED = "Created";
	public final static String STATUS_CODE_MESSAGE_ACCEPTED = "Accepted";
	public final static String STATUS_CODE_MESSAGE_BADREQUEST = "Bad Request";
	public final static String STATUS_CODE_MESSAGE_UNAUTH = "Unauthorized:";
	public final static String STATUS_CODE_MESSAGE_FORBIDDEN = "Forbidden";
	public final static String STATUS_CODE_MESSAGE_NOT_FOUND = "Not Found";
	public final static String STATUS_CODE_MESSAGE_METHOD_NOT_ALLOWED = "Method Not Allowed";
	public final static String STATUS_CODE_MESSAGE_CONFLICT = "conflict";
	public final static String STATUS_CODE_MESSAGE_INTERNAL_ERROR = "Internal Server Error";
	public final static String STATUS_CODE_MESSAGE_NOT_IMPLEMENTED = "Not Implemented";

	//Variables for http headers
	public final static String HEADER_CONTENT_TYPE = "Content-Type:application/json";
	public final static String HEADER_CONNECTION = "Connection:Close";
	public final static String HEADER_TRANSFER_ENCODING = "Transfer-Encoding:chunked";
	public final static String HEADER_XBACKSIDE = "X-Backside-Transport:FAIL FAIL";
	public final static String HEADER_HTTP_PROTOCOL = "null:HTTP/1.1";
	public final static String HEADER_AUTHORIZATION = "Authorization:Basic {auth}";
	public final static String HEADER_AUTHORIZATION_KEY = "Authorization";
	public final static String HEADER_USER_AGENT_MOZILLA="User-Agent:Mozilla/5.0";
	public final static String HEADER_USER_AGENT_JAVA ="User-Agent:Java/1.7.0";
	
	//Variables for response bodies
	public final static String RESPONSE_UNKNOWN_MACRO = "\"error\":[\"*** Unknown command or macro\", {error message}]";
	public final static String RESPONSE_OPERATION_COMPLETED = "\"{operation}\": \"Operation completed.\"";
	public final static String RESPONSE_OPERATION_FAILED = "\"{operation}\" : \"Operation has failed, please review error log.\"";
	public final static String RESPONSE_OBJECT_UPDATED = "\"{objectName}\":\"Configuration has been updated.\"";
	public final static String RESPONSE_OBJECT_DELETED = "\"{objectName}\":\"Configuration has been deleted.\"";
	public final static String RESPONSE_OBJECT_CREATED = "\"{objectName}\":\"Configuration has been created.\"";
	public final static String RESPONSE_PROPERTY_UPDATED = "\"{propertyName}\":\"property has been updated.\"";
	public final static String RESPONSE_PROPERTY_DELETED = "\"{propertyName}\":\"property has been deleted.\"";
	public final static String RESPONSE_PROPERTY_NOT_SET = "\"result\":\"Property value has not been set.\"";
	public final static String RESPONSE_INVALID_JSON = "\"error\":[\"Invalid JSON.\"]";
	public final static String RESPONSE_NOT_FOUND = "\"error\":[\"Resource not found.\"]";
	public final static String RESPONSE_METHOD_NOT_ALLOWED = "\"error\":[\"Method not allowed.\"]";
	public final static String RESPONSE_FORBIDDEN = "\"error\":[\"Forbidden.\"]";
	public final static String RESPONSE_FORBIDDEN_DEFAULT_ONLY = "\"error\":[\"Request rejected because the singleton object resides only in the default domain.\"]";
	public final static String RESPONSE_ACCESS_DENIED = "\"error\":[\"Access denied.\"]";
	public final static String RESPONSE_DOMAIN_DOESNT_EXIST = "\"error\":[\"Domain does not exist.\"]";
	public final static String RESPONSE_URI_ELEMENTS_DONT_MATCH = "\"error\":[\"URI elements and JSON do not match.\"]";
	public final static String RESPONSE_RESOURCE_EXIST = "\"error\":[\"Resource already exists.\"]";
	public final static String RESPONSE_BAD_REQUEST = "\"error\":[\"Bad Request.\"]";
	public final static String RESPONSE_AUTHENTICATION_FAILED = "\"error\":[\"Authentication failure.\"]";
	public final static String RESPONSE_INVALID_URI = "\"error\":[\"Invalid URI.\"]";
	public final static String RESPONSE_DELETE_SINGLETON = "\"error\":[\"DELETE not allowed for singleton object resources.\"]";
	public final static String RESPONSE_POST_SINGLETON = "\"error\":[\"POST not allowed for singleton object resources.\"]";
	public final static String RESPONSE_INVALID_PROPERTY = "\"error\":[\"Bad Request.\",\"'{invalidPropertyValue}' is not valid\", \"{propertyName} {propertySet}\"]";
	public final static String RESPONSE_SINGLETON_NOT_FOUND = "\"error\":[\"Singleton object resource is not found.\"]";
	public final static String RESPONSE_INVALID_OBJECT_NAME = "\"error\":[\"Invalid object name.\"]";
	public final static String RESPONSE_FILE_CREATED = "\"{name}\": \"File has been created.\"";
	public final static String RESPONSE_FILE_MODIFIED ="\"{name}\": \"File has been updated.\"";		
	public final static String RESPONSE_DIRECTORY_CREATED ="\"{name}\": \"Directory has been created.\"";
	public final static String RESPONSE_INVALID_SCHEMA = "\"error\":[\"Schema validation failure. Please check the operation schema and default log for more information.\"]";
	
	//Variables for standard JSON keys
	public final static String KEY_DISCOVERY = "_links";
	public final static String KEY_SELF_URI = "self";
	public final static String KEY_URI = "href";
	public final static String KEY_DOC = "doc";
	public final static String KEY_LOCATION="location";
	public final static String KEY_STATUS = "status";
	public final static String KEY_STEP_PROGRESS = "step-progress";
	public final static String KEY_COMPLETE="complete";
	public final static String KEY_TOTAL="total";
	public final static String KEY_PROPERTY_VALUE = "value";
	public final static String KEY_ERROR = "error";
	public final static String KEY_RESULT = "result";
	public final static String KEY_FILE = "file";
	public final static String KEY_FILE_SIZE = "size";
	public final static String KEY_FILE_MODIFIED = "modified";
	public final static String KEY_FILESTORE="filestore";
	public final static String KEY_DIRECTORY = "directory";
	public final static String KEY_FILE_NAME = "name";
	public final static String KEY_OBJECT_INSTANCE_NAME = "name";
	public final static String KEY_FILE_CONTENT = "content";
	public final static String KEY_STATE = "state";
	public final static String KEY_EMBEDDED = "_embedded";
	public final static String KEY_DOMAIN = "{domain}";
	public final static String KEY_OBJECT_CLASS = "{object}";
	public final static String KEY_STATE_ADMIN = "adminstate";
	public final static String KEY_STATE_OP = "opstate";
	public final static String KEY_STATE_EVENT = "eventcode";
	public final static String KEY_STATE_ERROR = "errorcode";
	public final static String KEY_STATE_CONFIG = "configstate";
	public final static String KEY_DMREFERENCE_VALUE = "value";
	public final static String KEY_DMREFERENCE_CLASS = "class";
	

	
	//Index in array when doing a split operation
	public final static int INDEX_URI_REQUEST_TYPE = 2;
	public final static int INDEX_URI_FILE_DIRECTORY = 4;
	public final static int INDEX_URI_FILE_PATH = 5;
	
	//JSON Key index
	public final static int INDEX_RESPONSE_OBJECT = 1;
	public final static int INDEX_RESPONSE_LINKS = 0;
	
	//Length of the prefix for a objects class name.  IE Action=6 for ActionActiveUsers, Config=6 for ConfigDomain, and so on...
	public final static int LENGTH_OF_OBJECT_NAME_PREFIX = 6;
	 
	
	//Variables for RMI Payloads
	public final static String PAYLOAD_CREATE_FILE = "{\"file\":{\"name\":\"{name}\", \"content\":\"{content}\"}}";
	public final static String PAYLOAD_CREATE_DIRECTORY = "{\"directory\":{\"name\":\"{name}\"}}";
	public final static String PAYLOAD_BATCH_PUT = "{\"LoadConfiguration\":{{body}}}";
	public final static String PAYLOAD_BATCH_PUT_FILE = "\"file\":{\"path\":\"{path}\",\"content\":\"{content}\"}";
	
	public static final String EXPECTED_KEY_UNKNOWN_MACRO = "UNKNOWN_MACRO";
	public static final String EXPECTED_KEY_OPERATION_COMPLETED = "OPERATION_COMPLETED";
	public static final String EXPECTED_KEY_OPERATION_FAILED = "OPERATION_FAILED";
	public static final String EXPECTED_KEY_OBJECT_UPDATED = "OBJECT_UPDATED";
	public static final String EXPECTED_KEY_OBJECT_DELETED = "OBJECT_DELETED";
	public static final String EXPECTED_KEY_OBJECT_CREATED = "OBJECT_CREATED";
	public static final String EXPECTED_KEY_PROPERTY_UPDATED= "PROPERTY_UPDATED";
	public static final String EXPECTED_KEY_PROPERTY_DELETED = "PROPERTY_DELETED";
	public static final String EXPECTED_KEY_PROPERTY_NOT_SET = "PROPERTY_NOT_SET";
	public static final String EXPECTED_KEY_INVALID_JSON = "INVALID_JSON";
	public static final String EXPECTED_KEY_NOT_FOUND = "NOT_FOUND";
	public static final String EXPECTED_KEY_METHOD_NOT_ALLOWED = "METHOD_NOT_ALLOWED";
	public static final String EXPECTED_KEY_FORBIDDEN = "FORBIDDEN";
	public static final String EXPECTED_KEY_FORBIDDEN_DEFAULT_ONLY = "FORBIDDEN_DEFAULT_ONLY";
	public static final String EXPECTED_KEY_ACCESS_DENIED = "ACCESS_DENIED";
	public static final String EXPECTED_KEY_DOMAIN_DOESNT_EXIST = "DOMAIN_DOESNT_EXIST";
	public static final String EXPECTED_KEY_URI_ELEMENTS_DONT_MATCH = "URI_ELEMENTS_DONT_MATCH";
	public static final String EXPECTED_KEY_RESOURCE_EXIST = "RESOURCE_EXIST";
	public static final String EXPECTED_KEY_BAD_REQUEST = "BAD_REQUEST";
	public static final String EXPECTED_KEY_AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED";
	public static final String EXPECTED_KEY_INVALID_URI = "INVALID_URI";
	public static final String EXPECTED_KEY_DELETE_SINGLETON = "DELETE_SINGLETON";
	public static final String EXPECTED_KEY_POST_SINGLETON = "POST_SINGLETON";
	public static final String EXPECTED_KEY_INVALID_PROPERTY = "INVALID_PROPERTY";
	public static final String EXPECTED_KEY_SINGLETON_NOT_FOUND = "SINGLETON_NOT_FOUND";
	public static final String EXPECTED_KEY_INVALID_OBJECT_NAME = "INVALID_OBJECT_NAME";
	public static final String EXPECTED_KEY_FILE_CREATED = "FILE_CREATED";
	public static final String EXPECTED_KEY_FILE_MODIFIED = "FILE_MODIFIED";
	public static final String EXPECTED_KEY_DIRECTORY_CREATED = "DIRECTORY_CREATED";
	public static final String EXPECTED_KEY_INVALID_SCHEMA = "INVALID_SCHEMA";

	public static HashMap<String, String> get7200ExpectedResponses(){
		
		HashMap<String, String> expected = new HashMap<>();
		expected.put(EXPECTED_KEY_UNKNOWN_MACRO, "\"error\":[\"*** Unknown command or macro\", {error message}]");
		expected.put(EXPECTED_KEY_OPERATION_COMPLETED,"\"{operation}\": \"Operation completed.\"");
		expected.put(EXPECTED_KEY_OPERATION_FAILED,"\"{operation}\" : \"Operation has failed, please review error log.\"");
		expected.put(EXPECTED_KEY_OBJECT_UPDATED,"\"{objectName}\":\"Configuration has been updated.\"");
		expected.put(EXPECTED_KEY_OBJECT_DELETED,"\"{objectName}\":\"Configuration has been deleted.\"");
		expected.put(EXPECTED_KEY_OBJECT_CREATED,"\"{objectName}\":\"Configuration has been created.\"");
		expected.put(EXPECTED_KEY_PROPERTY_UPDATED,"\"{propertyName}\":\"property has been updated.\"");
		expected.put(EXPECTED_KEY_PROPERTY_DELETED,"\"{propertyName}\":\"property has been deleted.\"");
		expected.put(EXPECTED_KEY_PROPERTY_NOT_SET,"\"result\":\"Property value has not been set.\"");
		expected.put(EXPECTED_KEY_INVALID_JSON,"\"error\":[\"Invalid JSON.\"]");
		expected.put(EXPECTED_KEY_NOT_FOUND,"\"error\":[\"Resource not found.\"]");
		expected.put(EXPECTED_KEY_METHOD_NOT_ALLOWED,"\"error\":[\"Method not allowed.\"]");
		expected.put(EXPECTED_KEY_FORBIDDEN,"\"error\":[\"Forbidden.\"]");
		expected.put(EXPECTED_KEY_FORBIDDEN_DEFAULT_ONLY,"\"error\":[\"Request rejected because the singleton object resides only in the default domain.\"]");
		expected.put(EXPECTED_KEY_ACCESS_DENIED,"\"error\":[\"Access denied.\"]");
		expected.put(EXPECTED_KEY_DOMAIN_DOESNT_EXIST,"\"error\":[\"Domain does not exist.\"]");
		expected.put(EXPECTED_KEY_URI_ELEMENTS_DONT_MATCH,"\"error\":[\"URI elements and JSON do not match.\"]");
		expected.put(EXPECTED_KEY_RESOURCE_EXIST,"\"error\":[\"Resource already exists.\"]");
		expected.put(EXPECTED_KEY_BAD_REQUEST,"\"error\":[\"Bad Request.\"]");
		expected.put(EXPECTED_KEY_AUTHENTICATION_FAILED,"\"error\":[\"Authentication failure.\"]");
		expected.put(EXPECTED_KEY_INVALID_URI,"\"error\":[\"Invalid URI.\"]");
		expected.put(EXPECTED_KEY_DELETE_SINGLETON,"\"error\":[\"DELETE not allowed for singleton object resources.\"]");
		expected.put(EXPECTED_KEY_POST_SINGLETON,"\"error\":[\"POST not allowed for singleton object resources.\"]");
		expected.put(EXPECTED_KEY_INVALID_PROPERTY,"\"error\":[\"Bad Request.\",\"'{invalidPropertyValue}' is not valid\", \"{propertyName} {propertySet}\"]");
		expected.put(EXPECTED_KEY_SINGLETON_NOT_FOUND,"\"error\":[\"Singleton object resource is not found.\"]");
		expected.put(EXPECTED_KEY_INVALID_OBJECT_NAME,"\"error\":[\"Invalid object name.\"]");
		expected.put(EXPECTED_KEY_FILE_CREATED,"\"{name}\": \"File has been created.\"");
		expected.put(EXPECTED_KEY_FILE_MODIFIED,"\"{name}\": \"File has been updated.\"");		
		expected.put(EXPECTED_KEY_DIRECTORY_CREATED,"\"{name}\": \"Directory has been created.\"");
		expected.put(EXPECTED_KEY_INVALID_SCHEMA,"\"error\":[\"Schema validation failure. Please check the operation schema and default log for more information.\"]");
		return expected;
	}
	
	public static HashMap<String, String> get7500ExpectedResponses(){
		HashMap<String, String> expected = RMIVariables.get7200ExpectedResponses();

		return expected;
	}
	
	/**
	 * List of singleton config objects.  Format: {objectName}/{instanceName}
	 */
	public static final String[] config_Singletons = new String[]{
			"AuditLog/AuditLog-Settings",
			"CertMonitor/Certificate Monitor",
			"ILMTAgent/ILMT-agent",
			"B2BPersistence/B2BPersistence",
			"ErrorReportSettings/Error-Report",
			"CRLFetch/CRL-Settings",
			"InteropService/IOP-Settings",
			"DNSNameService/Main-Name-Service",
			"DomainAvailability/default",
			"MgmtInterface/XMLMgmt-Settings",
			"NFSClientSettings/NFS-Client-Settings",
			"NetworkSettings/Network-Settings",
			"NTPService/NTP Service",
			"TimeSettings/Time",
			"NFSDynamicMounts/default",
			"ODR/ODRInstance",
			"Statistics/default",
			"SNMPSettings/SNMP-Settings",
			"SSHService/SSH Service",
			"SystemSettings/System-Settings",
			"Throttler/Throttler",
			"WebServicesAgent/default",
			"SQLRuntimeSettings/SQLRuntimeSettings",
			"RBMSettings/RBM-Settings",
			"SecureBackupMode/SecureBackupModeInstance",
			"WebGUI/WebGUI-Settings",
			"RestMgmtInterface/RestMgmt-Settings",
			"ZHybridTargetControlService/ZHybridTargetControlService",
			"xmltrace/File-Capture-Settings",
			"RADIUSSettings/RADIUS-Settings",
			"WebB2BViewer/WebB2BViewer-Settings",
			"QuotaEnforcementServer/QuotaEnforcementServer"
	};
	
	public String get_Singleton_InstanceName(String configClassName){
		for(String s: config_Singletons){
			if(s.split("/")[0].equals(configClassName)){
				return s.split("/")[1];
			}
		}
		
		return null;
	}
	
	public boolean is_Singleton(String configClassName){
		for(String s: config_Singletons){
			if(s.split("/")[0].equals(configClassName)){
				return true;
			}
		}
		return false;
	}




}
