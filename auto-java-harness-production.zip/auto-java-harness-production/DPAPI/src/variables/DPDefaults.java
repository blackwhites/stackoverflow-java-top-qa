package variables;

public class DPDefaults {
	
	final public static String DOMAIN = "\"Domain\":{\"name\":\"{name}\", ...";
}
