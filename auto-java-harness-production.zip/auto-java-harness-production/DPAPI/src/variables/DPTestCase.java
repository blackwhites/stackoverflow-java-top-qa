package variables;

import tools.DPLogger;

public abstract class DPTestCase {
	public abstract boolean setUpTest();
	public abstract boolean cleanUpTest();
	public abstract boolean runTestCases();
	public abstract boolean resetTestEnvironment();
	protected DPLogger log;

}