package variables;

public class DPVariables {
	public final static int DTAF_EXIT_FAIL = 1;
	public final static int DTAF_EXIT_PASS = 0;
	public final static String adminDomain= "default";
	public final static String adminUser= "admin";
	public final static String sqaPW= "jan0111j";
	public final static String REGEX_URL = "_^(?:(?:https?|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?!10(?:\\.\\d{1,3}){3})(?!127(?:\\.\\d{1,3}){3})(?!169\\.254(?:\\.\\d{1,3}){2})(?!192\\.168(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\x{00a1}-\\x{ffff}0-9]+-?)*[a-z\\x{00a1}-\\x{ffff}0-9]+)(?:\\.(?:[a-z\\x{00a1}-\\x{ffff}0-9]+-?)*[a-z\\x{00a1}-\\x{ffff}0-9]+)*(?:\\.(?:[a-z\\x{00a1}-\\x{ffff}]{2,})))(?::\\d{2,5})?(?:/[^\\s]*)?$_iuS";
	
	public final static  String REGEX_LOG_TIMESTAMP_DP_ZULU = "^[\\d]{8}T[\\d]+";
	public final static  String REGEX_LOG_TIMESTAMP_DP_SYSLOG = "^[\\w]{3,4} [\\w]{3} [\\d]{1,2} [\\d]{4} [\\d]{2}:[\\d]{2}:[\\d]{2}";
	public final static  String REGEX_LOG_TIMESTAMP_DP_NUMERIC = "^[\\d]+ ";
	public final static  String REGEX_LOG_TIMESTAMPS_DP = "(^[\\d]{8}T[\\d]+)|(^[\\w]{3,4} [\\w]{3} [\\d]{1,2} [\\d]{4} [\\d]{2}:[\\d]{2}:[\\d]{2})|(^[\\d]+)";


}
