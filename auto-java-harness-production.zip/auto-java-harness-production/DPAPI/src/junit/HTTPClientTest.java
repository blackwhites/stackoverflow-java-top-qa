package junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import tools.HTTPClient;

public class HTTPClientTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		HTTPClient tester = new HTTPClient();
//		tester.setHostName(hostName);
//		tester.setPort(port);
		tester.addURIParameter("testParm", "adfafd");
		tester.setUrl("http://httpbin.org/get" + tester.buildURLParametersString());
		tester.addBasicAuthenticationHeader("asdf","Asdf");
		tester.setReadTimeOut(300000);
		tester.setConnectionTimeOut(600000);
		long startRequest = System.currentTimeMillis();
//		tester.sendPost("blah");
		tester.sendGet();
		System.out.println("Response Time: " + ((System.currentTimeMillis()-startRequest)/1000) + " seconds");
//		tester.sendPost("{\"name\":\"adf\"}");
		
		System.out.println(tester.getLastResponse().toString());
		
		
		System.out.println("------------------------===========================----------------------------");
		tester.setUrl("http://httpbin.org/post" + tester.buildURLParametersString());
		tester.sendPost("Hello World");
		System.out.println("Response Time: " + ((System.currentTimeMillis()-startRequest)/1000) + " seconds");
//		tester.sendPost("{\"name\":\"adf\"}");
		
		System.out.println(tester.getLastResponse().toString());
		
//		"<SOAP:Envelope xmlns:SOAP=\"http://schemas.xmlsoap.org/soap/envelope/\"><SOAP:Body><echo xmlns=\"http://www.example.org\">this is a test of echoing</echo></SOAP:Body></SOAP:Envelope>"
//		RequestBean tmp = tester.sendGet();
//		System.out.println(tmp.getServerPayload());
//		System.out.println(tmp.getClientHeaders());
//		System.out.println(tmp.getServerHeaders());
//
//		System.out.println(tmp.getResponseContentLength());
//		System.out.println(tmp.getRequestContentLength());
//
//		System.out.println(tmp.getResponseContentType());


	}

}
