package junit;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import beans.RequestBean;
import tools.HTTPSClient;
import tools.URLClient;

public class testHTTPSClientLanguages {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HTTPSClient httpsClient = new HTTPSClient();
		
		httpsClient.setUrl("https://dpvirt4a.dp.rtp.raleigh.ibm.com:5554/mgmt/config/blaadfh/XMLManager");
		httpsClient.addBasicAuthenticationHeader("admin", "jan0111j");
		httpsClient.addHeader(URLClient.HEADER_KEY_AcceptLang, "ja");
		
		RequestBean response = httpsClient.sendGet();
		System.out.println(response.getServerHeaders().toString());
		String tmp = response.getServerPayload().substring(response.getServerPayload().indexOf("["), response.getServerPayload().indexOf("]")-1);
		System.out.println(tmp);
		tmp = tmp.substring(tmp.indexOf("\"")+1);
		System.out.println(tmp);
		String japanesString=null;
		try {
			japanesString = new String(tmp.getBytes("UTF8"), StandardCharsets.UTF_8);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(japanesString);

		System.out.println(response.getServerPayload());

	}

}
