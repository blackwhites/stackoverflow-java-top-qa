package junit;

public class HelpTestObject {

	protected int[] integer = new int[2];
	protected char[] character = new char[2];
	protected double[] doubleNumber = new double[2];

	public HelpTestObject(){
		integer[0]=1;
		integer[1]=2;
		character[0]='a';
		character[1]='B';
		doubleNumber[0]=1.1;
		doubleNumber[1]=-1.2;
	}
	
	public void setChar(char[] c){this.character=c;}

}
