package junit;

import org.junit.Test;

import tools.TelnetClient;

public class TelnetClientTest {

	@Test
	public void test() {
		try {
			TelnetClient tester = new TelnetClient("dpvirt4a.dp.rtp.raleigh.ibm.com", 22, "admin", "jan0111j");
			System.out.println(tester.startSession());
			System.out.println(tester.loginDP("nick_BlueMix"));
			System.out.println(tester.getLastResponse());
			System.out.println(tester.getResponse("show version"));
			System.out.println(tester.endSession());
			System.out.println(tester.errorMessage);


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
