package junit;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.xml.transform.TransformerException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import beans.RequestBean;
import tools.Converter;
import tools.SOMAClient;
import tools.SOMAObjectFactory;
import tools.SOMAPayloadConstructor;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigHTTPSourceProtocolHandler;
import xmlManagement.ConfigQuotaEnforcementServer;
import xmlManagement.ConfigXMLManager;
import xmlManagement.DmAdminState;
import xmlManagement.DmDocCachePolicy;
import xmlManagement.DmReference;
import xmlManagement.DmToggle;
import xmlManagement.File;
import xmlManagement.Response;
import xmlManagement.StatusActiveUsers;
import xmlManagement.StatusEnum;


public class SOMAObjectFactoryTest {
	SOMAClient s = new SOMAClient("dpvirt4c.dp.rtp.raleigh.ibm.com", 5550, "admin", "jan0111j", "default");
	SOMAObjectFactory tester = new SOMAObjectFactory();
	SOMAPayloadConstructor payload = new SOMAPayloadConstructor();
	Converter converter = new Converter();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testImportResponse() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, TransformerException{
		String response = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:response xmlns:dp=\"http://www.datapower.com/schemas/management\"><dp:timestamp>2016-07-29T15:27:30-04:00</dp:timestamp><dp:import><import-results domain=\"APIMgmt_AD0E58E268\"><export-details><description>Exported Configuration</description><user>admin</user><domain>APIMgmt_AD9821122E</domain><comment/><product-id>5725</product-id><product>IDG</product><display-product>IDG</display-product><model>IBM DataPower Gateway</model><display-model>IBM DataPower Gateway</display-model><device-name>169.54.149.161:9090</device-name><serial-number>0000000</serial-number><firmware-version>IDG.7.5.0.0</firmware-version><display-firmware-version>IDG.7.5.0.0</display-firmware-version><firmware-build>274960</firmware-build><firmware-timestamp>2016/03/11 15:09:45</firmware-timestamp><current-date>2016-04-15</current-date><current-time>11:24:41 EDT</current-time><reset-date>2016-04-15</reset-date><reset-time>06:39:50 EDT</reset-time><login-message/><custom-ui-file/></export-details><imported-files><file name=\"cert:///cryptoboy-client.keytab\" src=\"cert/cryptoboy-client.keytab\" status=\"missing-key\" overwrite=\"on\"/><file name=\"cert:///cryptoboy-server.keytab\" src=\"cert/cryptoboy-server.keytab\" status=\"missing-key\" overwrite=\"on\"/><file name=\"webgui:///clixform.xsl\" src=\"dp-aux/clixform.xsl\" status=\"internal\" overwrite=\"on\"/><file name=\"webgui:///SchemaUtil.xsl\" src=\"dp-aux/SchemaUtil.xsl\" status=\"internal\" overwrite=\"on\"/><file name=\"webgui:///management.xsl\" src=\"dp-aux/management.xsl\" status=\"internal\" overwrite=\"on\"/><file name=\"webgui:///map-dmz.xsl\" src=\"dp-aux/map-dmz.xsl\" status=\"internal\" overwrite=\"on\"/><file name=\"webgui:///drMgmt.xml\" src=\"dp-aux/drMgmt.xml\" status=\"internal\" overwrite=\"on\"/><file name=\"webgui:///basetypes.xml\" src=\"dp-aux/basetypes.xml\" status=\"internal\" overwrite=\"on\"/></imported-files><imported-objects><object class=\"CryptoKerberosKeytab\" name=\"cryptoboy-client\" status=\"new\" import-debug=\"false\" overwrite=\"off\"/><object class=\"CryptoKerberosKeytab\" name=\"cryptoboy-server\" status=\"new\" import-debug=\"false\" overwrite=\"off\"/></imported-objects><file-copy-log/><exec-script-results><cfg-result class=\"CryptoKerberosKeytab\" name=\"cryptoboy-client\" status=\"SUCCESS\"/><cfg-result class=\"CryptoKerberosKeytab\" name=\"cryptoboy-server\" status=\"SUCCESS\"/></exec-script-results></import-results></dp:import></dp:response></env:Body></env:Envelope>";
		Response r = tester.getResponseObject(converter.stringToXML(response));


		for(Element e: r.getImport().getAny()){
			System.out.println(e.toString());
			System.out.println(e.getNodeName());
			System.out.println(e.getNodeValue());
			NodeList ss = e.getChildNodes();
			for(int i=0;i<ss.getLength();i++){
				System.out.println(ss.item(i).getNodeName());
			}
		}
		
		System.out.println(converter.xmlToString(converter.stringToXML(response)));
	}
	
	@Test
	public void test_LoadResponse_DoAction(){
		try{
			RequestBean response = s.action.saveConfig();
			
//			System.out.println(response.getServerPayload());
//			System.out.println(response.getClientPayload());
			assertNull(response.getResponseObject().getFault());
			assertNotNull(response.getResponseObject().getResult());
			assertEquals("OK",(String)response.getResponseObject().getResult().getContent().get(0));

			//System.out.println(response.getResponseObject().getResult().getContent());

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test
	public void test_LoadResposne_Status(){
		try{
			RequestBean response = s.status.getStatus(StatusEnum.ACTIVE_USERS.value());
//			//System.out.println(response.getServerPayload());
			AnyStatusElement s = response.getResponseObject().getStatus();
			assertTrue(s.getStatusObjects().size()>0);
			for(Object status: s.getStatusObjects()){
				//System.out.println(((StatusActiveUsers)status).getName());
				//System.out.println(((StatusActiveUsers)status).getAddress());
				//System.out.println(((StatusActiveUsers)status).getConnection());
				//System.out.println(((StatusActiveUsers)status).getDomain());
				//System.out.println(((StatusActiveUsers)status).getLogin());
				//System.out.println("-------------------------------------");
				
				assertNotNull(((StatusActiveUsers)status).getName());
				assertNotNull(((StatusActiveUsers)status).getAddress());
				assertNotNull(((StatusActiveUsers)status).getConnection());
				assertNotNull(((StatusActiveUsers)status).getDomain());
				assertNotNull(((StatusActiveUsers)status).getLogin());

			}
		}catch(Exception e){
			
		}
	}
	
	@Test
	public void test_LoadResponse_GetFile(){
		try{
			s.setBufferSize(10000000);
			RequestBean response = s.filestore.getFile("logtemp", "default-log");
			System.out.println(response.getServerPayload());
			System.err.println("here");
			ArrayList<File> files = response.getResponseObject().getFile();
			
			assertTrue(files.size()>0);
			assertEquals("logtemp:/default-log", files.get(0).getName());
//			assertTrue(new String(files.get(0).getValue()).length()>0);
			System.out.println("here");

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test
	public void test_LoadResponse_Config() {
		ConfigXMLManager d = new ConfigXMLManager();
		d.setName("default");
		try {
			RequestBean response = s.configRequest.getConfigObject(d);
System.out.println(response.getServerPayload());
			assertNotNull(response.getResponseAsXML());
			ConfigXMLManager  d2 = (ConfigXMLManager) tester.loadConfigObject(response.getResponseAsXML(), new ConfigXMLManager());
////System.out.println(d2.getName());
			assertEquals("default", d2.getName());
			assertEquals("enabled", d2.getMAdminState().value());
			assertEquals("Default XML-Manager", d2.getUserSummary());
			assertEquals("default", d2.getUserAgent().getValue());
			assertEquals("HTTPUserAgent", d2.getUserAgent().getClazz());

			String emptyConfigResponse ="<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:response xmlns:dp=\"http://www.datapower.com/schemas/management\"><dp:timestamp>2016-04-14T11:57:10-04:00</dp:timestamp><dp:config/></dp:response></env:Body></env:Envelope>";
			assertNull("Verify Empty Config object in response payload returns null.", tester.loadConfigObject(converter.stringToXML(emptyConfigResponse), new ConfigXMLManager()));
			assertTrue("Verify Empty Config object in response payload returns null.", tester.getResponseObject(converter.stringToXML(emptyConfigResponse)).getConfig().getConfigObjects().size()==0);

		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException
				| ClassNotFoundException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void test_LoadConfig_QE(){
		ConfigQuotaEnforcementServer qe = new ConfigQuotaEnforcementServer();
		qe.setName("QuotaEnforcementServer");
		RequestBean response;
		try {
			response = s.configRequest.getConfigObject(qe);
			System.out.println(response.getServerPayload());
			assertNotNull(response.getResponseAsXML());
			assertNotNull("",response.getResponseObject());
			ConfigQuotaEnforcementServer  d2 = (ConfigQuotaEnforcementServer) tester.loadConfigObject(response.getResponseAsXML(), new ConfigQuotaEnforcementServer());
			
			assertNotNull(d2);
			assertEquals("QuotaEnforcementServer", qe.getName());
			assertEquals(qe.getName(),d2.getName());
			assertEquals("enabled", qe.getMAdminState().value());
			
			
			String emptyConfigResponse ="<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:response xmlns:dp=\"http://www.datapower.com/schemas/management\"><dp:timestamp>2016-04-14T11:57:10-04:00</dp:timestamp><dp:config/></dp:response></env:Body></env:Envelope>";
			assertNull("Verify Empty Config object in response payload returns null.", tester.loadConfigObject(converter.stringToXML(emptyConfigResponse), new ConfigQuotaEnforcementServer()));
			assertTrue("Verify Empty Config object in response payload returns null.", tester.getResponseObject(converter.stringToXML(emptyConfigResponse)).getConfig().getConfigObjects().size()==0);

		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException | ClassNotFoundException
				| InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@Test
	public void test_loadConfigObject_Complex_Arrays() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException{
		ConfigXMLManager getObject = new ConfigXMLManager();
		getObject.setName("TestLoading");
		getObject.setCacheSize("3245");
		getObject.setMAdminState(DmAdminState.ENABLED);
			DmReference compileOptionsPolicy = new DmReference();
			compileOptionsPolicy.setValue("reference1");
		getObject.setCompileOptionsPolicy(compileOptionsPolicy);
			DmDocCachePolicy e = new DmDocCachePolicy();
			e.setCacheBackendResponses(DmToggle.OFF);
			Long t= new Long(1231);
			e.setTTL(t);
			e.setXC10Grid(compileOptionsPolicy);
		getObject.getDocCachePolicy().add(e);
			e.setXC10Grid(null);
			e.setCacheBackendResponses(DmToggle.ON);
		getObject.getDocCachePolicy().add(e);
////System.out.println((payload.buildObjectPayload(getObject)));
		ConfigXMLManager loadObject = new ConfigXMLManager();
		ConfigXMLManager testEquals = (ConfigXMLManager) tester.loadObjectProperties(converter.stringToXML(payload.buildObjectPayload(getObject)).getFirstChild(),loadObject);
		
		
////System.out.println(loadObject.getName());
////System.out.println(loadObject.getCacheSize());
////System.out.println(loadObject.getMAdminState().value());
////System.out.println(loadObject.getCompileOptionsPolicy().getValue());
////System.out.println(loadObject.getDocCachePolicy().get(0));
////System.out.println(loadObject.getDocCachePolicy().get(1));
//
////System.out.println("========================================================================================================");
//
////System.out.println(testEquals.getName());
////System.out.println(testEquals.getCacheSize());
////System.out.println(testEquals.getMAdminState().value());
////System.out.println(testEquals.getCompileOptionsPolicy().getValue());
////System.out.println(testEquals.getDocCachePolicy().get(0));
////System.out.println(testEquals.getDocCachePolicy().get(1));

assertEquals(loadObject.getName(), testEquals.getName());
assertEquals(loadObject.getCacheSize(), testEquals.getCacheSize());
assertEquals(loadObject.getMAdminState(), testEquals.getMAdminState());
assertEquals(loadObject.getCompileOptionsPolicy(), testEquals.getCompileOptionsPolicy());
assertEquals(loadObject.getDocCachePolicy().get(0), testEquals.getDocCachePolicy().get(0));
assertEquals(loadObject.getDocCachePolicy().get(1), testEquals.getDocCachePolicy().get(1));
	
	}
	
	@Test
	public void testXMLTagsWithSpecialCharacters() throws Exception {
		AnyConfigElement configList = new AnyConfigElement();
		
		// -- start setup --
		ConfigHTTPSourceProtocolHandler sourceProtocolHandlerObject = new ConfigHTTPSourceProtocolHandler();
		sourceProtocolHandlerObject.setName("blorgh");
		sourceProtocolHandlerObject.setLocalPort("88");
		configList.getConfigObjects().add(sourceProtocolHandlerObject);
		
		ConfigHTTPSourceProtocolHandler loadObject = new ConfigHTTPSourceProtocolHandler();


		//simply get configuration for the handler
		ConfigHTTPSourceProtocolHandler equalObject = (ConfigHTTPSourceProtocolHandler) tester.loadObjectProperties(converter.stringToXML(payload.buildObjectPayload(sourceProtocolHandlerObject)).getFirstChild(),loadObject);
		
		assertTrue(equalObject.getLocalPort().equals(sourceProtocolHandlerObject.getLocalPort()));
		assertTrue(loadObject.getName().equals(sourceProtocolHandlerObject.getName()));

	}

	@Test
	public void testLoadFATTestPayload(){
		String somaFileName = "20160411_1734_fat-soma_9006_x52.log";
		String pathToSomaFile = "C:\\Users\\IBM_ADMIN\\Documents\\FAT\\Logs\\7500_final\\logx52";
		SOMAClient somaClient = new SOMAClient("",1,"","","");

try {
			
		Response response = somaClient.factory.getResponseObject(somaClient.converter.stringToXML(somaClient.readFile(pathToSomaFile, somaFileName).replace("\n\n", "")));
		StatusActiveUsers status = (StatusActiveUsers) response.getStatus().getStatusObjects().get(0);
//		System.out.println(status.getAutoNegCapabilities().getEth1000BaseTHD());
//		System.out.println(status.getAutoNegCapabilities().getEth1000BaseTFD());
//		System.out.println(status.getAutoNegCapabilities().getEth1000BaseXHD());

		System.out.println(status.getSession());
		System.out.println(status.getName());
		System.out.println(status.getConnection());
		System.out.println(	status.getAddress());
		System.out.println(status.getLogin());
		System.out.println(status.getDomain());
		
//			System.out.println(rmi.base64encoder.stringToXML(rmi.readFile(pathToSomaFile, somaFileName)).getFirstChild().toString());
		} catch (Exception e) {
			System.out.println("Exception thrown while trying to validate SOMA file.");
			e.printStackTrace();
			
		}
	}

}
