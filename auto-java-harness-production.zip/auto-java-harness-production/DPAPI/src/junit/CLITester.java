package junit;


import tools.SSHClient;

public class CLITester {
	public static volatile boolean closeSession =false;
	public static volatile int threadsLoggedIn=0;
	public static volatile Object pivot=new Object();

	public static void main(String args[]){
		CLITester tester = new CLITester();
		tester.run();
		
	}
	
	public void run(){
		try {
//			SSHClient dpCLI = new SSHClient("dpblade95.dp.rtp.raleigh.ibm.com", 22, "root", "jan0111j");
//			dpCLI.logIn();
//			System.out.println(dpCLI.getResponse());
//			System.out.println("=====================================================asdfasdf");
//			System.out.println(dpCLI.getResponse("ls -lts"));

			
//			Converter c = new Converter();
			SSHClient dpCLI = new SSHClient("dp508.dp.rtp.raleigh.ibm.com",22,"admin", "Jan0111j#Jan0111j", 1024);
//			dpCLI.loginDP("default");
			System.out.println(dpCLI.loginDP("default"));
			System.out.println(dpCLI.getResponse("show version"));

			System.out.println(dpCLI.errorMessage);
//			dpCLI.getResponse();
//			System.out.println(dpCLI.getHostKey());
//			System.out.println(dpCLI.getServerSSHVersion());
//			System.out.println(dpCLI.sendCommand("cd ~/sqa/dtaf2/testsuites/commonCriteria/suite_fcs_tls1_2/configs"));
//			System.out.println(dpCLI.getResponse("openssl s_server -accept 10602 -tls1_2 -cipher RC4:MD5:DES:AESGCM:EXP:aNULL:eNULL:DHE -cert ~/p4/main/sqa/dtaf2/testsuites/commonCriteria/suite_fcs_tls1_2/configs/alice.pem", 5000));
//			System.out.println(dpCLI.getResponse(10000));

//			System.out.println(dpCLI.sendCommand(3));
			
//			
//			System.out.println(dpCLI.getResponse());

//			System.out.println(dpCLI.trimResponse());

			dpCLI.endSession();
			System.out.println(dpCLI.getExitStatus());
//			dpCLI.establishSession();
//			System.out.println("getresponse");
//
//			dpCLI.getResponse(1000);
//			System.out.println("logging in");

//			dpCLI.loginDP("default");
//			System.out.println("what");
//
//			System.out.println(dpCLI.getLastResponse());
//			System.out.println("Here00");

			dpCLI.endSession();
			
			
			
//			ArrayList<CLIShell> clis = new ArrayList<>();
//			ArrayList<CLIThreads> clis2 = new ArrayList<>();
//		System.out.println("initializing");
//		CLIShell dpssh = new CLIShell("dp511.dp.rtp.raleigh.ibm.com",22,"admin", "Jan0111j#jan0111j");
//		System.out.println(dpssh.establishSession());
//		System.out.println(dpssh.loginDP("default"));
//		
//		CLIShell linux = new CLIShell("9.42.102.6", 22, "clchurch", "tina0323");
//		System.out.println(linux.establishSession());
////		System.out.println(linux.getResponse());
//		System.out.println(linux.getResponse("cd /home/clchurch/p4/clchurch-dpblade92-main/sqa/dtaf2/testsuites/commonCriteria/suite_cc_crypto/testcases/testdata",10000));
//		System.out.println("*****************************");
//		System.out.println(linux.sendCommand("perl /home/clchurch/p4/clchurch-dpblade92-main/sqa/dtaf2/testsuites/commonCriteria/suite_cc_crypto/testcases/testdata/cc_ssh_concurrent.pl 9.42.102.224 admin Jan0111j#jan0111j xi52"));
//			String tmp="";
//			Thread.sleep(25000);
//			
////			while(!tmp.contains("Thread 100 started")){
////				tmp += linux.getResponse(1000).replace("ERROR: Connection Timed Out(1000).\n", "");
//				System.out.println(tmp);
//			}
//System.out.println("*****************************");
//
//			System.out.println(dpssh.getResponse("show tcp;show users", 30000));
//			tmp += linux.getResponse(125000);
//System.out.println(tmp);
//			System.out.println(linux.getGroups(tmp, "successful\\.\\n").size());
//			linux.closeSession();
//			dpssh.closeSession();
//			CLI
//			System.out.println(dpCLI.getLastResponse());
//			System.out.println(dpCLI.checkResponseContains(dpCLI.getLastResponse(), "established: " + (this.numberOfSSHConnections+1)));
//			System.out.println(dpCLI.getGroups(dpCLI.getLastResponse(), "admin").size());
//
//			CLIShell dpCLI = new CLIShell("dp511.dp.rtp.raleigh.ibm.com",22,"admin", "Jan0111j#jan0111j", 1024);
//			dpCLI.establishSession();
//			dpCLI.loginDP("default");
//			for(int i=0;i<100;i++){
//				clis2.add(new CLIThreads("dp511.dp.rtp.raleigh.ibm.com",22,"admin", "Jan0111j#jan0111j", 1024));
//				clis2.get(i).start();
//				System.out.println(i + " Started");
////			clis.add(new CLIShell("dp511.dp.rtp.raleigh.ibm.com",22,"admin", "Jan0111j#jan0111j", 1024));
////			clis.get(i).establishSession();
////			System.out.println(clis.get(i).loginDP("default") + " " + i);
//			
//			}
//			while(this.threadsLoggedIn!=100){}
//			System.out.println(dpCLI.getResponse("show tcp;show users"));
//			this.closeSession= true;
//		
//		//while(waitForIt){Thread.sleep(4000);}
//		
//		for(int i=0;i<100;i++){
//			clis.get(i).closeSession();
//		}
////			System.out.println(cli.establishSession());
//////			System.out.println(cli.getResponse(5));
////			try{
////				cli.loginDP("default");
////				
////			}catch(Exception e){
////				e.printStackTrace();
////			}
////			System.out.println(cli.getLastResponse());
////			System.out.println(cli.getResponse("show users", 30000));
////
////			
//////			linux.sendCommand(command);
//			
//////			var =dpTarget.getResponse("show tcp-table;show users", 10000);
//////			linux.getResponse(120000);
////			
////			
//////			
//////				
//
//			for(int i=0;i<1030;i++){
//				if(!cli.establishSession()){
//					System.out.println("Stopped Accepting at:" + i);
//					break;
//				}
//			}
//			
//			for(int i=0;i<1030;i++){
//				cli.establishSession();
//			}
//			
//			//1028
//			System.out.println(cli.getResponse());
//			System.out.println(cli.getResponse("ps -A | grep httpd"));
//			ArrayList<String> tmpArray = cli.getGroups(cli.getLastResponse(), " [\\d]+ ");
//			System.out.println(tmpArray);
			
//			System.out.println(cli.getResponse("cd /home/cncoble/curl-loader-0.56"));
//			System.out.println(cli.sendCommand("curl-loader -f ./ISAMTraffic.conf"));
//			System.out.println(0x03);
//
//			Thread.sleep(5000);
//			System.out.println(cli.sendCommand2(0x03));
//			System.out.println(cli.getResponse());
//			
//			ArrayList<String> tmp = cli.getGroups("This is a <adf>234</adf> a  fslf.  \n  asdfjasfjpngggppa  124 m. a <adf>42</adf><adf>fadsf</adf>", "<adf>[\\d]+</adf>");
//			for(int i = 0; i<tmp.size();i++){
//				System.out.println(tmp.get(i));
//			}
//			System.out.println(cli.closeSession());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
//	public class CLIThreads extends Thread{
//		SSHClient cli;
//		public CLIThreads(String hostName, int port, String userName, String password, int bufferSize){
//			try {
//				this.cli = new SSHClient(hostName, port, userName, password, bufferSize);
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		
//		
//		public void run(){
//			this.cli.establishSession();
//			this.cli.loginDP("default");
//System.out.println(this.getName() + " has logged in.");
//			synchronized(CLITester.pivot){
//				CLITester.threadsLoggedIn++;
//			}
//			while(CLITester.closeSession != true){try {
//				Thread.sleep(5000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}}
//			this.cli.closeSession();
//System.out.println(this.getName() + " has closed");
//
//		}
//	}
	
}
