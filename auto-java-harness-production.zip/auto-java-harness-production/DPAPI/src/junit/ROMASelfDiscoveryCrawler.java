package junit;
//package ROMAControllers;
//
//import java.io.ByteArrayInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.Set;
//import javax.json.Json;
//import javax.json.JsonArray;
//import javax.json.JsonObject;
//import javax.json.JsonReader;
//import TOOLS.HTTPSRequester;
//import Beans.URIBean;
//import DataObjects.GlobalVariables;
//
//public class ROMASelfDiscoveryCrawler implements Runnable{
//
//	//Shared Variables
//	public static String userName="";
//	public static String pw="";
//	public static volatile boolean keepGoing = true;
//	public static volatile int workingCount = 0;
//	public static String domain;
//	public static volatile LinkedList<URIBean> requestQueue = new LinkedList<>();
//	public static volatile LinkedList<URIBean> responseQueue = new LinkedList<>();
//	public static volatile ArrayList<String> uris = new ArrayList<>();
//	private static String okStatus = "200";
//	
//	//Local Variables
//	private ArrayList<String> childrenURLS = new ArrayList<String>();
//	private HTTPSRequester requester;
//	private URIBean uriBean;
//	private JsonObject jsonObject;
//	private String url;
//	private String parentURI;
////	private int uriCount = 0;
//	private LinkedList<URIBean> childrenList = new LinkedList<>();
//
//	public ROMASelfDiscoveryCrawler(String domain, String userName, String pw){
//		ROMASelfDiscoveryCrawler.domain = domain;
//		ROMASelfDiscoveryCrawler.userName= userName;
//		ROMASelfDiscoveryCrawler.pw =  pw;
//		this.parentURI = "";
//		this.url = "";
//		this.requester = new HTTPSRequester();
//		this.requester.getHeaders().add("User-Agent:Mozilla/5.0");
//		this.requester.getHeaders().add("Content-Type:application/json");
//		this.requester.getHeaders().add("Connection:close");
//		this.requester.getHeaders().add("Authorization:" + this.requester.encodeAuthentication(userName, pw));
//	}
//
//	public void run(){
//
//		while(ROMASelfDiscoveryCrawler.keepGoing){
//			if(workingCount==0 && requestQueue.size() == 0 ){
//				ROMASelfDiscoveryCrawler.keepGoing = false;
//				break;
//			}else{
//				
//				synchronized(requestQueue){
//					incWorkingThreads();
//					this.uriBean = requestQueue.poll();
//				}
//				
//				if(this.uriBean != null ){
////if(!this.uriBean.getUrl().contains("/docs/") && !this.uriBean.getUrl().contains("/filestore/") ){
//					this.childrenURLS.clear();
////					this.uriCount++;
//					
//					//Store parent URI
//					this.parentURI = this.uriBean.getParentURI();
//					this.url = this.uriBean.getUrl();
//					this.requester.setURL(this.url);
//					URIBean tempBean = this.walkURITree();
//					
//					//Add this URI Bean to static list
//					synchronized(responseQueue){
//						responseQueue.add(tempBean);
//					}
////}
//					decWorkingThreads();
//				}else{
//					decWorkingThreads();
//					try {
//						Thread.sleep(10000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//				}
//			}
//		}
//		
////		System.out.println(this.toString() + " Finished: Crawled " + uriCount + " URI's.");
//	}
//
//	private URIBean walkURITree(){
//
//		//Get get URIBean containing JSON Payload from URI 
//		this.uriBean = this.requester.sendGETRequest();
//
//		//Store parent URI in bean
//		this.uriBean.setParentURI(this.parentURI);
//		
//		String options = this.requester.sendOPTIONRequest().getPayload();
//		InputStream	stream = new ByteArrayInputStream(options.getBytes());
//		JsonReader reader =  Json.createReader(stream);
//		
//		try{
//			JsonObject tempOptions = reader.readObject();
//			if(tempOptions.containsKey("Allow")){
//				this.uriBean.setHttpOptions(tempOptions.getString("Allow"));
//			}else{
//				this.uriBean.setHttpOptions(tempOptions.toString());
//			}
//		}catch(Exception e){
//			this.uriBean.setJSONError("OPTIONS ERROR:" + e.getMessage()+ ": -- " + options);
//		}finally{
//			try {
//				stream.close();
//			} catch (IOException e) {
//				System.out.println("Closing JSON Stream Error: ");
//				e.printStackTrace();
//			}
//		}	
//
//		//Convert Payload to JSON Object
//		stream = new ByteArrayInputStream(this.uriBean.getPayload().getBytes());
//
//		//Get JSON Payload
//		reader =  Json.createReader(stream);
//		try{
//			this.jsonObject = reader.readObject();
//		}catch(Exception e){
//			this.uriBean.setJSONError("GET ERROR: " + e.getMessage());
//			return this.uriBean;
//		}finally{
//			try {
//				stream.close();
//			} catch (IOException e) {
//				System.out.println("Closing JSON Stream Error: ");
//				e.printStackTrace();
//			}
//		}
//		
//		if(GlobalVariables.regfilestoreDiscovery.matcher(this.url).matches()){
//			this.childrenURLS.add( "https://"+this.requester.getURLIPPORT()+"/mgmt/filestore/"+ domain +"");
//		}else if(!GlobalVariables.regmetaDiscoveryURL.matcher(this.url).matches()){
//			//Get Children URL Links From JSON object
//			this.getChildrenURLS(this.jsonObject);
//		}
//		
//		//add children URI's to list
//		for(int k=0;k<this.getChildrenURLList().size();k++){
//				URIBean tempBean = new URIBean();
//				tempBean.setUrl(this.getChildrenURLList().get(k));
//				tempBean.setParentURI(this.url);
//				this.childrenList.add(tempBean);
//		}
//		
//		//Get metadata URL's and put in Queue
//		if(GlobalVariables.regConfigObjectsURL.matcher(this.url).matches()){
//			URIBean tempBean = new URIBean();
//			tempBean.setUrl(this.url.replace("/config/", "/metadata/"));
//			tempBean.setParentURI(this.url);
//			this.childrenList.add(tempBean);
//		}else if(GlobalVariables.regStatusObjectsURL.matcher(this.url).matches()){
//			URIBean tempBean = new URIBean();
//			tempBean.setUrl(this.url.replace("/status/", "/metadata/"));
//			tempBean.setParentURI(this.url);
//			this.childrenList.add(tempBean);
//		}else if(GlobalVariables.regmetaObjectsURL.matcher(this.url).matches()){
//			getMetaPropertyURIS(this.jsonObject);
//		}
//		
//		synchronized(uris){
//			URIBean tempBean;
//			while((tempBean = this.childrenList.poll())!=null){
//				if(!uris.contains(tempBean.getUrl())){
//					requestQueue.add(tempBean);
//					uris.add(tempBean.getUrl());
//				}
//			}
//		}
//		
//		return this.uriBean;
//	}
//	
//	public void getMetaPropertyURIS(JsonObject js){
//		try{
//			if(js.containsKey("object")){
//			js = js.getJsonObject("object");
//				if(js.containsKey("properties")){
//					js= js.getJsonObject("properties");
//					if(js.containsKey("property")){
//						if(js.get("property").toString().charAt(0)=='['){
//							JsonArray ja = js.getJsonArray("property");
//							String tempURL = this.url + "/";
//							for(int i=0;i<ja.size();i++){
//								if(!this.childrenURLS.contains(tempURL + ja.getJsonObject(i).getString("name"))){
//									this.childrenURLS.add(tempURL + ja.getJsonObject(i).getString("name"));
//								}
//							}
//						}else{
//							if(!this.childrenURLS.contains(this.url +"/" + js.getJsonObject("property").getString("name"))){
//								this.childrenURLS.add(this.url +"/" + js.getJsonObject("property").getString("name"));
//							}
//						}
//					}
//				}
//			}
//		}catch(Exception e){
//			System.out.println("Error creating MetaProperty URI's at uri " + this.url);
//			System.out.println("Parent: " + this.parentURI);
//		}
//	}
//	
//	public void getChildrenURLS(JsonObject js){
//		String self = "https://"+this.requester.getURLIPPORT();
//		
//		//Get links
//		findChildren(js, self);
//		
//		//Find property URI's
//		if( (this.url.contains("/config/")||this.url.contains("/status/")) && this.uriBean.getStatus().equals(okStatus) && !js.containsKey("result")){
//
//			//Check for config or status object
//			if(GlobalVariables.regConfigObjectNameURL.matcher(this.url).matches()){
//				//Split the URL to extract object name
//				String temp[] = this.url.split("/");
//				//Get Properties
//				this.extractObjectProperties(js.getJsonObject(temp[temp.length-2]), self, "/config/");
//			}else if(GlobalVariables.regStatusObjectsURL.matcher(this.url).matches()){
//				//Split the URL to extract object name
//				String temp[] = this.url.split("/");
//				//Check for array or single object
//				JsonObject js2;
//				if(js.toString().charAt(js.toString().indexOf("\""+temp[temp.length-1]+"\":")+(temp[temp.length-1].length()+3))=='['){
//					JsonArray ja = js.getJsonArray(temp[temp.length-1]);
//					js2= ja.getJsonObject(0);
//				}else{
//					js2 = js.getJsonObject(temp[temp.length-1]);
//				}
//				
//				//Get object properties
//				this.extractObjectProperties(js2, self, "/status/");
//			}
//		}
//	}
//
//	public static synchronized void incWorkingThreads(){
//		workingCount++;
//	}
//	
//	public static synchronized void decWorkingThreads(){
//		workingCount--;
//	}
//	
//	/**
//	 * Recursively looks for URLS embedded within the JSON Object and adds them to the URL List
//	 * @param js
//	 */
//	public void extractObjectProperties(JsonObject js, String self, String objectType){
//		try{
//			Set<String> keys = js.keySet();
//			for(int i=0;i< keys.size();i++){
//				if(!keys.toArray()[i].toString().equals("name")){
//					String tempURL = this.url + "/"+keys.toArray()[i].toString();
//					if(!this.childrenURLS.contains(tempURL)){
//						this.childrenURLS.add(tempURL);
//					}
//				}
////				//Build metadata URI's from properties
//////				if(!keys.toArray()[i].toString().equals("mAdminState")&&!keys.toArray()[i].toString().equals("name")){
////				if(objectType.equals("/status/")){
////					if(!this.childrenURLS.contains(tempURL.replace(objectType, "/metadata/"))){
////						this.childrenURLS.add(tempURL.replace(objectType, "/metadata/"));
////					}
////				}else if(objectType.equals("/config/")){
////					String metaURL = (this.url.substring(0, this.url.lastIndexOf('/')+1)+keys.toArray()[i].toString()).replace(objectType, "/metadata/");
////						if(!this.childrenURLS.contains(metaURL)){
////						this.childrenURLS.add(metaURL);
////					}
////				}
////				}
//			}
//			
//		}catch(Exception e){
//			System.out.println("Error extracting properties.  Stopping test.");
//			System.out.println(this.url);
//			System.out.println(this.parentURI);
//			System.out.println(this.uriBean.getPayload());
//			System.exit(-1);
//		}
//	}
//	
//	/**
//	 * Recursively looks for URLS embedded within the JSON Object and adds them to the URL List
//	 * @param js
//	 */
//	public void findChildren(JsonObject js, String self){
//		Set<String> keys = js.keySet();
//		for(int i=0;i<keys.size();i++){
//			
//			if(keys.toArray()[i].toString().equals(GlobalVariables.uriKey)){
//				String tempURL =  js.getString(GlobalVariables.uriKey);
//				if(tempURL.contains(self)){
//					System.out.println(this.url);
//				}else{
//					tempURL = self.concat(tempURL);
//				}
//				tempURL = tempURL.replace("{domain}", ROMASelfDiscoveryCrawler.domain);
//				if(!this.childrenURLS.contains(tempURL)|| !(tempURL.contains("/{operation}"))){
//					this.childrenURLS.add(tempURL);
//				}
//			}else if(js.get(keys.toArray()[i].toString()).toString().charAt(0)=='{'&& js.get(keys.toArray()[i].toString()).toString().contains(GlobalVariables.uriKey)){
//				findChildren(js.getJsonObject(keys.toArray()[i].toString()), self);
//			}else if(js.get(keys.toArray()[i].toString()).toString().charAt(0)=='['){
//				JsonArray ja = js.getJsonArray(keys.toArray()[i].toString());
//				if(js.toString().contains(GlobalVariables.uriKey)){
//					for(int j=0;j<ja.size();j++){
//						if(ja.get(j).toString().charAt(0)=='{'&& ja.get(j).toString().contains(GlobalVariables.uriKey)) {
//							findChildren((JsonObject) ja.get(j), self);
//						}
//					}
//				}
//			}
//		}	
//	}
//	
//	public void setUserName(String userName){
//		ROMASelfDiscoveryCrawler.userName = userName;
//	}
//	
//	public String getUserName(){
//		return ROMASelfDiscoveryCrawler.userName;
//	}
//	
//	public void setPassword(String pw){
//		ROMASelfDiscoveryCrawler.pw=pw;
//	}
//	
//	public String getPassword(){
//		return ROMASelfDiscoveryCrawler.pw;
//	}
//	
//	public ArrayList<String> getChildrenURLList(){
//		return this.childrenURLS;
//	}
//
//	public URIBean getURIBean(){
//		return this.uriBean;
//	}
//
//	/**
//	 * @return the url
//	 */
//	public String getUrl() {
//		return url;
//	}
//
//	/**
//	 * @param url the url to set
//	 */
//	public void setUrl(String url) {
//		this.url = url;
//	}
//
//	/**
//	 * @return the requester
//	 */
//	public HTTPSRequester getRequester() {
//		return requester;
//	}
//
//	/**
//	 * @param requester the requester to set
//	 */
//	public void setRequester(HTTPSRequester requester) {
//		this.requester = requester;
//	}
//
//}
