package junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import org.junit.Test;

import beans.RequestBean;
import tools.Converter;
import tools.RMIClient;
import tools.RMIObjectFactory;
import tools.RMIPayloadConstructor;
import xmlManagement.ActionRMIExport;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.ConfigDomain;
import xmlManagement.ConfigHTTPSourceProtocolHandler;
import xmlManagement.ConfigLogTarget;
import xmlManagement.ConfigXMLManager;
import xmlManagement.DmAdminState;
import xmlManagement.DmAsyncActionStatus;
import xmlManagement.DmDocCachePolicy;
import xmlManagement.DmLogEvent;
import xmlManagement.DmLogLevel;
import xmlManagement.DmRMIAsyncActionStatusState;
import xmlManagement.DmRMIExportFormat;
import xmlManagement.DmRMIExportObject;
import xmlManagement.DmReference;
import xmlManagement.DmToggle;
import xmlManagement.File;
import xmlManagement.RMIAsyncActionResult;
import xmlManagement.Response;
import xmlManagement.StatusActiveUsers;
import xmlManagement.StatusEnum;

public class ROMAObjectFactoryTest {

	String dpTarget = "dpvirt4c.dp.rtp.raleigh.ibm.com";
	int rmiPort = 5554;
	String userName = "admin";
	String password = "jan0111j";
	String domain = "default";
	RMIClient client = new RMIClient(dpTarget, rmiPort, userName, password, domain);;
	RMIObjectFactory tester = new RMIObjectFactory();
	RMIPayloadConstructor payload = new RMIPayloadConstructor();
	Converter converter = new Converter();
	
	@Test
	public void test_LoadResponse_DoAction(){
		try{
			RequestBean response =this.client.action.saveConfig();
			
			System.out.println(response.getServerPayload());
//			System.out.println(response.getClientPayload());
//			assertNull(response.getResponseObject().getFault());
			assertNotNull(response.getResponseObject().getResult());
			assertEquals("Operation completed.",(String)response.getResponseObject().getResult().getContent().get(0));

			//System.out.println(response.getResponseObject().getResult().getContent());

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test
	public void test_AsyncAction(){
		RequestBean response =this.client.batchPut.sendBatchRequestCustom("{\"LoadConfiguration\":{}}");
		System.out.println(response.getServerPayload());
		
		//Print action response
		System.out.println(((RMIAsyncActionResult)response.getResponseObject().getResult().getContent().get(0)).getResult());
		System.out.println(((RMIAsyncActionResult)response.getResponseObject().getResult().getContent().get(0)).getLocation());
		
		
		//Get and print action status
		response = this.client.action.getAsyncActionStatusFromURI(((RMIAsyncActionResult)response.getResponseObject().getResult().getContent().get(0)).getLocation());
		System.out.println(response.getServerPayload());
		System.out.println(response.getUrl());
		DmAsyncActionStatus actionStatus = ((DmAsyncActionStatus)response.getResponseObject().getResult().getContent().get(0));
		System.out.println(actionStatus.getResult());
		System.out.println(actionStatus.getStatus());
		if(actionStatus.getStepProgress() != null){
			System.out.println(actionStatus.getStepProgress().getComplete());
			System.out.println(actionStatus.getStepProgress().getTotal());
		}
	}
	
	@Test
	public void test_AsyncActionExport() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ActionRMIExport export = new ActionRMIExport();
		DmRMIExportObject user= new DmRMIExportObject();
		user.setClazz("HTTPUserAgent");
		user.setName("default");
		export.setAllFiles(DmToggle.OFF);
		export.setPersisted(DmToggle.ON);
		export.setIncludeInternalFiles(DmToggle.OFF);
		export.setUserComment("b");
		export.getObject().add(user);
		export.setFormat(DmRMIExportFormat.ZIP);
		RequestBean response = client.action.action(export);
System.out.println(response.getClientPayload());
System.out.println(response.getServerPayload());
		String statusURI = ((RMIAsyncActionResult)response.getResponseObject().getResult().getContent().get(0)).getLocation();
		while(true){
			response = client.action.getAsyncActionStatusFromURI(statusURI);
System.out.println(response.getServerPayload());
			if(((DmAsyncActionStatus)response.getResponseObject().getResult().getContent().get(0)).getStatus().equals(DmRMIAsyncActionStatusState.COMPLETED)){
				break;
			}
		}
		
		System.out.println(response.getResponseObject().getFile().get(0).getValueAsString());
	}
	
	@Test
	public void test_LoadResposne_Status(){
		try{
			RequestBean response =this.client.status.getStatus(StatusEnum.ACTIVE_USERS.value());
//			//System.out.println(response.getServerPayload());
			AnyStatusElement s = response.getResponseObject().getStatus();
			assertTrue(s.getStatusObjects().size()>0);
			
			for(Object status: s.getStatusObjects()){
				//System.out.println(((StatusActiveUsers)status).getName());
				//System.out.println(((StatusActiveUsers)status).getAddress());
				//System.out.println(((StatusActiveUsers)status).getConnection());
				//System.out.println(((StatusActiveUsers)status).getDomain());
				//System.out.println(((StatusActiveUsers)status).getLogin());
				
				assertNotNull(((StatusActiveUsers)status).getName());
				assertNotNull(((StatusActiveUsers)status).getAddress());
				assertNotNull(((StatusActiveUsers)status).getConnection());
				assertNotNull(((StatusActiveUsers)status).getDomain());
				assertNotNull(((StatusActiveUsers)status).getLogin());
				//System.out.println("-------------------------------------");

			}
		}catch(Exception e){
			
		}
	}
	
	@Test
	public void test_LoadResponse_GetFile(){
		try{
			
			RequestBean response =this.client.filestore.getFile("logtemp", "default-log");
//			//System.out.println(response.getServerPayload());
			ArrayList<File> files = response.getResponseObject().getFile();
			
			assertTrue(files.size()>0);
			assertEquals("logtemp:/default-log", files.get(0).getName());
			assertTrue(new String(files.get(0).getValue()).length()>0);

		}catch(Exception e){
			e.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void test_LoadResponse_Config() {
		ConfigXMLManager d = new ConfigXMLManager();
		d.setName("default");
		try {
			RequestBean response =this.client.configRequest.getConfigObject(d);
//System.out.println(response.getServerPayload());
			assertNotNull(response.getResponseAsJSON());
			ConfigXMLManager  d2 = (ConfigXMLManager) tester.loadConfigObject(response.getResponseAsJSON(), new ConfigXMLManager());
////System.out.println(d2.getName());
			assertEquals("default", d2.getName());
			assertEquals("enabled", d2.getMAdminState().value());
			assertEquals("Default XML-Manager", d2.getUserSummary());
			assertEquals("default", d2.getUserAgent().getValue());
//			assertEquals("HTTPUserAgent", d2.getUserAgent().getClazz());

			

		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException
				| ClassNotFoundException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		ConfigDomain testDomain = new ConfigDomain();
		testDomain.setName("default");
		try {
			RequestBean response =this.client.configRequest.getConfigObject(testDomain);
//System.out.println(response.getServerPayload());
			assertNotNull(response.getResponseAsJSON());
			ConfigDomain  d2 = (ConfigDomain) tester.loadConfigObject(response.getResponseAsJSON(), new ConfigDomain());
////System.out.println(d2.getName());
			assertEquals("default", d2.getName());
			assertEquals("enabled", d2.getMAdminState().value());
			assertEquals("Default System Domain", d2.getUserSummary());
//			assertEquals("HTTPUserAgent", d2.getUserAgent().getClazz());

			

		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException
				| ClassNotFoundException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ConfigDomain d3 = new ConfigDomain();
		d3.setName("default");

		try {
			RequestBean response = this.client.configRequest.getConfigObject(d3, "view=extended");
			d3 = (ConfigDomain) response.getResponseObject().getConfig().getConfigObjects().get(0);
			assertEquals("default", d3.getName());
			assertEquals("enabled", d3.getMAdminState().value());
			assertEquals("Default System Domain", d3.getUserSummary());
			assertEquals("3", d3.getMaxChkpoints());

		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException
				| ClassNotFoundException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		d3.setName("roma_Test_Vectors");
//		try {
//			RequestBean response = this.client.configRequest.getConfigObject(d3);
//			d3 = (ConfigDomain) response.getResponseObject().getConfig().getConfigObjects().get(0);
//			assertEquals("roma_Test_Vectors", d3.getName());
//			assertEquals("enabled", d3.getMAdminState().value());
//			assertEquals("3", d3.getMaxChkpoints());
//
//		} catch (IllegalArgumentException | IllegalAccessException
//				| NoSuchFieldException | SecurityException
//				| InvocationTargetException | NoSuchMethodException
//				| ClassNotFoundException | InstantiationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
	}

	@Test
	public void test_loadConfigObject_Complex_Arrays() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException{
		ConfigXMLManager getObject = new ConfigXMLManager();
		getObject.setName("TestLoading");
		getObject.setCacheSize("3245");
		getObject.setMAdminState(DmAdminState.ENABLED);
			DmReference compileOptionsPolicy = new DmReference();
			compileOptionsPolicy.setValue("reference1");
		getObject.setCompileOptionsPolicy(compileOptionsPolicy);
			DmDocCachePolicy e = new DmDocCachePolicy();
			e.setCacheBackendResponses(DmToggle.OFF);
			Long t= new Long(1231);
			e.setTTL(t);
			e.setXC10Grid(compileOptionsPolicy);
		getObject.getDocCachePolicy().add(e);
			e.setXC10Grid(null);
			e.setCacheBackendResponses(DmToggle.ON);
		getObject.getDocCachePolicy().add(e);
////System.out.println((payload.buildObjectPayload(getObject)));
		ConfigXMLManager loadObject = new ConfigXMLManager();
		
		ConfigXMLManager testEquals = (ConfigXMLManager) tester.loadObjectProperties((converter.stringToJSON(payload.buildObjectRequest(getObject))).getJsonObject("XMLManager"),loadObject);
		
		
////System.out.println(loadObject.getName());
////System.out.println(loadObject.getCacheSize());
////System.out.println(loadObject.getMAdminState().value());
////System.out.println(loadObject.getCompileOptionsPolicy().getValue());
////System.out.println(loadObject.getDocCachePolicy().get(0));
////System.out.println(loadObject.getDocCachePolicy().get(1));
//
////System.out.println("========================================================================================================");
//
////System.out.println(testEquals.getName());
////System.out.println(testEquals.getCacheSize());
////System.out.println(testEquals.getMAdminState().value());
////System.out.println(testEquals.getCompileOptionsPolicy().getValue());
////System.out.println(testEquals.getDocCachePolicy().get(0));
////System.out.println(testEquals.getDocCachePolicy().get(1));

assertEquals(loadObject.getName(), testEquals.getName());
assertEquals(loadObject.getCacheSize(), testEquals.getCacheSize());
assertEquals(loadObject.getMAdminState(), testEquals.getMAdminState());
assertEquals(loadObject.getCompileOptionsPolicy(), testEquals.getCompileOptionsPolicy());
assertEquals(loadObject.getDocCachePolicy().get(0), testEquals.getDocCachePolicy().get(0));
assertEquals(loadObject.getDocCachePolicy().get(1), testEquals.getDocCachePolicy().get(1));
	
	}
	
	@Test
	public void test_loadConfigWithStateParameter(){
		ConfigDomain d = new ConfigDomain();
		d.setName("default");
		try {
			RequestBean response = client.configRequest.getConfigObject(d, "state=1");
			d = (ConfigDomain) response.getResponseObject().getConfig().getConfigObjects().get(0);
			System.out.println("OpState: " + d.getState().getOpstate());
			System.out.println("admin state: " +d.getState().getAdminstate());
			System.out.println("config state: " +d.getState().getConfigstate());
			System.out.println("errorcode: " +d.getState().getErrorcode());
			System.out.println("eventcode: " +d.getState().getEventcode());
			
		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException
				| ClassNotFoundException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testJSONKeysWithSpecialCharacters() throws Exception {
		AnyConfigElement configList = new AnyConfigElement();
		this.client = new RMIClient(dpTarget, rmiPort, userName, password, domain);
		
		// -- start setup --
		ConfigHTTPSourceProtocolHandler sourceProtocolHandlerObject = new ConfigHTTPSourceProtocolHandler();
		sourceProtocolHandlerObject.setName("blorgh");
		sourceProtocolHandlerObject.setLocalPort("88");
		configList.getConfigObjects().add(sourceProtocolHandlerObject);
		RequestBean response = this.client.configRequest.createConfigObject(configList);
//System.out.println("Client Payload: " + response.getClientPayload());
//System.out.println("Server Response: " + response.getServerPayload());
//		assertTrue(response.getStatus().equals(RMIVariables.STATUS_CODE_OK.split(":")[0]));

		//simply get configuration for the handler
		response = client.configRequest.getConfigObject(configList); //throws NoSuchFieldException

		assertTrue(((ConfigHTTPSourceProtocolHandler)response.getResponseObject().getConfig().getConfigObjects().get(0)).getLocalPort().equals(sourceProtocolHandlerObject.getLocalPort()));
		assertTrue(((ConfigHTTPSourceProtocolHandler)response.getResponseObject().getConfig().getConfigObjects().get(0)).getName().equals(sourceProtocolHandlerObject.getName()));

	}

	@Test
	public void test_loadConfigObject_Bug_ComplexArrayOfDmReferences() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigLogTarget testObject = new ConfigLogTarget();
		testObject.setName("what");
		testObject.setType("file");
		testObject.setFormat("text");
		testObject.setArchiveMode("upload");
		testObject.setUploadMethod("scp");
		testObject.setRemoteAddress("1.2.3.4");
		testObject.setRemoteLogin("ba");
		testObject.setRemotePassword("fds");
		testObject.setRemotePort("22");
		testObject.setSize("100");
		testObject.setLocalFile("logtemp://asdf");
		DmLogEvent scpEvent = new DmLogEvent();
		DmReference scpLabel = new DmReference();
		scpLabel.setClazz("LogLabel");
		scpLabel.setValue("all");
		scpEvent.setClazz(scpLabel);
		scpEvent.setPriority(DmLogLevel.DEBUG);
		testObject.getLogEvents().add(scpEvent);

		DmLogEvent scpEvent2 = new DmLogEvent();
		DmReference scpLabel2 = new DmReference();
		scpLabel2.setClazz("LogLabel");
		scpLabel2.setValue("system");
		scpEvent2.setClazz(scpLabel2);
		scpEvent2.setPriority(DmLogLevel.ERROR);
		testObject.getLogEvents().add(scpEvent2);
		
		client.configRequest.createConfigObject(testObject);
		ConfigLogTarget testObject2 = new ConfigLogTarget();

		client.configRequest.loadConfigObject(testObject2, testObject.getName());
//		System.out.println(client.getLastResponse().getServerPayload());
//		System.out.println(payload.buildObjectRequest(testObject));
//		System.out.println(payload.buildObjectRequest(testObject2));
		
		assertEquals(payload.buildObjectRequest(testObject2), ("{\"LogTarget\":{\"mAdminState\":\"enabled\",\"Type\":\"file\",\"Priority\":\"normal\",\"SoapVersion\":\"soap11\",\"Format\":\"text\",\"TimestampFormat\":\"syslog\",\"FixedFormat\":\"off\",\"Size\":\"100\",\"LocalFile\":\"logtemp://asdf\",\"ArchiveMode\":\"upload\",\"UploadMethod\":\"scp\",\"Rotate\":\"3\",\"UseANSIColor\":\"off\",\"RemoteAddress\":\"1.2.3.4\",\"RemotePort\":\"22\",\"RemoteLogin\":\"ba\",\"SyslogFacility\":\"user\",\"RateLimit\":\"100\",\"ConnectTimeout\":\"60\",\"IdleTimeout\":\"15\",\"ActiveTimeout\":\"0\",\"FeedbackDetection\":\"off\",\"IdenticalEventSuppression\":\"off\",\"IdenticalEventPeriod\":\"10\",\"SSLClientConfigType\":\"proxy\",\"LogEvents\":[{\"Class\":\"all\",\"Priority\":\"debug\"},{\"Class\":\"system\",\"Priority\":\"error\"}],\"name\":\"what\"}}"));
	}

	@Test
	public void test_getAllDomains(){
		RequestBean response = this.client.getAllDomains();
		System.out.println(response.getServerPayload());
		System.out.println(response.getResponseObject().getConfig());
		System.out.println(response.getResponseObject().getConfig().getConfigObjects().size());
		for(ConfigConfigBase c: response.getResponseObject().getConfig().getConfigObjects()){
			System.out.println(((ConfigDomain)c).getName());
		}
	}
	
	@Test
	public void test_Filestore() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
//		RequestBean response = client.filestore.getDirectory("");
////		System.out.println(response.getUrl());
////		System.out.println(response.getResponseObject().getFilestore().getDirectory().getsubdirectories().get(0).getName());
//		assertTrue("Top level directory has 17 subdirectories", response.getResponseObject().getFilestore().getDirectory().getsubdirectories().size()==17);
		String responsePayload = "{        \"_links\" : {        \"self\" : {\"href\" : \"/mgmt/filestore/default/local\"},         \"doc\" : {\"href\" : \"/mgmt/docs/filestore\"}},         \"filestore\" : {        \"location\" : {\"name\" : \"local:\",         \"file\" : [{\"name\" : \"cryptoboy-client.keytab\",         \"size\" : 112,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/cryptoboy-client.keytab\"}, {\"name\" : \"mc-custom-AlwaysAllow-ip-id.xsl\",         \"size\" : 2731,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/mc-custom-AlwaysAllow-ip-id.xsl\"}, {\"name\" : 20090717.2025,         \"size\" : 790,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/20090717.2025\"}, {\"name\" : \"export.zip\",         \"size\" : 1075,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/export.zip\"}, {\"name\" : \"soapTest2.txt\",         \"size\" : 384390,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/soapTest2.txt\"}, {\"name\" : \"iii.conf\",         \"size\" : 625,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/iii.conf\"}, {\"name\" : 20090717.2123,         \"size\" : 790,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/20090717.2123\"}, {\"name\" : \"writeFirmwarefile.js\",         \"size\" : 413,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/writeFirmwarefile.js\"}, {\"name\" : 20090717.1853,         \"size\" : 790,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/20090717.1853\"}, {\"name\" : 20090717.1938,         \"size\" : 790,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/20090717.1938\"}, {\"name\" : \"te_stw.txt\",         \"size\" : 11,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/te_stw.txt\"}, {\"name\" : \"autoconfigInvalid.cfg\",         \"size\" : 5,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/autoconfigInvalid.cfg\"}, {\"name\" : \"300gbdiskfile2G.txt\",         \"size\" : 389120,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/300gbdiskfile2G.txt\"}, {\"name\" : \"ipmitool\",         \"size\" : 900446,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/ipmitool\"}, {\"name\" : \"mqBackendRouting.xsl\",         \"size\" : 7608,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/mqBackendRouting.xsl\"}, {\"name\" : \"msgtim.xsl\",         \"size\" : 332,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/msgtim.xsl\"}, {\"name\" : 20090716.1164,         \"size\" : 790,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/20090716.1164\"}, {\"name\" : \"soapTest32.txt\",         \"size\" : 1000550,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/soapTest32.txt\"}, {\"name\" : \"iiptest.conf\",         \"size\" : 625,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/iiptest.conf\"}, {\"name\" : \"test.txt\",         \"size\" : 11,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/test.txt\"}, {\"name\" : \"au-custom-AlwaysAUIdEqualsIP.xsl\",         \"size\" : 3005,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/au-custom-AlwaysAUIdEqualsIP.xsl\"}, {\"name\" : \"te_st.txt\",         \"size\" : 11,         \"modified\" : \"2016-08-31 12:41:21\",         \"href\" : \"/mgmt/filestore/default/local/te_st.txt\"}],         \"directory\" : [{\"name\" : \"local:/testingEmpty\",         \"href\" : \"/mgmt/filestore/default/local/testingEmpty\"}, {\"name\" : \"local:/MyQETest2\",         \"href\" : \"/mgmt/filestore/default/local/MyQETest2\"}, {\"name\" : \"local:/myflashdir01\",         \"href\" : \"/mgmt/filestore/default/local/myflashdir01\"}, {\"name\" : \"local:/MyQETest\",         \"href\" : \"/mgmt/filestore/default/local/MyQETest\"}, {\"name\" : \"local:/300gbdisk\",         \"href\" : \"/mgmt/filestore/default/local/300gbdisk\"}, {\"name\" : \"local:/myRaid\",         \"href\" : \"/mgmt/filestore/default/local/myRaid\"}, {\"name\" : \"local:/sbackup\",         \"href\" : \"/mgmt/filestore/default/local/sbackup\"}, {\"name\" : \"local:/dp525-srestore\",         \"href\" : \"/mgmt/filestore/default/local/dp525-srestore\"}, {\"name\" : \"local:/VSBR\",         \"href\" : \"/mgmt/filestore/default/local/VSBR\"}, {\"name\" : \"local:/preserve\",         \"href\" : \"/mgmt/filestore/default/local/preserve\"}],         \"href\" : \"/mgmt/filestore/default/local\"}}}";
		RMIObjectFactory r = new RMIObjectFactory();
		Converter c = new Converter();
		Response rr = r.getResponseObject(c.stringToJSON(responsePayload));
		assertEquals("local:", rr.getFilestore().getDirectory().getName());
		assertEquals("/mgmt/filestore/default/local", rr.getFilestore().getDirectory().getLocation());
		assertEquals(22, rr.getFilestore().getDirectory().getFiles().size());		
		assertEquals(10, rr.getFilestore().getDirectory().getsubdirectories().size());		

		assertEquals("cryptoboy-client.keytab", rr.getFilestore().getDirectory().getFiles().get(0).getName());
		assertEquals("112", rr.getFilestore().getDirectory().getFiles().get(0).getSize());
		assertEquals("2016-08-31 12:41:21", rr.getFilestore().getDirectory().getFiles().get(0).getModified());
		assertEquals("/mgmt/filestore/default/local/cryptoboy-client.keytab", rr.getFilestore().getDirectory().getFiles().get(0).getLocation());

		
	}
}
