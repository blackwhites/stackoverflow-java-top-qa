package junit;

import static org.junit.Assert.assertTrue;

import java.lang.reflect.InvocationTargetException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import beans.RequestBean;
import tools.SOMAClient;
import xmlManagement.ActionSaveConfig;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigEthernetInterface;
import xmlManagement.ConfigUserGroup;
import xmlManagement.ConfigXMLManager;
import xmlManagement.DmRMIFileDescription;
import xmlManagement.FilestoreLocation;
import xmlManagement.Request;
import xmlManagement.Request.GetFilestore;
import xmlManagement.StatusActiveUsers;
import xmlManagement.StatusEnum;

public class SOMAClientTest {
	static SOMAClient tester = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		tester = new SOMAClient("dp608.dp.rtp.raleigh.ibm.com", 5550, "admin", "jan0111j", "default");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_ModifyConfig(){
	    try {
	    	ConfigEthernetInterface ei = new ConfigEthernetInterface();
			ei.setIPAddress("3.2.1.3/99");
            ei.setName("eth13");
			RequestBean serverResponse = tester.configRequest.modifyConfigObject(ei);
			System.out.println(serverResponse.getStatus());
			System.out.println(serverResponse.getServerPayload());
		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void test_FileStore() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		
		tester.setReadTimeOut(120000);
		tester.setConnectionTimeout(120000);
		Request r = new Request();
		r.setDomain("default");
		GetFilestore f = new GetFilestore();
	
		f.setLocation(FilestoreLocation.LOCAL);
		f.setAnnotated(true);
		f.setLayoutOnly(false);
		f.setNoSubdirectories(true);
		r.setGetFilestore(f);
		RequestBean response = tester.sendRequest(r);
		System.out.println(response);
		
		System.out.println(response.getResponseObject().getFilestore().getDirectory());
		for(DmRMIFileDescription ff: response.getResponseObject().getFilestore().getDirectory().getFiles()){
			System.out.println(ff.getName());
			System.out.println(ff.getModified());
			System.out.println(ff.getSize());
			System.out.println("--------------");
		}
//		RequestBean response = tester.filestore.getFile("temporary", "apimdebug.json");
//		System.out.println(tester.filestore.getFileAsString("temporary", "apimdebug.json"));
//		System.out.println(response.toString());
//		String logAnchor = tester.filestore.getLogAnchor("logtemp", "default-log");
//		System.out.println(logAnchor);
//		System.out.println("==========================");
//		System.out.println(tester.filestore.getLogFromAnchor("logtemp", "default-log", logAnchor));
//		payload = tester.filestore.getCLILog();
//		System.out.println(payload);
//		Assert.assertNotNull("Verify get cli log method. ", payload);
//		
//		payload = null;
//		payload = tester.filestore.getDefaultLog();
//		System.out.println(payload);
//		Assert.assertNotNull("Verify get default log method. ", payload);
//	
//		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		payload = null;
//		payload = tester.filestore.getLogAnchor("logtemp", "default-log");
//		System.out.println(payload);
//		Assert.assertNotNull(payload);
//		
//		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		
//		HTTPSClient t = new HTTPSClient();
//		t.setUrl("dpvirt4a.dp.rtp.raleigh.ibm.com:16341378");
//		t.sendGet();
//		
//		payload = tester.filestore.getLogFromAnchor("logtemp", "default-log", payload);
//		System.out.println(payload);
//		Assert.assertNotNull(payload);
//		
//		//Test Set and  Delete File
//		RequestBean response = tester.filestore.createFile("local/preserve", "testing123.txt", "Testing SOMAClient");
//		
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//		
//		response = tester.filestore.getFile("local/preserve", "testing123.txt");
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//
//
//		response = tester.filestore.deleteFile("local/preserve", "testing123.txt");
//		
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//		
//		response = tester.filestore.createFile("local", "testing123.txt", "Testing SOMAClient");
//		
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//		
//		response = tester.filestore.getFile("local", "testing123.txt");
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//		System.out.println("================================================");
//
//		System.out.println(tester.filestore.getFileAsString("local", "testing123.txt"));
//		
//		System.out.println("================================================");
//		System.out.println("================================================");
//
//		response = tester.filestore.deleteFile("local", "testing123.txt");
//		
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//
//		response = tester.filestore.getFile("local", "testFile.txt");
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseAsXML().toString());
//		System.out.println("================================================");
//		System.out.println("================================================");
//		System.out.println("================================================");
//
//
//		try {
//			String fileContents = tester.readFile("./", "testFileSOMAError.txt");
//			response = tester.filestore.createFile("local", "testing123.txt", fileContents);
//			
//			System.out.println(response.getServerPayload());
//			System.out.println(response.getResponseAsXML().toString());
//			System.out.println("================================================");
//			
//			response = tester.filestore.getFile("local", "testing123.txt");
//			System.out.println(response.getServerPayload());
//			System.out.println(response.getResponseAsXML().toString());
//			System.out.println("================================================");
//
//
//			response = tester.filestore.deleteFile("local", "testing123.txt");
//			
//			System.out.println(response.getServerPayload());
//			System.out.println(response.getResponseAsXML().toString());
//			System.out.println("================================================");
//			String encoded = tester.converter.encodeBase64(fileContents);
//			System.out.println(encoded);
//			System.out.println(tester.converter.decodeBase64(encoded));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

	}

	@Test
	public void test_ActiveUsers_Status() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		RequestBean response = tester.status.getStatus(StatusEnum.ACTIVE_USERS.value());
		System.out.println(response.getServerPayload());
		AnyStatusElement statusList = response.getResponseObject().getStatus();
		System.out.println("Size of list: " +  statusList.getStatusObjects().size());
		assertTrue(statusList.getStatusObjects().size()>0);
		for(int i=0;i< statusList.getStatusObjects().size();i++){
			StatusActiveUsers activeUser = (StatusActiveUsers)statusList.getStatusObjects().get(i);
			assertTrue(activeUser != null);
			System.out.println(activeUser.getSession());
			System.out.println(activeUser.getDomain());
		}
	}
	
//	@Test
//	public void test_Load_Config_Object() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
//		ConfigXMLManager testXMLManager = new ConfigXMLManager();
//		tester.configRequest.loadConfigObject(testXMLManager, "default");
//		
//		Assert.assertTrue("Loaded Object Name", testXMLManager.getName().equals("default"));
//		Assert.assertTrue("Loaded Object User Summary", testXMLManager.getUserSummary().equals("Default XML-Manager"));
//
//		System.out.println(testXMLManager.getName());
//		System.out.println(testXMLManager.getUserSummary());
//
//	}
	
	@Test
	public void test_Action() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ActionSaveConfig action = new ActionSaveConfig();
		
		RequestBean response = tester.action.action(action);
		System.out.println("Client Payload: " + response.getClientPayload());
		System.out.println("Server Response: " + response.getServerPayload());
		
		if(response.getResponseObject().getResult() != null){
			System.out.println("Result Object: " + response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println("Fault Object: " + response.getResponseObject().getFault().getFaultstring());

		}else{
			assertTrue(false);
		}
		
	
	}
	
	@Test
	public void test_createobject_with_simple_array() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigUserGroup testObject = new ConfigUserGroup();
		testObject.setName("testingRMIClient");
		testObject.getAccessPolicies().add("blah");
		
		RequestBean response = tester.configRequest.createConfigObject(testObject);
		System.out.println("Client Payload: " + response.getClientPayload());
		System.out.println("Server Response: " + response.getServerPayload());
		if(response.getResponseObject().getResult() != null){
			System.out.println(response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println(response.getResponseObject().getFault().getFaultstring());

		}else{
			assertTrue(false);
		}
		System.out.println("=================================================");
//		assertTrue("Verify RMI Client correctly builds JSON Payload", response.getClientPayload().equals("{\"UserGroup\":{\"AccessPolicies\":[\"blah\"],\"name\":\"testingRMIClient\"}}"));
		
		testObject.getAccessPolicies().add("blah2");
		response = tester.configRequest.createConfigObject(testObject);
		System.out.println("Client Payload: " + response.getClientPayload());
		System.out.println("Server Response: " + response.getServerPayload());
		if(response.getResponseObject().getResult() != null){
			System.out.println("Result Object: " + response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println("Fault Object: " +response.getResponseObject().getFault().getFaultstring());
		}else{
			assertTrue(false);
		}
		System.out.println("=================================================");

//		assertTrue("Verify RMI Client correctly builds JSON Payload", response.getClientPayload().equals("{\"UserGroup\":{\"AccessPolicies\":[\"blah\",\"blah2\"],\"name\":\"testingRMIClient\"}}"));

		ConfigXMLManager manager = new ConfigXMLManager();
		manager.setName("testManager");
		System.out.println("Here");
		response = tester.configRequest.createConfigObject(manager);
		System.out.println("Client Payload: " + response.getClientPayload());
		System.out.println("Server Response: " + response.getServerPayload());
		if(response.getResponseObject().getResult() != null){
			System.out.println("Result Object: " + response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println("Fault Object: " +response.getResponseObject().getFault().getFaultstring());
		}else{
			assertTrue(false);
		}
		System.out.println("=================================================");

		response = tester.configRequest.deleteConfigObject(manager);
		System.out.println("Client Payload: " + response.getClientPayload());
		System.out.println("Server Response: " + response.getServerPayload());
		if(response.getResponseObject().getResult() != null){
			System.out.println("Result Object: " + response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println("Fault Object: " +response.getResponseObject().getFault().getFaultstring());
		}else{
			assertTrue(false);
		}
		
		
	}
}
