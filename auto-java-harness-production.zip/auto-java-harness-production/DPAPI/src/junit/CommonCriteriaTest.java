package junit;

import org.junit.Test;

import tools.CommonCriteria;
import tools.SSHClient;

public class CommonCriteriaTest {

	@Test
	public void test() {
		SSHClient test = new SSHClient("dp602.dp.rtp.raleigh.ibm.com", 22, "admin", "jan0111j", 1000000);
		System.out.println(test.loginDP("default"));
		String anchor ="";
		CommonCriteria cctools = new CommonCriteria();
		System.out.println(test.getResponse("show file logtemp:///js/jwsNoneErrors.log"));
		anchor = cctools.getDPLogAnchor(test, "logtemp:///js", "jwsNoneErrors.log");
		System.out.println(anchor);
		
		
		
//		System.out.println(anchor=cctools.getAuditAnchor(test));
//		System.out.println(test.getResponse("clock 00:00:00"));
//		System.out.println(test.getResponse("show clock"));
//		System.out.println(test.getResponse("loglevel error"));
//
//		System.out.println(cctools.getAuditLogFromAnchor(test, anchor));
//		
//		
//		System.out.println(anchor=cctools.getAuditAnchor(test));
//		System.out.println(test.getResponse("show clock"));
//		System.out.println(test.getResponse("show ntp-refresh"));
//		System.out.println(test.getResponse("loglevel error"));
////		System.out.println(test.getResponse("show audit-log -np"));
//
//		System.out.println(cctools.getAuditLogFromAnchor(test, anchor));

		test.endSession();
	}

}
