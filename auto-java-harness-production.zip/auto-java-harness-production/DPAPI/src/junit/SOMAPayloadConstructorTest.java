package junit;


import java.lang.reflect.InvocationTargetException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPException;

import tools.SOMAPayloadConstructor;
import xmlManagement.*;
import xmlManagement.Request.DoDeployPattern;
import xmlManagement.Request.DoExport;
import xmlManagement.Request.DoExport.Object;
import xmlManagement.Request.DoImport;
import xmlManagement.Request.GetConformanceReport;
import xmlManagement.Request.GetFile;
import xmlManagement.Request.GetFilestore;
import xmlManagement.Request.GetSamlart;
import xmlManagement.Request.SetFile;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class SOMAPayloadConstructorTest {
	SOMAPayloadConstructor test = new SOMAPayloadConstructor();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}
	

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testDoAction() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ActionFlushDocumentCache actionRequest = new ActionFlushDocumentCache();
		DmReference value = new DmReference();
		value.setValue("default");
		actionRequest.setXMLManager(value);
		String somaPayload = test.buildObjectRequest(actionRequest, "default");
		System.out.println(somaPayload);
	}

	@Test
	public void testConfigObjects() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ParserConfigurationException, JAXBException, SOAPException {
//		SOMAPayloadFactory test2 = new SOMAPayloadFactory();
		
		ConfigDomain domain = new ConfigDomain();
		AnyConfigElement configList = new AnyConfigElement();
		configList.getConfigObjects().add(domain);
		domain.setName("testing");
		domain.setMAdminState(DmAdminState.ENABLED);
		DmDomainFileMap value = new DmDomainFileMap();
		value.setCopyFrom(DmToggle.ON);
		value.setDelete(DmToggle.OFF);
		domain.setFileMap(value );
		
//		System.out.println("Theirs:");
//		Request r = new Request();
//		r.setSetConfig(e);
//		r.setDomain("default");
//		System.out.println(test2.buildSOMARequest(r));
//		System.out.println("============================================================");
		String somaPayload = test.buildObjectRequest(configList, "default");
		System.out.println(somaPayload);
		Assert.assertNotNull(somaPayload);
		Assert.assertTrue("Test ConfigDomain.",somaPayload.equals("<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"default\"><dp:set-config><Domain name=\"testing\"><mAdminState>enabled</mAdminState><FileMap><CopyFrom>on</CopyFrom><Delete>off</Delete></FileMap></Domain></dp:set-config></dp:request></env:Body></env:Envelope>"));
		
//		System.out.println(test.buildObjectRequest(e, "default"));
//		System.out.println("============================================================");


		ConfigXMLManager x2 = new ConfigXMLManager();
		configList.getConfigObjects().add(x2);
		x2.setName("TestINg");
		x2.setSearchResults("blah");
		DmReference r1 =new DmReference();
		r1.setValue("blah1");
		DmReference r2 =new DmReference();
		r2.setValue("blah2");

		x2.getVirtualServers().add(r1);
//		x2.getVirtualServers().add(r2);

		DmExtensionFunction ex1 = new DmExtensionFunction();
		ex1.setExtensionFunction("bfasf");
		ex1.setExtensionFunctionNamespace("bfasf");
		ex1.setLocalFunction("bfasf");
		ex1.setLocalFunctionNamespace("bfasf");
		
		DmExtensionFunction ex2 = new DmExtensionFunction();
		ex2.setExtensionFunction("bfas2f");
		ex2.setExtensionFunctionNamespace("bfas1f");
		ex2.setLocalFunction("bfa1sf");
		ex2.setLocalFunctionNamespace("bfas4f");
		
		x2.getExtensionFunctions().add(ex1);
		
		somaPayload = test.buildObjectRequest(configList, "default");
		System.out.println(somaPayload);
		Assert.assertNotNull(somaPayload);
		Assert.assertEquals("Test ConfigXMLManager.  Contains DmReference, Complex Array, and DmReference Array.",somaPayload, ("<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"default\"><dp:set-config><Domain name=\"testing\"><mAdminState>enabled</mAdminState><FileMap><CopyFrom>on</CopyFrom><Delete>off</Delete></FileMap></Domain><XMLManager name=\"TestINg\"><SearchResults>blah</SearchResults><VirtualServers>blah1</VirtualServers><ExtensionFunctions><ExtensionFunctionNamespace>bfasf</ExtensionFunctionNamespace><ExtensionFunction>bfasf</ExtensionFunction><LocalFunctionNamespace>bfasf</LocalFunctionNamespace><LocalFunction>bfasf</LocalFunction></ExtensionFunctions></XMLManager></dp:set-config></dp:request></env:Body></env:Envelope>"));
		
		
		ConfigHostAlias testHostAlias = new ConfigHostAlias();
		testHostAlias.setName("pickles");
		testHostAlias.setIPAddress("1.2.3.4");
		
		somaPayload = test.buildObjectRequest(testHostAlias, "default");
//		System.out.println(somaPayload);

		Assert.assertNotNull(somaPayload);
		System.out.println(somaPayload);
		Assert.assertEquals("Test ConfigHostAlias.",somaPayload, ("<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"default\"><dp:set-config><HostAlias name=\"pickles\"><IPAddress>1.2.3.4</IPAddress></HostAlias></dp:set-config></dp:request></env:Body></env:Envelope>"));
		

//			System.out.println("============================================================");
		
	}
	
	@Test
	public void test_Modify_Objects() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		////////////////////////////////////////////////////////////
		//  TEST MODIFY OBJECTS
		//////////////////////////////////////////////////////////
		DmReference r1 =new DmReference();
		r1.setValue("blah1");
		DmReference r2 =new DmReference();
		r2.setValue("blah2");
		DmExtensionFunction ex1 = new DmExtensionFunction();
		ex1.setExtensionFunction("bfasf");
		ex1.setExtensionFunctionNamespace("bfasf");
		ex1.setLocalFunction("bfasf");
		ex1.setLocalFunctionNamespace("bfasf");
		
		DmExtensionFunction ex2 = new DmExtensionFunction();
		ex2.setExtensionFunction("bfas2f");
		ex2.setExtensionFunctionNamespace("bfas1f");
		ex2.setLocalFunction("bfa1sf");
		ex2.setLocalFunctionNamespace("bfas4f");
		
		AnyModifyElement m = new AnyModifyElement();
		ModifyXMLManager m2 = new ModifyXMLManager();
		m.getConfigObjects().add(m2);
		m2.setName("TestINg");
		m2.setSearchResults("blah");
		m2.getVirtualServers().add(r1);
		m2.getVirtualServers().add(r2);
		
		m2.getExtensionFunctions().add(ex1);
		m2.getExtensionFunctions().add(ex2);
		
		String somaPayload = test.buildObjectRequest(m, "testDomain");
		System.out.println(somaPayload);
		Assert.assertNotNull(somaPayload);
		Assert.assertEquals("Test ModifyXMLManager.",somaPayload, ("<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"testDomain\"><dp:modify-config><XMLManager name=\"TestINg\"><SearchResults>blah</SearchResults><VirtualServers>blah1</VirtualServers><VirtualServers>blah2</VirtualServers><ExtensionFunctions><ExtensionFunctionNamespace>bfasf</ExtensionFunctionNamespace><ExtensionFunction>bfasf</ExtensionFunction><LocalFunctionNamespace>bfasf</LocalFunctionNamespace><LocalFunction>bfasf</LocalFunction></ExtensionFunctions><ExtensionFunctions><ExtensionFunctionNamespace>bfas1f</ExtensionFunctionNamespace><ExtensionFunction>bfas2f</ExtensionFunction><LocalFunctionNamespace>bfas4f</LocalFunctionNamespace><LocalFunction>bfa1sf</LocalFunction></ExtensionFunctions></XMLManager></dp:modify-config></dp:request></env:Body></env:Envelope>"));
	}
	
	@Test
	public void test_Filestore() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{

		GetFilestore f = new GetFilestore();
		f.setLocation(FilestoreLocation.LOCAL);
		f.setAnnotated(true);
		f.setLayoutOnly(true);
		f.setNoSubdirectories(true);
		
		String somaPayload = test.buildObjectReqeust(f, "default");
//		System.out.println(somaPayload);

		Assert.assertNotNull(somaPayload);
		System.out.println(somaPayload);
		Assert.assertTrue("Test GetFilestore.",somaPayload.equals("<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"default\"><dp:get-filestore location=\"local:\" annotated=\"true\" layout-only=\"true\" no-subdirectories=\"true\"/></dp:request></env:Body></env:Envelope>"));

//System.out.println("============================================================");

	}
	
	@Test
	public void test_Bug_ConfigLogTarget() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigLogTarget QElog = new ConfigLogTarget();
		QElog.setName("qe-log");
		QElog.setType("file");
		QElog.setSize("1024");
		QElog.setLocalFile("logtemp:///blah");
		QElog.setFormat("text");
		QElog.setTimestampFormat("syslog");
		DmLogEvent qe = new DmLogEvent();
		qe.setPriority(DmLogLevel.DEBUG);
		DmReference qeLabel = new DmReference();
		qeLabel.setValue("quota-enforcement");
		qeLabel.setClazz("LogLabel");
		qe.setClazz(qeLabel);
		QElog.getLogEvents().add(qe);
		
//		System.out.println(test.buildObjectRequest(QElog,"default"));
		String somaPayload = test.buildObjectRequest(QElog,"default");
		System.out.println(somaPayload);
		Assert.assertNotNull(somaPayload);
		Assert.assertEquals("Test ConfigLogTarget Bug. Complex Arrays with object that contain an enum.",somaPayload,("<?xml version=\"1.0\" encoding=\"UTF-8\"?><env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\"><env:Body><dp:request xmlns:dp=\"http://www.datapower.com/schemas/management\"  domain=\"default\"><dp:set-config><LogTarget name=\"qe-log\"><Type>file</Type><Format>text</Format><TimestampFormat>syslog</TimestampFormat><Size>1024</Size><LocalFile>logtemp:///blah</LocalFile><LogEvents><Class>quota-enforcement</Class><Priority>debug</Priority></LogEvents></LogTarget></dp:set-config></dp:request></env:Body></env:Envelope>"));

	}

	@Test
	public void testSetFile() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		SetFile f = new SetFile();
		f.setName("Blah");
		f.setValue("adf".getBytes());
//		System.out.println(test.buildObjectPayload(f));
		String somaPayload = test.buildObjectPayload(f);
		Assert.assertNotNull(somaPayload);
		System.out.println(somaPayload);
		Assert.assertTrue("Test Set-File.",somaPayload.equals("<dp:set-file name=\"Blah\">adf</dp:set-file>"));

	}
	
	@Test
	public void testgetFile() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		GetFile f = new GetFile();
		f.setName("Blah");
		System.out.println(test.buildObjectPayload(f));
		String somaPayload = test.buildObjectPayload(f);
		Assert.assertNotNull(somaPayload);
		Assert.assertTrue("Test Set-File.",somaPayload.equals("<dp:get-file name=\"Blah\"/>"));
	}
	
	@Test
	public void testGetSAML() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		GetSamlart f = new GetSamlart();
		f.setUser("dfyfud");
		f.setPassword("fghfj");
		String somaPayload = test.buildObjectPayload(f);
		Assert.assertNotNull(somaPayload);
		System.out.println(somaPayload);
		Assert.assertEquals("Test get-SAML.",somaPayload, "<dp:get-samlart user=\"dfyfud\" password=\"fghfj\"/>");

	}
	
	@Test
	public void testGetConformanceReport() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		GetConformanceReport f = new GetConformanceReport();
//		Request r = new Request();
//		r.setGetConformanceReport(value)
		f.setName("fsdytdd");
		f.setProfile("adfasdf");
		f.setClazz(ConfigEnum.AAA_POLICY);
		
		String somaPayload = test.buildObjectPayload(f);
		Assert.assertNotNull(somaPayload);
		Assert.assertEquals("Test get-ConformanceReport.",somaPayload, "<dp:get-conformance-report class=\"AAAPolicy\" name=\"fsdytdd\" profile=\"adfasdf\"/>");

//		System.out.println(test.buildObjectPayload(f));
	}
	
	@Test
	public void testDoDeployPattern() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		DoDeployPattern f = new DoDeployPattern();


		ConfigDeploymentPolicyParametersBinding value = new ConfigDeploymentPolicyParametersBinding();
		value.setExternal(true);
		value.setName("adf");
		f.setDeploymentPolicyVariables(value);
		f.setDeploymentpolicyvariablesAttribute("fhjgfhj");
		f.setDryRun(true);
		f.setOverwriteFiles(false);
		f.setOverwriteObjects(true);
		Base64Binary value2= new Base64Binary();
		value2.setValue("byte array".getBytes());
		f.setPatternFile(value2);		
		f.setSourceType(ExportFormat.XML);
		
		String somaPayload = test.buildObjectPayload(f);
		Assert.assertNotNull(somaPayload);
		System.out.println(somaPayload);
		Assert.assertEquals("Test Do-DeployPattern.",somaPayload, "<dp:do-deploy-pattern source-type=\"XML\" dry-run=\"true\" overwrite-files=\"false\" overwrite-objects=\"true\" deployment-policy-variables=\"fhjgfhj\"><pattern-file>byte array</pattern-file><deployment-policy-variables name=\"adf\" external=\"true\"/></dp:do-deploy-pattern>");

//		System.out.println(test.buildObjectPayload(f));
	}
	
	@Test
	public void testGetFilestore() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		GetFilestore f = new GetFilestore();
		f.setAnnotated(true);
		f.setLocation(FilestoreLocation.LOCAL);
		
		String somaPayload = test.buildObjectPayload(f);
		Assert.assertNotNull(somaPayload);
		System.out.println(somaPayload);
		Assert.assertTrue("Test get-filestore.",somaPayload.equals("<dp:get-filestore location=\"local:\" annotated=\"true\"/>"));

		
//		System.out.println(test.buildObjectPayload(f));
	}

	@Test
	public void testDoExport() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		Request r = new Request();
		DoExport value = new DoExport();
		value.setFormat(ExportFormat.ZIP);
		value.setAllFiles(false);
		Object e = new Object();
		e.setClazz("HTTPUserAgent");
		e.setName("default");
		
		Object e2 = new Object();
		e2.setClazz("HTTPUserAgent");
		e2.setName("default2");
		
		value.setUserComment("this is a comment");
		
		value.getObject().add(e);
		value.getObject().add(e2);
		r.setDoExport(value );
		String somaPayload = test.buildObjectPayload(value);
		System.out.println(somaPayload);

	}
	
	@Test
	public void do_Import() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{

//	@Test
//	public void get_FileStore(){
//		
//	}
		Request somaRequest = new Request();
		somaRequest.setDomain("badf");
			DoImport doImport = new DoImport();
				Base64Binary importXML = new Base64Binary();
				importXML.setValue("HEY, THIS IS SUPPOSED TO BE BASE64 ENCODED, WHAT ARE YOU DOING, YOU LUNATIC?".getBytes());
			doImport.setInputFile(importXML );
			doImport.setSourceType(ExportFormat.XML);
			doImport.setOverwriteFiles(true);
			xmlManagement.Request.DoImport.Object e = new xmlManagement.Request.DoImport.Object();
				e.setName("blah");
				e.setClazz(ConfigEnum.XML_FIREWALL_SERVICE.value());
				e.setImportDebug(true);
			doImport.getObject().add(e);
		somaRequest.setDoImport(doImport);
		String somaPayload = test.buildObjectRequest(somaRequest);
		System.out.println(somaPayload);
	}
}
