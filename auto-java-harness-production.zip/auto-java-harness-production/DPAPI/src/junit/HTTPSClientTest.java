package junit;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import tools.HTTPSClient;

public class HTTPSClientTest {
	ArrayList<String> properties = new ArrayList<>();
	int totalRequest=0;

	@Test
	public void testBlah(){
		HTTPSClient client = new HTTPSClient();
		client.setUrl("https://sjsldev160.dev.ciondemand.com/nc/new-catalog-1/?q=ibm_apim/activate/x&activationToken=eyJ1cmwiOiJodHRwczovL3Nqc2xkZXYxNTkuZGV2LmNpb25kZW1hbmQuY29tL3YxL3BvcnRhbC91c2Vycy81N2Q2Zjk0OWU0YjBjY2Q3YjMzZjhhOTMvYWN0aXZhdGUiLCJ1c2VybmFtZSI6IiFCQVNFNjRfU0lWX0VOQyFfQWFCNk5MVlBWaytRTmdMM0tHdnhTYnVkTk1KUGNReUFaNnk1RGlRWGVwMkFBQUFBRWIxUE4yb0tlQ1crV1BCUlJmNWhjSU1Ua1h0S21QZ0VKTmJNckFoeHE1OGIiLCJhdXRoZW50aWNhdGlvbiI6eyJ1c2VybmFtZSI6IjU3ZDZmODRhZTRiMGNjZDdiMzNmOGE4MC81N2QyYmVlNmU0YjBjY2Q3YjMzZjYyNDQvUzVsVzRySTJnUDBvRzdrSzZ1RTVtRTJ3UTdyRDN0VDFvTDRsRzdvWTN3IiwicGFzc3dvcmQiOiI3UGJjVGtrblhpNEhyYkd1Rmg1T3k1UjkvZ1pveWwrRTRJM Hp3M3M3VVAifSwicHJvdmlkZXJDb250ZXh0Ijp7Im9yZ0lEIjoiNTdkMmJlZTVlNGIwY2NkN2IzM2Y2MjNkIiwiZW52aXJvbm1lbnRJRCI6IjU3ZDZmODRhZTRiMGNjZDdiMzNmOGE4MCJ9fQ");
		client.sendGet();
		System.out.println(client.getLastResponse().toString());
		
	}
	
	@Test
	public void persistent(){
		HTTPSClient client = new HTTPSClient();
		client.addHeader("myKey", "my:value");
		client.setUrl("https://httpbin.org/get");
		client.sendRequestPersistent("GET", null);
		System.out.println(client.getLastResponse().toString());
		System.out.println("-------------------------------");
		client.sendRequestPersistent("GET", null);
		System.out.println(client.getLastResponse().toString());
		System.out.println("-------------------------------");
		client.closeConnection();
	}
	
	@Test
	public void test() throws UnsupportedEncodingException, IOException {
		HTTPSClient client = new HTTPSClient();
		client.setURL("https://httpbin.org/post");
		File importFile = new File("api.yaml");
		HashMap<String, Object> tmp = new HashMap<>();
		tmp.put("fda", "fadfaf");
		tmp.put("file", importFile);
		System.out.println(client.sendMultipartFormData(tmp, StandardCharsets.UTF_8));

		if(client.getLastResponse().isError()){
			client.getLastResponse().getException().printStackTrace();;
		}
	}
	
//	@Test
//	public void test_PersistentConnection() {
//		HTTPSClient tester=null;
//		try {
//			tester = new HTTPSClient();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		tester.addConnectionHeader("Keep-Alive");
//		tester.setUrl("https://dpblade95.dp.rtp.raleigh.ibm.com:443/1k.xml");
//		for(int i=0;i<100;i++){
//			tester.sendRequestPersistent("GET",null).getServerPayload();
//			tester.sendRequestPersistent("POST","XZCF").getServerPayload();
//
//		}
//		tester.closeConnection();
//	}
//	
//	@Test
//	public void test_basicRequest() throws InterruptedException {
//		
//		
//		HTTPSClient client = new HTTPSClient();
////		client.setURL("https://9.42.102.208/apim/");
//		client.setURL("https://sjsldev159.dev.ciondemand.com/apim/");
//		client.addConnectionHeader(URLClient.HEADER_VALUE_Connection_KeepAlive);
//		System.out.println(client.sendRequestPersistent("GET", null));
//System.out.println("=====================================");
////https://sjsldev159.dev.ciondemand.com/apim/proxy/apimanager/orgs/5731d0b8e4b034657639e9f4/apis/5732198ce4b034657639ee51
////Thread.sleep(3000);
////Get Cookie
//		String cookie = client.getLastResponse().getServerHeaders().get("Set-Cookie").get(0).split(";")[0];
//		System.out.println(cookie);
//		client.addHeader("Cookie", cookie);
////		client.setURL("https://9.42.102.208/apim/j_security_check");
//		client.setURL("https://sjsldev159.dev.ciondemand.com/apim/j_security_check");
//		System.out.println(client.sendRequestPersistent("POST", "j_username=cncoble%40us.ibm.com&j_password=Bigred1&login=true").toString());
//		
//		client.getHeaders().clear();
//		cookie = client.getLastResponse().getServerHeaders().get("Set-Cookie").get(0).split(";")[0];
//		
////		client.setURL("https://9.42.102.208/apim/");
//		client.setURL("https://sjsldev159.dev.ciondemand.com/apim/");
//		client.addHeader("Cookie", cookie);
//		System.out.println(client.sendGet().toString());
//		
//		client.addContentTypeHeader(URLClient.HEADER_VALUE_ContentType_JSON);
////		client.setURL("https://9.42.102.208/apim/proxy/orgs/572cd9480cf2074e827d8f18/products");
////		client.setURL("https://9.42.102.208/apim/proxy/apimanager/orgs/572cd9480cf2074e827d8f18/apis");
//		client.setURL("https://sjsldev159.dev.ciondemand.com/apim/proxy/apimanager/orgs/5735be47e4b043598599fa8f/apis");
//		System.out.println(client.sendRequestPersistent("POST", "{\"basePath\":\"/\",\"paths\":{\"testing\":true,\"/path-1\":{\"post\":{\"responses\":{\"200\":{\"description\":\"200 OK\"}},\"parameters\":[{\"schema\":{\"type\":\"string\"},\"in\":\"body\",\"name\":\"api_parameter-1\",\"required\":true}]}}},\"host\":\"$(catalog.host)\",\"x-ibm-configuration\":{\"phase\":\"realized\",\"enforced\":true,\"cors\":{\"enabled\":true},\"testable\":true,\"assembly\":{\"execute\":[{\"map\":{\"outputs\":{\"output\":{\"schema\":{\"type\":\"string\"},\"variable\":\"message.body\"}},\"inputs\":{\"input\":{\"schema\":{\"type\":\"string\"},\"variable\":\"$(request.body)\"}},\"title\":\"map\",\"actions\":[{\"set\":\"output\",\"from\":\"input\"}]}},{\"map\":{\"outputs\":{\"output\":{\"schema\":{\"type\":\"string\"},\"variable\":\"$(message.body)\"}},\"inputs\":{\"input\":{\"schema\":{\"type\":\"string\"},\"variable\":\"request.body\"}},\"title\":\"map\",\"actions\":[{\"set\":\"output\",\"from\":\"input\"}]}},{\"invoke\":{\"target-url\":\"$(target-url)\"}}]},\"gateway\":\"datapower-gateway\"},\"securityDefinitions\":{},\"swagger\":\"2.0\",\"info\":{\"x-ibm-name\":\"maptestinvalidreference\",\"title\":\"MapTestInvalidReference\",\"version\":\"1.0.0\"},\"consumes\":[\"text/plain\"]}").toString());
////		File importFile = new File("api.yaml");
////		System.out.println(client.sendFormPostFile("file", new ArrayList<String>(), importFile , StandardCharsets.UTF_8, "application/octet-stream"));
////		System.out.println(client.getLastResponse().getClientPayload());
//////		System.out.println(client.getLastResponse().getServerHeaders().get("Connection").get(0));
////		System.out.println(client.getLastResponse().getStatus());
////		System.out.println(client.getLastResponse().getServerPayload());
//		client.closeConnection();
////		CurlTask curl = new CurlTask("https://sjsldev159.dev.ciondemand.com/apim/proxy/apimanager/orgs/5731d0b8e4b034657639e9f4/apis");
////		curl.addHeader("Cookie:"+cookie);
////		curl.setInsecure(true);
////		curl.setSilent(true);
////		curl.setVerbose(true);
////		curl.setCustomParms("-F \"file=@C:\\Users\\IBM_ADMIN\\Perforce\\cncoble_ADMINIB-MOG38SB_7751\\main\\sqa\\java-harness\\src\\DPAPI\\api.yaml\"");
////		TaskLauncher curlRequest = new TaskLauncher();
////		TaskResult result = curlRequest.launchProcess(curl, 120000);
////		System.out.println(result.getCommand());
////		System.out.println(result.getErrOut());
////		System.out.println(result.getStdOut());
//		
////		HTTPSClient tester=null;
////		long start =0;
////		long finish=0;
////		try {
////			tester = new HTTPSClient();
////		} catch (Exception e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////		tester.setUrl("https://httpbin.org/get");
////		tester.addBasicAuthenticationHeader("admin", "jan0111j");
////		tester.setConnectionTimeOut(300000);
////		tester.setReadTimeOut(300000);
////		tester.addHeader("Host", "blah");
////		System.out.println(tester.sendGet().getServerPayload());
//		
//	}

//	@Test
////	public void test_RecursiveMetaRequest(){
////		HTTPSClient tester=null;
////		long start =0;
////		long finish=0;
////		try {
////			tester = new HTTPSClient();
////		} catch (Exception e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////		
////		tester.setUrl("https://google.com");
////		System.out.println(tester.sendRequest(URLClient.HTTP_GET, null).getStatus());
//////		tester.setUrl("https://dpvirt4a.dp.rtp.raleigh.ibm.com:5554/mgmt/metadata/default/MultiProtocolGateway");//?view=recursive
//////		tester.addBasicAuthenticationHeader("admin", "jan0111j");
//////		tester.addHeader(URLClient.HEADER_KEY_Connection, URLClient.HEADER_VALUE_Connection_KeepAlive);
//////		tester.setConnectionTimeOut(300000);
//////		tester.setReadTimeOut(300000);
//////		tester.sendRequestPersistent(URLClient.HTTP_GET, null);
//////		start = System.currentTimeMillis();
//////		this.totalRequest++;
//////		this.sendGetsToAllMetaProperties(tester.sendGet(), tester, "https://dpvirt4a.dp.rtp.raleigh.ibm.com:5554/mgmt/metadata/default/MultiProtocolGateway", "",8);
////////		System.out.println(tester.sendGet().getServerPayload());
//////		tester.closeConnection();
//////		finish = System.currentTimeMillis();
//////		System.out.println("Total Request Time: " + ((finish - start)/1000));
//////		System.out.println("Total Request: " + this.totalRequest);
////
////	}
////	
////	public void sendGetsToAllMetaProperties(RequestBean r , HTTPSClient client, String rootURL, String parameters, int depth){
////		ArrayList<String> urls = new ArrayList<>();
//		JsonObject js = client.encoder.stringToJSON(r.getServerPayload());
//		if(!js.containsKey("object") || !js.getJsonObject("object").containsKey("properties") || !js.getJsonObject("object").getJsonObject("properties").containsKey("property")){
//			return;
//		}
//		JsonObject metadataObject = js.getJsonObject("object");
//		JsonArray propertyList = metadataObject.getJsonObject("properties").getJsonArray("property");
//		if(depth>0){
//			for(int i=0;i<propertyList.size();i++){
//				
//				String propName = propertyList.getJsonObject(i).getString("name").toString();
////				if(properties.contains(propName)){continue;}
////				System.out.println(propName);
////				client.setUrl(rootURL + "/" + propName);
//				
////				type": {
////	            "href": "/mgmt/types/default/dmReference",
////	            "reference-to": {
////	              "href": "/mgmt/metadata/default/XMLManager"
////	            }
////	          }
//				if(propertyList.getJsonObject(i).getJsonObject("type").containsKey("reference-to")){
//					if(propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").containsKey(RMIVariables.KEY_URI)){
//						if(properties.contains(propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").getString(RMIVariables.KEY_URI))){continue;}else{properties.add( propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").getString(RMIVariables.KEY_URI));}
//
//
//						rootURL = "https://" + r.getHostName() + ":5554" + propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").getString(RMIVariables.KEY_URI);
//
//						System.out.println(propName);
//						System.out.println(rootURL);
//
//						
//						client.setURL(rootURL);
//						this.totalRequest++;
//						this.sendGetsToAllMetaProperties(client.sendRequestPersistent(client.HTTP_GET, null), client, rootURL, parameters, depth-1);
//						continue;
//					}else{
////						this.totalRequest++;
////						client.sendRequestPersistent(client.HTTP_GET, null);
//						continue;
//					}
//				}else{
//					if(properties.contains(propertyList.getJsonObject(i).getJsonObject("type").getString(RMIVariables.KEY_URI))){continue;}else{properties.add(propertyList.getJsonObject(i).getJsonObject("type").getString(RMIVariables.KEY_URI));}
//					rootURL = "https://" + r.getHostName() + ":5554" + propertyList.getJsonObject(i).getJsonObject("type").getString(RMIVariables.KEY_URI);
//					client.setURL(rootURL);
//				}
//				this.totalRequest++;
//				System.out.println(propName);
//				System.out.println(rootURL);
//				
//				this.sendGetsToAllMetaProperties(client.sendRequestPersistent(client.HTTP_GET, null), client, rootURL, parameters, depth-1);
//
//	//			client.sendGet();
//				//Add property to request queue
//	//			urls.add(rootURL + "/" + propName + parameters );
//			}
//		}else{
//for(int i=0;i<propertyList.size();i++){
//				
//				String propName = propertyList.getJsonObject(i).getString("name").toString();
////				if(properties.contains(propName)){continue;}
////				client.setUrl(rootURL + "/" + propName);
//				
////				type": {
////	            "href": "/mgmt/types/default/dmReference",
////	            "reference-to": {
////	              "href": "/mgmt/metadata/default/XMLManager"
////	            }
////	          }
//				if(propertyList.getJsonObject(i).getJsonObject("type").containsKey("reference-to")){
//					if(propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").containsKey(RMIVariables.KEY_URI)){
//						if(properties.contains(propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").getString(RMIVariables.KEY_URI))){continue;}else{properties.add( propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").getString(RMIVariables.KEY_URI));}
//
//
//						rootURL = "https://" + r.getHostName() + ":5554" + propertyList.getJsonObject(i).getJsonObject("type").getJsonObject("reference-to").getString(RMIVariables.KEY_URI);
//						System.out.println(propName);
//						System.out.println(rootURL);
//						client.setURL(rootURL);
//						this.totalRequest++;
//						client.sendRequestPersistent(client.HTTP_GET, null);
//						continue;
//					}else{
////						this.totalRequest++;
////						client.sendRequestPersistent(client.HTTP_GET, null);
//						continue;
//					}
//				}else{
//					if(properties.contains(propertyList.getJsonObject(i).getJsonObject("type").getString(RMIVariables.KEY_URI))){continue;}else{properties.add(propertyList.getJsonObject(i).getJsonObject("type").getString(RMIVariables.KEY_URI));}
//					rootURL = "https://" + r.getHostName() + ":5554" + propertyList.getJsonObject(i).getJsonObject("type").getString(RMIVariables.KEY_URI);
//					client.setURL(rootURL);
//				}
//				this.totalRequest++;
//				System.out.println(propName);
//				System.out.println(rootURL);
//				client.sendRequestPersistent(client.HTTP_GET, null);
//
//	//			client.sendGet();
//				//Add property to request queue
//	//			urls.add(rootURL + "/" + propName + parameters );
//			}
//		}
//	}
}
