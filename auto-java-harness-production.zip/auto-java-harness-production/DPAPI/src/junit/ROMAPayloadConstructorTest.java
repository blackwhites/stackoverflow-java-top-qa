package junit;


import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;
import org.junit.Test;
import tools.RMIPayloadConstructor;
import xmlManagement.ActionDisconnect;
import xmlManagement.ActionFlushDocumentCache;
import xmlManagement.ActionRMIExport;
import xmlManagement.ActionRMIImport;
import xmlManagement.AnyActionElement;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyModifyElement;
import xmlManagement.ConfigAAAPolicy;
import xmlManagement.ConfigLogTarget;
import xmlManagement.ConfigXMLFirewallService;
import xmlManagement.ConfigXMLManager;
import xmlManagement.DmAAAPAuthenticate;
import xmlManagement.DmAAAPEIBitmap;
import xmlManagement.DmAAAPERBitmap;
import xmlManagement.DmAAAPExtractIdentity;
import xmlManagement.DmAAAPExtractResource;
import xmlManagement.DmExtensionFunction;
import xmlManagement.DmHTTPClientServerVersion;
import xmlManagement.DmHTTPVersion;
import xmlManagement.DmLogEvent;
import xmlManagement.DmLogLevel;
import xmlManagement.DmRMIExportFormat;
import xmlManagement.DmRMIExportObject;
import xmlManagement.DmRMIImportDomain;
import xmlManagement.DmRMIImportFile;
import xmlManagement.DmRMIImportFormat;
import xmlManagement.DmRMIImportObject;
import xmlManagement.DmReference;
import xmlManagement.DmToggle;
import xmlManagement.File;
import xmlManagement.ModifyXMLManager;

public class ROMAPayloadConstructorTest {
	RMIPayloadConstructor roma = new RMIPayloadConstructor();

	@Test
	public void testCofigObjectAndPropertyPayloads() {
		AnyConfigElement e = new AnyConfigElement();
	
		ConfigXMLManager x2 = new ConfigXMLManager();
		e.getConfigObjects().add(x2);
		x2.setName("TestINg");
		x2.setSearchResults("blah");
		DmReference r1 =new DmReference();
		r1.setValue("blah1");
		DmReference r2 =new DmReference();
		r2.setValue("blah2");

		x2.getVirtualServers().add(r1);
		
		DmExtensionFunction ex1 = new DmExtensionFunction();
		ex1.setExtensionFunction("bfasf");
		ex1.setExtensionFunctionNamespace("bfasf");
		ex1.setLocalFunction("bfasf");
		ex1.setLocalFunctionNamespace("bfasf");
		
		DmExtensionFunction ex2 = new DmExtensionFunction();
		ex2.setExtensionFunction("bfas2f");
		ex2.setExtensionFunctionNamespace("bfas1f");
		ex2.setLocalFunction("bfa1sf");
		ex2.setLocalFunctionNamespace("bfas4f");
		
		x2.getExtensionFunctions().add(ex1);
		
 		try {
 			String newBuilder =roma.buildPropertyRequest(e, "SearchResults");
// 			System.out.println(newBuilder);
			assertEquals("{\"SearchResults\":\"blah\"}", newBuilder);

//			System.out.println("============================================================");

			
 			newBuilder =roma.buildPropertyRequest(e, "ExtensionFunctions");
 			System.out.println(newBuilder);
			assertEquals("{\"ExtensionFunctions\":[{\"ExtensionFunctionNamespace\":\"bfasf\",\"ExtensionFunction\":\"bfasf\",\"LocalFunctionNamespace\":\"bfasf\",\"LocalFunction\":\"bfasf\"}]}", newBuilder);

			x2.getExtensionFunctions().add(ex2);

			newBuilder =roma.buildPropertyRequest(e, "ExtensionFunctions");
// 			System.out.println(newBuilder);
			assertEquals("{\"ExtensionFunctions\":[{\"ExtensionFunctionNamespace\":\"bfasf\",\"ExtensionFunction\":\"bfasf\",\"LocalFunctionNamespace\":\"bfasf\",\"LocalFunction\":\"bfasf\"},{\"ExtensionFunctionNamespace\":\"bfas1f\",\"ExtensionFunction\":\"bfas2f\",\"LocalFunctionNamespace\":\"bfas4f\",\"LocalFunction\":\"bfa1sf\"}]}", newBuilder);

//			System.out.println("============================================================");

			newBuilder =roma.buildPropertyRequest(e, "VirtualServers");
// 			System.out.println(newBuilder);
			assertEquals("{\"VirtualServers\":[\"blah1\"]}", newBuilder);

			x2.getVirtualServers().add(r2);
			newBuilder =roma.buildPropertyRequest(e, "VirtualServers");
// 			System.out.println(newBuilder);
			assertEquals("{\"VirtualServers\":[\"blah1\",\"blah2\"]}", newBuilder);

//			System.out.println("============================================================");
			
			newBuilder =roma.buildObjectRequest(e);
// 			System.out.println(newBuilder);
//			System.out.println("==========={\"VirtualServers=================================================");
			assertEquals("{\"XMLManager\":{\"SearchResults\":\"blah\",\"VirtualServers\":[\"blah1\",\"blah2\"],\"ExtensionFunctions\":[{\"ExtensionFunctionNamespace\":\"bfasf\",\"ExtensionFunction\":\"bfasf\",\"LocalFunctionNamespace\":\"bfasf\",\"LocalFunction\":\"bfasf\"},{\"ExtensionFunctionNamespace\":\"bfas1f\",\"ExtensionFunction\":\"bfas2f\",\"LocalFunctionNamespace\":\"bfas4f\",\"LocalFunction\":\"bfa1sf\"}],\"name\":\"TestINg\"}}", newBuilder);

		} catch (IllegalArgumentException | SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//Test Complex
 catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchFieldException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
 		
 		
 		
	}
	
	@Test
	public void testConfigLogTargetBug() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigLogTarget QElog = new ConfigLogTarget();
		QElog.setName("qe-log");
		QElog.setType("file");
		QElog.setSize("1024");
		QElog.setLocalFile("logtemp:///blah");
		QElog.setFormat("text");
		QElog.setTimestampFormat("syslog");
		DmLogEvent qe = new DmLogEvent();
		qe.setPriority(DmLogLevel.DEBUG);
		DmReference qeLabel = new DmReference();
		qeLabel.setValue("quota-enforcement");
		qeLabel.setClazz("LogLabel");
		qe.setClazz(qeLabel);
		QElog.getLogEvents().add(qe);
		
		String newBuilder = roma.buildObjectRequest(QElog);
//		System.out.println(newBuilder);
		assertEquals("{\"LogTarget\":{\"Type\":\"file\",\"Format\":\"text\",\"TimestampFormat\":\"syslog\",\"Size\":\"1024\",\"LocalFile\":\"logtemp:///blah\",\"LogEvents\":[{\"Class\":\"quota-enforcement\",\"Priority\":\"debug\"}],\"name\":\"qe-log\"}}", newBuilder);

	}
	
	@Test
	public void testConfigHTTPVersionEnumBug() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigXMLFirewallService t = new ConfigXMLFirewallService();
		DmHTTPClientServerVersion v = new DmHTTPClientServerVersion();
		v.setBack(DmHTTPVersion.HTTP_1_0);
		v.setFront(DmHTTPVersion.HTTP_1_0);
		

		t.setHTTPVersion(v);
		String newBuilder = roma.buildObjectRequest(t);
//		System.out.println(newBuilder);
		assertEquals("{\"XMLFirewallService\":{\"HTTPVersion\":{\"Front\":\"HTTP/1.0\",\"Back\":\"HTTP/1.0\"}}}", newBuilder);

	}
	
	@Test
	public void testActionObjectPayload() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ActionDisconnect action1 = new ActionDisconnect();
		action1.setConnection("con1");
		action1.setId("id1");
		String newBuilder = roma.buildObjectRequest(action1);
//		System.out.println(newBuilder);
		assertEquals("{\"Disconnect\":{\"id\":\"id1\",\"connection\":\"con1\"}}", newBuilder);

		
		ActionFlushDocumentCache t = new ActionFlushDocumentCache();
		AnyActionElement tt = new AnyActionElement();
		tt.getActionObjects().add(t);
		DmReference v = new DmReference();
		v.setValue("XmlMgr-60sec");
//		v.setClazz("XMLManager");
		t.setXMLManager(v);
		
		try {
			System.out.println(roma.buildObjectRequest(tt));
			assertEquals("{\"FlushDocumentCache\":{\"XMLManager\":\"XmlMgr-60sec\"}}", roma.buildObjectRequest(tt));
		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
	
	@Test
	public void testModifyObjectPayload(){
		////////////////////////////////////////////////////////////
		//  TEST MODIFY OBJECTS
		//////////////////////////////////////////////////////////
				
		DmReference r1 =new DmReference();
		r1.setValue("blah1");
		DmReference r2 =new DmReference();
		r2.setValue("blah2");
		
		
		DmExtensionFunction ex1 = new DmExtensionFunction();
		ex1.setExtensionFunction("bfasf");
		ex1.setExtensionFunctionNamespace("bfasf");
		ex1.setLocalFunction("bfasf");
		ex1.setLocalFunctionNamespace("bfasf");
		
		DmExtensionFunction ex2 = new DmExtensionFunction();
		ex2.setExtensionFunction("bfas2f");
		ex2.setExtensionFunctionNamespace("bfas1f");
		ex2.setLocalFunction("bfa1sf");
		ex2.setLocalFunctionNamespace("bfas4f");
				
		AnyModifyElement m = new AnyModifyElement();
		ModifyXMLManager m2 = new ModifyXMLManager();
		m.getConfigObjects().add(m2);
		m2.setName("TestINg");
		m2.setSearchResults("blah");
		m2.getVirtualServers().add(r1);
		m2.getVirtualServers().add(r2);
		
		m2.getExtensionFunctions().add(ex1);
		m2.getExtensionFunctions().add(ex2);
		
		try {
		String newBuilder =roma.buildPropertyRequest(m, "SearchResults");
//		System.out.println(newBuilder);
		assertEquals("{\"SearchResults\":\"blah\"}", newBuilder);

//		System.out.println("============================================================");
		
		
		newBuilder =roma.buildPropertyRequest(m, "ExtensionFunctions");
//		System.out.println(newBuilder);
		assertEquals("{\"ExtensionFunctions\":[{\"ExtensionFunctionNamespace\":\"bfasf\",\"ExtensionFunction\":\"bfasf\",\"LocalFunctionNamespace\":\"bfasf\",\"LocalFunction\":\"bfasf\"},{\"ExtensionFunctionNamespace\":\"bfas1f\",\"ExtensionFunction\":\"bfas2f\",\"LocalFunctionNamespace\":\"bfas4f\",\"LocalFunction\":\"bfa1sf\"}]}", newBuilder);

//		System.out.println("============================================================");
		
		newBuilder =roma.buildPropertyRequest(m, "VirtualServers");
//		System.out.println(newBuilder);
		assertEquals("{\"VirtualServers\":[\"blah1\",\"blah2\"]}", newBuilder);

//		System.out.println("============================================================");
		
		newBuilder =roma.buildObjectRequest(m);
//		System.out.println(newBuilder);
		assertEquals("{\"XMLManager\":{\"SearchResults\":\"blah\",\"VirtualServers\":[\"blah1\",\"blah2\"],\"ExtensionFunctions\":[{\"ExtensionFunctionNamespace\":\"bfasf\",\"ExtensionFunction\":\"bfasf\",\"LocalFunctionNamespace\":\"bfasf\",\"LocalFunction\":\"bfasf\"},{\"ExtensionFunctionNamespace\":\"bfas1f\",\"ExtensionFunction\":\"bfas2f\",\"LocalFunctionNamespace\":\"bfas4f\",\"LocalFunction\":\"bfa1sf\"}],\"name\":\"TestINg\"}}", newBuilder);

//		System.out.println("============================================================");
		
		} catch (IllegalArgumentException | SecurityException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
		//Test Complex
		catch (IllegalAccessException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		} catch (NoSuchFieldException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		} catch (InvocationTargetException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}
	}

	@Test
	public void testPostFile() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		File file1 = new File();
		file1.setName("fil1");
		file1.setValue("fil1 content".getBytes());

		String newBuilder =roma.buildObjectRequest(file1);
//		System.out.println(newBuilder);
		assertEquals("{\"file\":{\"fil1 content\",\"name\":\"fil1\"}}", newBuilder);

	}
	
	@Test
	public void testAAABug() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		//Bug 
		//Getting: {"AAAPolicy":{"http-basic-auth":"on","AUPort":"7891","http-method":"on","name":"aaa-20151209162849"}
		//Expecting: {"AAAPolicy":{"ExtractIdentity":{"EIBitmap":{"http-basic-auth":"on"}},"AUPort":"7891","ExtractResource":{"ERBitmap":{"http-method":"on"}},"name":"aaa2"}}
		//Fix, forgot to wrap the recursive complex build property body call with the name of the complex property.
		
		ConfigAAAPolicy aaa = new ConfigAAAPolicy();
		aaa.setName("aaa-");
		aaa.setAuthenticate(new DmAAAPAuthenticate());
		aaa.getAuthenticate().setAUPort(7891);
		aaa.setExtractIdentity(new DmAAAPExtractIdentity());
		aaa.getExtractIdentity().setEIBitmap(new DmAAAPEIBitmap());
		aaa.getExtractIdentity().getEIBitmap().setHttpBasicAuth(DmToggle.ON);
		aaa.setExtractResource(new DmAAAPExtractResource());
		aaa.getExtractResource().setERBitmap(new DmAAAPERBitmap());
		aaa.getExtractResource().getERBitmap().setHttpMethod(DmToggle.ON);
		
		String newBuilder =roma.buildObjectRequest(aaa);
		System.out.println(newBuilder);
		assertEquals("{\"AAAPolicy\":{\"ExtractIdentity\":{\"EIBitmap\":{\"http-basic-auth\":\"on\"}},\"Authenticate\":{\"AUPort\":\"7891\"},\"ExtractResource\":{\"ERBitmap\":{\"http-method\":\"on\"}},\"name\":\"aaa-\"}}", newBuilder);
	}

	@Test
	public void testExportAction() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ActionRMIExport testExport = new ActionRMIExport();
		testExport.setFormat(DmRMIExportFormat.JSON);
		testExport.setAllFiles(DmToggle.ON);
		testExport.setPersisted(DmToggle.OFF);
		DmRMIImportDomain domain1 = new DmRMIImportDomain();
		domain1.setName("scott1");
		testExport.getDomain().add(domain1);
		DmRMIImportDomain domain2 = new DmRMIImportDomain();
		domain2.setName("scott2");
		testExport.getDomain().add(domain2);
		
		
		
		DmRMIExportObject e = new DmRMIExportObject();
		e.setName("loopback-firewall");
		e.setClazz("XMLFirewallService");
		e.setRefFiles(DmToggle.ON);
		e.setRefObjects(DmToggle.ON);
		e.setIncludeDebug(DmToggle.ON);
		
		DmRMIExportObject e2 = new DmRMIExportObject();
		e2.setName("loopback-firewall2");
		e2.setClazz("XMLFirewallService");
		e2.setRefFiles(DmToggle.ON);
		e2.setRefObjects(DmToggle.ON);
		e2.setIncludeDebug(DmToggle.ON);

		testExport.getObject().add(e);
		testExport.getObject().add(e2);
		
		String newBuilder =roma.buildObjectRequest(testExport);
		System.out.println(newBuilder);
		
	}

	@Test
	public void testImportAction() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ActionRMIImport testImport = new ActionRMIImport();
		testImport.setFormat(DmRMIImportFormat.ZIP);
		testImport.setInputFile("this would be a blob");
		testImport.setOverwriteFiles(DmToggle.ON);
		testImport.setDeploymentPolicy("newdp");
		testImport.setOverwriteObjects(DmToggle.ON);
		
		DmRMIImportFile file1 = new DmRMIImportFile();
		file1.setName("file1");
		file1.setOverwrite(DmToggle.OFF);
		testImport.getFile().add(file1);
		
		DmRMIImportFile file2 = new DmRMIImportFile();
		file2.setName("file2");
		file2.setOverwrite(DmToggle.ON);
		testImport.getFile().add(file2);
		
		DmRMIImportDomain domain1 = new DmRMIImportDomain();
		domain1.setName("domain1");
		domain1.setImportDomain(DmToggle.ON);
		domain1.setResetDomain(DmToggle.OFF);
		testImport.getDomain().add(domain1);
		
		DmRMIImportDomain domain2 = new DmRMIImportDomain();
		domain2.setName("domain2");
		domain2.setImportDomain(DmToggle.OFF);
		domain2.setResetDomain(DmToggle.ON);
		testImport.getDomain().add(domain2);
		
		
		DmRMIImportObject object1 = new DmRMIImportObject();
		object1.setName("object1");
		object1.setClazz("class");
		object1.setImportDebug(DmToggle.OFF);
		object1.setOverwrite(DmToggle.OFF);
		testImport.getObject().add(object1 );
		
		DmRMIImportObject object2 = new DmRMIImportObject();
		object2.setName("object2");
		object2.setClazz("class2");
		object2.setImportDebug(DmToggle.OFF);
		object2.setOverwrite(DmToggle.OFF);
		testImport.getObject().add(object2);
		
		String newBuilder =roma.buildObjectRequest(testImport);
		System.out.println(newBuilder);
		
		ActionRMIImport importXML = new ActionRMIImport();
		DmRMIImportObject man = new DmRMIImportObject();
		man.setClazz("StylePolicyAction");
		man.setName("testAction");
		importXML.getObject().add(man);
		importXML.setInputFile("InputFiletrest");
		importXML.setFormat(DmRMIImportFormat.XML); 
		System.out.println(roma.buildObjectRequest(importXML));

	}
	
	@Test
	public void test_Bug_ComplexArrayOfDmReferences() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigLogTarget testObject = new ConfigLogTarget();
		testObject.setName("what");
		testObject.setType("file");
		testObject.setFormat("text");
		testObject.setArchiveMode("upload");
		testObject.setUploadMethod("scp");
		testObject.setRemoteAddress("1.2.3.4");
		testObject.setRemoteLogin("ba");
		testObject.setRemotePassword("fds");
		testObject.setRemotePort("22");
		testObject.setSize("100");
		testObject.setLocalFile("logtemp://asdf");
		DmLogEvent scpEvent = new DmLogEvent();
		DmReference scpLabel = new DmReference();
		scpLabel.setClazz("LogLabel");
		scpLabel.setValue("all");
		scpEvent.setClazz(scpLabel);
		scpEvent.setPriority(DmLogLevel.DEBUG);
		testObject.getLogEvents().add(scpEvent);

		DmLogEvent scpEvent2 = new DmLogEvent();
		DmReference scpLabel2 = new DmReference();
		scpLabel2.setClazz("LogLabel");
		scpLabel2.setValue("system");
		scpEvent2.setClazz(scpLabel2);
		scpEvent2.setPriority(DmLogLevel.ERROR);
		testObject.getLogEvents().add(scpEvent2);
		
//		client.configRequest.createConfigObject(testObject);
//		ConfigLogTarget testObject2 = new ConfigLogTarget();
//
//		client.configRequest.loadConfigObject(testObject2, testObject.getName());
//		System.out.println(client.getLastResponse().getServerPayload());
//		System.out.println(payload.buildObjectRequest(testObject));
//		System.out.println(payload.buildObjectRequest(testObject2));
		
		assertEquals(this.roma.buildObjectRequest(testObject), ("{\"LogTarget\":{\"Type\":\"file\",\"Format\":\"text\",\"Size\":\"100\",\"LocalFile\":\"logtemp://asdf\",\"ArchiveMode\":\"upload\",\"UploadMethod\":\"scp\",\"RemoteAddress\":\"1.2.3.4\",\"RemotePort\":\"22\",\"RemoteLogin\":\"ba\",\"RemotePassword\":\"fds\",\"LogEvents\":[{\"Class\":\"all\",\"Priority\":\"debug\"},{\"Class\":\"system\",\"Priority\":\"error\"}],\"name\":\"what\"}}"));
	}
		
}
