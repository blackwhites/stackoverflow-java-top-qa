package junit;
import java.lang.reflect.InvocationTargetException;

import beans.RequestBean;
import tools.RMIClient;
import xmlManagement.AnyConfigElement;
import xmlManagement.ConfigHTTPSourceProtocolHandler;

public class test {

	static RMIClient client;
	static AnyConfigElement SourceProtocolHandlerObject;

	public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
		client = new RMIClient("dp513.dp.rtp.raleigh.ibm.com", 5554, "admin", "jan0111j", "syhtest");
		SourceProtocolHandlerObject = new AnyConfigElement();

		// -- start setup --
		ConfigHTTPSourceProtocolHandler testhandler = new ConfigHTTPSourceProtocolHandler();
		testhandler.setName("blorgh");
		testhandler.setLocalPort("88");
		SourceProtocolHandlerObject.getConfigObjects().add(testhandler);
		createObject(SourceProtocolHandlerObject);
		//-- end setup--

		//simply get configuration for the handler
		RequestBean response = client.configRequest.getConfigObject(SourceProtocolHandlerObject); //throws NoSuchFieldException

//		System.out.println(response.getServerPayload()); //looks like it works fine otherwise
		System.out.println(((ConfigHTTPSourceProtocolHandler)response.getResponseObject().getConfig().getConfigObjects().get(0)).getLocalPort());
		System.out.println(((ConfigHTTPSourceProtocolHandler)response.getResponseObject().getConfig().getConfigObjects().get(0)).getName());

		tearDown();
	}

	public static void tearDown() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{

		client.configRequest.deleteConfigObject(SourceProtocolHandlerObject);
		client.action.postAction("{\"SaveConfig\":{}}");

	}

	public static void createObject(AnyConfigElement ace) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		String s = client.payloadBuilder.buildObjectRequest(ace);

		RequestBean response = client.configRequest.createConfigObject(s,client.payloadBuilder.getClassName(ace).substring(6));
		System.out.println(response);
//		System.out.println("Payload Sent:\n" + s);
//		System.out.println("\nPayload Received:\n" + response.getServerPayload());
	}
}