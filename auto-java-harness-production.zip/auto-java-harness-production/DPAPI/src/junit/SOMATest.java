package junit;

import xmlManagement.Request;

public class SOMATest {
	
	Request r = new Request();
//	
//	@Test
//	public void test() {
//		r.setGetStatus(new GetStatus());
//		r.getGetStatus().setClazz(StatusEnum.HTTP_MEAN_TRANSACTION_TIME_2);
//		
//		try {
//			DPManagementClient dpclient = new DPManagementClient("dpvirt4a.dp.rtp.raleigh.ibm.com", "admin", "jan0111j","nick_BlueMix");
//			AnyStatusElement s=	dpclient.soma.getStatus(StatusEnum.SG_CLIENT_CONNECTION_STATUS).getResponseObject().getStatus();
//			for(int i=0;i<s.getStatusObjects().size();i++){
//				System.out.println(((StatusSGClientConnectionStatus)(s.getStatusObjects().get(i))).getBytesRcvd());
//			}
//		} catch (Exception e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		
//		
////		r.setDomain(value)
////		Response rr = new Response();
////		AnyStatusElement s = new AnyStatusElement();
////		StatusHTTPTransactions2 st = new StatusHTTPTransactions2();
////		
////		s.setHTTPTransactions2(st);
////		httpTransaction.getOneDay();
////		httpTransaction.getOneHour();
////		httpTransaction.getOneMinute();
////		httpTransaction.getProxy();
////		httpTransaction.getTenMinutes();
////		httpTransaction.getTenSeconds();
////		httpTransaction.getServiceClass();
//		
//		try {
//			System.out.println(this.p.buildSOMARequest(r));
////			System.out.println(this.p.getConfig("Domain", "default", "default"));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
////		String response = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
////		"<dp:response xmlns:dp=\"http://www.datapower.com/schemas/management\"><dp:timestamp>2015-05-12T11:27:45-04:00</dp:timestamp>"+
////	    "<dp:config><Domain xmlns:env=\"http://www.w3.org/2003/05/soap-envelope\" name=\"default\" intrinsic=\"true\" read-only=\"true\"><mAdminState read-only=\"true\">enabled</mAdminState><UserSummary read-only=\"true\">Default System Domain</UserSummary>"+
////"<FileMap read-only=\"true\"><CopyFrom>on</CopyFrom><CopyTo>on</CopyTo><Delete>on</Delete><Display>on</Display><Exec>on</Exec><Subdir>on</Subdir></FileMap>"+
////"<MonitoringMap read-only=\"true\"><Audit>off</Audit><Log>off</Log></MonitoringMap><ConfigMode read-only=\"true\">local</ConfigMode><ImportFormat read-only=\"true\">ZIP</ImportFormat><LocalIPRewrite read-only=\"true\">on</LocalIPRewrite>"+
////"<MaxChkpoints read-only=\"true\">3</MaxChkpoints></Domain></dp:config></dp:response>";
////		
////		try {
////			Response rr= this.p.getResponseObject(response);
////			
////			//Build XML Object
////			JAXBContext jc = JAXBContext.newInstance(Response.class);
////			Marshaller m = jc.createMarshaller();
////			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
////			m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
////			org.w3c.dom.Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
////			m.marshal(r, System.out);
////		} catch (Exception e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////		
//////		Response = this.p.loadPayload)
//////		
//////		TransformerFactory tf = TransformerFactory.newInstance();
//////		Transformer transformer = tf.newTransformer();
//////		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
//////		StringWriter writer = new StringWriter();
//////		transformer.transform(new DOMSource(document), new StreamResult(writer));
//////		String output2 = writer.getBuffer().toString().replaceAll("\n|\r", "");
//////		System.out.println(output2);//TODO
//
//	
//	}
}
