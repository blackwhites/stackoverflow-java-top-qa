package junit;

import org.junit.Test;

import tools.TerminalClient;

public class TerminalClientTest {

	@Test
	public void test_Windows() {
	
			TerminalClient tester = new TerminalClient("cmd.exe");
			tester.startSession();
			System.out.println(tester.getResponse("dir"));
			System.out.println(tester.getResponse("cd C:\\Users\\IBM_ADMIN\\Documents\\apachelogger"));//C:\Users\IBM_ADMIN\Documents\apachelogger
			System.out.println(tester.getResponse("dir"));
			System.out.println(tester.endSession());

	
	}

}
