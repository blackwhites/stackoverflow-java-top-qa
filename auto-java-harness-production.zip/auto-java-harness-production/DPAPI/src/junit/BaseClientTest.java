package junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

import tools.DPManagementClient;
import tools.HTTPClient;
import xmlManagement.ConfigDomain;
import xmlManagement.DmAdminState;
import xmlManagement.DmDomainFileMap;
import xmlManagement.DmReference;
import xmlManagement.DmToggle;

public class BaseClientTest {

	@Test
	public void test_isEqual_BaseClient() throws InvocationTargetException, NoSuchMethodException, SecurityException {
		DPManagementClient dp = new DPManagementClient(null,null,null,null);
		ConfigDomain d1 = new ConfigDomain();
		ConfigDomain d2 = new ConfigDomain();

		try {
			assertTrue(dp.isEqual(d1, d2));
			assertTrue(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			assertFalse(dp.isEqual(null, d1));
			assertFalse(dp.isEqual(d2, null));
			assertFalse(dp.isEqual(null, null));
			assert(false);//Shouldnt make it here
		} catch (IllegalArgumentException | IllegalAccessException e) {
			assertTrue(e.getMessage().equals("Error: Object o1 was null"));
		}
		
		try {
			assertFalse(dp.isEqual(d2, null));
			 assert(false);

		} catch (IllegalArgumentException | IllegalAccessException e) {
			assertTrue(e.getMessage().equals("Error: Object o2 was null"));
		}
		
		try {
			assertFalse(dp.isEqual(null, null));
			 assert(false);

		} catch (IllegalArgumentException | IllegalAccessException e) {
			assertTrue(e.getMessage().equals("Error: Object o1 was null"));
			
			
		}
		
		d1.setName("blah");
		
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		d2.setName("blah2");
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		d2.setName("blah");
		try {
			assertTrue(dp.isEqual(d1, d2));
			assertTrue(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		DmDomainFileMap fmap= new DmDomainFileMap();
		fmap.setCopyFrom(DmToggle.ON);
		fmap.setCopyTo(DmToggle.OFF);
		fmap.setDelete(DmToggle.ON);
		
		d1.setFileMap(fmap);
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		DmDomainFileMap fmap2= new DmDomainFileMap();
		fmap2.setCopyFrom(DmToggle.ON);
		fmap2.setCopyTo(DmToggle.OFF);
		fmap2.setDelete(DmToggle.ON);
		d2.setFileMap(fmap2);
		try {
			assertTrue(dp.isEqual(d1, d2));
			assertTrue(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		System.out.println("==========================================");
		d2.setMAdminState(DmAdminState.DISABLED);
		d1.setMAdminState(DmAdminState.ENABLED);
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		d2.setMAdminState(DmAdminState.ENABLED);
		try {
			assertTrue(dp.isEqual(d1, d2));
			assertTrue(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		DmReference ref = new DmReference();
		ref.setValue("adf");
		ref.setClazz("fda");
		d2.setDeploymentPolicy(ref);
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		

		DmReference ref2 = new DmReference();
		ref2.setValue("adf");
		ref2.setClazz("fda");
		d1.setDeploymentPolicy(ref2);
		try {
			assertTrue(dp.isEqual(d1, d2));
			assertTrue(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		ref2.setClazz("fdaadfdsa");
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		
		//Array Test
		ref2.setClazz("fda");
		d1.getDomainUser().add(ref);
		d1.getDomainUser().add(ref2);
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		d2.getDomainUser().add(ref);
		try {
			assertFalse(dp.isEqual(d1, d2));
			assertFalse(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		d2.getDomainUser().add(ref2);
		try {
			assertTrue(dp.isEqual(d1, d2));
			assertTrue(dp.isEqual(d2, d1));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}
		
		HelpTestObject o1 = new HelpTestObject();
		HelpTestObject o2 = new HelpTestObject();
		try {
			assertTrue(dp.isEqual(o1, o2));
			char[]c = new char[2];
			c[0]='p';
			c[1]='q';
			o2.setChar(c);
			assertFalse(dp.isEqual(o1, o2));
		} catch (IllegalArgumentException | IllegalAccessException e) {
			 assert(false);
		}

	}
	
	
	@Test
	public void test_SubStringRegEx(){
		DPManagementClient dp = new DPManagementClient(null,null,null,null);
		String response ="blah\nblah2\nblah3\nblah4\nblah5";
		String regExp ="\n";
		int regExIndex =1;
		boolean dotAll = false;
		
		
		assertEquals(dp.subStringFromRegExAt(response, regExp, regExIndex, dotAll),"blah2\nblah3\nblah4\nblah5");
		assertEquals(dp.subStringFromRegExAt(response, regExp, 4, dotAll),"blah5");
		assertEquals(dp.subStringFromRegExAt(response, regExp, 5, dotAll),"Error: RegExp only has 4 matches.  Index 5 is not valid.  RegExp: \n");
		assertEquals(dp.subStringFromRegExAt(null, regExp, 5, dotAll),null);
		assertEquals(dp.subStringFromRegExAt(response, null, 5, dotAll),null);
		assertEquals(dp.subStringFromRegExAt(response, regExp, 4, true),"blah5");
		assertEquals(dp.subStringFromRegExAt(response, regExp, 0, dotAll),null);
		assertEquals(dp.subStringFromRegExAt("", regExp, 5, dotAll),null);
		assertEquals(dp.subStringFromRegExAt(response, "", 5, dotAll),null);
		assertEquals(dp.subStringFromFirstRegEx(response, regExp, dotAll),"blah2\nblah3\nblah4\nblah5");
		assertEquals(dp.subStringFromLastRegEx(response, regExp, dotAll),"blah5");

		
	}
	@Test
	public void test_regExCount(){
		DPManagementClient dp = new DPManagementClient(null,null,null,null);
		String response ="blah\nblah2\nblah3\nblah4\nblah5";
		String regExp ="\n";
		boolean dotAll = false;
		
		
		assertEquals(dp.count(response, regExp, dotAll),4);
		assertEquals(dp.count(null, regExp, dotAll),-1);
		assertEquals(dp.count(response, null, dotAll),-1);
		assertEquals(dp.count(response, regExp, true),4);
		assertEquals(dp.count(response, "blahh", true),0);
		assertEquals(dp.count(response, "blah", true),5);

	}
	@Test
	public void test_regExGroups(){
		DPManagementClient dp = new DPManagementClient(null,null,null,null);
		String response ="blah\nblah2\nblah3\nblah4\nblah5";
//		String regExp ="\n";
		boolean dotAll = false;

		assertEquals(dp.getGroups(response, "blah[\\d]*", dotAll).size(),5);
		assertEquals(dp.getGroups(response, "blah[\\d]+", dotAll).size(),4);
		assertEquals(dp.getGroups(response, "qt", dotAll).size(),0);
		assertEquals(dp.getGroups(null, "qt", dotAll),null);
		assertEquals(dp.getGroups(response, null, dotAll),null);

	}
	
	@Test
	public void test_replace(){
		DPManagementClient dp = new DPManagementClient(null,null,null,null);
		String response ="blah\nblah2\nblah3\nblah4\nblah5";
		String regExp ="\n";
		boolean dotAll = false;
		
		
		assertEquals(dp.replaceFirst(response, regExp, "", dotAll),"blahblah2\nblah3\nblah4\nblah5");
		assertEquals(dp.replaceAll(response, regExp, "", dotAll),"blahblah2blah3blah4blah5");
		assertEquals(dp.replaceAll(response, "[\\d]+", "",dotAll),"blah\nblah\nblah\nblah\nblah");
		assertEquals(dp.replaceAll(response, "blah[\\d]+.+blah[\\d]+", "",true),"blah\n");
		assertEquals(dp.getRegEx(null, "blah[\\d]+", dotAll),null);
		assertEquals(dp.getRegEx(response, null, dotAll),null);
		
	}
	@Test
	public void test_getRegEx(){
		DPManagementClient dp = new DPManagementClient(null,null,null,null);
		String response ="blah\nblah2\nblah3\nblah4\nblah5";
		boolean dotAll = false;
		
		
		assertEquals(dp.getRegEx(response, "blah[\\d]+", dotAll),"blah2");
		assertEquals(dp.getRegEx(response, "blah[\\d]*", dotAll),"blah");
		assertEquals(dp.getRegEx(response, "[\\d]+", dotAll),"2");
		assertEquals(dp.getRegEx(null, "blah[\\d]+", dotAll),null);
		assertEquals(dp.getRegEx(response, null, dotAll),null);

	}
	@Test
	public void  test_ReadFile() throws IOException{
		HTTPClient c = new HTTPClient();
		System.out.println(c.readFile("C:\\Users\\IBM_ADMIN\\Perforce\\cncoble_ADMINIB-MOG38SB_7751\\main\\sqa\\java-harness\\src\\DPAPI", "testFileSOMAError.txt"));
	}
	@Test
	public void test_CLITrimResponse(){
		DPManagementClient dp = new DPManagementClient("sd","sd","sd","sd");
		dp.initSSH(22);
		
//		String response ="blah\nblah2\nblah3\nblah4\nblah5";
//		boolean dotAll = false;
		
		dp.ssh.lastCommand="blah\nblah2\n";
		dp.ssh.response="blah\nblah2\nblah3\nblah4\nblah5";
		assertEquals(dp.ssh.trimResponse(),"blah3\nblah4");

		dp.ssh.lastCommand="blah\nbsdfslah2\n";
		assertEquals(dp.ssh.trimResponse(),"blah3\nblah4");

	}
}
