package junit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

//import datatypes.Environment;

import beans.RequestBean;
import tools.RMIClient;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.ConfigDomain;
import xmlManagement.ConfigEnum;
import xmlManagement.ConfigHTTPSourceProtocolHandler;
import xmlManagement.ConfigMatching;
import xmlManagement.ConfigMultiProtocolGateway;
import xmlManagement.ConfigPolicyAttachments;
import xmlManagement.ConfigStylePolicy;
import xmlManagement.ConfigStylePolicyRule;
import xmlManagement.ConfigUserGroup;
import xmlManagement.ConfigXMLFirewallService;
import xmlManagement.ConfigXMLManager;
import xmlManagement.DmAdminState;
import xmlManagement.DmPolicyMap;
import xmlManagement.DmReference;
import xmlManagement.StatusActiveUsers;
import xmlManagement.StatusEnum;
import xmlManagement.StatusQuotaEnforcementStatus;

public class RMIClientTest {
	static String dpTarget = "dpvirt4c.dp.rtp.raleigh.ibm.com";
	static int rmiPort = 5554;
	static String userName = "admin";
	static String password = "jan0111j";
	static String domain = "default";
	static RMIClient test=null;
	
//	static Environment env; //= Environment.getInstance();
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
//		env = Environment.getInstance();
		test = new RMIClient(dpTarget, rmiPort, userName, password, domain);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void test_ActiveUsers_Status() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		RequestBean response = test.status.getStatus(StatusEnum.ACTIVE_USERS.value());
//		System.out.println(response.getServerPayload());
		AnyStatusElement statusList = response.getResponseObject().getStatus();
//		System.out.println("Size of list: " +  statusList.getStatusObjects().size());
		assertTrue(statusList.getStatusObjects().size()>0);
		for(int i=0;i< statusList.getStatusObjects().size();i++){
			StatusActiveUsers activeUser = (StatusActiveUsers)statusList.getStatusObjects().get(i);
			assertTrue(activeUser != null);
//			System.out.println(activeUser.getSession());
//			System.out.println(activeUser.getDomain());
		}
	}
	
	@Test
	public void test_disconnectActiveUsers() throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException{
		//TODO have active users in the specified domain for the test to pass
		ArrayList<StatusActiveUsers> response = (test.action).disconnectActiveUsers("default");
		
		assertTrue(response != null);
		assertTrue(response.size()>0);
		for(StatusActiveUsers user: response){
			System.out.println("Disconnected: " + user.getName() + " Session: " + user.getSession());
		}
	}
	
	@Test
	public void test_Load_Config_Object() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
		ConfigXMLManager testXMLManager = new ConfigXMLManager();
//		testXMLManager.setName("default");
		test.configRequest.loadConfigObject(testXMLManager, "default");
		
		Assert.assertTrue("Loaded Object Name", testXMLManager.getName().equals("default"));
		Assert.assertTrue("Loaded Object User Summary", testXMLManager.getUserSummary().equals("Default XML-Manager"));

		System.out.println(testXMLManager.getName());
		System.out.println(testXMLManager.getUserSummary());

	}
	
	@Test
	public void test_Getting_List_Of_Existing_Configs() throws IllegalArgumentException, IllegalAccessException{
			
		RequestBean response = test.configRequest.getExistingObjects(ConfigEnum.DOMAIN.value());
	//	System.out.println(response.getServerPayload());
	
		AnyConfigElement configList= response.getResponseObject().getConfig();
		assertTrue(configList.getConfigObjects().size()>0);
		assertTrue(configList.getConfigObjects().size()>1);
	//	System.out.println(response.getServerPayload());
		for(ConfigConfigBase config: configList.getConfigObjects()){
			System.out.println(((ConfigDomain)config).getName());
		}
		
		configList.getConfigObjects().clear();
		response = test.configRequest.getExistingObjects(configList, ConfigEnum.DOMAIN.value());
//		System.out.println(response.getServerPayload());
//		System.out.println(response.getResponseObject().getConfig().getConfigObjects().size());
//		assertTrue(configList.getConfigObjects().size()>0);
		for(ConfigConfigBase config: configList.getConfigObjects()){
			System.out.println(((ConfigDomain)config).getName());
		}
		
	}

	@Test
	public void test_createobject_with_simple_array() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		ConfigUserGroup testObject = new ConfigUserGroup();
		testObject.setName("testingRMIClient");
		testObject.getAccessPolicies().add("blah");
		
		RequestBean response = test.configRequest.createConfigObject(testObject);
		
		assertTrue("Verify RMI Client correctly builds JSON Payload", response.getClientPayload().equals("{\"UserGroup\":{\"AccessPolicies\":[\"blah\"],\"name\":\"testingRMIClient\"}}"));
		
		testObject.getAccessPolicies().add("blah2");
		response = test.configRequest.createConfigObject(testObject);
		assertTrue("Verify RMI Client correctly builds JSON Payload", response.getClientPayload().equals("{\"UserGroup\":{\"AccessPolicies\":[\"blah\",\"blah2\"],\"name\":\"testingRMIClient\"}}"));

		ConfigXMLManager manager = new ConfigXMLManager();
		manager.setName("testManager");
		System.out.println("Here");
		response = test.configRequest.createConfigObject(manager);
		System.out.println(response.getServerPayload());
		if(response.getResponseObject().getResult() != null){
			System.out.println(response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println(response.getResponseObject().getFault().getFaultstring());

		}else{
			assertTrue(false);
		}
		
		response = test.configRequest.deleteConfigObject(manager);
		System.out.println(response.getServerPayload());
		if(response.getResponseObject().getResult() != null){
			System.out.println(response.getResponseObject().getResult().getContent());
		}else if(response.getResponseObject().getFault() != null){
			System.out.println(response.getResponseObject().getFault().getFaultstring());

		}else{
			assertTrue(false);
		}
		
		
	}
	
	@Test
	public void test_Batch_PUT() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, IOException{

		ConfigXMLManager manager = new ConfigXMLManager();
		manager.setName("tc4_testManager");
		test.batchPut.addObjectToPayloadList(manager);
		
		test.batchPut.addFileToPayloadList("./", "test.txt", "local");
		
		RequestBean response = test.batchPut.sendBatchPut();
		
		System.out.println(response.getClientPayload());
		assertTrue(test.validJSON(response.getClientPayload()));
	}
	
	@Test
	public void test_Async_Action_Status(){
		RequestBean response = test.action.getAsyncActionStatus("ZulutIMESTAMP");
		System.out.println(response.getUrl());
	}
	
	@Test
	public void test_FileStore_GetLogFromAnchor(){
		String logAnchor = test.filestore.getLogAnchor("logtemp", "default-log");
		assertNotNull(logAnchor);
		assertTrue(!logAnchor.isEmpty());
		
		String logFromAnchor = test.filestore.getLogFromAnchor("logtemp", "default-log", logAnchor);
		assertNotNull(logFromAnchor);
		assertTrue(!logFromAnchor.isEmpty());
		
		System.out.println(test.filestore.getLog("logtemp", "default-log"));
		
		System.out.println(test.getLastResponse().getUrl());
	}

	@Test
	public void test_Get_MPGW() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		//Create test gateway
		 ConfigHTTPSourceProtocolHandler testhandler = new ConfigHTTPSourceProtocolHandler();

	 ConfigHTTPSourceProtocolHandler testhandler2 = new ConfigHTTPSourceProtocolHandler();
	 ConfigMatching matching = new ConfigMatching();
	 ConfigStylePolicyRule rule = new ConfigStylePolicyRule();
	 ConfigStylePolicy mpgwPolicy = new ConfigStylePolicy();
	 ConfigPolicyAttachments pattach = new ConfigPolicyAttachments();
	 ConfigMultiProtocolGateway testmpgw = new ConfigMultiProtocolGateway();
	 DmReference handler = new DmReference();
	 DmReference handler2 = new DmReference();
		testhandler.setName("blorgh");
		testhandler.setLocalPort("7891");
		testhandler.setMAdminState(DmAdminState.ENABLED);
		test.configRequest.createConfigObject(testhandler);

		testhandler2.setName("blergh");
		testhandler2.setLocalPort("7892");
		testhandler2.setMAdminState(DmAdminState.ENABLED);
		test.configRequest.createConfigObject(testhandler2);

		test.action.postAction("{\"SaveConfig\":{}}");

		matching.setName("testMatching");
		test.configRequest.createConfigObject(matching);

		//this ConfigPolicyRule should be down from the get-go
		rule.setName("testRule");
		test.configRequest.createConfigObject(rule);

		//map rule to matching
		DmReference ruleRef = new DmReference();
		ruleRef.setClazz("StylePolicyRule");
		ruleRef.setValue("testRule");
		DmReference matchRef = new DmReference();
		matchRef.setClazz("Matching");
		matchRef.setValue("testMatching");

		DmPolicyMap testPolicyMap = new DmPolicyMap();
		testPolicyMap.setMatch(matchRef);;
		testPolicyMap.setRule(ruleRef);

		//set policy map
		mpgwPolicy.setName("testPolicy");
		mpgwPolicy.getPolicyMaps().add(testPolicyMap);
		test.configRequest.createConfigObject(mpgwPolicy);

		pattach.setName("gurgle");
		test.configRequest.createConfigObject(pattach);

		//finally, create MPGW
		System.out.println("\tSetting up MPGW...\n");
		testmpgw.setName("bleh");
		testmpgw.setType("static-backend");
		testmpgw.setBackendUrl("http://127.0.0.1:2068");
		DmReference policy = new DmReference();
		policy.setClazz("StylePolicy");
		policy.setValue("default");
		testmpgw.setStylePolicy(policy);
		handler.setClazz("HTTPSourceProtocolHandler");
		handler.setValue("blorgh");
		handler2.setClazz("HTTPSourceProtocolHandler");
		handler2.setValue("blergh");
		testmpgw.getFrontProtocol().add(handler);
		testmpgw.getFrontProtocol().add(handler2);
//		DmReference attachments = new DmReference();
//		attachments.setClazz("PolicyAttachments");
//		attachments.setValue("gurgle");
//		testmpgw.setPolicyAttachments(attachments);
		test.configRequest.createConfigObject(testmpgw);
		try {
			RequestBean response = test.configRequest.getConfigObject(testmpgw,"state=1");
			System.out.println(response);
		} catch (IllegalArgumentException | IllegalAccessException
				| NoSuchFieldException | SecurityException
				| InvocationTargetException | NoSuchMethodException
				| ClassNotFoundException | InstantiationException e) {
			e.printStackTrace();
			assertFalse(true);
		}
		
		
	}

	@Test
	public void test_QuotaEnforcement_Status(){

		try {
			RequestBean response = test.status.getStatus(StatusEnum.QUOTA_ENFORCEMENT_STATUS);
			System.out.println(response.getURI());
			System.out.println(response.getServerPayload());
			StatusQuotaEnforcementStatus status =  (StatusQuotaEnforcementStatus) response.getResponseObject().getStatus().getStatusObjects().get(0);
			System.out.println(status.getConnectedSlaves());
			System.out.println(status.getKeys());
			System.out.println(status.getMode());
			System.out.println(status.getRole());
			System.out.println(status.getSize());


		} catch (NoSuchMethodException | SecurityException
				| ClassNotFoundException | IllegalAccessException
				| InstantiationException | IllegalArgumentException
				| InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void test_ResponseObject_File(){
		RequestBean r = test.filestore.getFile("local", "export.zip");
		System.out.println(r.getResponseObject().getFile().get(0).getValueAsString());
		
	}
	
	@Test
	public void test_DownloadFile() throws IOException{
//		Converter c = new Converter();
//		String zipFile = "UEsDBBQAAAAIACpzmUhI4uwniQMAAM8IAAAKABwAZXhwb3J0LnhtbFVUCQADEGEeVxBhHld1eAsAAQQAAAAABAAAAACNVttu4zgMfc9XGH635WvTBoqAbpPFLNAuikkHM6+KzSQCLNmQ5CSdr1/aTmM7F+zkJSZ5DkVSJG2ac8ur8gDay0q1EdtacytK5exBG/yfu7HLKByrUlsvB8tFYRjNwWRaVA2QLVsb5M7LkE/JEENrA5rxXAo0tM80LyUXiuWw4XVhEd7JNCulBGUJo5Uu8zqznshZOo1SSgaKLyP79U8anC3oVZiq4J/ewByh7wstlWUOBVtg6u9N6k7npdOefdwADXx9gWEvMvAUl8Dyai+0TaHJvddSTFfwwlO1XGPiQfejZKymG6HlgWvwToVvM/OnfuoHPqKvzOcwbxGjnngX1p+4rkWRM4kwBX40TaeP08GBnbVHWyHBWC4rFgXhAwkSEkVOGM3idBYOA+1xNKu1xjv1sNegZXlB4jU3OjKcYQ2ThcksSmdR4CwXHz2wNVENBm54G6hPkM5TPAuCWXzyNDDQotwK5WGYhm+BNAEYW0qvFlitolGQy8YXyoLecLzbZm4GstPc9dwFuwtcx35W+Ly0O9AKrNvO0twV1T5xHVF5PM/13H3y46kfxoEfBVOX3HQV/qGrEJ2kqR8GoT99anyRyzjHs93N2tw9DR8O+K+31zeusAr6dPqXyUFPWigjsrlrdQ2uc5SFMjNQ+7m7s7aaEXI4HPxD7Jd6S6IgiEmQElPyykMMFGV15uTViHLePD7OPDHZDiQ3RLZhNCvAZRMqn5udsbLNnYLi6wJynNOBckJ/4CCtaim5/mSLLmoH0/FO+VAyBEzoC8eDVuI3tk76QEkvTujq23PYyEJtWbPBhjJa8TyRLcqsboJ74QX2Q4u6oUc0cJ3tvoPBcE64kQYRddX01sfxJ9eKlZsNQkaqCX0DWYrf7Z21LobyhL5zjZm9Cims+evTglllXCnIWRI+JXGQUHIXMSYvi7beC6jsjqVhNCaOrGPis8XeWNcWXspaWRZGj2PqhX1MfuPHf3GHtrWP4zRNkvji5CFizP271GuRL4/Y5IoX32EDuB0y6Ar9R8CLClwDNi3zohT/5wcjftewEUe0hEGUXOVztl7XAsfOVDy7xxzYr7ivZcaLFsAeupfLfcCEYqu2XY96fDQsbRmX2h7X1n+AON0Hioj9qQX2FYuj6cNjC+l13Wg+b7F5nKzgBvfWt4+P97PS7V/+Zx2urn4VoTDaW81LqADT7Lc7Xy3sP1BLAQIeAxQAAAAIACpzmUhI4uwniQMAAM8IAAAKABgAAAAAAAEAAACAgQAAAABleHBvcnQueG1sVVQFAAMQYR5XdXgLAAEEAAAAAAQAAAAAUEsFBgAAAAABAAEAUAAAAM0DAAAAAA==";
		test.filestore.downloadFile("local", "export.zip", "C:", "export.zip", StandardCharsets.ISO_8859_1.name());
//System.out.println(StandardCharsets.ISO_8859_1.name());
	}

	@Test
	public void test_EnableProbe() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{

		
		
		ConfigXMLFirewallService configObject = new ConfigXMLFirewallService();
		configObject.setName("xmlfw-sql-failover-1");
//		configObject.setDebugMode("on");
//		configObject.setLocalPort("9999");
//		configObject.setRemotePort("3223");
//		configObject.setHTTPProxyHost("https://blah.com");
//		configObject.setHTTPProxyPort("21233");
//		configObject.setRemoteAddress("https://blah.com");
		RequestBean response = test.configRequest.getConfigObject(configObject);//.createConfigObject(configObject);
		configObject.setName("testingProbe2");
		configObject.setDebugMode("on");
		response = test.configRequest.modifyConfigObject(configObject);
		System.out.println(response.getStatus());
		System.out.println(response.getClientPayload());
		System.out.println(response.getServerPayload());
		
	}

	@Test
	public void test_CreateFile(){
		String logAN = test.filestore.getLogAnchor("logtemp", "default-log");
		test.filestore.createEncodedFile("cert", "explorys_sslcer1.crt", "ERTWEFdfgerfnkeldkfo2efUJKIYJUGHFG==");
System.out.println(test.getLastResponse());
System.out.println(test.filestore.getLogFromAnchor("logtemp", "default-log", logAN));
//test.filestore.createEncodedFile("sharedcert", "te_stww.txt", "ERTWEFdfgerfnkeldkfo2efUJKIYJUGHFG==");
//System.out.println(test.getLastResponse());
//test.filestore.createEncodedFile("pubcert", "te_stw.txt", "ERTWEFdfgerfnkeldkfo2efUJKIYJUGHFG==");
//System.out.println(test.getLastResponse());

	}

}
