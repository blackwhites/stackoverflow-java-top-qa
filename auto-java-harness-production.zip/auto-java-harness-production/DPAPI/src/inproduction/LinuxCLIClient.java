package inproduction;

import java.io.File;
import java.security.InvalidParameterException;

import tools.SSHClient;

/**
 * 
 * @author nickCoble
 *
 */
public class LinuxCLIClient extends SSHClient{

	public LinuxCLIClient(String hostName, int port, String userName, String password) throws InvalidParameterException {super(hostName, port, userName, password);}
	
	public String appendToFile(String textToAppend, String pathToFile, String fileName, int timeOutMilli){
		String tmp = this.getResponse("echo \""+ textToAppend +"\" | sudo tee -a " + pathToFile + File.separatorChar + fileName, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		
		return tmp;
	}
	
	public String overWriteFile(String textToWrite, String pathToFile, String fileName, int timeOutMilli){
		String tmp = this.getResponse("echo \""+ textToWrite +"\" | sudo tee " + pathToFile + File.separatorChar + fileName, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		
		return tmp;
	}
	
	public String getLastLinesOfFile(int numberOfLinesToGet, String pathToFile, String fileName, int timeOutMilli){
		String tmp = this.getResponse("sudo tail -n \""+ numberOfLinesToGet +" " + pathToFile + File.separatorChar + fileName, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		
		return tmp;
	}
	
	public String fileContainsString(String stringToSearchFor, String pathToFile, String fileName, int timeOutMilli){
		String tmp = this.getResponse("sudo grep -q "+ stringToSearchFor + " " + pathToFile + File.separatorChar + fileName, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		
		return tmp;
	}

	public String replaceStringInFile(String stringToReplace, String replacementString, String pathToFile, String fileName){
		//TODO Sed command
		return null;
	}
	
	public boolean fileExist(String pathToFile, String fileName){
		this.getResponseTrim("[ -a " + pathToFile + "/" + fileName + " ];echo $?");
		return this.getLastResponse().equals("0");
	}
	
	public String removeFile(String pathToFile, String fileName, int timeOutMilli){
		String tmp = this.getResponse("sudo rm "+ pathToFile + File.separatorChar + fileName, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		return tmp;
	}
	
	public String copyFile(String pathToFile, String fileName, String pathToCopy, String fileNameCopy, int timeOutMilli){
		String tmp = this.getResponse("sudo cp "+ pathToFile + File.separatorChar + fileName + " " + pathToCopy + File.separatorChar + fileNameCopy, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		return tmp;
	}
	
	public String moveFile(String pathToFile, String fileName, String pathToMove, String fileNameMove, int timeOutMilli){
		String tmp = this.getResponse("sudo cp "+ pathToFile + File.separatorChar + fileName + " " + pathToMove + File.separatorChar + fileNameMove, timeOutMilli);
		if(this.response.trim().endsWith("[sudo] password for " + this.getUserName() + ":")){//TODO place holder, not real value
			tmp += this.getResponse(this.password);
		}
		return tmp;
	}
		
	public int lastCommandExitValue(){
		return Integer.valueOf(this.getResponseTrim("echo $?"));
	}
	
	public int countWordsInFile(String file){
		return Integer.valueOf(this.getResponseTrim("wc " + file + " | awk '{print $3-$1}'"));
	}
	//Count Number of Words in file: wc <filename> | awk '{print $3-$1}'
	
}
