package inproduction;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import tools.CLIClient;
import variables.CLIVariables;

public class SSHClientFactory {

	protected JSch jsh = new JSch();
	protected ArrayList<SSHSession> sessions = new ArrayList<>();
	private String strictHostCheck = "no";

	public SSHSession getSession(String hostName, int port,String userName,String password){
		
		try {
			//Create Session
			SSHSession ss = new SSHSession(this.jsh.getSession(userName,hostName,port), hostName, port, userName, password, this.strictHostCheck);
			this.sessions.add(ss);
			return (ss);
		} catch (JSchException e) {
			e.printStackTrace();
			
		} 
		
		return null;
	}
	
	public boolean closeAllSessions(){
		boolean pass=true;
		for(SSHSession s: this.sessions){
			if(s != null && !s.endSession()){
				pass = false;
			}
			
			s = null;
		}
		
		this.sessions.clear();
		
		return pass;
	}

	/**
	 * True if you want to be prompted to accept host key, false otherwise
	 * @param check
	 */
	public void setStrictHostCheck(boolean check){
		if(check){
			this.strictHostCheck="yes";
		}else{
			this.strictHostCheck="no";
		}
	}
	
	/**
	 * Used instead of password auth, must include path with file name.
	 * @param keyFile: Path to and name of keyfile
	 * @return
	 */
	public boolean setKeyFile(String pathToKeyFile, String keyFileName){
		if(pathToKeyFile == null || keyFileName == null || keyFileName.equals("")){return false;}
		
		try {
			this.jsh.addIdentity(pathToKeyFile + "/" + keyFileName);
			return true;
		} catch (JSchException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public class SSHSession extends CLIClient{
		
		protected PipedOutputStream pin; 
		protected PipedInputStream pout;
		protected InputStream in;// =new PipedInputStream(100000);
		protected OutputStream out;// = new PipedOutputStream();
		protected Session session;
		protected ChannelShell channel;
		public boolean loggedIn =false;
		public boolean established = false;
		long responseBytes = 0;
		long charTimeOut = 10000;//milliseconds.  Used to time out from last character read during getResponse()
		long totalTimeOut = 60000;//Total time to get response, default 1 min
		int bufferSize = 100000;//Default buffer for the read from stream pipe
		String hostName=null;
		String password= null;
		String userName=null;
		String errorMessage =null;
		int port =0;
		private String response=null;
		public String lastCommand=null;
		public int lastHexCommand=-1;
//		private String domain=null;
		private String strictHostCheck=null;
		
		public SSHSession(Session session, String hostName, int port, String userName, String  password, String strictHostCheck){
			this.hostName = hostName;
			this.port = port;
			this.userName =userName;
			this.password = password;
			this.session = session;
			this.strictHostCheck=strictHostCheck;
			this.startSession();
		}


		/**
		 * Method to establish an ssh session
		 * Handles logging into remote host
		 * @return boolean
		 */
		public boolean startSession(){
			
			try {
				//Check session is not already open, if so close it 
				if((this.session != null && this.session.isConnected()) || (this.channel != null && this.channel.isConnected())){this.endSession();}
				
				in =new PipedInputStream(5000);
				out = new PipedOutputStream();
				try {
					pin = new PipedOutputStream((PipedInputStream)in);
					pout = new PipedInputStream((PipedOutputStream)out,bufferSize);
				} catch (IOException e) {
					e.printStackTrace();
					this.errorMessage = e.getMessage();
					return false;
				}
				
				//Connect Session
				this.session.setPassword(this.password);
				this.session.setConfig("StrictHostKeyChecking", this.strictHostCheck);		
				this.session.connect();
				
				//Open Channel
				this.channel = (ChannelShell) this.session.openChannel("shell");
				this.channel.setPtyType("dumb");
			    this.channel.setInputStream(in);
				this.channel.setOutputStream(out);
				this.channel.connect();
				
				return (this.established=true);
			} catch (JSchException e) {
				e.printStackTrace();
				this.errorMessage= e.getMessage();
				return (this.established = false);
			} 
		}
		
		/**
		 * Does a series of checks to see if client is connected to remote host
		 */
		public boolean isConnected(){return (this.channel!=null && this.channel.isConnected() && this.loggedIn && this.established);}
		
		/**
		 * Sets the buffer size of the pipes used, larger buffers will increase the transfer speed of larger sets of data
		 * @param size
		 */
		public void setBufferSize(int size){
			if(size<1){return;}
			this.bufferSize=size;
			try {
				pout = new PipedInputStream((PipedOutputStream)out,this.bufferSize);
			} catch (IOException e) {
				e.printStackTrace();
				this.errorMessage = e.getMessage();
				System.out.println("Error Resetting output pipe. \n"+e.getMessage());
			}
		}
			
		/**
		 * Method to close the ssh session
		 * @return boolean
		 */
		public boolean endSession(){
			if(this.channel!=null && this.channel.isConnected()){
				while(!this.channel.isClosed()){
					this.getResponse("exit");
					if(!this.response.toLowerCase().contains("goodbye")){
						break;
					}
				}}
			
			if(this.session!=null){this.session.disconnect();}else{this.errorMessage="Unable to close session, object was null.";}
			if(pin != null){
				try {
					pin.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				pin=null;
			}
			
			if(pout != null){
				try {
					pout.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				pout=null;
			}
			
			if(in!=null){
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				in=null;
			}
			
			if(out!=null){
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				out=null;
			}

			if(this.channel!=null && this.session!=null){
				boolean r = this.channel.isClosed() && !this.session.isConnected();
				this.established = this.loggedIn= false;
				return r;
			}else{
				return (this.established = this.loggedIn= false);
			}
		}
		
		/**
		 * Method to get cli response from remote service.
		 * Times out according to global variable totalTimeOut
		 * @return String
		 */
		public String getResponse(){return this.getResponse((int)this.totalTimeOut);}
		
		/**
		 * Gets response 
		 * Specify time out in milliseconds
		 * @param timeOut
		 * @return
		 */
		public String getResponse(int timeOutMilli){
			if(timeOutMilli < 1){return null;}
			this.response = "";
			String tmpHolder="";
			StringBuilder stringBuilder= new StringBuilder();
			long startTime = System.currentTimeMillis();
			boolean doublecheck =false;
			boolean startedReading = false;
			if(this.channel==null || this.channel.isClosed()){return "ERROR: Unable to get response, channel is closed.\n";}
			try {
				while(true){
					if((this.pout.available()>0)){
	//System.out.println(this.pout.available());
						startedReading = true;
						doublecheck =false;
						while(this.pout.available()>0){
							int i = pout.read();
	//System.out.print(i +" = ");
	//System.out.println(((char)i));
							if(i<0){
								break;
							}else{
								stringBuilder.append((char)i);
							}
						}
						
						if((System.currentTimeMillis() - startTime > timeOutMilli)){
							stringBuilder.append("\nERROR: Timed Out("+ timeOutMilli +").\n");
							break;
						}
						
					}else{
//		System.out.println("Double Check: " + doublecheck);
						if(!doublecheck){//Gives buffer a chance to fill back up incase end of response check is a false positive
//		System.out.println("Double Check Wait");
//		System.out.println(stringBuilder.toString());
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
	//System.out.println("Double Check Wait Finished");

							doublecheck=true;
							continue;
						}
						
						if(startedReading){
							tmpHolder = stringBuilder.toString();
							if((tmpHolder.endsWith(": ") || tmpHolder.endsWith("# ") || tmpHolder.endsWith("> ") || tmpHolder.endsWith("$ ") || tmpHolder.endsWith(") ")|| tmpHolder.endsWith("? "))){
//							System.out.println("Checking EOL: " + tmpHolder.substring(tmpHolder.length()-2));
//							if(this.endOfLineMarkers.contains(tmpHolder.substring(tmpHolder.length()-2))){
							//System.out.println("End Of Response Check");

								break;
							}
						}

						if(System.currentTimeMillis() - startTime > timeOutMilli){
							stringBuilder.append("\nERROR: Timed Out("+ timeOutMilli +").\n");
							break;
						}

						if(this.channel.isClosed()){
							if(!stringBuilder.toString().toLowerCase().contains("goodbye")){
								stringBuilder.append("\nERROR: Channel was closed unexpectedly.\n");
							}
							break;
						}else{
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
				
				}
			} catch (IOException e) {
				e.printStackTrace();
				this.errorMessage = e.getMessage();
				stringBuilder.append("\nERROR getting response: " + e.getMessage() + "\n");
			}
			
			this.response = stringBuilder.toString().replace("\r\n", "\n").replace("\r", "");
			this.responseBytes = this.response.getBytes().length;
	//System.out.println();
	//System.out.println(this.response);
	//System.out.println("==================================================================================================");
			return this.response;
		}
		
		/**
		 * Returns the response to the provided command.
		 * @param command
		 * @return String
		 */
		public String getResponse(String command){
			if(command==null){return null;}
			if(this.sendCommand(command)){
				return this.getResponse();
			}else{
				return "ERROR: Unable to send the " + command +  " command.\n";
			}
		}
		
		/**
		 * Returns the response to the provided command.
		 * Specify time out in milliseconds
		 * @param command
		 * @param timeOutMilli
		 * @return
		 */
		public String getResponse(String command, int timeOutMilli){
			if(command == null || timeOutMilli < 1){return null;}
			if(this.sendCommand(command)){
				return this.getResponse(timeOutMilli);
			}else{
				return "ERROR: Unable to send the " + command +  " command.\n";
			}
		}
		
		/**
		 * Method to send commands to appliance.
		 * @param command:String
		 * @return boolean
		 */
		public boolean sendCommand(String command){
			if(command == null){return false;}
			this.lastCommand = command + "\n";
			if(this.channel.isConnected()){
				try {
					pin.write(this.lastCommand.getBytes());
					pin.flush();
					return true;
				} catch (IOException e) {
					this.errorMessage = e.getMessage();
					e.printStackTrace();
				}
			}
			return false;
		}
		
		/**
		 * Send Ctrl type Commands using hex or int number code
		 * IE: Ctrl-C = 3
		 * Table of codes at http://www.nthelp.com/ascii.htm list
		 * @param n
		 * @return boolean
		 */
		public boolean sendCommand(int n){
			if(n<0){return false;}
			this.lastHexCommand = n ;
			if(this.channel.isConnected()){
				try {
					pin.write(n);
					pin.flush();
					return true;
				} catch (IOException e) {
					this.errorMessage = e.getMessage();
					e.printStackTrace();
				}
			}
			return false;
		}
		
		/**
		 * Returns a array of Strings found in the response String that matched the provided regExp
		 * @param response
		 * @param regExp
		 * @return
		 */
		public ArrayList<String> getGroupsFromLastResponse(String regExp){
			if(regExp==null || regExp.equals("")){return null;}
			ArrayList<String> tmp = new ArrayList<>();
			Pattern p = Pattern.compile(regExp, Pattern.DOTALL);
			Matcher m = p.matcher(this.response);

			while(m.find()){
			   tmp.add(m.group(0));
			}
			return tmp;
		}

		/**
		 * Attempts to log in to a DP appliance
		 * @param domain
		 * @throws Exception
		 */
		public boolean loginDP(String domain){
			if(domain==null || domain.equals("")){return false;}
			
			this.domain=domain;
			
			//Establish connection if not already
			if(this.channel ==null || !this.channel.isConnected()){
				if(!this.startSession()){
					this.errorMessage="Unable to establish ssh session." + this.errorMessage;
					System.out.println(this.errorMessage);
					return (this.established=this.loggedIn=false);
				}
			}
			
	System.out.println(this.userName);
	System.out.println(this.password);
	System.out.println(domain);
			
			//Attempt to log in
			if(!CLIVariables.loginPrompt.matcher(this.getResponse()).find() && !this.response.equals("\nERROR: Get Response Timed Out("+ this.totalTimeOut +").\n")){
	System.out.println(this.response);
				this.errorMessage="Unable to access login prompt.  Expected: " + CLIVariables.loginPrompt.toString() + ", Recieved: " + this.response;
				//System.out.println(this.errorMessage);
				return (this.loggedIn=false);
			}else if(!CLIVariables.passwordPrompt.matcher(this.getResponse(this.userName)).find()){
	System.out.println(this.response);
				this.errorMessage="Unable to access password prompt.  Expected: " + CLIVariables.passwordPrompt.toString() + ", Recieved: " + this.response;
//				System.out.println(this.errorMessage);
				return (this.loggedIn=false);
			}else if(!CLIVariables.domainPrompt.matcher(this.getResponse(this.password)).find()){
	System.out.println(this.response);

				if(!CLIVariables.welcomeMessage.matcher(this.response).find()){
	System.out.println(this.response);
					this.errorMessage="Unable to access welcome prompt1.  Expected: " + CLIVariables.welcomeMessage.toString() + ", Recieved: " + this.response;
//					System.out.println(this.errorMessage);
					return (this.loggedIn=false);
				}else{

					this.getResponse("switch domain " + domain);
	System.out.println(this.response);

				}
				
			}else if(!CLIVariables.welcomeMessage.matcher(this.getResponse(domain)).find()){
	System.out.println(this.response);
				this.errorMessage="Unable to access welcome prompt2.  Expected: " + CLIVariables.welcomeMessage.toString() + ", Recieved: " + this.response;
				System.out.println(this.errorMessage);
				return (this.loggedIn=false);
			}
			
			return (this.loggedIn=true);
		}
		
		/**
		 * Returns the number of bytes in the response
		 * @return
		 */
		public long getResponseBytes(){return this.responseBytes;}

		/**
		 * Returns the host key of the server
		 * @return
		 */
		public String getHostKey(){
			return this.session.getHostKey().getKey();

		}
		
		/**
		 * Returns the ssh version used by the server
		 * @return
		 */
		public String getServerSSHVersion(){
			return this.session.getServerVersion();
		}
		
		/**
		 * Returns the ssh version used by the client
		 * @return
		 */
		public String getClientSSHVersion(){
			return this.session.getClientVersion();
		}
		
		/**
		 * returns the exit status of the session
		 * @return
		 */
		public int getExitStatus(){
			return this.channel.getExitStatus();
		}
		
		/**
		 * Method to trim off the command sent and command line prompt of the last response
		 * @return String
		 */
		public String trimResponse(){
			if(this.response == null){
				return null;
			}else if(this.response.equals("")){
				return this.response;
			}else{
				String tmp = this.response.substring(this.lastCommand.length());//.replace(this.lastCommand +"\n", "");
				
				if(tmp.contains("\n")){
					tmp = tmp.substring(0, tmp.lastIndexOf("\n"));
				}

				return this.response = tmp;
			}
			
		}
		
		
		
	}

}
