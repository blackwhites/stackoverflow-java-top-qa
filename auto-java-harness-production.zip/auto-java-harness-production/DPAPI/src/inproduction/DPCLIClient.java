package inproduction;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import tools.CLIClient;
import tools.DPManagement;
import tools.SSHClient;
import tools.TelnetClient;
import variables.CLIVariables;
import variables.DPVariables;

/**
 * Incomplete, waiting for DPLogger to be completed.
 * Class to connect to a DP appliance using telnet or ssh.<br/>
 * Sample:<br/>
 	&emsp;public boolean helloWorldTelnet(){  <br/>
 	&emsp;&emsp;	DPCLIClient telnetClient = null;
 	&emsp;&emsp;				try{<br/>
 	&emsp;&emsp;&emsp;					telnetClient = new DPCLIClient("dpvirt4a.dp.rtp.raleigh.ibm.com", 23, "admin", "admin1", "testDomain", "telnet");<br/>
 	&emsp;&emsp;				}catch(Exception e){<br/>
 	&emsp;&emsp;&emsp;					e.printStackTrace();<br/>
 	&emsp;&emsp;&emsp;					return false;<br/>
 	&emsp;&emsp;				}<br/>
 					
 	&emsp;&emsp;	if(!telnetClient.loginDP("default){<br/>
 	&emsp;&emsp;&emsp;		telnetClient.endSession();<br/>
 	&emsp;&emsp;&emsp;		return false;<br/>
 	&emsp;&emsp;	}<br/><br/>
 		
 	&emsp;&emsp;	System.out.println(telnetClient.getResponse("show version"));<br/>
 	&emsp;&emsp;	telnetClient.endSession();<br/>
 	&emsp;			}<br/><br/><br/>
 	
 	&emsp;		public boolean helloWorldSSH(){  <br/>
 	&emsp;&emsp; 	DPCLIClient sshClient = null;<br/>
  	&emsp;&emsp;	try{<br/>
 	&emsp;&emsp;		sshClient = new DPCLIClient("dpvirt4a.dp.rtp.raleigh.ibm.com", 22, "admin", "admin1", "testDomain", "ssh");<br/>
 	&emsp;&emsp;	}catch(Exception e){<br/>
 	&emsp;&emsp;&emsp;	e.printStackTrace();<br/>
 	&emsp;&emsp;&emsp;	return false;<br/>
 	&emsp;&emsp;	}<br/>
 
 &emsp;&emsp;		if(!sshClient.startSession(){<br/>
 	&emsp;&emsp;&emsp;		sshClient.endSession();<br/>
 	&emsp;&emsp;&emsp;		return false;<br/>
 	&emsp;&emsp;	}<br/>
 	&emsp;&emsp;	System.out.println(sshClient.getResponse());//Gets log in response<br/>

 	&emsp;&emsp;	System.out.println(sshClient.getResponse("ls -latr"));<br/>
 	&emsp;&emsp;	sshClient.endSession();<br/>
 	&emsp;}<br/>
 * @author nickCoble
 *
 */
public class DPCLIClient extends DPManagement{
	protected CLIClient cli=null;
	protected boolean loggedIn=false;
	public String errorMessage="";
	public String userName="";
	public String password="";
	public String domain="";
	protected final String buildFileDir = "image";
	protected final String buildFileName="i";
	
	public DPCLIClient(String dpHostName, int port, String userName, String password, String domain, String connectionType) throws NumberFormatException, InvalidParameterException{
		super(dpHostName, port, userName, password, domain);

		if(dpHostName == null || dpHostName.equals("")){
			throw new InvalidParameterException("Invalid Hostname: " + dpHostName);
		}else if( port < 1){
			throw new InvalidParameterException("Invalid port: " + port);
		}else if(userName == null || userName.equals("")){
			throw new InvalidParameterException("Invalid userName: " + userName);
		}else if(password ==  null || password.equals("")){
			throw new InvalidParameterException("Invalid password: " + password);
		}else if(domain == null || domain.equals("")){
			throw new InvalidParameterException("Invalid domain: " + domain);
		}else if(connectionType == null || !(connectionType.toLowerCase().equals("ssh")|| connectionType.toLowerCase().equals("telnet") )){
			throw new InvalidParameterException("Invalid connectionType: " + connectionType);
		}
		
		
		switch(connectionType.toLowerCase()){
			case "ssh":
				this.cli = new SSHClient(dpHostName, Integer.valueOf(port), userName, password);
				break;
			case "telnet":
				this.cli = new TelnetClient(dpHostName, Integer.valueOf(port), userName, password);
				break;
			default:
				throw new InvalidParameterException("Unknow client type: " + connectionType + ".  Options are ssh or telnet");
		}
		
		if(!this.cli.loginDP(domain)){
			this.cli.endSession();
			throw new IllegalStateException("Unable to log into DP.  Error: " + this.cli.errorMessage);
		}
		
		
	}
	
	public String getResponse(String command, int timeOutMilli){
		return this.cli.getResponse(command, timeOutMilli);
	}
	
	public String getResponse(int timeOut){
		return this.cli.getResponse(timeOut);
	}
	
	public boolean sendCommand(String command){
		return this.cli.sendCommand(command);
	}
	
	public String getStatus(String status){
		return this.cli.getResponse("top;co;show " + status, 60000);
	}
	
	public String getConfig(String type, String name){
		return this.cli.getResponse("top;co;show " + type + " " + name,60000);
	}
	
	public String setConfig(String type, String name, ArrayList<String> setPropertyCommands){
		String command = "top;co;" + type + " " + name;
		String response = this.cli.getResponse(command, 60000);
		if(!this.cli.responseContains(CLIVariables.SUCCESS_CONFIG_MODIFIED) && !this.cli.responseContains(CLIVariables.CONFIG_NEW) ){
			return this.cli.getLastResponse();
		}
		
		for(String s: setPropertyCommands){
			response += this.cli.getResponse(s, 60000);
			if(this.cli.getLastResponse().contains("[y/n]")){
				this.cli.getResponse("y", 60000);
			}else if(this.cli.getLastResponse().contains("Re-enter Password")){
				response += this.cli.getResponse(s, 60000);
			}
		}
	
		response += this.cli.getResponse("show;exit",60000);
	
		return response;
	}
	
	public String setCryptoConfig(String type, String name, ArrayList<String> setPropertyCommands){
		String command = "top;co;crypto;" + type + " " + name;
		String response = this.cli.getResponse(command, 60000);
		
		for(String s: setPropertyCommands){
			response += this.cli.getResponse(s, 60000);
			if(this.cli.getLastResponse().contains("[y/n]")){
				this.cli.getResponse("y", 60000);
			}else if(this.cli.getLastResponse().contains("Re-enter Password")){
				response += this.cli.getResponse(s, 60000);
			}
		}
	
		response += this.cli.getResponse("exit",60000);
	
		return response;
	}
	
	public String deleteConfig(String type, String name){
		return this.cli.getResponse("top;co;no " + type + " " + name,60000);
	}
	
	public boolean LogOut(){
		return this.cli.endSession();
	}
	
	public String copyFile(String from, String to,String password, boolean force, int timeOutMilli){
		String command = "top;co;copy ";
		if(force){
			command += "-f ";
		}
		
		command += from + " " + to;
		if(password!=null && !password.equals("")){
			command +="\n" + password;
		}
		return this.cli.getResponse(command, timeOutMilli);
	}
	
	//TODO
	public String copyFromAppliance(String protocol, String pathToFile, String fileName,String remoteHostName,String remoteUser,String remotePW,String remotePath, boolean force, int timeOutMilli){
		String command = "top;co;copy ";
		
		if(force){command += "-f ";}
		
		command += pathToFile + "/" + fileName + " " + remoteUser + ":"+ remotePW +"@"+remoteHostName +"/"+remotePath + "/"+fileName;

		return this.cli.getResponse(command, timeOutMilli);
	}
	
	//TODO
	public String copyToAppliance(String protocol, String pathToFile, String fileName,String remoteHostName,String remoteUser,String remotePW,String remotePath, boolean force, int timeOutMilli){
		
		String command = "top;co;copy ";
		
		if(force){command += "-f ";}
		
		command += remoteUser + ":" + remotePW + "@" + remoteHostName + "/" + remotePath + "/" + fileName + " " + pathToFile + "/" + fileName;
				

		return this.cli.getResponse(command, timeOutMilli);
	}

	public String moveFile(String from, String to,String password, boolean force){
		String command = "top;co;move ";
		if(force){
			command += "-f ";
		}
		
		command += from + " " + to;
		if(password!=null){
			command +="\n" + password;
		}
		return this.cli.getResponse(command, 120000);
	}
	
	public String showFile(String file, String pathToFile, int timeOutMilli){
		return this.cli.getResponse("top;co;show file " + pathToFile + "/" + file, timeOutMilli);
	}
	
	public String showDirectory(String directory){
		if(directory==null){return null;}
		return this.cli.getResponse("top;co;dir " + directory, 60000);
	}
	
	public String deleteFile(String file, boolean force){
		if(file == null || file.equals("")){return null;}
		
		String command = "top;co;delete ";
		if(force){
			command += "-f ";
		}
		
		command += file;
		
		return this.cli.getResponse(command, 120000);
	}
	
	public String deleteDirectory(String directory, boolean force){
		if(directory == null || directory.equals("")){return null;}

		String command = "top;co;rmdir ";
		if(force){
			command += "-f ";
		}
		
		command += directory;
		
		return this.cli.getResponse(command, 120000);
	}
		
	public String execFile(String file, int timeOutMilli){
		if(file == null || file.equals("")){return null;}

		String command = "top;co;exec " + file;
		return this.cli.getResponse(command, timeOutMilli);
	}

	/**
	 * Helper method to restart a DP domain.<br/>
	 * Assumes client is already logged in.<br/>
	 * Returns false if invalid parameter is provided.
	 * @param domain
	 * @param dpClient
	 * @param log
	 * @return
	 */
	public boolean helper_RestartDomain(String domain, Logger log){
		if(this == null || domain == null || domain.equals("") || log == null){
			if(log != null){
				log.severe("Error running helper_RestartDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running helper_RestartDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		String command = "top;co;restart domain " + domain + "\ny";
		return this.verifyCommand("Restart Domain", command,"Domain restarted successfully" , Level.SEVERE, Level.INFO, log, false);
	}
	
	
	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes Client is already logged into appliance.<br/>
	 * Returns null if Client is null or unable to find anchor point.  Use getLastResponse() to see log.
	 * @param dpClient
	 * @return
	 */
	public String getAuditAnchor(){
		
		this.cli.getResponse("top;co;show audit-log -np", 120000);
		
		String[] tmp = this.cli.getLastResponse().split("\n");
		int i=tmp.length-3;
		for(;i>=0;i--){
			if(this.containsRegEx(tmp[i], DPVariables.REGEX_LOG_TIMESTAMP_DP_ZULU) || this.containsRegEx(tmp[i], DPVariables.REGEX_LOG_TIMESTAMP_DP_SYSLOG)){
				break;
			}
		}
		return tmp[i];
	}
	
	
	/**
	 * Helper method to check standard dp log for list of expected RegEx's.<br/>
	 * Assumes client is already logged in.<br/>
	 * Returns false any parameter is invalid.
	 * @param dpClient
	 * @param expectedRegEx
	 * @param logAnchor
	 * @param dotAll
	 * @param log
	 * @return
	 */
	public boolean checkLog(ArrayList<String> expectedRegEx, String logAnchor,  boolean dotAll, Logger log){
		if(expectedRegEx == null || expectedRegEx.size()<1 || logAnchor == null){
			if(log != null){
				log.severe("Error running checkLog method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running checkLog method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		String tmp = this.cli.getResponse("top;show log", 60000);
		boolean pass = true;
		if(tmp.indexOf(logAnchor)==-1){
			//Get cycled file
			this.cli.getResponse("top;co;show file logtemp:///default-log.1", 60000);
			tmp = this.cli.trimResponse() + tmp;
		}
		
//		if(log!=null){
//			log.finest("DP Log.\n[Log]:" + tmp);
//		}else{
//			System.out.println("DP Log.\n[Log]:" + tmp);
//		}
		tmp = tmp.substring(tmp.indexOf(logAnchor) + logAnchor.length());

		StringBuilder logMessage = new StringBuilder();
		logMessage.append("Verifing DP Logs.\n[SubLog]:\n" + tmp);
		for(String expected: expectedRegEx){
			logMessage.append("\n------------------------------\n");
			if(this.containsRegEx(tmp, expected, dotAll)){
				logMessage.append("\n[Expected RegEx]: " + expected.replace("\n", "\\n") + "\n[Found]: " + this.getRegEx(tmp, expected, dotAll));
			}else{
				logMessage.append("\n[Expected RegEx]: " + expected.replace("\n", "\\n")  + "\n[Not Found]:");
				pass = false;
			}
		}
		
		if(pass){
			logMessage.append("\n[Result]: passed");
		}else{
			logMessage.append("\n[Result]: failed");

		}
		
		if(log !=null){
			log.info(logMessage.toString());
		}else{
			System.out.println(logMessage.toString());
		}
		return pass;
	}
	
	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes Client is already logged into appliance.<br/>
	 * Returns null if Client is null or unable to find anchor point.  Use getLastResponse() to see log.
	 * @param dpClient
	 * @return
	 */
	public String getDPLogAnchor(){
			
		String[] tmp = this.cli.getResponse("top;co;show log", 60000).split("\n");
		int i=tmp.length-3;
		for(;i>=0;i--){
			if(this.containsRegEx(tmp[i], "(" + DPVariables.REGEX_LOG_TIMESTAMP_DP_ZULU + ")|(" + DPVariables.REGEX_LOG_TIMESTAMP_DP_SYSLOG + ")|(" + DPVariables.REGEX_LOG_TIMESTAMP_DP_NUMERIC + ")")){
				break;
			}
		}
		if(i==-1){
			return null;
		}
		return tmp[i];
	}
	
	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes Client is already logged into appliance.<br/>
	 * Returns null if Client is null or unable to find anchor point.  Use getLastResponse() to see log. 
	 * @param dpClient
	 * @param pathToLog
	 * @param fileName
	 * @return
	 */
	public String getDPLogAnchor(String pathToLog, String fileName){
		if(this.cli == null || pathToLog==null || fileName == null){
			return null;
		}
		this.cli.getResponse("top;co;show file " + pathToLog + "/" + fileName, 60000);
		
		String[] tmp = this.cli.getLastResponse().split("\n");
		int i=tmp.length-2;
		for(;i>=0;i--){
			if(this.containsRegEx(tmp[i], "(" + DPVariables.REGEX_LOG_TIMESTAMP_DP_ZULU + ")|(" + DPVariables.REGEX_LOG_TIMESTAMP_DP_SYSLOG + ")|(" + DPVariables.REGEX_LOG_TIMESTAMP_DP_NUMERIC + ")")){
				break;
			}
		}
		if(i==-1){
			return null;
		}
		return tmp[i];
	}
	
	/**
	 * Returns the DP logs that appear after the specified anchor point.<br/>
	 * Note: Anchor point should contain something unique like a time stamp.<br/>
	 * 
	 * @param dpClient
	 * @param anchorPoint
	 * @param pathToLog
	 * @param fileName
	 * @return
	 */
	public String getDPLogFromAnchorPoint(String anchorPoint, String pathToLog, String fileName){
		if(this.cli == null || anchorPoint == null || anchorPoint.equals("")||pathToLog==null|| pathToLog.equals("") || fileName==null|fileName.equals("")){
			return null;
		}
		
		String tmp = this.cli.getResponse("top;co;show file " + pathToLog + "/" + fileName, 60000);		
	
		if(tmp.indexOf(anchorPoint)==-1){
			//Get cycled file
			this.cli.getResponse("top;show file " + pathToLog + "/" + fileName + ".1", 60000);
			tmp = this.cli.trimResponse() + tmp;
		}
		
		tmp = tmp.substring(tmp.indexOf(anchorPoint) + anchorPoint.length());
		return tmp;
	}
	
	/**
	 * Returns the DP logs that appear after the specified anchor point.<br/>
	 * Note: Anchor point should contain something unique like a time stamp.<br/>
	 * 
	 * @param dpClient
	 * @param anchorPoint
	 * @return
	 */
	public String getDPLogFromAnchorPoint(String anchorPoint){
		if(this.cli == null || anchorPoint == null || anchorPoint.equals("")){
			return null;
		}
		
		String tmp = this.cli.getResponse("top;show log", 60000);		
	
		if(tmp.indexOf(anchorPoint)==-1){
			//Get cycled file
			this.cli.getResponse("top;show file logtemp:///default-log.1", 60000);
			tmp = this.cli.trimResponse() + tmp;
		}
		
		tmp = tmp.substring(tmp.indexOf(anchorPoint) + anchorPoint.length());
		return tmp;
	}
	
	/**
	 * Attempts to create and execute an import-package. If return is false use this.cli.getLastResponse() to see last response from DP.
	 * @param domain
	 * @param dpClient
	 * @param packageName
	 * @param packageFileName
	 * @param pathToPackageFileOnDP
	 * @param log
	 * @return
	 */
	public boolean importDPPackage(String domain, String packageName, String packageFileName, String pathToPackageFileOnDP, Logger log){
		if(this.cli == null || domain == null || domain.equals("") || packageName == null  || packageName.equals("")  || packageFileName == null || packageFileName.equals("")  || pathToPackageFileOnDP == null || pathToPackageFileOnDP.equals("") || log == null){
			if(log != null){
				log.severe("Error running importDPPackage method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running importDPPackage method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		//Switch to test domain and create test objects
		String command = "top;switch "+domain+";co;import-package " + packageName +";source-url " + pathToPackageFileOnDP + "/"+ packageFileName+";exit;show import-package "+ packageName;
		if(!this.verifyCommand("Create Import Package For File " + packageFileName + ".", command, "import-package: " + packageName + " \\[up\\]", Level.SEVERE, Level.CONFIG, log, false)){
			return false;
		}
		
		command = "import-exec " + packageName;
		if(!this.verifyCommand("Load Import Package.", command, "Loading import-package '"+packageName +"'.\nImport package is complete.", Level.SEVERE, Level.CONFIG, log, false)){
			return false;
		}
		return true;
	}
	
	/**
	 * Removes domain by first disconnecting any active users then sending the no domain command.
	 * <br/>
	 * If returns false, check DP response by using the this.cli.getLastResponse() command.
	 * 
	 * @param dpClient
	 * @param domain
	 * @return boolean
	 */
	public boolean deleteDomain(String domain, Logger log){
		if(domain == null || domain.equals("") || log == null){
			if(log != null){
				log.severe("Error running deleteDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running deleteDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		
		//Remove test domain
		this.cli.getResponse("top;switch domain default", 60000);
				
		//Disconnect Active Users in test domain
		//Loop to disconnect active users
		String[] tmp = this.cli.getResponse("top;co;show users", 60000).split("\n");
		log.config("Check For Active Users In Test Domain: " + domain+"\n" + this.cli.getLastResponse());
		for(String s: tmp){
			//Split by spaces
			if(s.trim().endsWith(domain)){
				String[] tmp2 = s.trim().split(" ");
				this.verifyCommand("Disconnect Test Users In Test Domians.",  "disconnect " + tmp2[0], "Session [\\d]+ closed", Level.SEVERE, Level.CONFIG, log, false);
			}
		}
		
		
		return this.verifyCommand("Remove Test Domain",  "top;co;no domain " + domain + "\ny", CLIVariables.SUCCESS_DOMAIN_DELETED, Level.WARNING, Level.CONFIG, log, false);
				
	}
	
	/**
	 * Attempts to log in to a DP appliance
	 * @param domain
	 * @throws Exception
	 */
	public boolean loginDP(String domain){
		if(domain==null || domain.equals("")){return false;}
		this.domain=domain;
		return (this.loggedIn=this.cli.loginDP(domain));
	}
	
	public boolean login(){
		return (this.loggedIn=this.cli.loginDP(domain));
	}

	//TODO
	public String loadBuild(String url, boolean acceptLicense, long rebootTimeOutMilli, int fileCopyTimeOutMilli, int loadFirmwareTimeOutMilli){
		if(url == null || url.equals("")){return null;}
		String tmpResponse ="";
		this.copyFile(url, buildFileDir, null, true, fileCopyTimeOutMilli);
		if(!this.cli.responseContains(CLIVariables.SUCCESS_COPY_FILE)){
			return "Error: unable to copy build file.  Response: " + this.cli.getLastResponse() +"\n";
		}
		tmpResponse += this.cli.getLastResponse();
		String command = "top;co;fl;boot " + buildFileDir + " ";
		if(acceptLicense){
			command += "accept-license ";
		}
		command += buildFileName;
		
		tmpResponse += this.cli.getResponse(command, 300000);
		while(true){
			if(!this.cli.getResponse("y", 5000).contains("[y/n]")){
				tmpResponse += this.cli.getLastResponse();
				break;
			}else{
				tmpResponse += this.cli.getLastResponse();
			}
			
		}
		
		
		//Get reboot message
//		Firmware upgrade successful
//		Device is rebooting now.
		long startTime = System.currentTimeMillis();
		while(!(tmpResponse += this.cli.getResponse(3000)).contains("Firmware upgrade successful")){
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if(System.currentTimeMillis()-startTime > loadFirmwareTimeOutMilli){
				tmpResponse = this.cli.replaceAll(tmpResponse, "\nERROR: Timed Out\\([\\d]+\\).\n", "", false);
				return "Error: Time Out Waiting Firmware upgrade.\n\tSSHClient Error Message: " + this.cli.errorMessage + "\n\tProgress: " + tmpResponse;
			}
		}
	
		startTime = System.currentTimeMillis();
		while(this.cli.isConnected()){
			//Waiting for reboot
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(System.currentTimeMillis()-startTime > loadFirmwareTimeOutMilli){
				//Remove Time Out Messages
				tmpResponse = this.cli.replaceAll(tmpResponse, "\nERROR: Timed Out\\([\\d]+\\).\n", "", false);
				return "Error: Time Out Waiting For Appliance To Reboot.\n\tProgress: " + tmpResponse;
			}
		}
		
		
		
		//Try to connnect
		startTime = System.currentTimeMillis();
		while(!this.cli.loginDP(domain)){
			if(System.currentTimeMillis()-startTime > rebootTimeOutMilli){
				tmpResponse = this.cli.replaceAll(tmpResponse, "\nERROR: Timed Out\\([\\d]+\\).\n", "", false);
				return "Error: Time Out Waiting for restart.\n\tSSHClient Error Message: " + this.cli.errorMessage + "\n\tProgress: " + tmpResponse;
			}
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		tmpResponse += this.cli.getLastResponse();
		
		//Remove Time Out Messages
		tmpResponse = this.cli.replaceAll(tmpResponse, "\nERROR: Timed Out\\([\\d]+\\).\n", "", false);

		return tmpResponse + this.cli.getResponse("show version", 30000);
	}

	public boolean sendCommand(int hexCommand) {return this.cli.sendCommand(hexCommand);}
	
	public boolean isConnected() {
		return this.cli.isConnected();
	}
	
	/**
	 * Helper method to verify a test step
	 * @param stepDescription
	 * @param client
	 * @param command
	 * @param expectedRegEx
	 * @param failedLevel
	 * @param passLevel
	 * @param logger
	 * @param dotAll: Include newline characters when using . in RegEx
	 * @return
	 */
	public boolean verifyCommand(String stepDescription, String command, String expectedRegEx, Level failedLevel, Level passLevel, Logger logger, boolean dotAll){
		if(stepDescription == null || stepDescription.equals("") || command == null || command.equals("") || expectedRegEx == null || expectedRegEx.equals("") || failedLevel == null || passLevel == null){
			if(logger != null){
				logger.severe("Error running verifyStep method.  Invalid parameter: Object was null or a String was empty");
			}else{
				System.out.println("Error running verifyStep method.  Invalid parameter: Object was null or a String was empty");
			}
			
			return false;
		}
		
		this.cli.getResponse(command, 120000);//2 minute time outs

		StringBuilder logInfo=new StringBuilder();
		logInfo.append("[Description]: ");
		logInfo.append(stepDescription);
		logInfo.append("\n[Command]: ");
		logInfo.append(this.cli.lastCommand.replace("\n", "\\n"));
		logInfo.append("[Response]: ");
		logInfo.append(this.cli.getLastResponse());
		logInfo.append("\n[Expected RegEx]: ");
		logInfo.append(expectedRegEx.replace("\n", "\\n"));					
		if(!this.cli.responseContains(expectedRegEx, dotAll)){
			logInfo.append("\n[Not Found]:\n");
			logInfo.append("\n[Result]: Failed");
			if(logger != null){
				logger.log(failedLevel, logInfo.toString());
			}else{
				System.out.println(logInfo.toString());
			}
			return false;
		}else{
			
			logInfo.append("\n[Found]:\n");
			logInfo.append(this.getRegEx(this.cli.getLastResponse().substring(this.cli.getLastResponse().indexOf("\n")), expectedRegEx, dotAll));
			logInfo.append("\n[Result]: Passed");
			if(logger !=null){
				logger.log(passLevel, logInfo.toString());
			}else{
				System.out.println(logInfo.toString());
			}
			return true;
		}
	}
	
	/**
	 * Checks if last response match regEx
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * returns false if parameters are invalid
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public boolean responseMatches(String regExp, boolean dotAll){return this.cli.matchesRegEx(this.cli.response, regExp, dotAll);}

	/**
	 * Checks if last cli response String contains the provided regular expression<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns false if parameters are invalid
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public boolean responseContains(String regExp, boolean dotAll){return this.containsRegEx(this.cli.response, regExp, dotAll);}

	/**
	 * Returns a array of Strings found in the last cli response String that matched the provided regExp<br/>
 	 * Returns null if parameters are invalid. <br/>
 	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public ArrayList<String> responseGetGroups(String regExp, boolean dotAll){return this.getGroups(this.cli.response, regExp, dotAll);}

	/**
	 * Returns the string found in the last response that matches the provided regular expression.
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public String responseGetRegEx(String regExp, boolean dotAll){
		return this.getRegEx(this.cli.response, regExp, dotAll);
	}
	
	/**
	 * Returns the number of times the RegEx is found in the last cli response
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public int responseCount(String regExp, boolean dotAll){return this.count(this.cli.response, regExp, dotAll);}
	
	public String trimResponse(){
		return this.cli.trimResponse();
	}

	@Override
	public boolean lastResponseContains(String expectedRegEx, boolean dotAll) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean lastResponseMatches(String expectedRegEx, boolean dotAll) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String lastResponseGetRegEx(String regEx, boolean dotAll) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<String> lastResponseGetGroups(String regEx, boolean dotAll) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int lastResponseCountRegEx(String regEx, boolean dotAll) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
