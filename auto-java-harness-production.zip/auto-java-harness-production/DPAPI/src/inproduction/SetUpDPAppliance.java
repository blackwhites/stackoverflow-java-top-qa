package inproduction;

import tools.SSHClient;

public class SetUpDPAppliance {

	SSHClient annexClient;
	int annexPort=22;
	String annexURL="";
	String annexUserNam ="InReach";
	String annexPW = "access";
	
	public SetUpDPAppliance(){
		
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {}
	
	

}
