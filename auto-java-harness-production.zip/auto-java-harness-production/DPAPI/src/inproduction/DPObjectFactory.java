package inproduction;

import java.lang.reflect.InvocationTargetException;

import tools.Converter;
import tools.DPManagementClient;
import tools.RMIObjectFactory;
import variables.DPDefaults;
import xmlManagement.*;
import beans.RequestBean;

public class DPObjectFactory {

	String dpHostName;
	String userName;
	String pw;
	DPManagementClient client;
	RMIObjectFactory rmiFactory = new RMIObjectFactory();
	Converter converter = new Converter();
	RequestBean serverResponse;
	
	
	public ConfigDomain createTestDomain(String domainName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
		Response r = rmiFactory.getResponseObject(converter.stringToJSON(DPDefaults.DOMAIN.replaceFirst("{name}", domainName)));
		serverResponse = this.client.roma.configRequest.createConfigObject(r.getConfig());
		if(serverResponse.equals("200")){
			return (ConfigDomain) r.getConfig().getConfigObjects().get(0);
		}else{
			return null;
		}
	}
	
}
