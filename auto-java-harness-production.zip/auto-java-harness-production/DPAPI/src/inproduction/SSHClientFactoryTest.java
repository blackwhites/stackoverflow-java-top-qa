package inproduction;

import org.junit.Test;

import inproduction.SSHClientFactory.SSHSession;


public class SSHClientFactoryTest {

	@Test
	public void test() {
		SSHClientFactory sshFactory = new SSHClientFactory();
		
		SSHSession s1 = sshFactory.getSession("dpvirt4a.dp.rtp.raleigh.ibm.com", 22, "admin", "jan0111j");
		SSHSession s2 = sshFactory.getSession("dp527.dp.rtp.raleigh.ibm.com", 22, "admin", "jan0111j#jan0111J");
		SSHSession s3 = sshFactory.getSession("dpBlade95.dp.rtp.raleigh.ibm.com", 22, "root", "jan0111j");
		
		System.out.println(s1.loginDP("default"));
		System.out.println(s2.loginDP("default"));
		System.out.println(s3.getResponse());

		System.out.println(s1.getResponse("show version"));
		System.out.println(s2.getResponse("show version"));
		System.out.println(s3.getResponse("ls -latr"));
		
		s1.endSession();
		s2.endSession();
		s3.endSession();
		sshFactory.closeAllSessions();
	}

}
