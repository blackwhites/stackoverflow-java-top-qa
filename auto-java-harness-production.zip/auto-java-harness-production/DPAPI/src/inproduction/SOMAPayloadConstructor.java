package inproduction;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import variables.SOMAVariables;
import xmlManagement.AnyActionElement;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyDeleteElement;
import xmlManagement.AnyModifyElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.DmAdminState;
import xmlManagement.DmReference;
import xmlManagement.ModifyConfigBase;
import xmlManagement.Request;
import xmlManagement.Request.GetFilestore;

/**
 * Java Class to construct client payloads for SOMA requests.
 * 
 * New Version to resplace SOMAPayloadFactory.  Uses reflection to build payloads.
 * 
 * Under Construction
 * 
 * need to update once other request become avaialbe
 * @author Nick Coble
 *
 */
public class SOMAPayloadConstructor {

	
	/**
	 * Method to get class name from first object in list.
	 * @param c:AnyConfigElement - 
	 * @return String
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws Exception
	 */
	public String getClassName(AnyConfigElement c) throws IllegalArgumentException, IllegalAccessException  {
		if(c==null){return null;}
		return this.getClassName((Object)c.getConfigObjects().get(0));
	}
	
	public String getClassName(AnyActionElement a) throws IllegalArgumentException, IllegalAccessException {
		if(a==null){return null;}
		return this.getClassName((Object)a.getActionObjects().get(0));
	}
	
	public String getObjectName(AnyConfigElement c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		if(c==null){return null;}
		return this.getObjectName(c.getConfigObjects().get(0));
	}
	
	public String getObjectName(AnyModifyElement c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		if(c==null){return null;}
		return this.getObjectName(c.getConfigObjects().get(0));
	}
	
	public String getObjectName(AnyDeleteElement c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		if(c==null){return null;}
		return this.getObjectName(c.getConfigObjects().get(0));
	}
	
	public String getObjectName(Object c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
		if(c==null){return null;}
		Field f = c.getClass().getDeclaredField("name");
		f.setAccessible(true);
		
		if(f.get(c)==null){
			return null;
		}
		return f.get(c).toString();
	}
	
	public String buildObjectRequest(Request r, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(r==null){return null;}
		Object object = this.getAvaiableObject(r);
		
		if(object==null){
			return null;
		}else if(object instanceof AnyActionElement){
			return this.buildObjectRequest((AnyActionElement) object, domain);
		}else if(object instanceof AnyConfigElement){
			return this.buildObjectRequest((AnyConfigElement) object, domain);
		}else if(object instanceof AnyModifyElement){
			return this.buildObjectRequest((AnyModifyElement) object, domain);
		}			
		
		System.out.println("Invalid Object Type.  Expected AnyConfigElement or AnyActionElement");
		return null;
	}
	
	public String buildObjectRequest(Request r) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(r==null){return null;}
		Object object = this.getAvaiableObject(r);
		
		if(object==null){
			return null;
		}else if(object instanceof AnyActionElement){
			return this.buildObjectRequest((AnyActionElement) object, r.getDomain());
		}else if(object instanceof AnyConfigElement){
			return this.buildObjectRequest((AnyConfigElement) object,  r.getDomain());
		}else if(object instanceof AnyModifyElement){
			return this.buildObjectRequest((AnyModifyElement) object,  r.getDomain());
		}else if(object instanceof GetFilestore){
			
		}
		
		System.out.println("Invalid Object Type.  Expected AnyConfigElement or AnyActionElement");
		return null;
	}
	
	public String buildObjectRequest(AnyActionElement a, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(a==null || a.getActionObjects().size()==0){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += SOMAVariables.actionRequestHeader;
		payload += this.buildRequest(a.getActionObjects().get(0));
		payload += SOMAVariables.actionRequestFooter;
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	
	public String buildObjectRequest(Object action, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(action==null){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += SOMAVariables.actionRequestHeader;
		payload += this.buildRequest(action);
		payload += SOMAVariables.actionRequestFooter;
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	
	public String buildObjectRequest(AnyConfigElement c, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(c==null|| c.getConfigObjects().size()==0){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += SOMAVariables.setConfigRequestHeader;
		for(ConfigConfigBase config: c.getConfigObjects()){
			payload += this.buildRequest(config);
		}
//		payload += this.buildRequest(c.getConfigObjects().get(0));
		payload += SOMAVariables.setConfigRequestFooter;
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	public String buildObjectRequest(ConfigConfigBase c, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += SOMAVariables.setConfigRequestHeader;
		payload += this.buildRequest(c);
		payload += SOMAVariables.setConfigRequestFooter;
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	public String buildModifyObjectRequest(ConfigConfigBase c, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += SOMAVariables.modifyConfigRequestHeader;
		payload += this.buildRequest(c);
		payload += SOMAVariables.modifyConfigRequestFooter;
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	public String buildObjectRequest(AnyModifyElement m, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(m==null|| m.getConfigObjects().size()==0){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += SOMAVariables.modifyConfigRequestHeader;
		for(ModifyConfigBase config: m.getConfigObjects()){
			payload += this.buildRequest(config);
		}
//		payload += this.buildRequest(m.getConfigObjects().get(0));
		payload += SOMAVariables.modifyConfigRequestFooter;
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	
	public String buildObjectReqeust(GetFilestore f, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(f==null|| f.getLocation() == null){return null;}
		String payload ="";
		payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
		payload += this.buildRequest(f);
		payload += SOMAVariables.somaRequestFooter;
		return payload;
	}
	
	public String buildXMLPropSimple(String propName, String propValue){return ("<" + propName + ">" + propValue + "</" + propName + ">");}
	
	public String buildXMLPropSimpleArray(String propName, ArrayList<String> contents){
		if(contents.size()==0){return "</"+propName+">";}
		String tmp=null;
		for(int i=0;i<contents.size();i++){
			tmp = "<"+propName+">" + contents.get(i) + "</"+propName+">" ;
		}
		return tmp;
	}
	
	/**
	 * Use buildXMLPropSimple to construct contents
	 * @param propName
	 * @param contents
	 * @return
	 */
	public String buildXMLPropComplex(String propName, String contents){return ("<" + propName + ">" + contents + "</" + propName + ">");}
	
	/**
	 * Use buildXMLPropSimple to construct each array entry 
	 * @param propName
	 * @param contents
	 * @return
	 */
	public String buildXMLPropComplexArray(String propName, ArrayList<String> contents){
		String tmp=null;
		for(int i=0;i<contents.size();i++){
			 tmp = "<"+propName+">" + contents.get(i) + "</"+propName+">";
		}
		return tmp;
	}

	////////////////////////////////////////////////////////////////////////
	//  Private Helper Methods											 //
	//////////////////////////////////////////////////////////////////////
	
	/**
	 * Method to build and object payload.  IE ConfigXMLManager, StatusActiveUsersStatus, etc..
	 * @param Object:o
	 * @return String
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	private String buildRequest(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		return this.buildPayloadBody(o);
		//Place object reqeust name in payload
//				String payload ="";
//				payload += SOMAVariables.somaRequestHead.replace("{domain}", domain);
				//Build object contents
//				payload += this.buildPayloadBody(o);
//				payload += SOMAVariables.somaRequestFooter;

//				return (payload);	
//		//Get name of object
//		String objectName = o.getClass().getSimpleName().substring(6);
//
//		//Place object reqeust name in payload
//		String payload ="<" + objectName + ">";
//
//		//Build object contents
//		payload += this.buildPayloadBody(o);
//		
//		return (payload + "</" + objectName + ">");
	}

	private String buildPayloadBody(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		String payload="";
		String payloadHeader = "<" + o.getClass().getSimpleName().substring(6) + " ";
		
		if(o instanceof GetFilestore){
			payloadHeader = "<dp:get-filestore ";
		}
		
		boolean first = true;
		if(o instanceof ConfigConfigBase && ((ConfigConfigBase) o).getMAdminState()!=null){
			//Grab the property name from annotation;
			String[] propertyNames = ConfigConfigBase.class.getAnnotation(XmlType.class).propOrder();
			payload += this.buildXMLPropSimple(propertyNames[0],((ConfigConfigBase) o).getMAdminState().toString().toLowerCase());
			first=false;
		}
		

		for (Field field : this.getAllFields(o.getClass())) {
			field.setAccessible(true);
			if(field.get(o)==null || field.get(o) instanceof DmAdminState){
				continue;
			}else{
				
				String propName;
				if(field.getAnnotation(XmlElement.class) != null){
					propName = field.getAnnotation(XmlElement.class).name();
					payload += this.buildPayloadProperty(field, o, first);
				}else if(field.getAnnotation(XmlAttribute.class) != null){
					propName = field.getAnnotation(XmlAttribute.class).name();
					payloadHeader += " " + propName + "=\"";
					 if(field.getType().isEnum()){
						 try {
							 payloadHeader += ((String)(field.get(o).getClass().getDeclaredMethod("value").invoke(field.get(o))));
							} catch (InvocationTargetException | NoSuchMethodException | SecurityException e) {
								e.printStackTrace();
							}
					 }else{
						 payloadHeader += field.get(o); 
					 }
					 
					 payloadHeader += "\"";
				}else{
					payload+="Unable To determine Property Name from annotation from field object " + field.getClass().getSimpleName();
				}
				
				first = false;
			}
		}
		
		if(o instanceof GetFilestore){
			payload = payloadHeader + "/>"; 
		}else{
			payload = payloadHeader + ">" + payload + "</" + o.getClass().getSimpleName().substring(6) + ">"; 

		}
		return payload;
		
		
//		
//		
//		
//		String payload="";
//		boolean first = true;
//		if(o instanceof ConfigConfigBase && ((ConfigConfigBase) o).getMAdminState()!=null){
//			//Grab the property name from annotation;
//			String[] propertyNames = ConfigConfigBase.class.getAnnotation(XmlType.class).propOrder();
//			payload += this.buildXMLPropSimple(propertyNames[0],((ConfigConfigBase) o).getMAdminState().toString().toLowerCase());
//			first=false;
//		}
//		
//		for (Field field : this.getAllFields(o.getClass())) {
//			field.setAccessible(true);
//			if(field.get(o)==null || field.get(o) instanceof DmAdminState){
//				continue;
//			}else{
//				payload += this.buildPayloadProperty(field, o, first);
//				first = false;
//			}
//		}
//		return payload;
	}
	
	private List<Field> getAllFields(Class<?> superClass){
		List<Field> fields = new ArrayList<Field>();
        for (Class<?> c = superClass; c != null; c = c.getSuperclass()) {
            fields.addAll(Arrays.asList(c.getDeclaredFields()));
        }
        return fields;
	}

	private String buildPayloadProperty(Field field, Object o, boolean first) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		String payload ="";
		field.setAccessible(true);


		if(field.get(o)==null){
			return null;
		}else{
			//Grab the property name from annotation;
			String propName;
			if(field.getAnnotation(XmlElement.class) != null){
				propName = field.getAnnotation(XmlElement.class).name();
			}else if(field.getAnnotation(XmlAttribute.class) != null){
				propName = field.getAnnotation(XmlAttribute.class).name();
			}else{
				propName ="Unable To determine Property Name from annotation from field object " + field.getClass().getSimpleName();
			}
			
			if(!field.getClass().isPrimitive() && !(field.get(o) instanceof String) && !(field.get(o) instanceof List<?>) && !field.getType().isEnum() && !field.getType().equals(Boolean.class)){//Is it a complex type
					payload += this.buildXMLFromComplexField(propName,field.get(o));

			}else if(field.get(o) instanceof List<?>){//List

				if(((List<?>)field.get(o)).size()>0){//Empty List?
					if((((List<?>)field.get(o)).get(0).getClass().isPrimitive()) || (((List<?>)field.get(o)).get(0) instanceof String)){//Simple list
						payload += this.buildXMLFromSimpleArray(propName,field.get(o));
					}else{//complex list
						payload += this.buildXMLFromComplexArray(propName, field.get(o));
					}
				}
			}else{//Simple Type
				payload += this.buildXMLFromSimpleField(field, o);
			}
		}
		
		return payload;
	}
	
	private String buildXMLFromSimpleField(Field f, Object o) throws IllegalArgumentException, IllegalAccessException {

		//Get name
		String propName;
		if(f.getAnnotation(XmlElement.class) != null){
			propName = f.getAnnotation(XmlElement.class).name();
		}else if(f.getAnnotation(XmlAttribute.class) != null){
			propName = f.getAnnotation(XmlAttribute.class).name();
		}else{
			propName ="Unable To determine Property Name from annotation";
		}

		
		 //Check if an enum
		 if(f.getType().isEnum()){
			 try {
					return this.buildXMLPropSimple(propName, ((String)(f.get(o).getClass().getDeclaredMethod("value").invoke(f.get(o)))));
				} catch (InvocationTargetException | NoSuchMethodException | SecurityException e) {
					e.printStackTrace();
				}
				 return null;
		 }else{
			 return this.buildXMLPropSimple(propName, f.get(o).toString());

		 }
	}
	
	private String buildXMLFromComplexField(String propName, Object f) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		 String payload ="";
		 boolean firstField=true;
		if(f instanceof DmReference){	
		 	if(!firstField){payload+=",";}
				firstField = false;
				Field tmp = f.getClass().getDeclaredField("value");
				tmp.setAccessible(true);
				payload += this.buildXMLPropSimple(propName, (String) tmp.get(f));
				return payload;
		 }
		
		 //Construct object elements
		 for (Field field : f.getClass().getDeclaredFields()) {
			field.setAccessible(true);
			if(field.get(f)==null){
				continue;
			}else {
				 firstField = false;
				 payload += this.buildXMLFromSimpleField(field, f);
			 }
		 }
		 
		 return (this.buildXMLPropComplex(propName, payload));
	}
	
	private String buildXMLFromComplexArray(String propName, Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException {
		ArrayList<String> values = new ArrayList<>();
		boolean realComplex = true;
		for(int i=0;i<((List<?>)o).size();i++){					                			

			if(((List<?>)o).get(i) instanceof DmReference){	
				
				values.add((String) ((List<?>)o).get(i).getClass().getMethod("getValue").invoke(((List<?>)o).get(i)));
				realComplex = false;
			}else{
				 String value ="";
				 for (Field field : ((List<?>)o).get(i).getClass().getDeclaredFields()) {
					 field.setAccessible(true);
					 if(field.get(((List<?>)o).get(i))!=null){
 						if(field.getClass().isPrimitive() || (field.get(((List<?>)o).get(i)) instanceof String)){
 							value += this.buildXMLPropSimple(field.getAnnotation(XmlElement.class).name().toString(), field.get(((List<?>)o).get(i)).toString());
 						}else{
 							value += this.buildXMLFromComplexField(field.getAnnotation(XmlElement.class).name().toString(), field.get(((List<?>)o).get(i)));
 						}
					 }
				 }
				 values.add(value);
			}
		}
		
		if(realComplex){
			return this.buildXMLPropComplexArray(propName, values);
		}else{
			return this.buildXMLPropSimpleArray(propName, values);
		}
	}
	
	private String buildXMLFromSimpleArray(String propName, Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		ArrayList<String> values = new ArrayList<>();
		for(int i=0;i<((List<?>)o).size();i++){					                			
			values.add((String) ((List<?>)o).get(i));
		}

		return this.buildXMLPropSimpleArray(propName, values);
	}
	
	/**
	 * @param o
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private Object getAvaiableObject(Object o) throws IllegalArgumentException, IllegalAccessException  {
		for(Field q: o.getClass().getDeclaredFields()){
			q.setAccessible(true);
			if(q.get(o)==null){
				continue;
			}else{
				return q.get(o);
			}
		}
		return null;
	}
	
	public String getClassName(Object a) throws IllegalArgumentException, IllegalAccessException{
		return a.getClass().getAnnotation(XmlType.class).name();
    }

}
