package inproduction;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import tools.XMLManagementFactory;
import variables.SOMAVariables;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.DmReference;
import xmlManagement.File;
import xmlManagement.Response;
import xmlManagement.Response.Fault;
import xmlManagement.Response.Result;

/**
 * Class to generate xmlManagement objects from a SOMA payload.
 * 
 * @author Nick Coble
 *
 */
public class SOMAObjectFactory extends XMLManagementFactory {

	/**
	 * Method generates a response object set with the object in the payload<br/>
	 * Possible Objects:  Config Object, Status Object, or Fault(Error)
	 * @param somaPayload
	 * @return Response
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	public Response getResponseObject(Document somaPayload) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		if(somaPayload==null){return null;}
long startTime = System.currentTimeMillis();	
		//Check for error key
		Response response= new Response();
		Node responseBody =   somaPayload.getChildNodes().item(0).getChildNodes().item(0).getChildNodes().item(0);
		String responseType = responseBody.getNodeName();
//System.out.println(responseType);
		if(responseType.equals(SOMAVariables.KEY_RESPONSE_FAULT)){
			xmlManagement.Response.Fault fault = new Fault();
			String faultCode = responseBody.getChildNodes().item(0).getNodeValue();
			String faultString =responseBody.getChildNodes().item(1).getNodeValue();
			fault.setFaultcode(faultCode);
			fault.setFaultstring(faultString);
			response.setFault(fault);
			return response;
		}
	
		NodeList itemsInResponse = responseBody.getChildNodes();
//System.out.println("Items in list: " + itemsInResponse.getLength());
		//Load time stamp
		try {
			DateFormat dateF =new SimpleDateFormat("yyyy-MM-dd hh:mm:ssX");
//System.out.println(itemsInResponse.item(0).getTextContent());
			Date date = dateF.parse(itemsInResponse.item(0).getTextContent().replace("T", " "));
			GregorianCalendar gcal = new GregorianCalendar();
			gcal.setTime(date);
			@SuppressWarnings("deprecation")
			XMLGregorianCalendar timeStamp = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal.get(Calendar.YEAR), gcal.get(Calendar.MONTH)+1, gcal.get(Calendar.DAY_OF_MONTH), date.getHours(),date.getMinutes(),date.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, TimeZone.SHORT).normalize();
			response.setTimestamp(timeStamp);
		} catch (DOMException | ParseException e) {
			e.printStackTrace();
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
	
		//Load Soap Body Objects
		for(int i=1;i<itemsInResponse.getLength();i++){
			String bodyType = 	itemsInResponse.item(i).getNodeName();
			switch(bodyType){
				case SOMAVariables.KEY_RESPONSE_CONFIG:
					if(response.getConfig()== null){
						response.setConfig(new AnyConfigElement());
					}
					
					NodeList configList =  itemsInResponse.item(i).getChildNodes();
					for(int index = 0; index < configList.getLength();index++){
						response.getConfig().getConfigObjects().add(this.loadConfigObject(configList.item(index)));
					}
					break;
				case SOMAVariables.KEY_RESPONSE_STATUS:
					if(response.getStatus()== null){
						response.setStatus(new AnyStatusElement());
					}
					
					NodeList statusList =  itemsInResponse.item(i).getChildNodes();
					for(int index = 0; index < statusList.getLength();index++){
						response.getStatus().getStatusObjects().add(this.loadStatusObject(statusList.item(index)));
					}
					break;
				case SOMAVariables.KEY_RESPONSE_FILE:
					File file = new File();
					file.setName(itemsInResponse.item(i).getAttributes().getNamedItem("name").getNodeValue());
					file.setValue(converter.decodeBase64(itemsInResponse.item(i).getTextContent()).getBytes());
					response.getFile().add(file);
					break;
				case SOMAVariables.KEY_RESPONSE_RESULT:
					Result value = new Result();
					//if has child check for error log else assume string
					if(itemsInResponse.item(i).hasChildNodes() && itemsInResponse.item(i).getFirstChild().getNodeName().equals(SOMAVariables.KEY_RESPONSE_ERROR_LOG)){
						value.getContent().add(itemsInResponse.item(i).getFirstChild().getTextContent().trim());
					}else{
						value.getContent().add(itemsInResponse.item(i).getTextContent().trim());
					}
					
					response.setResult(value);
					break;
				default:
					System.out.println("Unexpected response type. Recieved: " + bodyType);
					return null;
				}
		}
System.out.println("Time to build request: " + (System.currentTimeMillis()- startTime));
		return response;
	}
	
	/**
	 * Loads the payload values into the config object.  Returns null if parameters are invalid.
	 * @param somaPayload: Node, roma get response
	 * @param configObject: Config Object 
	 * @return 
	 */
	public ConfigConfigBase loadConfigObject(Document somaPayload, ConfigConfigBase configObject){
		if(somaPayload==null || configObject==null ){return null;}
		
		//Check for fault key
		String responseType = somaPayload.getChildNodes().item(0).getChildNodes().item(0).getChildNodes().item(0).getNodeName();
		Node responseBody = somaPayload.getChildNodes().item(0).getChildNodes().item(0).getChildNodes().item(0);
//System.out.println("Starting Load ConfigObject w/ Response Body: " + responseBody.getNodeName());
//System.out.println("Starting Load ConfigObject w/ Response Type: " + responseType);


		if(responseType.equals(SOMAVariables.KEY_RESPONSE_FAULT)){return null;}

		NodeList itemsInResponse = responseBody.getChildNodes();

		String bodyType = itemsInResponse.item(1).getNodeName();
//System.out.println("Starting Load ConfigObject w/ Body Type: " + bodyType);

		
		switch(bodyType){
			case SOMAVariables.KEY_RESPONSE_CONFIG:
//System.out.println("Config Object: " + itemsInResponse.item(1).getFirstChild().getNodeName());
				return (ConfigConfigBase) this.loadObjectProperties(itemsInResponse.item(1).getFirstChild(), configObject);
			default:
				System.out.println("Unexpected response type. Expected: " + SOMAVariables.KEY_RESPONSE_CONFIG + ", Recieved: " + bodyType);
				return null;
		}
	
	}

	
	/**
	 * Returns an AnyConfigElement loaded with the objects defined in the provided parameter
	 * @param configObjectNode
	 * @return
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
 	public ConfigConfigBase loadConfigObject(Node configObjectNode) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
// System.out.println("Loading configNode");
 		if(configObjectNode==null){return null;}
		
//System.out.println("Loading ConfigNode");
		
		//Get Configuration object name from node
		String objectName = configObjectNode.getNodeName();
			
		//Use xmlManagement factory to generate configuration object from node name
		Object returnObject = factory.getClass().getMethod("createConfig" + objectName).invoke(factory);
		
		//Call helper method to load object properties
		ConfigConfigBase configObject = (ConfigConfigBase)this.loadObjectProperties(configObjectNode, returnObject);
			
		return configObject;
	}
	
	/**
	 * Sets the properties of the provided Object with the values in the provided Node
	 * @param xmlObject
	 * @param returnObject
	 * @return
	 */
	public Object loadObjectProperties(Node xmlObject, Object returnObject){
		//Find Object
		try{
			NodeList propList = xmlObject.getChildNodes();
			//Set Attributes
			if(xmlObject.hasAttributes()){
				
				for(int index=0;index<xmlObject.getAttributes().getLength();index++){
					String propName = xmlObject.getAttributes().item(index).getNodeName();
					String propValue = xmlObject.getAttributes().item(index).getNodeValue();
					
					//System.out.println("Node Name: " + propList.item(index).getNodeName());
					//System.out.println("Node Type: " + propList.item(index).getNodeType());

					
					this.buildSimpleField(this.getFieldFromAnnotation(returnObject,propName), returnObject, propValue);

				}
			}
			for(int index=0;index<propList.getLength();index++){
				String propName = propList.item(index).getNodeName();
				//String Case
//System.out.println("Node Name: " + propList.item(index).getNodeName());
//System.out.println("Node Type: " + propList.item(index).getNodeType());
//System.out.println("Has Children: " + propList.item(index).hasChildNodes());
//System.out.println("Has Attributes: " + propList.item(index).hasAttributes());
//System.out.println("Text: " + propList.item(index).getTextContent());

				if(propList.item(index).getTextContent() != null && !propList.item(index).getTextContent().equals("")){//propList.item(index).getNodeType() == Node.TEXT_NODE
//System.out.println("Text node - PropName: " + propName);

					//Check base field type
					Field objectProperty = this.getFieldFromAnnotation(returnObject,propName);
					
//System.out.println("Field Name : " + objectProperty.getType().getSimpleName());
					if(objectProperty == null){
						continue;
					}else if(objectProperty.getType().getSimpleName().equals(DmReference.class.getSimpleName())){
						 DmReference tmp = new DmReference();
						 tmp.setValue(propList.item(index).getTextContent());
						 if(propList.item(index).getAttributes().getNamedItem("class") != null){
							 tmp.setClazz(propList.item(index).getAttributes().getNamedItem("class").getNodeValue());
						 }
							 
						 
						 objectProperty.setAccessible(true);
						 objectProperty.set(returnObject, tmp);
					}else{
						this.buildSimpleField(objectProperty, returnObject, propList.item(index).getTextContent());
					}
				}
				//Complex Case
				else{
//System.out.println("Complex node - PropName: " + propName);
					Field f =this.getFieldFromAnnotation(returnObject, propName);
//System.out.println("Field: " + f.getName());

					this.buildComplexField(f, returnObject, xmlObject);
				}
			}
			
			return returnObject;

		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	/**
	 * Converts a Node from a roma Status payload into a list of Java Objects
	 * @param somaPayload
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public Object loadStatusObject(Node statusNode) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException{
		if(statusNode==null){return null;}
		
		//Get Configuration object name from node
		String objectName = statusNode.getNodeName();

		//Use xmlManagement factory to generate status object
		Object returnObject = factory.getClass().getMethod("createStatus" + objectName).invoke(factory);
				
		return this.loadObjectProperties(statusNode, returnObject);

	}
	
	@SuppressWarnings("unchecked")
	private void buildComplexField(Field f, Object o, Node value) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException {
System.out.println("Building COmplex field: " + f.getName());
		if(value==null || f==null){return;}
		f.setAccessible(true);
		 
		 if(f.getType().getSimpleName().equals(DmReference.class.getSimpleName())){
			 DmReference tmp = new DmReference();
			 tmp.setValue(value.getNodeValue());
System.out.println(value.getAttributes().getNamedItem("class").getNodeValue());
			 tmp.setClazz(value.getAttributes().getNamedItem("class").getNodeValue());
			 f.set(o, tmp);
			 return;
		 }
		 
		 //Set complex object properties
		 NodeList propList = value.getChildNodes();
		 if(propList == null){return ;}
		 
		 for(int i=0;i<propList.getLength();i++){
			 if(f.getClass().getSimpleName().equals(List.class.getSimpleName())){
				String methodName = "get" + f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1);
				List<Object> l = (List<Object>) o.getClass().getMethod(methodName).invoke(o) ;
		        ParameterizedType stringListType = (ParameterizedType) f.getGenericType();
		        Class<?> stringListClass = (Class<?>) stringListType.getActualTypeArguments()[0];
		        
		        
		        if(stringListClass.getClass().isInstance(DmReference.class)){
		        	DmReference tmp = new DmReference();
		        	tmp.setValue(propList.item(i).getNodeValue());
		        	l.add(tmp);
		        }else if (stringListClass.getClass().isInstance(String.class)){
		        	l.add(value);
		        }else{
		        	try {
						l.add(this.loadConfigObject(propList.item(i)));
					} catch (ClassNotFoundException | InstantiationException e) {
						e.printStackTrace();
					}
		        }
		        f.set(o, l);
			}else if(!f.getType().isEnum() && !f.getType().isPrimitive() && !f.getType().getClass().getSimpleName().equals(Boolean.class.getSimpleName()) && !f.getType().getClass().getSimpleName().equals(Integer.class.getSimpleName())){
	 			//get Complex object
	 			Object complexField = (factory.getClass().getMethod("create"+f.getType().getSimpleName()).invoke(factory));
				this.buildComplexField(this.getFieldFromAnnotation(complexField, propList.item(i).getNodeName()), complexField, propList.item(i));
				f.set(o, complexField);
			}else{
	 			//set Simple field
//	 			Object complexField = (factory.getClass().getMethod("create"+f.getType().getSimpleName()).invoke(factory));
	 			this.buildSimpleField(this.getFieldFromAnnotation(f, propList.item(i).getNodeName()), f, propList.item(i).getNodeValue().toString().replace("\"", ""));
//	 			f.set(o, f);
	 		}
		 }
	 }

}
