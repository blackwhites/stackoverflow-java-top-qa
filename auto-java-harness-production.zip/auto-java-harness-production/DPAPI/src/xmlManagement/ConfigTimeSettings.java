
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigTimeSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigTimeSettings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigDeviceSettings"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="LocalTimeZone"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeZone {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CustomTZName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UTCDirection" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeDirection {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OffsetHours" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OffsetMinutes" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightOffsetHours" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TZNameDST" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStartMonth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmMonth {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStartWeek" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStartDay" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWeekday {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStartTimeHours" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStartTimeMinutes" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStopMonth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmMonth {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStopWeek" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStopDay" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWeekday {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStopTimeHours" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DaylightStopTimeMinutes" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigTimeSettings", propOrder = {
    "localTimeZone",
    "customTZName",
    "utcDirection",
    "offsetHours",
    "offsetMinutes",
    "daylightOffsetHours",
    "tzNameDST",
    "daylightStartMonth",
    "daylightStartWeek",
    "daylightStartDay",
    "daylightStartTimeHours",
    "daylightStartTimeMinutes",
    "daylightStopMonth",
    "daylightStopWeek",
    "daylightStopDay",
    "daylightStopTimeHours",
    "daylightStopTimeMinutes"
})
public class ConfigTimeSettings
    extends ConfigDeviceSettings
{

    @XmlElement(name = "LocalTimeZone")
    protected String localTimeZone;
    @XmlElement(name = "CustomTZName")
    protected String customTZName;
    @XmlElement(name = "UTCDirection")
    protected String utcDirection;
    @XmlElement(name = "OffsetHours")
    protected String offsetHours;
    @XmlElement(name = "OffsetMinutes")
    protected String offsetMinutes;
    @XmlElement(name = "DaylightOffsetHours")
    protected String daylightOffsetHours;
    @XmlElement(name = "TZNameDST")
    protected String tzNameDST;
    @XmlElement(name = "DaylightStartMonth")
    protected String daylightStartMonth;
    @XmlElement(name = "DaylightStartWeek")
    protected String daylightStartWeek;
    @XmlElement(name = "DaylightStartDay")
    protected String daylightStartDay;
    @XmlElement(name = "DaylightStartTimeHours")
    protected String daylightStartTimeHours;
    @XmlElement(name = "DaylightStartTimeMinutes")
    protected String daylightStartTimeMinutes;
    @XmlElement(name = "DaylightStopMonth")
    protected String daylightStopMonth;
    @XmlElement(name = "DaylightStopWeek")
    protected String daylightStopWeek;
    @XmlElement(name = "DaylightStopDay")
    protected String daylightStopDay;
    @XmlElement(name = "DaylightStopTimeHours")
    protected String daylightStopTimeHours;
    @XmlElement(name = "DaylightStopTimeMinutes")
    protected String daylightStopTimeMinutes;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the localTimeZone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalTimeZone() {
        return localTimeZone;
    }

    /**
     * Sets the value of the localTimeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalTimeZone(String value) {
        this.localTimeZone = value;
    }

    /**
     * Gets the value of the customTZName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomTZName() {
        return customTZName;
    }

    /**
     * Sets the value of the customTZName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomTZName(String value) {
        this.customTZName = value;
    }

    /**
     * Gets the value of the utcDirection property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUTCDirection() {
        return utcDirection;
    }

    /**
     * Sets the value of the utcDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUTCDirection(String value) {
        this.utcDirection = value;
    }

    /**
     * Gets the value of the offsetHours property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOffsetHours() {
        return offsetHours;
    }

    /**
     * Sets the value of the offsetHours property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOffsetHours(String value) {
        this.offsetHours = value;
    }

    /**
     * Gets the value of the offsetMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOffsetMinutes() {
        return offsetMinutes;
    }

    /**
     * Sets the value of the offsetMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOffsetMinutes(String value) {
        this.offsetMinutes = value;
    }

    /**
     * Gets the value of the daylightOffsetHours property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightOffsetHours() {
        return daylightOffsetHours;
    }

    /**
     * Sets the value of the daylightOffsetHours property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightOffsetHours(String value) {
        this.daylightOffsetHours = value;
    }

    /**
     * Gets the value of the tzNameDST property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTZNameDST() {
        return tzNameDST;
    }

    /**
     * Sets the value of the tzNameDST property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTZNameDST(String value) {
        this.tzNameDST = value;
    }

    /**
     * Gets the value of the daylightStartMonth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStartMonth() {
        return daylightStartMonth;
    }

    /**
     * Sets the value of the daylightStartMonth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStartMonth(String value) {
        this.daylightStartMonth = value;
    }

    /**
     * Gets the value of the daylightStartWeek property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStartWeek() {
        return daylightStartWeek;
    }

    /**
     * Sets the value of the daylightStartWeek property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStartWeek(String value) {
        this.daylightStartWeek = value;
    }

    /**
     * Gets the value of the daylightStartDay property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStartDay() {
        return daylightStartDay;
    }

    /**
     * Sets the value of the daylightStartDay property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStartDay(String value) {
        this.daylightStartDay = value;
    }

    /**
     * Gets the value of the daylightStartTimeHours property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStartTimeHours() {
        return daylightStartTimeHours;
    }

    /**
     * Sets the value of the daylightStartTimeHours property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStartTimeHours(String value) {
        this.daylightStartTimeHours = value;
    }

    /**
     * Gets the value of the daylightStartTimeMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStartTimeMinutes() {
        return daylightStartTimeMinutes;
    }

    /**
     * Sets the value of the daylightStartTimeMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStartTimeMinutes(String value) {
        this.daylightStartTimeMinutes = value;
    }

    /**
     * Gets the value of the daylightStopMonth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStopMonth() {
        return daylightStopMonth;
    }

    /**
     * Sets the value of the daylightStopMonth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStopMonth(String value) {
        this.daylightStopMonth = value;
    }

    /**
     * Gets the value of the daylightStopWeek property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStopWeek() {
        return daylightStopWeek;
    }

    /**
     * Sets the value of the daylightStopWeek property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStopWeek(String value) {
        this.daylightStopWeek = value;
    }

    /**
     * Gets the value of the daylightStopDay property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStopDay() {
        return daylightStopDay;
    }

    /**
     * Sets the value of the daylightStopDay property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStopDay(String value) {
        this.daylightStopDay = value;
    }

    /**
     * Gets the value of the daylightStopTimeHours property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStopTimeHours() {
        return daylightStopTimeHours;
    }

    /**
     * Sets the value of the daylightStopTimeHours property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStopTimeHours(String value) {
        this.daylightStopTimeHours = value;
    }

    /**
     * Gets the value of the daylightStopTimeMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaylightStopTimeMinutes() {
        return daylightStopTimeMinutes;
    }

    /**
     * Sets the value of the daylightStopTimeMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaylightStopTimeMinutes(String value) {
        this.daylightStopTimeMinutes = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
