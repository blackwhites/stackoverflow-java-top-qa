
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionRaidChangeEncryptionSettings2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionRaidChangeEncryptionSettings2"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="VolumeName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalDriveEncryption"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalDriveDefaultPassphrase" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEncryptionMethod2 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalDriveUserPassphrase" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionRaidChangeEncryptionSettings2", propOrder = {
    "volumeName",
    "localDriveEncryption",
    "localDriveDefaultPassphrase",
    "localDriveUserPassphrase"
})
public class ActionRaidChangeEncryptionSettings2 {

    @XmlElement(name = "VolumeName")
    protected String volumeName;
    @XmlElement(name = "LocalDriveEncryption", required = true)
    protected String localDriveEncryption;
    @XmlElement(name = "LocalDriveDefaultPassphrase")
    protected String localDriveDefaultPassphrase;
    @XmlElement(name = "LocalDriveUserPassphrase")
    protected String localDriveUserPassphrase;

    /**
     * Gets the value of the volumeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVolumeName() {
        return volumeName;
    }

    /**
     * Sets the value of the volumeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVolumeName(String value) {
        this.volumeName = value;
    }

    /**
     * Gets the value of the localDriveEncryption property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalDriveEncryption() {
        return localDriveEncryption;
    }

    /**
     * Sets the value of the localDriveEncryption property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalDriveEncryption(String value) {
        this.localDriveEncryption = value;
    }

    /**
     * Gets the value of the localDriveDefaultPassphrase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalDriveDefaultPassphrase() {
        return localDriveDefaultPassphrase;
    }

    /**
     * Sets the value of the localDriveDefaultPassphrase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalDriveDefaultPassphrase(String value) {
        this.localDriveDefaultPassphrase = value;
    }

    /**
     * Gets the value of the localDriveUserPassphrase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalDriveUserPassphrase() {
        return localDriveUserPassphrase;
    }

    /**
     * Sets the value of the localDriveUserPassphrase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalDriveUserPassphrase(String value) {
        this.localDriveUserPassphrase = value;
    }

}
