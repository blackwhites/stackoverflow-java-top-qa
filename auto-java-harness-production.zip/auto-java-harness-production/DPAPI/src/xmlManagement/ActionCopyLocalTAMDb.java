
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionCopyLocalTAMDb complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionCopyLocalTAMDb"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TAMObject" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="CopyDatabase"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoveDatabase"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionCopyLocalTAMDb", propOrder = {
    "tamObject",
    "copyDatabase",
    "removeDatabase"
})
public class ActionCopyLocalTAMDb {

    @XmlElement(name = "TAMObject", required = true)
    protected DmReference tamObject;
    @XmlElement(name = "CopyDatabase", required = true)
    protected String copyDatabase;
    @XmlElement(name = "RemoveDatabase", required = true)
    protected String removeDatabase;

    /**
     * Gets the value of the tamObject property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getTAMObject() {
        return tamObject;
    }

    /**
     * Sets the value of the tamObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setTAMObject(DmReference value) {
        this.tamObject = value;
    }

    /**
     * Gets the value of the copyDatabase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCopyDatabase() {
        return copyDatabase;
    }

    /**
     * Sets the value of the copyDatabase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCopyDatabase(String value) {
        this.copyDatabase = value;
    }

    /**
     * Gets the value of the removeDatabase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoveDatabase() {
        return removeDatabase;
    }

    /**
     * Sets the value of the removeDatabase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoveDatabase(String value) {
        this.removeDatabase = value;
    }

}
