
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigCompileOptionsPolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigCompileOptionsPolicy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XSLTVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXSLTVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Strict" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Profile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Debug" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Stream" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="TryStream" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MinimumEscaping" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="StackSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PreferXG4" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DisallowXG4" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSIValidation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSIValidationMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLValidateBody" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSDLValidationMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLValidateHeaders" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSDLValidationMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLValidateFaults" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSDLValidationMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLWrappedFaults" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowSoapEncArray" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ValidateSoapEncArray" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WildcardsIgnoreXsiType" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSDLStrictSOAPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XACMLDebug" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowXOPInclude" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigCompileOptionsPolicy", propOrder = {
    "userSummary",
    "xsltVersion",
    "strict",
    "profile",
    "debug",
    "stream",
    "tryStream",
    "minimumEscaping",
    "stackSize",
    "preferXG4",
    "disallowXG4",
    "wsiValidation",
    "wsdlValidateBody",
    "wsdlValidateHeaders",
    "wsdlValidateFaults",
    "wsdlWrappedFaults",
    "allowSoapEncArray",
    "validateSoapEncArray",
    "wildcardsIgnoreXsiType",
    "wsdlStrictSOAPVersion",
    "xacmlDebug",
    "allowXOPInclude"
})
public class ConfigCompileOptionsPolicy
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "XSLTVersion")
    protected String xsltVersion;
    @XmlElement(name = "Strict")
    protected String strict;
    @XmlElement(name = "Profile")
    protected DmReference profile;
    @XmlElement(name = "Debug")
    protected DmReference debug;
    @XmlElement(name = "Stream")
    protected DmReference stream;
    @XmlElement(name = "TryStream")
    protected DmReference tryStream;
    @XmlElement(name = "MinimumEscaping")
    protected DmReference minimumEscaping;
    @XmlElement(name = "StackSize")
    protected String stackSize;
    @XmlElement(name = "PreferXG4")
    protected DmReference preferXG4;
    @XmlElement(name = "DisallowXG4")
    protected DmReference disallowXG4;
    @XmlElement(name = "WSIValidation")
    protected String wsiValidation;
    @XmlElement(name = "WSDLValidateBody")
    protected String wsdlValidateBody;
    @XmlElement(name = "WSDLValidateHeaders")
    protected String wsdlValidateHeaders;
    @XmlElement(name = "WSDLValidateFaults")
    protected String wsdlValidateFaults;
    @XmlElement(name = "WSDLWrappedFaults")
    protected String wsdlWrappedFaults;
    @XmlElement(name = "AllowSoapEncArray")
    protected DmReference allowSoapEncArray;
    @XmlElement(name = "ValidateSoapEncArray")
    protected DmReference validateSoapEncArray;
    @XmlElement(name = "WildcardsIgnoreXsiType")
    protected DmReference wildcardsIgnoreXsiType;
    @XmlElement(name = "WSDLStrictSOAPVersion")
    protected String wsdlStrictSOAPVersion;
    @XmlElement(name = "XACMLDebug")
    protected String xacmlDebug;
    @XmlElement(name = "AllowXOPInclude")
    protected DmReference allowXOPInclude;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the xsltVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXSLTVersion() {
        return xsltVersion;
    }

    /**
     * Sets the value of the xsltVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXSLTVersion(String value) {
        this.xsltVersion = value;
    }

    /**
     * Gets the value of the strict property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrict() {
        return strict;
    }

    /**
     * Sets the value of the strict property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrict(String value) {
        this.strict = value;
    }

    /**
     * Gets the value of the profile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getProfile() {
        return profile;
    }

    /**
     * Sets the value of the profile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setProfile(DmReference value) {
        this.profile = value;
    }

    /**
     * Gets the value of the debug property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDebug() {
        return debug;
    }

    /**
     * Sets the value of the debug property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDebug(DmReference value) {
        this.debug = value;
    }

    /**
     * Gets the value of the stream property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getStream() {
        return stream;
    }

    /**
     * Sets the value of the stream property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setStream(DmReference value) {
        this.stream = value;
    }

    /**
     * Gets the value of the tryStream property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getTryStream() {
        return tryStream;
    }

    /**
     * Sets the value of the tryStream property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setTryStream(DmReference value) {
        this.tryStream = value;
    }

    /**
     * Gets the value of the minimumEscaping property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMinimumEscaping() {
        return minimumEscaping;
    }

    /**
     * Sets the value of the minimumEscaping property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMinimumEscaping(DmReference value) {
        this.minimumEscaping = value;
    }

    /**
     * Gets the value of the stackSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStackSize() {
        return stackSize;
    }

    /**
     * Sets the value of the stackSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStackSize(String value) {
        this.stackSize = value;
    }

    /**
     * Gets the value of the preferXG4 property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getPreferXG4() {
        return preferXG4;
    }

    /**
     * Sets the value of the preferXG4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setPreferXG4(DmReference value) {
        this.preferXG4 = value;
    }

    /**
     * Gets the value of the disallowXG4 property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDisallowXG4() {
        return disallowXG4;
    }

    /**
     * Sets the value of the disallowXG4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDisallowXG4(DmReference value) {
        this.disallowXG4 = value;
    }

    /**
     * Gets the value of the wsiValidation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSIValidation() {
        return wsiValidation;
    }

    /**
     * Sets the value of the wsiValidation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSIValidation(String value) {
        this.wsiValidation = value;
    }

    /**
     * Gets the value of the wsdlValidateBody property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLValidateBody() {
        return wsdlValidateBody;
    }

    /**
     * Sets the value of the wsdlValidateBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLValidateBody(String value) {
        this.wsdlValidateBody = value;
    }

    /**
     * Gets the value of the wsdlValidateHeaders property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLValidateHeaders() {
        return wsdlValidateHeaders;
    }

    /**
     * Sets the value of the wsdlValidateHeaders property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLValidateHeaders(String value) {
        this.wsdlValidateHeaders = value;
    }

    /**
     * Gets the value of the wsdlValidateFaults property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLValidateFaults() {
        return wsdlValidateFaults;
    }

    /**
     * Sets the value of the wsdlValidateFaults property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLValidateFaults(String value) {
        this.wsdlValidateFaults = value;
    }

    /**
     * Gets the value of the wsdlWrappedFaults property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLWrappedFaults() {
        return wsdlWrappedFaults;
    }

    /**
     * Sets the value of the wsdlWrappedFaults property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLWrappedFaults(String value) {
        this.wsdlWrappedFaults = value;
    }

    /**
     * Gets the value of the allowSoapEncArray property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAllowSoapEncArray() {
        return allowSoapEncArray;
    }

    /**
     * Sets the value of the allowSoapEncArray property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAllowSoapEncArray(DmReference value) {
        this.allowSoapEncArray = value;
    }

    /**
     * Gets the value of the validateSoapEncArray property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getValidateSoapEncArray() {
        return validateSoapEncArray;
    }

    /**
     * Sets the value of the validateSoapEncArray property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setValidateSoapEncArray(DmReference value) {
        this.validateSoapEncArray = value;
    }

    /**
     * Gets the value of the wildcardsIgnoreXsiType property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWildcardsIgnoreXsiType() {
        return wildcardsIgnoreXsiType;
    }

    /**
     * Sets the value of the wildcardsIgnoreXsiType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWildcardsIgnoreXsiType(DmReference value) {
        this.wildcardsIgnoreXsiType = value;
    }

    /**
     * Gets the value of the wsdlStrictSOAPVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLStrictSOAPVersion() {
        return wsdlStrictSOAPVersion;
    }

    /**
     * Sets the value of the wsdlStrictSOAPVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLStrictSOAPVersion(String value) {
        this.wsdlStrictSOAPVersion = value;
    }

    /**
     * Gets the value of the xacmlDebug property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXACMLDebug() {
        return xacmlDebug;
    }

    /**
     * Sets the value of the xacmlDebug property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXACMLDebug(String value) {
        this.xacmlDebug = value;
    }

    /**
     * Gets the value of the allowXOPInclude property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAllowXOPInclude() {
        return allowXOPInclude;
    }

    /**
     * Sets the value of the allowXOPInclude property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAllowXOPInclude(DmReference value) {
        this.allowXOPInclude = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
