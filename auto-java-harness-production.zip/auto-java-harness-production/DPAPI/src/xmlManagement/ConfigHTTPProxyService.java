
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigHTTPProxyService complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigHTTPProxyService"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigService"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSchedulerPriority {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemotePort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ACL" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="HTTPTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPPersistTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoHostRewrite" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuppressHTTPWarnings" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPCompression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPIncludeResponseTypeEncoding" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AlwaysShowErrors" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisallowGet" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisallowEmptyResponse" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPPersistentConnections" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPClientIPLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPLogCorIDLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPProxyHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPProxyPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPVersion" type="{http://www.datapower.com/schemas/management}dmHTTPClientServerVersion" minOccurs="0"/&gt;
 *         &lt;element name="DoChunkedUpload" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HeaderInjection" type="{http://www.datapower.com/schemas/management}dmHeaderInjection" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HeaderSuppression" type="{http://www.datapower.com/schemas/management}dmHeaderSuppression" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="StylesheetParameters" type="{http://www.datapower.com/schemas/management}dmStylesheetParameter" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DefaultParamNamespace" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="QueryParamNamespace" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ForcePolicyExec" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CountMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DurationMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MonitorProcessingPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmMonitorProcessingPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDebugMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugHistory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugTrigger" type="{http://www.datapower.com/schemas/management}dmMSDebugTriggerType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigHTTPProxyService", propOrder = {
    "userSummary",
    "priority",
    "localPort",
    "remoteAddress",
    "remotePort",
    "acl",
    "httpTimeout",
    "httpPersistTimeout",
    "doHostRewrite",
    "suppressHTTPWarnings",
    "httpCompression",
    "httpIncludeResponseTypeEncoding",
    "alwaysShowErrors",
    "disallowGet",
    "disallowEmptyResponse",
    "httpPersistentConnections",
    "httpClientIPLabel",
    "httpLogCorIDLabel",
    "httpProxyHost",
    "httpProxyPort",
    "httpVersion",
    "doChunkedUpload",
    "headerInjection",
    "headerSuppression",
    "stylesheetParameters",
    "defaultParamNamespace",
    "queryParamNamespace",
    "forcePolicyExec",
    "countMonitors",
    "durationMonitors",
    "monitorProcessingPolicy",
    "debugMode",
    "debugHistory",
    "debugTrigger"
})
@XmlSeeAlso({
    ConfigXMLFirewallService.class,
    ConfigXSLProxyService.class
})
public class ConfigHTTPProxyService
    extends ConfigService
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "RemoteAddress")
    protected String remoteAddress;
    @XmlElement(name = "RemotePort")
    protected String remotePort;
    @XmlElement(name = "ACL")
    protected DmReference acl;
    @XmlElement(name = "HTTPTimeout")
    protected String httpTimeout;
    @XmlElement(name = "HTTPPersistTimeout")
    protected String httpPersistTimeout;
    @XmlElement(name = "DoHostRewrite")
    protected String doHostRewrite;
    @XmlElement(name = "SuppressHTTPWarnings")
    protected String suppressHTTPWarnings;
    @XmlElement(name = "HTTPCompression")
    protected String httpCompression;
    @XmlElement(name = "HTTPIncludeResponseTypeEncoding")
    protected String httpIncludeResponseTypeEncoding;
    @XmlElement(name = "AlwaysShowErrors")
    protected String alwaysShowErrors;
    @XmlElement(name = "DisallowGet")
    protected String disallowGet;
    @XmlElement(name = "DisallowEmptyResponse")
    protected String disallowEmptyResponse;
    @XmlElement(name = "HTTPPersistentConnections")
    protected String httpPersistentConnections;
    @XmlElement(name = "HTTPClientIPLabel")
    protected String httpClientIPLabel;
    @XmlElement(name = "HTTPLogCorIDLabel")
    protected String httpLogCorIDLabel;
    @XmlElement(name = "HTTPProxyHost")
    protected String httpProxyHost;
    @XmlElement(name = "HTTPProxyPort")
    protected String httpProxyPort;
    @XmlElement(name = "HTTPVersion")
    protected DmHTTPClientServerVersion httpVersion;
    @XmlElement(name = "DoChunkedUpload")
    protected String doChunkedUpload;
    @XmlElement(name = "HeaderInjection")
    protected List<DmHeaderInjection> headerInjection;
    @XmlElement(name = "HeaderSuppression")
    protected List<DmHeaderSuppression> headerSuppression;
    @XmlElement(name = "StylesheetParameters")
    protected List<DmStylesheetParameter> stylesheetParameters;
    @XmlElement(name = "DefaultParamNamespace")
    protected String defaultParamNamespace;
    @XmlElement(name = "QueryParamNamespace")
    protected String queryParamNamespace;
    @XmlElement(name = "ForcePolicyExec")
    protected String forcePolicyExec;
    @XmlElement(name = "CountMonitors")
    protected List<DmReference> countMonitors;
    @XmlElement(name = "DurationMonitors")
    protected List<DmReference> durationMonitors;
    @XmlElement(name = "MonitorProcessingPolicy")
    protected String monitorProcessingPolicy;
    @XmlElement(name = "DebugMode")
    protected String debugMode;
    @XmlElement(name = "DebugHistory")
    protected String debugHistory;
    @XmlElement(name = "DebugTrigger")
    protected List<DmMSDebugTriggerType> debugTrigger;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the remoteAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteAddress() {
        return remoteAddress;
    }

    /**
     * Sets the value of the remoteAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteAddress(String value) {
        this.remoteAddress = value;
    }

    /**
     * Gets the value of the remotePort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemotePort() {
        return remotePort;
    }

    /**
     * Sets the value of the remotePort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemotePort(String value) {
        this.remotePort = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getACL() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setACL(DmReference value) {
        this.acl = value;
    }

    /**
     * Gets the value of the httpTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPTimeout() {
        return httpTimeout;
    }

    /**
     * Sets the value of the httpTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPTimeout(String value) {
        this.httpTimeout = value;
    }

    /**
     * Gets the value of the httpPersistTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPPersistTimeout() {
        return httpPersistTimeout;
    }

    /**
     * Sets the value of the httpPersistTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPPersistTimeout(String value) {
        this.httpPersistTimeout = value;
    }

    /**
     * Gets the value of the doHostRewrite property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoHostRewrite() {
        return doHostRewrite;
    }

    /**
     * Sets the value of the doHostRewrite property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoHostRewrite(String value) {
        this.doHostRewrite = value;
    }

    /**
     * Gets the value of the suppressHTTPWarnings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuppressHTTPWarnings() {
        return suppressHTTPWarnings;
    }

    /**
     * Sets the value of the suppressHTTPWarnings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuppressHTTPWarnings(String value) {
        this.suppressHTTPWarnings = value;
    }

    /**
     * Gets the value of the httpCompression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPCompression() {
        return httpCompression;
    }

    /**
     * Sets the value of the httpCompression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPCompression(String value) {
        this.httpCompression = value;
    }

    /**
     * Gets the value of the httpIncludeResponseTypeEncoding property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPIncludeResponseTypeEncoding() {
        return httpIncludeResponseTypeEncoding;
    }

    /**
     * Sets the value of the httpIncludeResponseTypeEncoding property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPIncludeResponseTypeEncoding(String value) {
        this.httpIncludeResponseTypeEncoding = value;
    }

    /**
     * Gets the value of the alwaysShowErrors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlwaysShowErrors() {
        return alwaysShowErrors;
    }

    /**
     * Sets the value of the alwaysShowErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlwaysShowErrors(String value) {
        this.alwaysShowErrors = value;
    }

    /**
     * Gets the value of the disallowGet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisallowGet() {
        return disallowGet;
    }

    /**
     * Sets the value of the disallowGet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisallowGet(String value) {
        this.disallowGet = value;
    }

    /**
     * Gets the value of the disallowEmptyResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisallowEmptyResponse() {
        return disallowEmptyResponse;
    }

    /**
     * Sets the value of the disallowEmptyResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisallowEmptyResponse(String value) {
        this.disallowEmptyResponse = value;
    }

    /**
     * Gets the value of the httpPersistentConnections property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPPersistentConnections() {
        return httpPersistentConnections;
    }

    /**
     * Sets the value of the httpPersistentConnections property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPPersistentConnections(String value) {
        this.httpPersistentConnections = value;
    }

    /**
     * Gets the value of the httpClientIPLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPClientIPLabel() {
        return httpClientIPLabel;
    }

    /**
     * Sets the value of the httpClientIPLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPClientIPLabel(String value) {
        this.httpClientIPLabel = value;
    }

    /**
     * Gets the value of the httpLogCorIDLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPLogCorIDLabel() {
        return httpLogCorIDLabel;
    }

    /**
     * Sets the value of the httpLogCorIDLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPLogCorIDLabel(String value) {
        this.httpLogCorIDLabel = value;
    }

    /**
     * Gets the value of the httpProxyHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPProxyHost() {
        return httpProxyHost;
    }

    /**
     * Sets the value of the httpProxyHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPProxyHost(String value) {
        this.httpProxyHost = value;
    }

    /**
     * Gets the value of the httpProxyPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPProxyPort() {
        return httpProxyPort;
    }

    /**
     * Sets the value of the httpProxyPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPProxyPort(String value) {
        this.httpProxyPort = value;
    }

    /**
     * Gets the value of the httpVersion property.
     * 
     * @return
     *     possible object is
     *     {@link DmHTTPClientServerVersion }
     *     
     */
    public DmHTTPClientServerVersion getHTTPVersion() {
        return httpVersion;
    }

    /**
     * Sets the value of the httpVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmHTTPClientServerVersion }
     *     
     */
    public void setHTTPVersion(DmHTTPClientServerVersion value) {
        this.httpVersion = value;
    }

    /**
     * Gets the value of the doChunkedUpload property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoChunkedUpload() {
        return doChunkedUpload;
    }

    /**
     * Sets the value of the doChunkedUpload property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoChunkedUpload(String value) {
        this.doChunkedUpload = value;
    }

    /**
     * Gets the value of the headerInjection property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerInjection property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderInjection().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmHeaderInjection }
     * 
     * 
     */
    public List<DmHeaderInjection> getHeaderInjection() {
        if (headerInjection == null) {
            headerInjection = new ArrayList<DmHeaderInjection>();
        }
        return this.headerInjection;
    }

    /**
     * Gets the value of the headerSuppression property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerSuppression property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderSuppression().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmHeaderSuppression }
     * 
     * 
     */
    public List<DmHeaderSuppression> getHeaderSuppression() {
        if (headerSuppression == null) {
            headerSuppression = new ArrayList<DmHeaderSuppression>();
        }
        return this.headerSuppression;
    }

    /**
     * Gets the value of the stylesheetParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stylesheetParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStylesheetParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmStylesheetParameter }
     * 
     * 
     */
    public List<DmStylesheetParameter> getStylesheetParameters() {
        if (stylesheetParameters == null) {
            stylesheetParameters = new ArrayList<DmStylesheetParameter>();
        }
        return this.stylesheetParameters;
    }

    /**
     * Gets the value of the defaultParamNamespace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultParamNamespace() {
        return defaultParamNamespace;
    }

    /**
     * Sets the value of the defaultParamNamespace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultParamNamespace(String value) {
        this.defaultParamNamespace = value;
    }

    /**
     * Gets the value of the queryParamNamespace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueryParamNamespace() {
        return queryParamNamespace;
    }

    /**
     * Sets the value of the queryParamNamespace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueryParamNamespace(String value) {
        this.queryParamNamespace = value;
    }

    /**
     * Gets the value of the forcePolicyExec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForcePolicyExec() {
        return forcePolicyExec;
    }

    /**
     * Sets the value of the forcePolicyExec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForcePolicyExec(String value) {
        this.forcePolicyExec = value;
    }

    /**
     * Gets the value of the countMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the countMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCountMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getCountMonitors() {
        if (countMonitors == null) {
            countMonitors = new ArrayList<DmReference>();
        }
        return this.countMonitors;
    }

    /**
     * Gets the value of the durationMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the durationMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDurationMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getDurationMonitors() {
        if (durationMonitors == null) {
            durationMonitors = new ArrayList<DmReference>();
        }
        return this.durationMonitors;
    }

    /**
     * Gets the value of the monitorProcessingPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonitorProcessingPolicy() {
        return monitorProcessingPolicy;
    }

    /**
     * Sets the value of the monitorProcessingPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonitorProcessingPolicy(String value) {
        this.monitorProcessingPolicy = value;
    }

    /**
     * Gets the value of the debugMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugMode() {
        return debugMode;
    }

    /**
     * Sets the value of the debugMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugMode(String value) {
        this.debugMode = value;
    }

    /**
     * Gets the value of the debugHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugHistory() {
        return debugHistory;
    }

    /**
     * Sets the value of the debugHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugHistory(String value) {
        this.debugHistory = value;
    }

    /**
     * Gets the value of the debugTrigger property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the debugTrigger property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDebugTrigger().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmMSDebugTriggerType }
     * 
     * 
     */
    public List<DmMSDebugTriggerType> getDebugTrigger() {
        if (debugTrigger == null) {
            debugTrigger = new ArrayList<DmMSDebugTriggerType>();
        }
        return this.debugTrigger;
    }

}
