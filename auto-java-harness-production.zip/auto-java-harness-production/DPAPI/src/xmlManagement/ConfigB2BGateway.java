
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigB2BGateway complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigB2BGateway"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSchedulerPriority {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DocStoreLocation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSDirectory {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ASFrontProtocol" type="{http://www.datapower.com/schemas/management}dmASFrontProtocol" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AS1MDNEmail" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AS1MDNSMTPServerConnection" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AS2MDNURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AS3MDNURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="B2BProfiles" type="{http://www.datapower.com/schemas/management}dmB2BActiveProfile" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="B2BGroups" type="{http://www.datapower.com/schemas/management}dmB2BActiveGroup" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DocumentRoutingPreprocessorType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmB2BDocumentRoutingPreprocessorType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DocumentRoutingPreprocessor"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DocumentRoutingPreprocessorDebug" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveMode"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmB2BArchiveMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveLocation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveFileName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveMinimumSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveDocumentAge" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveMinimumDocuments" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DiskUseCheckInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxDocumentDiskUse" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveMonitor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ShapingThreshold" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveBackupDocuments" type="{http://www.datapower.com/schemas/management}dmB2BBackupMsgType" minOccurs="0"/&gt;
 *         &lt;element name="XPathRoutingPolicies" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="DebugMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDebugMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugHistory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CPAEntries" type="{http://www.datapower.com/schemas/management}dmB2BCPAEntry" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SQLDataSource" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="FrontSideTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigB2BGateway", propOrder = {
    "userSummary",
    "priority",
    "docStoreLocation",
    "asFrontProtocol",
    "as1MDNEmail",
    "as1MDNSMTPServerConnection",
    "as2MDNURL",
    "as3MDNURL",
    "b2BProfiles",
    "b2BGroups",
    "documentRoutingPreprocessorType",
    "documentRoutingPreprocessor",
    "documentRoutingPreprocessorDebug",
    "archiveMode",
    "archiveLocation",
    "archiveFileName",
    "archiveMinimumSize",
    "archiveDocumentAge",
    "archiveMinimumDocuments",
    "diskUseCheckInterval",
    "maxDocumentDiskUse",
    "archiveMonitor",
    "shapingThreshold",
    "archiveBackupDocuments",
    "xPathRoutingPolicies",
    "xmlManager",
    "debugMode",
    "debugHistory",
    "cpaEntries",
    "sqlDataSource",
    "frontSideTimeout"
})
public class ConfigB2BGateway
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "DocStoreLocation")
    protected String docStoreLocation;
    @XmlElement(name = "ASFrontProtocol")
    protected List<DmASFrontProtocol> asFrontProtocol;
    @XmlElement(name = "AS1MDNEmail")
    protected String as1MDNEmail;
    @XmlElement(name = "AS1MDNSMTPServerConnection")
    protected DmReference as1MDNSMTPServerConnection;
    @XmlElement(name = "AS2MDNURL")
    protected String as2MDNURL;
    @XmlElement(name = "AS3MDNURL")
    protected String as3MDNURL;
    @XmlElement(name = "B2BProfiles")
    protected List<DmB2BActiveProfile> b2BProfiles;
    @XmlElement(name = "B2BGroups")
    protected List<DmB2BActiveGroup> b2BGroups;
    @XmlElement(name = "DocumentRoutingPreprocessorType")
    protected String documentRoutingPreprocessorType;
    @XmlElement(name = "DocumentRoutingPreprocessor")
    protected String documentRoutingPreprocessor;
    @XmlElement(name = "DocumentRoutingPreprocessorDebug")
    protected String documentRoutingPreprocessorDebug;
    @XmlElement(name = "ArchiveMode")
    protected String archiveMode;
    @XmlElement(name = "ArchiveLocation")
    protected String archiveLocation;
    @XmlElement(name = "ArchiveFileName")
    protected String archiveFileName;
    @XmlElement(name = "ArchiveMinimumSize")
    protected String archiveMinimumSize;
    @XmlElement(name = "ArchiveDocumentAge")
    protected String archiveDocumentAge;
    @XmlElement(name = "ArchiveMinimumDocuments")
    protected String archiveMinimumDocuments;
    @XmlElement(name = "DiskUseCheckInterval")
    protected String diskUseCheckInterval;
    @XmlElement(name = "MaxDocumentDiskUse")
    protected String maxDocumentDiskUse;
    @XmlElement(name = "ArchiveMonitor")
    protected String archiveMonitor;
    @XmlElement(name = "ShapingThreshold")
    protected String shapingThreshold;
    @XmlElement(name = "ArchiveBackupDocuments")
    protected DmB2BBackupMsgType archiveBackupDocuments;
    @XmlElement(name = "XPathRoutingPolicies")
    protected List<DmReference> xPathRoutingPolicies;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "DebugMode")
    protected String debugMode;
    @XmlElement(name = "DebugHistory")
    protected String debugHistory;
    @XmlElement(name = "CPAEntries")
    protected List<DmB2BCPAEntry> cpaEntries;
    @XmlElement(name = "SQLDataSource")
    protected DmReference sqlDataSource;
    @XmlElement(name = "FrontSideTimeout")
    protected String frontSideTimeout;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the docStoreLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocStoreLocation() {
        return docStoreLocation;
    }

    /**
     * Sets the value of the docStoreLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocStoreLocation(String value) {
        this.docStoreLocation = value;
    }

    /**
     * Gets the value of the asFrontProtocol property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the asFrontProtocol property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getASFrontProtocol().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmASFrontProtocol }
     * 
     * 
     */
    public List<DmASFrontProtocol> getASFrontProtocol() {
        if (asFrontProtocol == null) {
            asFrontProtocol = new ArrayList<DmASFrontProtocol>();
        }
        return this.asFrontProtocol;
    }

    /**
     * Gets the value of the as1MDNEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAS1MDNEmail() {
        return as1MDNEmail;
    }

    /**
     * Sets the value of the as1MDNEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAS1MDNEmail(String value) {
        this.as1MDNEmail = value;
    }

    /**
     * Gets the value of the as1MDNSMTPServerConnection property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAS1MDNSMTPServerConnection() {
        return as1MDNSMTPServerConnection;
    }

    /**
     * Sets the value of the as1MDNSMTPServerConnection property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAS1MDNSMTPServerConnection(DmReference value) {
        this.as1MDNSMTPServerConnection = value;
    }

    /**
     * Gets the value of the as2MDNURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAS2MDNURL() {
        return as2MDNURL;
    }

    /**
     * Sets the value of the as2MDNURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAS2MDNURL(String value) {
        this.as2MDNURL = value;
    }

    /**
     * Gets the value of the as3MDNURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAS3MDNURL() {
        return as3MDNURL;
    }

    /**
     * Sets the value of the as3MDNURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAS3MDNURL(String value) {
        this.as3MDNURL = value;
    }

    /**
     * Gets the value of the b2BProfiles property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the b2BProfiles property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getB2BProfiles().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmB2BActiveProfile }
     * 
     * 
     */
    public List<DmB2BActiveProfile> getB2BProfiles() {
        if (b2BProfiles == null) {
            b2BProfiles = new ArrayList<DmB2BActiveProfile>();
        }
        return this.b2BProfiles;
    }

    /**
     * Gets the value of the b2BGroups property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the b2BGroups property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getB2BGroups().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmB2BActiveGroup }
     * 
     * 
     */
    public List<DmB2BActiveGroup> getB2BGroups() {
        if (b2BGroups == null) {
            b2BGroups = new ArrayList<DmB2BActiveGroup>();
        }
        return this.b2BGroups;
    }

    /**
     * Gets the value of the documentRoutingPreprocessorType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentRoutingPreprocessorType() {
        return documentRoutingPreprocessorType;
    }

    /**
     * Sets the value of the documentRoutingPreprocessorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentRoutingPreprocessorType(String value) {
        this.documentRoutingPreprocessorType = value;
    }

    /**
     * Gets the value of the documentRoutingPreprocessor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentRoutingPreprocessor() {
        return documentRoutingPreprocessor;
    }

    /**
     * Sets the value of the documentRoutingPreprocessor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentRoutingPreprocessor(String value) {
        this.documentRoutingPreprocessor = value;
    }

    /**
     * Gets the value of the documentRoutingPreprocessorDebug property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentRoutingPreprocessorDebug() {
        return documentRoutingPreprocessorDebug;
    }

    /**
     * Sets the value of the documentRoutingPreprocessorDebug property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentRoutingPreprocessorDebug(String value) {
        this.documentRoutingPreprocessorDebug = value;
    }

    /**
     * Gets the value of the archiveMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveMode() {
        return archiveMode;
    }

    /**
     * Sets the value of the archiveMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveMode(String value) {
        this.archiveMode = value;
    }

    /**
     * Gets the value of the archiveLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveLocation() {
        return archiveLocation;
    }

    /**
     * Sets the value of the archiveLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveLocation(String value) {
        this.archiveLocation = value;
    }

    /**
     * Gets the value of the archiveFileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveFileName() {
        return archiveFileName;
    }

    /**
     * Sets the value of the archiveFileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveFileName(String value) {
        this.archiveFileName = value;
    }

    /**
     * Gets the value of the archiveMinimumSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveMinimumSize() {
        return archiveMinimumSize;
    }

    /**
     * Sets the value of the archiveMinimumSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveMinimumSize(String value) {
        this.archiveMinimumSize = value;
    }

    /**
     * Gets the value of the archiveDocumentAge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveDocumentAge() {
        return archiveDocumentAge;
    }

    /**
     * Sets the value of the archiveDocumentAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveDocumentAge(String value) {
        this.archiveDocumentAge = value;
    }

    /**
     * Gets the value of the archiveMinimumDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveMinimumDocuments() {
        return archiveMinimumDocuments;
    }

    /**
     * Sets the value of the archiveMinimumDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveMinimumDocuments(String value) {
        this.archiveMinimumDocuments = value;
    }

    /**
     * Gets the value of the diskUseCheckInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiskUseCheckInterval() {
        return diskUseCheckInterval;
    }

    /**
     * Sets the value of the diskUseCheckInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiskUseCheckInterval(String value) {
        this.diskUseCheckInterval = value;
    }

    /**
     * Gets the value of the maxDocumentDiskUse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxDocumentDiskUse() {
        return maxDocumentDiskUse;
    }

    /**
     * Sets the value of the maxDocumentDiskUse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxDocumentDiskUse(String value) {
        this.maxDocumentDiskUse = value;
    }

    /**
     * Gets the value of the archiveMonitor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveMonitor() {
        return archiveMonitor;
    }

    /**
     * Sets the value of the archiveMonitor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveMonitor(String value) {
        this.archiveMonitor = value;
    }

    /**
     * Gets the value of the shapingThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShapingThreshold() {
        return shapingThreshold;
    }

    /**
     * Sets the value of the shapingThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShapingThreshold(String value) {
        this.shapingThreshold = value;
    }

    /**
     * Gets the value of the archiveBackupDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link DmB2BBackupMsgType }
     *     
     */
    public DmB2BBackupMsgType getArchiveBackupDocuments() {
        return archiveBackupDocuments;
    }

    /**
     * Sets the value of the archiveBackupDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmB2BBackupMsgType }
     *     
     */
    public void setArchiveBackupDocuments(DmB2BBackupMsgType value) {
        this.archiveBackupDocuments = value;
    }

    /**
     * Gets the value of the xPathRoutingPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the xPathRoutingPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getXPathRoutingPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getXPathRoutingPolicies() {
        if (xPathRoutingPolicies == null) {
            xPathRoutingPolicies = new ArrayList<DmReference>();
        }
        return this.xPathRoutingPolicies;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the debugMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugMode() {
        return debugMode;
    }

    /**
     * Sets the value of the debugMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugMode(String value) {
        this.debugMode = value;
    }

    /**
     * Gets the value of the debugHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugHistory() {
        return debugHistory;
    }

    /**
     * Sets the value of the debugHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugHistory(String value) {
        this.debugHistory = value;
    }

    /**
     * Gets the value of the cpaEntries property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cpaEntries property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCPAEntries().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmB2BCPAEntry }
     * 
     * 
     */
    public List<DmB2BCPAEntry> getCPAEntries() {
        if (cpaEntries == null) {
            cpaEntries = new ArrayList<DmB2BCPAEntry>();
        }
        return this.cpaEntries;
    }

    /**
     * Gets the value of the sqlDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSQLDataSource() {
        return sqlDataSource;
    }

    /**
     * Sets the value of the sqlDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSQLDataSource(DmReference value) {
        this.sqlDataSource = value;
    }

    /**
     * Gets the value of the frontSideTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontSideTimeout() {
        return frontSideTimeout;
    }

    /**
     * Sets the value of the frontSideTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontSideTimeout(String value) {
        this.frontSideTimeout = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
