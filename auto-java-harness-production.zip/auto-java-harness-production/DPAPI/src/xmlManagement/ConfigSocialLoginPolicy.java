
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSocialLoginPolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSocialLoginPolicy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigCrypto"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientID"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientSecret"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientGrant" type="{http://www.datapower.com/schemas/management}dmClientGrantType" minOccurs="0"/&gt;
 *         &lt;element name="ClientScope" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientRedirectURI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientOptionalQueryParams" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientSSLProfile" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="Provider" type="{http://www.datapower.com/schemas/management}dmProviderType"/&gt;
 *         &lt;element name="ProviderAZEndpoint" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProviderTokenEndpoint" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ValidateJWTToken"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JWTValidator" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSocialLoginPolicy", propOrder = {
    "userSummary",
    "clientID",
    "clientSecret",
    "clientGrant",
    "clientScope",
    "clientRedirectURI",
    "clientOptionalQueryParams",
    "clientSSLProfile",
    "provider",
    "providerAZEndpoint",
    "providerTokenEndpoint",
    "validateJWTToken",
    "jwtValidator"
})
public class ConfigSocialLoginPolicy
    extends ConfigCrypto
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "ClientID")
    protected String clientID;
    @XmlElement(name = "ClientSecret")
    protected String clientSecret;
    @XmlElement(name = "ClientGrant")
    @XmlSchemaType(name = "string")
    protected DmClientGrantType clientGrant;
    @XmlElement(name = "ClientScope")
    protected String clientScope;
    @XmlElement(name = "ClientRedirectURI")
    protected String clientRedirectURI;
    @XmlElement(name = "ClientOptionalQueryParams")
    protected String clientOptionalQueryParams;
    @XmlElement(name = "ClientSSLProfile")
    protected DmReference clientSSLProfile;
    @XmlElement(name = "Provider")
    @XmlSchemaType(name = "string")
    protected DmProviderType provider;
    @XmlElement(name = "ProviderAZEndpoint")
    protected String providerAZEndpoint;
    @XmlElement(name = "ProviderTokenEndpoint")
    protected String providerTokenEndpoint;
    @XmlElement(name = "ValidateJWTToken")
    protected String validateJWTToken;
    @XmlElement(name = "JWTValidator")
    protected DmReference jwtValidator;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the clientID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientID() {
        return clientID;
    }

    /**
     * Sets the value of the clientID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientID(String value) {
        this.clientID = value;
    }

    /**
     * Gets the value of the clientSecret property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientSecret() {
        return clientSecret;
    }

    /**
     * Sets the value of the clientSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientSecret(String value) {
        this.clientSecret = value;
    }

    /**
     * Gets the value of the clientGrant property.
     * 
     * @return
     *     possible object is
     *     {@link DmClientGrantType }
     *     
     */
    public DmClientGrantType getClientGrant() {
        return clientGrant;
    }

    /**
     * Sets the value of the clientGrant property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmClientGrantType }
     *     
     */
    public void setClientGrant(DmClientGrantType value) {
        this.clientGrant = value;
    }

    /**
     * Gets the value of the clientScope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientScope() {
        return clientScope;
    }

    /**
     * Sets the value of the clientScope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientScope(String value) {
        this.clientScope = value;
    }

    /**
     * Gets the value of the clientRedirectURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientRedirectURI() {
        return clientRedirectURI;
    }

    /**
     * Sets the value of the clientRedirectURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientRedirectURI(String value) {
        this.clientRedirectURI = value;
    }

    /**
     * Gets the value of the clientOptionalQueryParams property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientOptionalQueryParams() {
        return clientOptionalQueryParams;
    }

    /**
     * Sets the value of the clientOptionalQueryParams property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientOptionalQueryParams(String value) {
        this.clientOptionalQueryParams = value;
    }

    /**
     * Gets the value of the clientSSLProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getClientSSLProfile() {
        return clientSSLProfile;
    }

    /**
     * Sets the value of the clientSSLProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setClientSSLProfile(DmReference value) {
        this.clientSSLProfile = value;
    }

    /**
     * Gets the value of the provider property.
     * 
     * @return
     *     possible object is
     *     {@link DmProviderType }
     *     
     */
    public DmProviderType getProvider() {
        return provider;
    }

    /**
     * Sets the value of the provider property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmProviderType }
     *     
     */
    public void setProvider(DmProviderType value) {
        this.provider = value;
    }

    /**
     * Gets the value of the providerAZEndpoint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderAZEndpoint() {
        return providerAZEndpoint;
    }

    /**
     * Sets the value of the providerAZEndpoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderAZEndpoint(String value) {
        this.providerAZEndpoint = value;
    }

    /**
     * Gets the value of the providerTokenEndpoint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderTokenEndpoint() {
        return providerTokenEndpoint;
    }

    /**
     * Sets the value of the providerTokenEndpoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderTokenEndpoint(String value) {
        this.providerTokenEndpoint = value;
    }

    /**
     * Gets the value of the validateJWTToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidateJWTToken() {
        return validateJWTToken;
    }

    /**
     * Sets the value of the validateJWTToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidateJWTToken(String value) {
        this.validateJWTToken = value;
    }

    /**
     * Gets the value of the jwtValidator property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getJWTValidator() {
        return jwtValidator;
    }

    /**
     * Sets the value of the jwtValidator property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setJWTValidator(DmReference value) {
        this.jwtValidator = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
