
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigMQhost complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigMQhost"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigMQConfiguration"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="QueueManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="GetQueue"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PutQueue"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="ContentType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MessageType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Credentials" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="StylesheetParameters" type="{http://www.datapower.com/schemas/management}dmStylesheetParameter" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DefaultParameterNamespace" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StylePolicyRule" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="FirewallExtensions" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AttachmentsMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontAttachmentFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackAttachmentFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDebugMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugHistory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugTrigger" type="{http://www.datapower.com/schemas/management}dmMQMSDebugTriggerType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CodePage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SOAPSchemaURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CountMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DurationMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigMQhost", propOrder = {
    "userSummary",
    "queueManager",
    "getQueue",
    "putQueue",
    "xmlManager",
    "contentType",
    "messageType",
    "credentials",
    "stylesheetParameters",
    "defaultParameterNamespace",
    "stylePolicyRule",
    "firewallExtensions",
    "attachmentsMode",
    "frontAttachmentFormat",
    "backAttachmentFormat",
    "debugMode",
    "debugHistory",
    "debugTrigger",
    "codePage",
    "soapSchemaURL",
    "countMonitors",
    "durationMonitors"
})
public class ConfigMQhost
    extends ConfigMQConfiguration
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "QueueManager")
    protected DmReference queueManager;
    @XmlElement(name = "GetQueue")
    protected String getQueue;
    @XmlElement(name = "PutQueue")
    protected String putQueue;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "ContentType")
    protected String contentType;
    @XmlElement(name = "MessageType")
    protected String messageType;
    @XmlElement(name = "Credentials")
    protected DmReference credentials;
    @XmlElement(name = "StylesheetParameters")
    protected List<DmStylesheetParameter> stylesheetParameters;
    @XmlElement(name = "DefaultParameterNamespace")
    protected String defaultParameterNamespace;
    @XmlElement(name = "StylePolicyRule")
    protected DmReference stylePolicyRule;
    @XmlElement(name = "FirewallExtensions")
    protected String firewallExtensions;
    @XmlElement(name = "AttachmentsMode")
    protected String attachmentsMode;
    @XmlElement(name = "FrontAttachmentFormat")
    protected String frontAttachmentFormat;
    @XmlElement(name = "BackAttachmentFormat")
    protected String backAttachmentFormat;
    @XmlElement(name = "DebugMode")
    protected String debugMode;
    @XmlElement(name = "DebugHistory")
    protected String debugHistory;
    @XmlElement(name = "DebugTrigger")
    protected List<DmMQMSDebugTriggerType> debugTrigger;
    @XmlElement(name = "CodePage")
    protected String codePage;
    @XmlElement(name = "SOAPSchemaURL")
    protected String soapSchemaURL;
    @XmlElement(name = "CountMonitors")
    protected List<DmReference> countMonitors;
    @XmlElement(name = "DurationMonitors")
    protected List<DmReference> durationMonitors;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the queueManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getQueueManager() {
        return queueManager;
    }

    /**
     * Sets the value of the queueManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setQueueManager(DmReference value) {
        this.queueManager = value;
    }

    /**
     * Gets the value of the getQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGetQueue() {
        return getQueue;
    }

    /**
     * Sets the value of the getQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGetQueue(String value) {
        this.getQueue = value;
    }

    /**
     * Gets the value of the putQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPutQueue() {
        return putQueue;
    }

    /**
     * Sets the value of the putQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPutQueue(String value) {
        this.putQueue = value;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the contentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Sets the value of the contentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentType(String value) {
        this.contentType = value;
    }

    /**
     * Gets the value of the messageType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * Sets the value of the messageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageType(String value) {
        this.messageType = value;
    }

    /**
     * Gets the value of the credentials property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getCredentials() {
        return credentials;
    }

    /**
     * Sets the value of the credentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setCredentials(DmReference value) {
        this.credentials = value;
    }

    /**
     * Gets the value of the stylesheetParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stylesheetParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStylesheetParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmStylesheetParameter }
     * 
     * 
     */
    public List<DmStylesheetParameter> getStylesheetParameters() {
        if (stylesheetParameters == null) {
            stylesheetParameters = new ArrayList<DmStylesheetParameter>();
        }
        return this.stylesheetParameters;
    }

    /**
     * Gets the value of the defaultParameterNamespace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultParameterNamespace() {
        return defaultParameterNamespace;
    }

    /**
     * Sets the value of the defaultParameterNamespace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultParameterNamespace(String value) {
        this.defaultParameterNamespace = value;
    }

    /**
     * Gets the value of the stylePolicyRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getStylePolicyRule() {
        return stylePolicyRule;
    }

    /**
     * Sets the value of the stylePolicyRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setStylePolicyRule(DmReference value) {
        this.stylePolicyRule = value;
    }

    /**
     * Gets the value of the firewallExtensions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirewallExtensions() {
        return firewallExtensions;
    }

    /**
     * Sets the value of the firewallExtensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirewallExtensions(String value) {
        this.firewallExtensions = value;
    }

    /**
     * Gets the value of the attachmentsMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachmentsMode() {
        return attachmentsMode;
    }

    /**
     * Sets the value of the attachmentsMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachmentsMode(String value) {
        this.attachmentsMode = value;
    }

    /**
     * Gets the value of the frontAttachmentFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontAttachmentFormat() {
        return frontAttachmentFormat;
    }

    /**
     * Sets the value of the frontAttachmentFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontAttachmentFormat(String value) {
        this.frontAttachmentFormat = value;
    }

    /**
     * Gets the value of the backAttachmentFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackAttachmentFormat() {
        return backAttachmentFormat;
    }

    /**
     * Sets the value of the backAttachmentFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackAttachmentFormat(String value) {
        this.backAttachmentFormat = value;
    }

    /**
     * Gets the value of the debugMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugMode() {
        return debugMode;
    }

    /**
     * Sets the value of the debugMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugMode(String value) {
        this.debugMode = value;
    }

    /**
     * Gets the value of the debugHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugHistory() {
        return debugHistory;
    }

    /**
     * Sets the value of the debugHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugHistory(String value) {
        this.debugHistory = value;
    }

    /**
     * Gets the value of the debugTrigger property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the debugTrigger property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDebugTrigger().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmMQMSDebugTriggerType }
     * 
     * 
     */
    public List<DmMQMSDebugTriggerType> getDebugTrigger() {
        if (debugTrigger == null) {
            debugTrigger = new ArrayList<DmMQMSDebugTriggerType>();
        }
        return this.debugTrigger;
    }

    /**
     * Gets the value of the codePage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePage() {
        return codePage;
    }

    /**
     * Sets the value of the codePage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePage(String value) {
        this.codePage = value;
    }

    /**
     * Gets the value of the soapSchemaURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOAPSchemaURL() {
        return soapSchemaURL;
    }

    /**
     * Sets the value of the soapSchemaURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOAPSchemaURL(String value) {
        this.soapSchemaURL = value;
    }

    /**
     * Gets the value of the countMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the countMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCountMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getCountMonitors() {
        if (countMonitors == null) {
            countMonitors = new ArrayList<DmReference>();
        }
        return this.countMonitors;
    }

    /**
     * Gets the value of the durationMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the durationMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDurationMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getDurationMonitors() {
        if (durationMonitors == null) {
            durationMonitors = new ArrayList<DmReference>();
        }
        return this.durationMonitors;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
