
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigWSGateway complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigWSGateway"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigGatewayBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="RequestType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType1 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType1 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FollowRedirects" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCompression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Type"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSGatewayType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AutoCreateSources" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLServerConfigType" type="{http://www.datapower.com/schemas/management}dmSSLConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLSNIServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EndpointRewritePolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LocalEndpointRewrite" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="RemoteEndpointRewrite" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AAAPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="StylePolicy" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="RemoteFetchRetry" type="{http://www.datapower.com/schemas/management}dmNetworkRetry" minOccurs="0"/&gt;
 *         &lt;element name="WSDLCachePolicy" type="{http://www.datapower.com/schemas/management}dmWSDLCachePolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BaseWSDL" type="{http://www.datapower.com/schemas/management}dmWSBaseWSDL" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UserToggles" type="{http://www.datapower.com/schemas/management}dmWSUserToggles" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ClientPrincipal" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ServerPrincipal" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="KerberosKeytab" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DecryptKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EncryptedKeySHA1CacheLifeTime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PreserveKeyChain" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DecryptWithKeyFromED" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SOAPActionPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSOAPActionMatchPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UDDISubscriptions" type="{http://www.datapower.com/schemas/management}dmUDDIWSDLSource" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="WSRRSubscriptions" type="{http://www.datapower.com/schemas/management}dmWSRRWSDLSource" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="WSRRSavedSearchSubscriptions" type="{http://www.datapower.com/schemas/management}dmWSRRSavedSearchWSDLSource" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OperationPriority" type="{http://www.datapower.com/schemas/management}dmWSOperationSchedulerPriority" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OperationConformancePolicy" type="{http://www.datapower.com/schemas/management}dmWSOperationConformancePolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OperationPolicySubjectOptOut" type="{http://www.datapower.com/schemas/management}dmWSOperationPolicySubjectOptOut" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PolicyParameter" type="{http://www.datapower.com/schemas/management}dmWSPolicyParameters" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ReliableMessaging" type="{http://www.datapower.com/schemas/management}dmWSOperationReliableMessaging" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="WSMAgentMonitor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSMAgentMonitorPCM" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSMPayloadCaptureMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProcessRespRulesOnOneWayMEP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigWSGateway", propOrder = {
    "requestType",
    "responseType",
    "followRedirects",
    "allowCompression",
    "type",
    "autoCreateSources",
    "sslServerConfigType",
    "sslServer",
    "sslsniServer",
    "endpointRewritePolicy",
    "localEndpointRewrite",
    "remoteEndpointRewrite",
    "aaaPolicy",
    "stylePolicy",
    "remoteFetchRetry",
    "wsdlCachePolicy",
    "baseWSDL",
    "userToggles",
    "clientPrincipal",
    "serverPrincipal",
    "kerberosKeytab",
    "decryptKey",
    "encryptedKeySHA1CacheLifeTime",
    "preserveKeyChain",
    "decryptWithKeyFromED",
    "soapActionPolicy",
    "uddiSubscriptions",
    "wsrrSubscriptions",
    "wsrrSavedSearchSubscriptions",
    "operationPriority",
    "operationConformancePolicy",
    "operationPolicySubjectOptOut",
    "policyParameter",
    "reliableMessaging",
    "wsmAgentMonitor",
    "wsmAgentMonitorPCM",
    "processRespRulesOnOneWayMEP"
})
public class ConfigWSGateway
    extends ConfigGatewayBase
{

    @XmlElement(name = "RequestType")
    protected String requestType;
    @XmlElement(name = "ResponseType")
    protected String responseType;
    @XmlElement(name = "FollowRedirects")
    protected String followRedirects;
    @XmlElement(name = "AllowCompression")
    protected String allowCompression;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "AutoCreateSources")
    protected String autoCreateSources;
    @XmlElement(name = "SSLServerConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLConfigType sslServerConfigType;
    @XmlElement(name = "SSLServer")
    protected DmReference sslServer;
    @XmlElement(name = "SSLSNIServer")
    protected DmReference sslsniServer;
    @XmlElement(name = "EndpointRewritePolicy")
    protected DmReference endpointRewritePolicy;
    @XmlElement(name = "LocalEndpointRewrite")
    protected DmReference localEndpointRewrite;
    @XmlElement(name = "RemoteEndpointRewrite")
    protected DmReference remoteEndpointRewrite;
    @XmlElement(name = "AAAPolicy")
    protected DmReference aaaPolicy;
    @XmlElement(name = "StylePolicy")
    protected DmReference stylePolicy;
    @XmlElement(name = "RemoteFetchRetry")
    protected DmNetworkRetry remoteFetchRetry;
    @XmlElement(name = "WSDLCachePolicy")
    protected List<DmWSDLCachePolicy> wsdlCachePolicy;
    @XmlElement(name = "BaseWSDL")
    protected List<DmWSBaseWSDL> baseWSDL;
    @XmlElement(name = "UserToggles")
    protected List<DmWSUserToggles> userToggles;
    @XmlElement(name = "ClientPrincipal")
    protected String clientPrincipal;
    @XmlElement(name = "ServerPrincipal")
    protected String serverPrincipal;
    @XmlElement(name = "KerberosKeytab")
    protected DmReference kerberosKeytab;
    @XmlElement(name = "DecryptKey")
    protected DmReference decryptKey;
    @XmlElement(name = "EncryptedKeySHA1CacheLifeTime")
    protected String encryptedKeySHA1CacheLifeTime;
    @XmlElement(name = "PreserveKeyChain")
    protected String preserveKeyChain;
    @XmlElement(name = "DecryptWithKeyFromED")
    protected String decryptWithKeyFromED;
    @XmlElement(name = "SOAPActionPolicy")
    protected String soapActionPolicy;
    @XmlElement(name = "UDDISubscriptions")
    protected List<DmUDDIWSDLSource> uddiSubscriptions;
    @XmlElement(name = "WSRRSubscriptions")
    protected List<DmWSRRWSDLSource> wsrrSubscriptions;
    @XmlElement(name = "WSRRSavedSearchSubscriptions")
    protected List<DmWSRRSavedSearchWSDLSource> wsrrSavedSearchSubscriptions;
    @XmlElement(name = "OperationPriority")
    protected List<DmWSOperationSchedulerPriority> operationPriority;
    @XmlElement(name = "OperationConformancePolicy")
    protected List<DmWSOperationConformancePolicy> operationConformancePolicy;
    @XmlElement(name = "OperationPolicySubjectOptOut")
    protected List<DmWSOperationPolicySubjectOptOut> operationPolicySubjectOptOut;
    @XmlElement(name = "PolicyParameter")
    protected List<DmWSPolicyParameters> policyParameter;
    @XmlElement(name = "ReliableMessaging")
    protected List<DmWSOperationReliableMessaging> reliableMessaging;
    @XmlElement(name = "WSMAgentMonitor")
    protected String wsmAgentMonitor;
    @XmlElement(name = "WSMAgentMonitorPCM")
    protected String wsmAgentMonitorPCM;
    @XmlElement(name = "ProcessRespRulesOnOneWayMEP")
    protected String processRespRulesOnOneWayMEP;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the followRedirects property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFollowRedirects() {
        return followRedirects;
    }

    /**
     * Sets the value of the followRedirects property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFollowRedirects(String value) {
        this.followRedirects = value;
    }

    /**
     * Gets the value of the allowCompression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCompression() {
        return allowCompression;
    }

    /**
     * Sets the value of the allowCompression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCompression(String value) {
        this.allowCompression = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the autoCreateSources property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoCreateSources() {
        return autoCreateSources;
    }

    /**
     * Sets the value of the autoCreateSources property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoCreateSources(String value) {
        this.autoCreateSources = value;
    }

    /**
     * Gets the value of the sslServerConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLConfigType }
     *     
     */
    public DmSSLConfigType getSSLServerConfigType() {
        return sslServerConfigType;
    }

    /**
     * Sets the value of the sslServerConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLConfigType }
     *     
     */
    public void setSSLServerConfigType(DmSSLConfigType value) {
        this.sslServerConfigType = value;
    }

    /**
     * Gets the value of the sslServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLServer() {
        return sslServer;
    }

    /**
     * Sets the value of the sslServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLServer(DmReference value) {
        this.sslServer = value;
    }

    /**
     * Gets the value of the sslsniServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLSNIServer() {
        return sslsniServer;
    }

    /**
     * Sets the value of the sslsniServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLSNIServer(DmReference value) {
        this.sslsniServer = value;
    }

    /**
     * Gets the value of the endpointRewritePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEndpointRewritePolicy() {
        return endpointRewritePolicy;
    }

    /**
     * Sets the value of the endpointRewritePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEndpointRewritePolicy(DmReference value) {
        this.endpointRewritePolicy = value;
    }

    /**
     * Gets the value of the localEndpointRewrite property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLocalEndpointRewrite() {
        return localEndpointRewrite;
    }

    /**
     * Sets the value of the localEndpointRewrite property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLocalEndpointRewrite(DmReference value) {
        this.localEndpointRewrite = value;
    }

    /**
     * Gets the value of the remoteEndpointRewrite property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getRemoteEndpointRewrite() {
        return remoteEndpointRewrite;
    }

    /**
     * Sets the value of the remoteEndpointRewrite property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setRemoteEndpointRewrite(DmReference value) {
        this.remoteEndpointRewrite = value;
    }

    /**
     * Gets the value of the aaaPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAAAPolicy() {
        return aaaPolicy;
    }

    /**
     * Sets the value of the aaaPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAAAPolicy(DmReference value) {
        this.aaaPolicy = value;
    }

    /**
     * Gets the value of the stylePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getStylePolicy() {
        return stylePolicy;
    }

    /**
     * Sets the value of the stylePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setStylePolicy(DmReference value) {
        this.stylePolicy = value;
    }

    /**
     * Gets the value of the remoteFetchRetry property.
     * 
     * @return
     *     possible object is
     *     {@link DmNetworkRetry }
     *     
     */
    public DmNetworkRetry getRemoteFetchRetry() {
        return remoteFetchRetry;
    }

    /**
     * Sets the value of the remoteFetchRetry property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmNetworkRetry }
     *     
     */
    public void setRemoteFetchRetry(DmNetworkRetry value) {
        this.remoteFetchRetry = value;
    }

    /**
     * Gets the value of the wsdlCachePolicy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wsdlCachePolicy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWSDLCachePolicy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSDLCachePolicy }
     * 
     * 
     */
    public List<DmWSDLCachePolicy> getWSDLCachePolicy() {
        if (wsdlCachePolicy == null) {
            wsdlCachePolicy = new ArrayList<DmWSDLCachePolicy>();
        }
        return this.wsdlCachePolicy;
    }

    /**
     * Gets the value of the baseWSDL property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the baseWSDL property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBaseWSDL().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSBaseWSDL }
     * 
     * 
     */
    public List<DmWSBaseWSDL> getBaseWSDL() {
        if (baseWSDL == null) {
            baseWSDL = new ArrayList<DmWSBaseWSDL>();
        }
        return this.baseWSDL;
    }

    /**
     * Gets the value of the userToggles property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the userToggles property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUserToggles().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSUserToggles }
     * 
     * 
     */
    public List<DmWSUserToggles> getUserToggles() {
        if (userToggles == null) {
            userToggles = new ArrayList<DmWSUserToggles>();
        }
        return this.userToggles;
    }

    /**
     * Gets the value of the clientPrincipal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientPrincipal() {
        return clientPrincipal;
    }

    /**
     * Sets the value of the clientPrincipal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientPrincipal(String value) {
        this.clientPrincipal = value;
    }

    /**
     * Gets the value of the serverPrincipal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServerPrincipal() {
        return serverPrincipal;
    }

    /**
     * Sets the value of the serverPrincipal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServerPrincipal(String value) {
        this.serverPrincipal = value;
    }

    /**
     * Gets the value of the kerberosKeytab property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getKerberosKeytab() {
        return kerberosKeytab;
    }

    /**
     * Sets the value of the kerberosKeytab property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setKerberosKeytab(DmReference value) {
        this.kerberosKeytab = value;
    }

    /**
     * Gets the value of the decryptKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDecryptKey() {
        return decryptKey;
    }

    /**
     * Sets the value of the decryptKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDecryptKey(DmReference value) {
        this.decryptKey = value;
    }

    /**
     * Gets the value of the encryptedKeySHA1CacheLifeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncryptedKeySHA1CacheLifeTime() {
        return encryptedKeySHA1CacheLifeTime;
    }

    /**
     * Sets the value of the encryptedKeySHA1CacheLifeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncryptedKeySHA1CacheLifeTime(String value) {
        this.encryptedKeySHA1CacheLifeTime = value;
    }

    /**
     * Gets the value of the preserveKeyChain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreserveKeyChain() {
        return preserveKeyChain;
    }

    /**
     * Sets the value of the preserveKeyChain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreserveKeyChain(String value) {
        this.preserveKeyChain = value;
    }

    /**
     * Gets the value of the decryptWithKeyFromED property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecryptWithKeyFromED() {
        return decryptWithKeyFromED;
    }

    /**
     * Sets the value of the decryptWithKeyFromED property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecryptWithKeyFromED(String value) {
        this.decryptWithKeyFromED = value;
    }

    /**
     * Gets the value of the soapActionPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOAPActionPolicy() {
        return soapActionPolicy;
    }

    /**
     * Sets the value of the soapActionPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOAPActionPolicy(String value) {
        this.soapActionPolicy = value;
    }

    /**
     * Gets the value of the uddiSubscriptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the uddiSubscriptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUDDISubscriptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmUDDIWSDLSource }
     * 
     * 
     */
    public List<DmUDDIWSDLSource> getUDDISubscriptions() {
        if (uddiSubscriptions == null) {
            uddiSubscriptions = new ArrayList<DmUDDIWSDLSource>();
        }
        return this.uddiSubscriptions;
    }

    /**
     * Gets the value of the wsrrSubscriptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wsrrSubscriptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWSRRSubscriptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSRRWSDLSource }
     * 
     * 
     */
    public List<DmWSRRWSDLSource> getWSRRSubscriptions() {
        if (wsrrSubscriptions == null) {
            wsrrSubscriptions = new ArrayList<DmWSRRWSDLSource>();
        }
        return this.wsrrSubscriptions;
    }

    /**
     * Gets the value of the wsrrSavedSearchSubscriptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wsrrSavedSearchSubscriptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWSRRSavedSearchSubscriptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSRRSavedSearchWSDLSource }
     * 
     * 
     */
    public List<DmWSRRSavedSearchWSDLSource> getWSRRSavedSearchSubscriptions() {
        if (wsrrSavedSearchSubscriptions == null) {
            wsrrSavedSearchSubscriptions = new ArrayList<DmWSRRSavedSearchWSDLSource>();
        }
        return this.wsrrSavedSearchSubscriptions;
    }

    /**
     * Gets the value of the operationPriority property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the operationPriority property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOperationPriority().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSOperationSchedulerPriority }
     * 
     * 
     */
    public List<DmWSOperationSchedulerPriority> getOperationPriority() {
        if (operationPriority == null) {
            operationPriority = new ArrayList<DmWSOperationSchedulerPriority>();
        }
        return this.operationPriority;
    }

    /**
     * Gets the value of the operationConformancePolicy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the operationConformancePolicy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOperationConformancePolicy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSOperationConformancePolicy }
     * 
     * 
     */
    public List<DmWSOperationConformancePolicy> getOperationConformancePolicy() {
        if (operationConformancePolicy == null) {
            operationConformancePolicy = new ArrayList<DmWSOperationConformancePolicy>();
        }
        return this.operationConformancePolicy;
    }

    /**
     * Gets the value of the operationPolicySubjectOptOut property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the operationPolicySubjectOptOut property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOperationPolicySubjectOptOut().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSOperationPolicySubjectOptOut }
     * 
     * 
     */
    public List<DmWSOperationPolicySubjectOptOut> getOperationPolicySubjectOptOut() {
        if (operationPolicySubjectOptOut == null) {
            operationPolicySubjectOptOut = new ArrayList<DmWSOperationPolicySubjectOptOut>();
        }
        return this.operationPolicySubjectOptOut;
    }

    /**
     * Gets the value of the policyParameter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the policyParameter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPolicyParameter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSPolicyParameters }
     * 
     * 
     */
    public List<DmWSPolicyParameters> getPolicyParameter() {
        if (policyParameter == null) {
            policyParameter = new ArrayList<DmWSPolicyParameters>();
        }
        return this.policyParameter;
    }

    /**
     * Gets the value of the reliableMessaging property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reliableMessaging property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReliableMessaging().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSOperationReliableMessaging }
     * 
     * 
     */
    public List<DmWSOperationReliableMessaging> getReliableMessaging() {
        if (reliableMessaging == null) {
            reliableMessaging = new ArrayList<DmWSOperationReliableMessaging>();
        }
        return this.reliableMessaging;
    }

    /**
     * Gets the value of the wsmAgentMonitor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSMAgentMonitor() {
        return wsmAgentMonitor;
    }

    /**
     * Sets the value of the wsmAgentMonitor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSMAgentMonitor(String value) {
        this.wsmAgentMonitor = value;
    }

    /**
     * Gets the value of the wsmAgentMonitorPCM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSMAgentMonitorPCM() {
        return wsmAgentMonitorPCM;
    }

    /**
     * Sets the value of the wsmAgentMonitorPCM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSMAgentMonitorPCM(String value) {
        this.wsmAgentMonitorPCM = value;
    }

    /**
     * Gets the value of the processRespRulesOnOneWayMEP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessRespRulesOnOneWayMEP() {
        return processRespRulesOnOneWayMEP;
    }

    /**
     * Sets the value of the processRespRulesOnOneWayMEP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessRespRulesOnOneWayMEP(String value) {
        this.processRespRulesOnOneWayMEP = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
