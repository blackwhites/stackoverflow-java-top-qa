
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionInitializeRaidVolumeFilesystem2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionInitializeRaidVolumeFilesystem2"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="VolumeName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnableB2BStorage"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalDriveEncryptionMethod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEncryptionMethod3 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalDriveUserPassphrase" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionInitializeRaidVolumeFilesystem2", propOrder = {
    "volumeName",
    "enableB2BStorage",
    "localDriveEncryptionMethod",
    "localDriveUserPassphrase"
})
public class ActionInitializeRaidVolumeFilesystem2 {

    @XmlElement(name = "VolumeName")
    protected String volumeName;
    @XmlElement(name = "EnableB2BStorage", required = true)
    protected String enableB2BStorage;
    @XmlElement(name = "LocalDriveEncryptionMethod")
    protected String localDriveEncryptionMethod;
    @XmlElement(name = "LocalDriveUserPassphrase")
    protected String localDriveUserPassphrase;

    /**
     * Gets the value of the volumeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVolumeName() {
        return volumeName;
    }

    /**
     * Sets the value of the volumeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVolumeName(String value) {
        this.volumeName = value;
    }

    /**
     * Gets the value of the enableB2BStorage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableB2BStorage() {
        return enableB2BStorage;
    }

    /**
     * Sets the value of the enableB2BStorage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableB2BStorage(String value) {
        this.enableB2BStorage = value;
    }

    /**
     * Gets the value of the localDriveEncryptionMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalDriveEncryptionMethod() {
        return localDriveEncryptionMethod;
    }

    /**
     * Sets the value of the localDriveEncryptionMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalDriveEncryptionMethod(String value) {
        this.localDriveEncryptionMethod = value;
    }

    /**
     * Gets the value of the localDriveUserPassphrase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalDriveUserPassphrase() {
        return localDriveUserPassphrase;
    }

    /**
     * Sets the value of the localDriveUserPassphrase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalDriveUserPassphrase(String value) {
        this.localDriveUserPassphrase = value;
    }

}
