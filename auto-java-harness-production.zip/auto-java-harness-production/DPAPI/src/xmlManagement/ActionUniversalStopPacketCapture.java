
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionUniversalStopPacketCapture complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionUniversalStopPacketCapture"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="InterfaceType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPcapInterfaceType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EthernetInterface" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="VLANInterface" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LinkAggregation" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="StandaloneInterface" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionUniversalStopPacketCapture", propOrder = {
    "interfaceType",
    "ethernetInterface",
    "vlanInterface",
    "linkAggregation",
    "standaloneInterface"
})
public class ActionUniversalStopPacketCapture {

    @XmlElement(name = "InterfaceType", required = true)
    protected String interfaceType;
    @XmlElement(name = "EthernetInterface")
    protected DmReference ethernetInterface;
    @XmlElement(name = "VLANInterface")
    protected DmReference vlanInterface;
    @XmlElement(name = "LinkAggregation")
    protected DmReference linkAggregation;
    @XmlElement(name = "StandaloneInterface")
    protected DmReference standaloneInterface;

    /**
     * Gets the value of the interfaceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterfaceType() {
        return interfaceType;
    }

    /**
     * Sets the value of the interfaceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterfaceType(String value) {
        this.interfaceType = value;
    }

    /**
     * Gets the value of the ethernetInterface property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEthernetInterface() {
        return ethernetInterface;
    }

    /**
     * Sets the value of the ethernetInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEthernetInterface(DmReference value) {
        this.ethernetInterface = value;
    }

    /**
     * Gets the value of the vlanInterface property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getVLANInterface() {
        return vlanInterface;
    }

    /**
     * Sets the value of the vlanInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setVLANInterface(DmReference value) {
        this.vlanInterface = value;
    }

    /**
     * Gets the value of the linkAggregation property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLinkAggregation() {
        return linkAggregation;
    }

    /**
     * Sets the value of the linkAggregation property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLinkAggregation(DmReference value) {
        this.linkAggregation = value;
    }

    /**
     * Gets the value of the standaloneInterface property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getStandaloneInterface() {
        return standaloneInterface;
    }

    /**
     * Sets the value of the standaloneInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setStandaloneInterface(DmReference value) {
        this.standaloneInterface = value;
    }

}
