
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigISAMReverseProxy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigISAMReverseProxy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ISAMRuntime" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LocalHost"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PrimaryInterface"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLocalIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Administrator"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Password" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="ISAMDomain"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnableHTTP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnableHTTPS" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPSPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientPersistentConnTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WorkerThreads"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserRegistrySSL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserRegistrySSLPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserRegistryCertDB" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserRegistryCertLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLCertKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLServerCert" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionCertKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Junctions" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="JunctionHTTPTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionHTTPSTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionMaxCachedPersistentConns"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionPersistentConnTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ManagedCookieList" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HealthCheckPingInterval"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HealthCheckPingMethod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HealthCheckPingURI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasicAuthTransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasicAuthRealm" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientCertAccept" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyClientCertAccept {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientCertEAIURI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientCertData" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyCertData" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EAITransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EAITriggerURL" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AuthLevels" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormsAuthTransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionReauthenForInactive" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionMaxCacheEntries"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionLifetimeTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionInactiveTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionTCPCookie"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionSSLCookie"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionUseSame" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTMLRedirect" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalRespRedirect" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalRespRedirectURI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalRespRedirectMacros" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyRespRedirectMacros {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FailoverTransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FailoverCookiesLifetime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FailoverCookiesKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CDSSOTransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CDSSOTransportGen" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CDSSOPeers" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyCDSSOPeer" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LTPATransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPACookie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAKeyFilePw" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAKeyFilePwAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ECSSOTransport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuthTransport {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ECSSOName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ECSSOIsMasterAuthServer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ECSSOMasterAuthServer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ECSSODomains" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyECSSODomain" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AgentLogging" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RefererLogging" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestLogging" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestLogFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxLogSize"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FlushLogTime"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AuditLogging" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AuditLogType" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyAuditLogType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxAuditLogSize"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FlushAuditLogTime"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SecondaryInts" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxySecondaryInt" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ConfigFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RoutingFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigISAMReverseProxy", propOrder = {
    "userSummary",
    "isamRuntime",
    "localHost",
    "localPort",
    "primaryInterface",
    "administrator",
    "password",
    "isamDomain",
    "enableHTTP",
    "httpPort",
    "enableHTTPS",
    "httpsPort",
    "clientPersistentConnTimeout",
    "workerThreads",
    "userRegistrySSL",
    "userRegistrySSLPort",
    "userRegistryCertDB",
    "userRegistryCertLabel",
    "sslCertKeyFile",
    "sslServerCert",
    "junctionCertKeyFile",
    "junctions",
    "junctionHTTPTimeout",
    "junctionHTTPSTimeout",
    "junctionMaxCachedPersistentConns",
    "junctionPersistentConnTimeout",
    "managedCookieList",
    "healthCheckPingInterval",
    "healthCheckPingMethod",
    "healthCheckPingURI",
    "basicAuthTransport",
    "basicAuthRealm",
    "clientCertAccept",
    "clientCertEAIURI",
    "clientCertData",
    "eaiTransport",
    "eaiTriggerURL",
    "authLevels",
    "formsAuthTransport",
    "sessionReauthenForInactive",
    "sessionMaxCacheEntries",
    "sessionLifetimeTimeout",
    "sessionInactiveTimeout",
    "sessionTCPCookie",
    "sessionSSLCookie",
    "sessionUseSame",
    "htmlRedirect",
    "localRespRedirect",
    "localRespRedirectURI",
    "localRespRedirectMacros",
    "failoverTransport",
    "failoverCookiesLifetime",
    "failoverCookiesKeyFile",
    "cdssoTransport",
    "cdssoTransportGen",
    "cdssoPeers",
    "ltpaTransport",
    "ltpaCookie",
    "ltpaKeyFile",
    "ltpaKeyFilePw",
    "ltpaKeyFilePwAlias",
    "ecssoTransport",
    "ecssoName",
    "ecssoIsMasterAuthServer",
    "ecssoMasterAuthServer",
    "ecssoDomains",
    "agentLogging",
    "refererLogging",
    "requestLogging",
    "requestLogFormat",
    "maxLogSize",
    "flushLogTime",
    "auditLogging",
    "auditLogType",
    "maxAuditLogSize",
    "flushAuditLogTime",
    "secondaryInts",
    "configFile",
    "routingFile"
})
public class ConfigISAMReverseProxy
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "ISAMRuntime")
    protected DmReference isamRuntime;
    @XmlElement(name = "LocalHost")
    protected String localHost;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "PrimaryInterface")
    protected String primaryInterface;
    @XmlElement(name = "Administrator")
    protected String administrator;
    @XmlElement(name = "Password")
    protected DmReference password;
    @XmlElement(name = "ISAMDomain")
    protected String isamDomain;
    @XmlElement(name = "EnableHTTP")
    protected String enableHTTP;
    @XmlElement(name = "HTTPPort")
    protected String httpPort;
    @XmlElement(name = "EnableHTTPS")
    protected String enableHTTPS;
    @XmlElement(name = "HTTPSPort")
    protected String httpsPort;
    @XmlElement(name = "ClientPersistentConnTimeout")
    protected String clientPersistentConnTimeout;
    @XmlElement(name = "WorkerThreads")
    protected String workerThreads;
    @XmlElement(name = "UserRegistrySSL")
    protected String userRegistrySSL;
    @XmlElement(name = "UserRegistrySSLPort")
    protected String userRegistrySSLPort;
    @XmlElement(name = "UserRegistryCertDB")
    protected String userRegistryCertDB;
    @XmlElement(name = "UserRegistryCertLabel")
    protected String userRegistryCertLabel;
    @XmlElement(name = "SSLCertKeyFile")
    protected String sslCertKeyFile;
    @XmlElement(name = "SSLServerCert")
    protected String sslServerCert;
    @XmlElement(name = "JunctionCertKeyFile")
    protected String junctionCertKeyFile;
    @XmlElement(name = "Junctions")
    protected List<DmReference> junctions;
    @XmlElement(name = "JunctionHTTPTimeout")
    protected String junctionHTTPTimeout;
    @XmlElement(name = "JunctionHTTPSTimeout")
    protected String junctionHTTPSTimeout;
    @XmlElement(name = "JunctionMaxCachedPersistentConns")
    protected String junctionMaxCachedPersistentConns;
    @XmlElement(name = "JunctionPersistentConnTimeout")
    protected String junctionPersistentConnTimeout;
    @XmlElement(name = "ManagedCookieList")
    protected String managedCookieList;
    @XmlElement(name = "HealthCheckPingInterval")
    protected String healthCheckPingInterval;
    @XmlElement(name = "HealthCheckPingMethod")
    protected String healthCheckPingMethod;
    @XmlElement(name = "HealthCheckPingURI")
    protected String healthCheckPingURI;
    @XmlElement(name = "BasicAuthTransport")
    protected String basicAuthTransport;
    @XmlElement(name = "BasicAuthRealm")
    protected String basicAuthRealm;
    @XmlElement(name = "ClientCertAccept")
    protected String clientCertAccept;
    @XmlElement(name = "ClientCertEAIURI")
    protected String clientCertEAIURI;
    @XmlElement(name = "ClientCertData")
    protected List<DmISAMReverseProxyCertData> clientCertData;
    @XmlElement(name = "EAITransport")
    protected String eaiTransport;
    @XmlElement(name = "EAITriggerURL")
    protected List<String> eaiTriggerURL;
    @XmlElement(name = "AuthLevels")
    protected List<String> authLevels;
    @XmlElement(name = "FormsAuthTransport")
    protected String formsAuthTransport;
    @XmlElement(name = "SessionReauthenForInactive")
    protected String sessionReauthenForInactive;
    @XmlElement(name = "SessionMaxCacheEntries")
    protected String sessionMaxCacheEntries;
    @XmlElement(name = "SessionLifetimeTimeout")
    protected String sessionLifetimeTimeout;
    @XmlElement(name = "SessionInactiveTimeout")
    protected String sessionInactiveTimeout;
    @XmlElement(name = "SessionTCPCookie")
    protected String sessionTCPCookie;
    @XmlElement(name = "SessionSSLCookie")
    protected String sessionSSLCookie;
    @XmlElement(name = "SessionUseSame")
    protected String sessionUseSame;
    @XmlElement(name = "HTMLRedirect")
    protected String htmlRedirect;
    @XmlElement(name = "LocalRespRedirect")
    protected String localRespRedirect;
    @XmlElement(name = "LocalRespRedirectURI")
    protected String localRespRedirectURI;
    @XmlElement(name = "LocalRespRedirectMacros")
    protected List<String> localRespRedirectMacros;
    @XmlElement(name = "FailoverTransport")
    protected String failoverTransport;
    @XmlElement(name = "FailoverCookiesLifetime")
    protected String failoverCookiesLifetime;
    @XmlElement(name = "FailoverCookiesKeyFile")
    protected String failoverCookiesKeyFile;
    @XmlElement(name = "CDSSOTransport")
    protected String cdssoTransport;
    @XmlElement(name = "CDSSOTransportGen")
    protected String cdssoTransportGen;
    @XmlElement(name = "CDSSOPeers")
    protected List<DmISAMReverseProxyCDSSOPeer> cdssoPeers;
    @XmlElement(name = "LTPATransport")
    protected String ltpaTransport;
    @XmlElement(name = "LTPACookie")
    protected String ltpaCookie;
    @XmlElement(name = "LTPAKeyFile")
    protected String ltpaKeyFile;
    @XmlElement(name = "LTPAKeyFilePw")
    protected String ltpaKeyFilePw;
    @XmlElement(name = "LTPAKeyFilePwAlias")
    protected DmReference ltpaKeyFilePwAlias;
    @XmlElement(name = "ECSSOTransport")
    protected String ecssoTransport;
    @XmlElement(name = "ECSSOName")
    protected String ecssoName;
    @XmlElement(name = "ECSSOIsMasterAuthServer")
    protected String ecssoIsMasterAuthServer;
    @XmlElement(name = "ECSSOMasterAuthServer")
    protected String ecssoMasterAuthServer;
    @XmlElement(name = "ECSSODomains")
    protected List<DmISAMReverseProxyECSSODomain> ecssoDomains;
    @XmlElement(name = "AgentLogging")
    protected String agentLogging;
    @XmlElement(name = "RefererLogging")
    protected String refererLogging;
    @XmlElement(name = "RequestLogging")
    protected String requestLogging;
    @XmlElement(name = "RequestLogFormat")
    protected String requestLogFormat;
    @XmlElement(name = "MaxLogSize")
    protected String maxLogSize;
    @XmlElement(name = "FlushLogTime")
    protected String flushLogTime;
    @XmlElement(name = "AuditLogging")
    protected String auditLogging;
    @XmlElement(name = "AuditLogType")
    protected List<String> auditLogType;
    @XmlElement(name = "MaxAuditLogSize")
    protected String maxAuditLogSize;
    @XmlElement(name = "FlushAuditLogTime")
    protected String flushAuditLogTime;
    @XmlElement(name = "SecondaryInts")
    protected List<DmISAMReverseProxySecondaryInt> secondaryInts;
    @XmlElement(name = "ConfigFile")
    protected String configFile;
    @XmlElement(name = "RoutingFile")
    protected String routingFile;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the isamRuntime property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getISAMRuntime() {
        return isamRuntime;
    }

    /**
     * Sets the value of the isamRuntime property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setISAMRuntime(DmReference value) {
        this.isamRuntime = value;
    }

    /**
     * Gets the value of the localHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalHost() {
        return localHost;
    }

    /**
     * Sets the value of the localHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalHost(String value) {
        this.localHost = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the primaryInterface property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryInterface() {
        return primaryInterface;
    }

    /**
     * Sets the value of the primaryInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryInterface(String value) {
        this.primaryInterface = value;
    }

    /**
     * Gets the value of the administrator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdministrator() {
        return administrator;
    }

    /**
     * Sets the value of the administrator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdministrator(String value) {
        this.administrator = value;
    }

    /**
     * Gets the value of the password property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setPassword(DmReference value) {
        this.password = value;
    }

    /**
     * Gets the value of the isamDomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISAMDomain() {
        return isamDomain;
    }

    /**
     * Sets the value of the isamDomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISAMDomain(String value) {
        this.isamDomain = value;
    }

    /**
     * Gets the value of the enableHTTP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableHTTP() {
        return enableHTTP;
    }

    /**
     * Sets the value of the enableHTTP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableHTTP(String value) {
        this.enableHTTP = value;
    }

    /**
     * Gets the value of the httpPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPPort() {
        return httpPort;
    }

    /**
     * Sets the value of the httpPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPPort(String value) {
        this.httpPort = value;
    }

    /**
     * Gets the value of the enableHTTPS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableHTTPS() {
        return enableHTTPS;
    }

    /**
     * Sets the value of the enableHTTPS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableHTTPS(String value) {
        this.enableHTTPS = value;
    }

    /**
     * Gets the value of the httpsPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPSPort() {
        return httpsPort;
    }

    /**
     * Sets the value of the httpsPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPSPort(String value) {
        this.httpsPort = value;
    }

    /**
     * Gets the value of the clientPersistentConnTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientPersistentConnTimeout() {
        return clientPersistentConnTimeout;
    }

    /**
     * Sets the value of the clientPersistentConnTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientPersistentConnTimeout(String value) {
        this.clientPersistentConnTimeout = value;
    }

    /**
     * Gets the value of the workerThreads property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkerThreads() {
        return workerThreads;
    }

    /**
     * Sets the value of the workerThreads property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkerThreads(String value) {
        this.workerThreads = value;
    }

    /**
     * Gets the value of the userRegistrySSL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserRegistrySSL() {
        return userRegistrySSL;
    }

    /**
     * Sets the value of the userRegistrySSL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserRegistrySSL(String value) {
        this.userRegistrySSL = value;
    }

    /**
     * Gets the value of the userRegistrySSLPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserRegistrySSLPort() {
        return userRegistrySSLPort;
    }

    /**
     * Sets the value of the userRegistrySSLPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserRegistrySSLPort(String value) {
        this.userRegistrySSLPort = value;
    }

    /**
     * Gets the value of the userRegistryCertDB property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserRegistryCertDB() {
        return userRegistryCertDB;
    }

    /**
     * Sets the value of the userRegistryCertDB property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserRegistryCertDB(String value) {
        this.userRegistryCertDB = value;
    }

    /**
     * Gets the value of the userRegistryCertLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserRegistryCertLabel() {
        return userRegistryCertLabel;
    }

    /**
     * Sets the value of the userRegistryCertLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserRegistryCertLabel(String value) {
        this.userRegistryCertLabel = value;
    }

    /**
     * Gets the value of the sslCertKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLCertKeyFile() {
        return sslCertKeyFile;
    }

    /**
     * Sets the value of the sslCertKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLCertKeyFile(String value) {
        this.sslCertKeyFile = value;
    }

    /**
     * Gets the value of the sslServerCert property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLServerCert() {
        return sslServerCert;
    }

    /**
     * Sets the value of the sslServerCert property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLServerCert(String value) {
        this.sslServerCert = value;
    }

    /**
     * Gets the value of the junctionCertKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionCertKeyFile() {
        return junctionCertKeyFile;
    }

    /**
     * Sets the value of the junctionCertKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionCertKeyFile(String value) {
        this.junctionCertKeyFile = value;
    }

    /**
     * Gets the value of the junctions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the junctions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJunctions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getJunctions() {
        if (junctions == null) {
            junctions = new ArrayList<DmReference>();
        }
        return this.junctions;
    }

    /**
     * Gets the value of the junctionHTTPTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionHTTPTimeout() {
        return junctionHTTPTimeout;
    }

    /**
     * Sets the value of the junctionHTTPTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionHTTPTimeout(String value) {
        this.junctionHTTPTimeout = value;
    }

    /**
     * Gets the value of the junctionHTTPSTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionHTTPSTimeout() {
        return junctionHTTPSTimeout;
    }

    /**
     * Sets the value of the junctionHTTPSTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionHTTPSTimeout(String value) {
        this.junctionHTTPSTimeout = value;
    }

    /**
     * Gets the value of the junctionMaxCachedPersistentConns property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionMaxCachedPersistentConns() {
        return junctionMaxCachedPersistentConns;
    }

    /**
     * Sets the value of the junctionMaxCachedPersistentConns property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionMaxCachedPersistentConns(String value) {
        this.junctionMaxCachedPersistentConns = value;
    }

    /**
     * Gets the value of the junctionPersistentConnTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionPersistentConnTimeout() {
        return junctionPersistentConnTimeout;
    }

    /**
     * Sets the value of the junctionPersistentConnTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionPersistentConnTimeout(String value) {
        this.junctionPersistentConnTimeout = value;
    }

    /**
     * Gets the value of the managedCookieList property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManagedCookieList() {
        return managedCookieList;
    }

    /**
     * Sets the value of the managedCookieList property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManagedCookieList(String value) {
        this.managedCookieList = value;
    }

    /**
     * Gets the value of the healthCheckPingInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHealthCheckPingInterval() {
        return healthCheckPingInterval;
    }

    /**
     * Sets the value of the healthCheckPingInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHealthCheckPingInterval(String value) {
        this.healthCheckPingInterval = value;
    }

    /**
     * Gets the value of the healthCheckPingMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHealthCheckPingMethod() {
        return healthCheckPingMethod;
    }

    /**
     * Sets the value of the healthCheckPingMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHealthCheckPingMethod(String value) {
        this.healthCheckPingMethod = value;
    }

    /**
     * Gets the value of the healthCheckPingURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHealthCheckPingURI() {
        return healthCheckPingURI;
    }

    /**
     * Sets the value of the healthCheckPingURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHealthCheckPingURI(String value) {
        this.healthCheckPingURI = value;
    }

    /**
     * Gets the value of the basicAuthTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicAuthTransport() {
        return basicAuthTransport;
    }

    /**
     * Sets the value of the basicAuthTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicAuthTransport(String value) {
        this.basicAuthTransport = value;
    }

    /**
     * Gets the value of the basicAuthRealm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicAuthRealm() {
        return basicAuthRealm;
    }

    /**
     * Sets the value of the basicAuthRealm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicAuthRealm(String value) {
        this.basicAuthRealm = value;
    }

    /**
     * Gets the value of the clientCertAccept property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientCertAccept() {
        return clientCertAccept;
    }

    /**
     * Sets the value of the clientCertAccept property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientCertAccept(String value) {
        this.clientCertAccept = value;
    }

    /**
     * Gets the value of the clientCertEAIURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientCertEAIURI() {
        return clientCertEAIURI;
    }

    /**
     * Sets the value of the clientCertEAIURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientCertEAIURI(String value) {
        this.clientCertEAIURI = value;
    }

    /**
     * Gets the value of the clientCertData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clientCertData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClientCertData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyCertData }
     * 
     * 
     */
    public List<DmISAMReverseProxyCertData> getClientCertData() {
        if (clientCertData == null) {
            clientCertData = new ArrayList<DmISAMReverseProxyCertData>();
        }
        return this.clientCertData;
    }

    /**
     * Gets the value of the eaiTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEAITransport() {
        return eaiTransport;
    }

    /**
     * Sets the value of the eaiTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEAITransport(String value) {
        this.eaiTransport = value;
    }

    /**
     * Gets the value of the eaiTriggerURL property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eaiTriggerURL property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEAITriggerURL().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEAITriggerURL() {
        if (eaiTriggerURL == null) {
            eaiTriggerURL = new ArrayList<String>();
        }
        return this.eaiTriggerURL;
    }

    /**
     * Gets the value of the authLevels property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the authLevels property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthLevels().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAuthLevels() {
        if (authLevels == null) {
            authLevels = new ArrayList<String>();
        }
        return this.authLevels;
    }

    /**
     * Gets the value of the formsAuthTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormsAuthTransport() {
        return formsAuthTransport;
    }

    /**
     * Sets the value of the formsAuthTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormsAuthTransport(String value) {
        this.formsAuthTransport = value;
    }

    /**
     * Gets the value of the sessionReauthenForInactive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionReauthenForInactive() {
        return sessionReauthenForInactive;
    }

    /**
     * Sets the value of the sessionReauthenForInactive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionReauthenForInactive(String value) {
        this.sessionReauthenForInactive = value;
    }

    /**
     * Gets the value of the sessionMaxCacheEntries property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionMaxCacheEntries() {
        return sessionMaxCacheEntries;
    }

    /**
     * Sets the value of the sessionMaxCacheEntries property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionMaxCacheEntries(String value) {
        this.sessionMaxCacheEntries = value;
    }

    /**
     * Gets the value of the sessionLifetimeTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionLifetimeTimeout() {
        return sessionLifetimeTimeout;
    }

    /**
     * Sets the value of the sessionLifetimeTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionLifetimeTimeout(String value) {
        this.sessionLifetimeTimeout = value;
    }

    /**
     * Gets the value of the sessionInactiveTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionInactiveTimeout() {
        return sessionInactiveTimeout;
    }

    /**
     * Sets the value of the sessionInactiveTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionInactiveTimeout(String value) {
        this.sessionInactiveTimeout = value;
    }

    /**
     * Gets the value of the sessionTCPCookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionTCPCookie() {
        return sessionTCPCookie;
    }

    /**
     * Sets the value of the sessionTCPCookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionTCPCookie(String value) {
        this.sessionTCPCookie = value;
    }

    /**
     * Gets the value of the sessionSSLCookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionSSLCookie() {
        return sessionSSLCookie;
    }

    /**
     * Sets the value of the sessionSSLCookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionSSLCookie(String value) {
        this.sessionSSLCookie = value;
    }

    /**
     * Gets the value of the sessionUseSame property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionUseSame() {
        return sessionUseSame;
    }

    /**
     * Sets the value of the sessionUseSame property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionUseSame(String value) {
        this.sessionUseSame = value;
    }

    /**
     * Gets the value of the htmlRedirect property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTMLRedirect() {
        return htmlRedirect;
    }

    /**
     * Sets the value of the htmlRedirect property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTMLRedirect(String value) {
        this.htmlRedirect = value;
    }

    /**
     * Gets the value of the localRespRedirect property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalRespRedirect() {
        return localRespRedirect;
    }

    /**
     * Sets the value of the localRespRedirect property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalRespRedirect(String value) {
        this.localRespRedirect = value;
    }

    /**
     * Gets the value of the localRespRedirectURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalRespRedirectURI() {
        return localRespRedirectURI;
    }

    /**
     * Sets the value of the localRespRedirectURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalRespRedirectURI(String value) {
        this.localRespRedirectURI = value;
    }

    /**
     * Gets the value of the localRespRedirectMacros property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the localRespRedirectMacros property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocalRespRedirectMacros().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLocalRespRedirectMacros() {
        if (localRespRedirectMacros == null) {
            localRespRedirectMacros = new ArrayList<String>();
        }
        return this.localRespRedirectMacros;
    }

    /**
     * Gets the value of the failoverTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFailoverTransport() {
        return failoverTransport;
    }

    /**
     * Sets the value of the failoverTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFailoverTransport(String value) {
        this.failoverTransport = value;
    }

    /**
     * Gets the value of the failoverCookiesLifetime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFailoverCookiesLifetime() {
        return failoverCookiesLifetime;
    }

    /**
     * Sets the value of the failoverCookiesLifetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFailoverCookiesLifetime(String value) {
        this.failoverCookiesLifetime = value;
    }

    /**
     * Gets the value of the failoverCookiesKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFailoverCookiesKeyFile() {
        return failoverCookiesKeyFile;
    }

    /**
     * Sets the value of the failoverCookiesKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFailoverCookiesKeyFile(String value) {
        this.failoverCookiesKeyFile = value;
    }

    /**
     * Gets the value of the cdssoTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCDSSOTransport() {
        return cdssoTransport;
    }

    /**
     * Sets the value of the cdssoTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCDSSOTransport(String value) {
        this.cdssoTransport = value;
    }

    /**
     * Gets the value of the cdssoTransportGen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCDSSOTransportGen() {
        return cdssoTransportGen;
    }

    /**
     * Sets the value of the cdssoTransportGen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCDSSOTransportGen(String value) {
        this.cdssoTransportGen = value;
    }

    /**
     * Gets the value of the cdssoPeers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cdssoPeers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCDSSOPeers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyCDSSOPeer }
     * 
     * 
     */
    public List<DmISAMReverseProxyCDSSOPeer> getCDSSOPeers() {
        if (cdssoPeers == null) {
            cdssoPeers = new ArrayList<DmISAMReverseProxyCDSSOPeer>();
        }
        return this.cdssoPeers;
    }

    /**
     * Gets the value of the ltpaTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPATransport() {
        return ltpaTransport;
    }

    /**
     * Sets the value of the ltpaTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPATransport(String value) {
        this.ltpaTransport = value;
    }

    /**
     * Gets the value of the ltpaCookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPACookie() {
        return ltpaCookie;
    }

    /**
     * Sets the value of the ltpaCookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPACookie(String value) {
        this.ltpaCookie = value;
    }

    /**
     * Gets the value of the ltpaKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPAKeyFile() {
        return ltpaKeyFile;
    }

    /**
     * Sets the value of the ltpaKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPAKeyFile(String value) {
        this.ltpaKeyFile = value;
    }

    /**
     * Gets the value of the ltpaKeyFilePw property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPAKeyFilePw() {
        return ltpaKeyFilePw;
    }

    /**
     * Sets the value of the ltpaKeyFilePw property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPAKeyFilePw(String value) {
        this.ltpaKeyFilePw = value;
    }

    /**
     * Gets the value of the ltpaKeyFilePwAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLTPAKeyFilePwAlias() {
        return ltpaKeyFilePwAlias;
    }

    /**
     * Sets the value of the ltpaKeyFilePwAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLTPAKeyFilePwAlias(DmReference value) {
        this.ltpaKeyFilePwAlias = value;
    }

    /**
     * Gets the value of the ecssoTransport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECSSOTransport() {
        return ecssoTransport;
    }

    /**
     * Sets the value of the ecssoTransport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECSSOTransport(String value) {
        this.ecssoTransport = value;
    }

    /**
     * Gets the value of the ecssoName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECSSOName() {
        return ecssoName;
    }

    /**
     * Sets the value of the ecssoName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECSSOName(String value) {
        this.ecssoName = value;
    }

    /**
     * Gets the value of the ecssoIsMasterAuthServer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECSSOIsMasterAuthServer() {
        return ecssoIsMasterAuthServer;
    }

    /**
     * Sets the value of the ecssoIsMasterAuthServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECSSOIsMasterAuthServer(String value) {
        this.ecssoIsMasterAuthServer = value;
    }

    /**
     * Gets the value of the ecssoMasterAuthServer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECSSOMasterAuthServer() {
        return ecssoMasterAuthServer;
    }

    /**
     * Sets the value of the ecssoMasterAuthServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECSSOMasterAuthServer(String value) {
        this.ecssoMasterAuthServer = value;
    }

    /**
     * Gets the value of the ecssoDomains property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecssoDomains property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getECSSODomains().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyECSSODomain }
     * 
     * 
     */
    public List<DmISAMReverseProxyECSSODomain> getECSSODomains() {
        if (ecssoDomains == null) {
            ecssoDomains = new ArrayList<DmISAMReverseProxyECSSODomain>();
        }
        return this.ecssoDomains;
    }

    /**
     * Gets the value of the agentLogging property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentLogging() {
        return agentLogging;
    }

    /**
     * Sets the value of the agentLogging property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentLogging(String value) {
        this.agentLogging = value;
    }

    /**
     * Gets the value of the refererLogging property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefererLogging() {
        return refererLogging;
    }

    /**
     * Sets the value of the refererLogging property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefererLogging(String value) {
        this.refererLogging = value;
    }

    /**
     * Gets the value of the requestLogging property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestLogging() {
        return requestLogging;
    }

    /**
     * Sets the value of the requestLogging property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestLogging(String value) {
        this.requestLogging = value;
    }

    /**
     * Gets the value of the requestLogFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestLogFormat() {
        return requestLogFormat;
    }

    /**
     * Sets the value of the requestLogFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestLogFormat(String value) {
        this.requestLogFormat = value;
    }

    /**
     * Gets the value of the maxLogSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxLogSize() {
        return maxLogSize;
    }

    /**
     * Sets the value of the maxLogSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxLogSize(String value) {
        this.maxLogSize = value;
    }

    /**
     * Gets the value of the flushLogTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlushLogTime() {
        return flushLogTime;
    }

    /**
     * Sets the value of the flushLogTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlushLogTime(String value) {
        this.flushLogTime = value;
    }

    /**
     * Gets the value of the auditLogging property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditLogging() {
        return auditLogging;
    }

    /**
     * Sets the value of the auditLogging property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditLogging(String value) {
        this.auditLogging = value;
    }

    /**
     * Gets the value of the auditLogType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the auditLogType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuditLogType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAuditLogType() {
        if (auditLogType == null) {
            auditLogType = new ArrayList<String>();
        }
        return this.auditLogType;
    }

    /**
     * Gets the value of the maxAuditLogSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxAuditLogSize() {
        return maxAuditLogSize;
    }

    /**
     * Sets the value of the maxAuditLogSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxAuditLogSize(String value) {
        this.maxAuditLogSize = value;
    }

    /**
     * Gets the value of the flushAuditLogTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlushAuditLogTime() {
        return flushAuditLogTime;
    }

    /**
     * Sets the value of the flushAuditLogTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlushAuditLogTime(String value) {
        this.flushAuditLogTime = value;
    }

    /**
     * Gets the value of the secondaryInts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the secondaryInts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecondaryInts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxySecondaryInt }
     * 
     * 
     */
    public List<DmISAMReverseProxySecondaryInt> getSecondaryInts() {
        if (secondaryInts == null) {
            secondaryInts = new ArrayList<DmISAMReverseProxySecondaryInt>();
        }
        return this.secondaryInts;
    }

    /**
     * Gets the value of the configFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigFile() {
        return configFile;
    }

    /**
     * Sets the value of the configFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigFile(String value) {
        this.configFile = value;
    }

    /**
     * Gets the value of the routingFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoutingFile() {
        return routingFile;
    }

    /**
     * Sets the value of the routingFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoutingFile(String value) {
        this.routingFile = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
