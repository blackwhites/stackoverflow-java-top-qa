
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigFormsLoginPolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigFormsLoginPolicy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LoginForm"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseCookieAttributes" type="{http://www.datapower.com/schemas/management}dmUseCookieAttributes"/&gt;
 *         &lt;element name="CookieAttributes" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="UseSSLForLogin" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnableMigration"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SharedSecret" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ErrorPage"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogoutPage"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DefaultURL"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormsLocation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFormsLocation {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalLoginForm" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalErrorPage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalLogoutPage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UsernameField"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PasswordField"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RedirectField"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormProcessingURL"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InactivityTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionLifetime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RedirectURLType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmRedirectURLType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormSupportType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFormSupportType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FormSupportScript" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigFormsLoginPolicy", propOrder = {
    "userSummary",
    "loginForm",
    "useCookieAttributes",
    "cookieAttributes",
    "useSSLForLogin",
    "enableMigration",
    "sslPort",
    "sharedSecret",
    "errorPage",
    "logoutPage",
    "defaultURL",
    "formsLocation",
    "localLoginForm",
    "localErrorPage",
    "localLogoutPage",
    "usernameField",
    "passwordField",
    "redirectField",
    "formProcessingURL",
    "inactivityTimeout",
    "sessionLifetime",
    "redirectURLType",
    "formSupportType",
    "formSupportScript"
})
public class ConfigFormsLoginPolicy
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "LoginForm")
    protected String loginForm;
    @XmlElement(name = "UseCookieAttributes")
    @XmlSchemaType(name = "string")
    protected DmUseCookieAttributes useCookieAttributes;
    @XmlElement(name = "CookieAttributes")
    protected DmReference cookieAttributes;
    @XmlElement(name = "UseSSLForLogin")
    protected String useSSLForLogin;
    @XmlElement(name = "EnableMigration")
    protected String enableMigration;
    @XmlElement(name = "SSLPort")
    protected String sslPort;
    @XmlElement(name = "SharedSecret")
    protected DmReference sharedSecret;
    @XmlElement(name = "ErrorPage")
    protected String errorPage;
    @XmlElement(name = "LogoutPage")
    protected String logoutPage;
    @XmlElement(name = "DefaultURL")
    protected String defaultURL;
    @XmlElement(name = "FormsLocation")
    protected String formsLocation;
    @XmlElement(name = "LocalLoginForm")
    protected String localLoginForm;
    @XmlElement(name = "LocalErrorPage")
    protected String localErrorPage;
    @XmlElement(name = "LocalLogoutPage")
    protected String localLogoutPage;
    @XmlElement(name = "UsernameField")
    protected String usernameField;
    @XmlElement(name = "PasswordField")
    protected String passwordField;
    @XmlElement(name = "RedirectField")
    protected String redirectField;
    @XmlElement(name = "FormProcessingURL")
    protected String formProcessingURL;
    @XmlElement(name = "InactivityTimeout")
    protected String inactivityTimeout;
    @XmlElement(name = "SessionLifetime")
    protected String sessionLifetime;
    @XmlElement(name = "RedirectURLType")
    protected String redirectURLType;
    @XmlElement(name = "FormSupportType")
    protected String formSupportType;
    @XmlElement(name = "FormSupportScript")
    protected String formSupportScript;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the loginForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginForm() {
        return loginForm;
    }

    /**
     * Sets the value of the loginForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginForm(String value) {
        this.loginForm = value;
    }

    /**
     * Gets the value of the useCookieAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link DmUseCookieAttributes }
     *     
     */
    public DmUseCookieAttributes getUseCookieAttributes() {
        return useCookieAttributes;
    }

    /**
     * Sets the value of the useCookieAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmUseCookieAttributes }
     *     
     */
    public void setUseCookieAttributes(DmUseCookieAttributes value) {
        this.useCookieAttributes = value;
    }

    /**
     * Gets the value of the cookieAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getCookieAttributes() {
        return cookieAttributes;
    }

    /**
     * Sets the value of the cookieAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setCookieAttributes(DmReference value) {
        this.cookieAttributes = value;
    }

    /**
     * Gets the value of the useSSLForLogin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseSSLForLogin() {
        return useSSLForLogin;
    }

    /**
     * Sets the value of the useSSLForLogin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseSSLForLogin(String value) {
        this.useSSLForLogin = value;
    }

    /**
     * Gets the value of the enableMigration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableMigration() {
        return enableMigration;
    }

    /**
     * Sets the value of the enableMigration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableMigration(String value) {
        this.enableMigration = value;
    }

    /**
     * Gets the value of the sslPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLPort() {
        return sslPort;
    }

    /**
     * Sets the value of the sslPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLPort(String value) {
        this.sslPort = value;
    }

    /**
     * Gets the value of the sharedSecret property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSharedSecret() {
        return sharedSecret;
    }

    /**
     * Sets the value of the sharedSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSharedSecret(DmReference value) {
        this.sharedSecret = value;
    }

    /**
     * Gets the value of the errorPage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorPage() {
        return errorPage;
    }

    /**
     * Sets the value of the errorPage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorPage(String value) {
        this.errorPage = value;
    }

    /**
     * Gets the value of the logoutPage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogoutPage() {
        return logoutPage;
    }

    /**
     * Sets the value of the logoutPage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogoutPage(String value) {
        this.logoutPage = value;
    }

    /**
     * Gets the value of the defaultURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultURL() {
        return defaultURL;
    }

    /**
     * Sets the value of the defaultURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultURL(String value) {
        this.defaultURL = value;
    }

    /**
     * Gets the value of the formsLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormsLocation() {
        return formsLocation;
    }

    /**
     * Sets the value of the formsLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormsLocation(String value) {
        this.formsLocation = value;
    }

    /**
     * Gets the value of the localLoginForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalLoginForm() {
        return localLoginForm;
    }

    /**
     * Sets the value of the localLoginForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalLoginForm(String value) {
        this.localLoginForm = value;
    }

    /**
     * Gets the value of the localErrorPage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalErrorPage() {
        return localErrorPage;
    }

    /**
     * Sets the value of the localErrorPage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalErrorPage(String value) {
        this.localErrorPage = value;
    }

    /**
     * Gets the value of the localLogoutPage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalLogoutPage() {
        return localLogoutPage;
    }

    /**
     * Sets the value of the localLogoutPage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalLogoutPage(String value) {
        this.localLogoutPage = value;
    }

    /**
     * Gets the value of the usernameField property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsernameField() {
        return usernameField;
    }

    /**
     * Sets the value of the usernameField property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsernameField(String value) {
        this.usernameField = value;
    }

    /**
     * Gets the value of the passwordField property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPasswordField() {
        return passwordField;
    }

    /**
     * Sets the value of the passwordField property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPasswordField(String value) {
        this.passwordField = value;
    }

    /**
     * Gets the value of the redirectField property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRedirectField() {
        return redirectField;
    }

    /**
     * Sets the value of the redirectField property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRedirectField(String value) {
        this.redirectField = value;
    }

    /**
     * Gets the value of the formProcessingURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormProcessingURL() {
        return formProcessingURL;
    }

    /**
     * Sets the value of the formProcessingURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormProcessingURL(String value) {
        this.formProcessingURL = value;
    }

    /**
     * Gets the value of the inactivityTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInactivityTimeout() {
        return inactivityTimeout;
    }

    /**
     * Sets the value of the inactivityTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInactivityTimeout(String value) {
        this.inactivityTimeout = value;
    }

    /**
     * Gets the value of the sessionLifetime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionLifetime() {
        return sessionLifetime;
    }

    /**
     * Sets the value of the sessionLifetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionLifetime(String value) {
        this.sessionLifetime = value;
    }

    /**
     * Gets the value of the redirectURLType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRedirectURLType() {
        return redirectURLType;
    }

    /**
     * Sets the value of the redirectURLType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRedirectURLType(String value) {
        this.redirectURLType = value;
    }

    /**
     * Gets the value of the formSupportType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormSupportType() {
        return formSupportType;
    }

    /**
     * Sets the value of the formSupportType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormSupportType(String value) {
        this.formSupportType = value;
    }

    /**
     * Gets the value of the formSupportScript property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormSupportScript() {
        return formSupportScript;
    }

    /**
     * Sets the value of the formSupportScript property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormSupportScript(String value) {
        this.formSupportScript = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
