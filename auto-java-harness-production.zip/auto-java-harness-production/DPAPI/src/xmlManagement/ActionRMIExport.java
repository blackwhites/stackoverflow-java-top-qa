package xmlManagement;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Object for sending RMI Export Async Action request
 * @author nickCoble
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Export", propOrder = {
    "Format",
    "DeploymentPolicy",
    "AllFiles",
    "Persisted",
    "IncludeInternalFiles",
    "UserComment",
    "Domain",
    "Object"
})
public class ActionRMIExport {

	@XmlElement(name = "Format", required = true)
	protected DmRMIExportFormat format;
	@XmlElement(name = "DeploymentPolicy", required = false)
	protected String deploymentPolicy;
	@XmlElement(name = "AllFiles", required = false)
	protected DmToggle allFiles;
	@XmlElement(name = "Persisted", required = false)
	protected DmToggle persisted;
	@XmlElement(name = "IncludeInternalFiles", required = false)
	protected DmToggle includeInternalFiles;
	@XmlElement(name = "UserComment", required = false)
	protected String userComment;
	@XmlElement(name = "Domain", required = false)
	protected List<DmRMIImportDomain> domain;
	@XmlElement(name = "Object", required = false)
	protected List<DmRMIExportObject> object;
	
	
	
	
	/**
	 * @return the deploymentPolicy
	 */
	public String getDeploymentPolicy() {
		return deploymentPolicy;
	}



	/**
	 * @param deploymentPolicy the deploymentPolicy to set
	 */
	public void setDeploymentPolicy(String deploymentPolicy) {
		this.deploymentPolicy = deploymentPolicy;
	}



	/**
	 * @return the object
	 */
	public List<DmRMIExportObject> getObject() {
		if(object == null){
			object = new ArrayList<>();
		}
		return object;
	}



	/**
	 * @return the domain
	 */
	public List<DmRMIImportDomain> getDomain() {
		if(domain == null){
			domain = new ArrayList<DmRMIImportDomain>();
		}
		return domain;
	}



	/**
	 * @return the format
	 */
	public DmRMIExportFormat getFormat() {
		return format;
	}

	/**
	 * @param format the format to set
	 */
	public void setFormat(DmRMIExportFormat format) {
		this.format = format;
	}

	/**
	 * @return the allFiles
	 */
	public DmToggle getAllFiles() {
		return allFiles;
	}

	/**
	 * @param allFiles the allFiles to set
	 */
	public void setAllFiles(DmToggle allFiles) {
		this.allFiles = allFiles;
	}

	/**
	 * @return the persisted
	 */
	public DmToggle getPersisted() {
		return persisted;
	}

	/**
	 * @param persisted the persisted to set
	 */
	public void setPersisted(DmToggle persisted) {
		this.persisted = persisted;
	}

	/**
	 * @return the includedInternalFiles
	 */
	public DmToggle getIncludeInternalFiles() {
		return includeInternalFiles;
	}

	/**
	 * @param includedInternalFiles the includedInternalFiles to set
	 */
	public void setIncludeInternalFiles(DmToggle includedInternalFiles) {
		this.includeInternalFiles = includedInternalFiles;
	}

	/**
	 * @return the userComment
	 */
	public String getUserComment() {
		return userComment;
	}

	/**
	 * @param userComment the userComment to set
	 */
	public void setUserComment(String userComment) {
		this.userComment = userComment;
	}



	
}
