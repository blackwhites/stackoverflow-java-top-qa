
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigNetworkSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigNetworkSettings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigNetworkConfiguration"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BlockNonmanagementTraffic" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ICMPDisable" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmICMPReplyType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ECNDisable" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DestinationRouting" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCrosstalkOnSubnet" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowAllCrosstalk" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TCPSYNRetries" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArpRetries" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArpInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ReversePathFiltering" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TCPWindowScaling" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EphemeralPortRange" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigNetworkSettings", propOrder = {
    "userSummary",
    "blockNonmanagementTraffic",
    "icmpDisable",
    "ecnDisable",
    "destinationRouting",
    "allowCrosstalkOnSubnet",
    "allowAllCrosstalk",
    "tcpsynRetries",
    "arpRetries",
    "arpInterval",
    "reversePathFiltering",
    "tcpWindowScaling",
    "ephemeralPortRange"
})
public class ConfigNetworkSettings
    extends ConfigNetworkConfiguration
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "BlockNonmanagementTraffic")
    protected String blockNonmanagementTraffic;
    @XmlElement(name = "ICMPDisable")
    protected List<String> icmpDisable;
    @XmlElement(name = "ECNDisable")
    protected String ecnDisable;
    @XmlElement(name = "DestinationRouting")
    protected String destinationRouting;
    @XmlElement(name = "AllowCrosstalkOnSubnet")
    protected String allowCrosstalkOnSubnet;
    @XmlElement(name = "AllowAllCrosstalk")
    protected String allowAllCrosstalk;
    @XmlElement(name = "TCPSYNRetries")
    protected String tcpsynRetries;
    @XmlElement(name = "ArpRetries")
    protected String arpRetries;
    @XmlElement(name = "ArpInterval")
    protected String arpInterval;
    @XmlElement(name = "ReversePathFiltering")
    protected String reversePathFiltering;
    @XmlElement(name = "TCPWindowScaling")
    protected String tcpWindowScaling;
    @XmlElement(name = "EphemeralPortRange")
    protected String ephemeralPortRange;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the blockNonmanagementTraffic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBlockNonmanagementTraffic() {
        return blockNonmanagementTraffic;
    }

    /**
     * Sets the value of the blockNonmanagementTraffic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlockNonmanagementTraffic(String value) {
        this.blockNonmanagementTraffic = value;
    }

    /**
     * Gets the value of the icmpDisable property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the icmpDisable property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getICMPDisable().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getICMPDisable() {
        if (icmpDisable == null) {
            icmpDisable = new ArrayList<String>();
        }
        return this.icmpDisable;
    }

    /**
     * Gets the value of the ecnDisable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECNDisable() {
        return ecnDisable;
    }

    /**
     * Sets the value of the ecnDisable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECNDisable(String value) {
        this.ecnDisable = value;
    }

    /**
     * Gets the value of the destinationRouting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationRouting() {
        return destinationRouting;
    }

    /**
     * Sets the value of the destinationRouting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationRouting(String value) {
        this.destinationRouting = value;
    }

    /**
     * Gets the value of the allowCrosstalkOnSubnet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCrosstalkOnSubnet() {
        return allowCrosstalkOnSubnet;
    }

    /**
     * Sets the value of the allowCrosstalkOnSubnet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCrosstalkOnSubnet(String value) {
        this.allowCrosstalkOnSubnet = value;
    }

    /**
     * Gets the value of the allowAllCrosstalk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowAllCrosstalk() {
        return allowAllCrosstalk;
    }

    /**
     * Sets the value of the allowAllCrosstalk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowAllCrosstalk(String value) {
        this.allowAllCrosstalk = value;
    }

    /**
     * Gets the value of the tcpsynRetries property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTCPSYNRetries() {
        return tcpsynRetries;
    }

    /**
     * Sets the value of the tcpsynRetries property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTCPSYNRetries(String value) {
        this.tcpsynRetries = value;
    }

    /**
     * Gets the value of the arpRetries property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArpRetries() {
        return arpRetries;
    }

    /**
     * Sets the value of the arpRetries property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArpRetries(String value) {
        this.arpRetries = value;
    }

    /**
     * Gets the value of the arpInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArpInterval() {
        return arpInterval;
    }

    /**
     * Sets the value of the arpInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArpInterval(String value) {
        this.arpInterval = value;
    }

    /**
     * Gets the value of the reversePathFiltering property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReversePathFiltering() {
        return reversePathFiltering;
    }

    /**
     * Sets the value of the reversePathFiltering property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReversePathFiltering(String value) {
        this.reversePathFiltering = value;
    }

    /**
     * Gets the value of the tcpWindowScaling property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTCPWindowScaling() {
        return tcpWindowScaling;
    }

    /**
     * Sets the value of the tcpWindowScaling property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTCPWindowScaling(String value) {
        this.tcpWindowScaling = value;
    }

    /**
     * Gets the value of the ephemeralPortRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEphemeralPortRange() {
        return ephemeralPortRange;
    }

    /**
     * Sets the value of the ephemeralPortRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEphemeralPortRange(String value) {
        this.ephemeralPortRange = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
