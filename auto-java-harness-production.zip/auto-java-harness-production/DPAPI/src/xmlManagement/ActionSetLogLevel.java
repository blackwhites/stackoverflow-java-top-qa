
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionSetLogLevel complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionSetLogLevel"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LogLevel"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InternalLog" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RBMLog" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="GlobalIPLogFilter" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionSetLogLevel", propOrder = {
    "logLevel",
    "internalLog",
    "rbmLog",
    "globalIPLogFilter"
})
public class ActionSetLogLevel {

    @XmlElement(name = "LogLevel", required = true)
    protected String logLevel;
    @XmlElement(name = "InternalLog")
    protected String internalLog;
    @XmlElement(name = "RBMLog")
    protected String rbmLog;
    @XmlElement(name = "GlobalIPLogFilter")
    protected String globalIPLogFilter;

    /**
     * Gets the value of the logLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogLevel() {
        return logLevel;
    }

    /**
     * Sets the value of the logLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogLevel(String value) {
        this.logLevel = value;
    }

    /**
     * Gets the value of the internalLog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalLog() {
        return internalLog;
    }

    /**
     * Sets the value of the internalLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalLog(String value) {
        this.internalLog = value;
    }

    /**
     * Gets the value of the rbmLog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRBMLog() {
        return rbmLog;
    }

    /**
     * Sets the value of the rbmLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRBMLog(String value) {
        this.rbmLog = value;
    }

    /**
     * Gets the value of the globalIPLogFilter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGlobalIPLogFilter() {
        return globalIPLogFilter;
    }

    /**
     * Sets the value of the globalIPLogFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlobalIPLogFilter(String value) {
        this.globalIPLogFilter = value;
    }

}
