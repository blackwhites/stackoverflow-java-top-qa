
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionRefreshTAMKeystorePwd complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionRefreshTAMKeystorePwd"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TAMObject" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionRefreshTAMKeystorePwd", propOrder = {
    "tamObject"
})
public class ActionRefreshTAMKeystorePwd {

    @XmlElement(name = "TAMObject", required = true)
    protected DmReference tamObject;

    /**
     * Gets the value of the tamObject property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getTAMObject() {
        return tamObject;
    }

    /**
     * Sets the value of the tamObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setTAMObject(DmReference value) {
        this.tamObject = value;
    }

}
