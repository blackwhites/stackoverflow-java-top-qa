
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigAAAJWTValidator complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigAAAJWTValidator"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigCrypto"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Issuer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Aud" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ValMethod" type="{http://www.datapower.com/schemas/management}dmJWTValMethod" minOccurs="0"/&gt;
 *         &lt;element name="CustomizedScript" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DecryptCredentialType" type="{http://www.datapower.com/schemas/management}dmJWTCredType" minOccurs="0"/&gt;
 *         &lt;element name="DecryptKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DecryptSSecret" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DecryptJWK" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DecryptFetchCredURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DecryptFetchCredSSLProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ValidateCustom" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VerifyCredentialType" type="{http://www.datapower.com/schemas/management}dmJWTCredType" minOccurs="0"/&gt;
 *         &lt;element name="VerifyCertificate" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="VerifyCertificateAgainstValCred" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VerifyValCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="VerifySSecret" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="VerifyJWK" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VerifyFetchCredURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VerifyFetchCredSSLProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Claims" type="{http://www.datapower.com/schemas/management}dmClaim" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UsernameClaim"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigAAAJWTValidator", propOrder = {
    "userSummary",
    "issuer",
    "aud",
    "valMethod",
    "customizedScript",
    "decryptCredentialType",
    "decryptKey",
    "decryptSSecret",
    "decryptJWK",
    "decryptFetchCredURL",
    "decryptFetchCredSSLProfile",
    "validateCustom",
    "verifyCredentialType",
    "verifyCertificate",
    "verifyCertificateAgainstValCred",
    "verifyValCred",
    "verifySSecret",
    "verifyJWK",
    "verifyFetchCredURL",
    "verifyFetchCredSSLProfile",
    "claims",
    "usernameClaim"
})
public class ConfigAAAJWTValidator
    extends ConfigCrypto
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Issuer")
    protected String issuer;
    @XmlElement(name = "Aud")
    protected String aud;
    @XmlElement(name = "ValMethod")
    protected DmJWTValMethod valMethod;
    @XmlElement(name = "CustomizedScript")
    protected String customizedScript;
    @XmlElement(name = "DecryptCredentialType")
    @XmlSchemaType(name = "string")
    protected DmJWTCredType decryptCredentialType;
    @XmlElement(name = "DecryptKey")
    protected DmReference decryptKey;
    @XmlElement(name = "DecryptSSecret")
    protected DmReference decryptSSecret;
    @XmlElement(name = "DecryptJWK")
    protected String decryptJWK;
    @XmlElement(name = "DecryptFetchCredURL")
    protected String decryptFetchCredURL;
    @XmlElement(name = "DecryptFetchCredSSLProfile")
    protected DmReference decryptFetchCredSSLProfile;
    @XmlElement(name = "ValidateCustom")
    protected String validateCustom;
    @XmlElement(name = "VerifyCredentialType")
    @XmlSchemaType(name = "string")
    protected DmJWTCredType verifyCredentialType;
    @XmlElement(name = "VerifyCertificate")
    protected DmReference verifyCertificate;
    @XmlElement(name = "VerifyCertificateAgainstValCred")
    protected String verifyCertificateAgainstValCred;
    @XmlElement(name = "VerifyValCred")
    protected DmReference verifyValCred;
    @XmlElement(name = "VerifySSecret")
    protected DmReference verifySSecret;
    @XmlElement(name = "VerifyJWK")
    protected String verifyJWK;
    @XmlElement(name = "VerifyFetchCredURL")
    protected String verifyFetchCredURL;
    @XmlElement(name = "VerifyFetchCredSSLProfile")
    protected DmReference verifyFetchCredSSLProfile;
    @XmlElement(name = "Claims")
    protected List<DmClaim> claims;
    @XmlElement(name = "UsernameClaim")
    protected String usernameClaim;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the issuer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * Sets the value of the issuer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuer(String value) {
        this.issuer = value;
    }

    /**
     * Gets the value of the aud property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAud() {
        return aud;
    }

    /**
     * Sets the value of the aud property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAud(String value) {
        this.aud = value;
    }

    /**
     * Gets the value of the valMethod property.
     * 
     * @return
     *     possible object is
     *     {@link DmJWTValMethod }
     *     
     */
    public DmJWTValMethod getValMethod() {
        return valMethod;
    }

    /**
     * Sets the value of the valMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmJWTValMethod }
     *     
     */
    public void setValMethod(DmJWTValMethod value) {
        this.valMethod = value;
    }

    /**
     * Gets the value of the customizedScript property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomizedScript() {
        return customizedScript;
    }

    /**
     * Sets the value of the customizedScript property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomizedScript(String value) {
        this.customizedScript = value;
    }

    /**
     * Gets the value of the decryptCredentialType property.
     * 
     * @return
     *     possible object is
     *     {@link DmJWTCredType }
     *     
     */
    public DmJWTCredType getDecryptCredentialType() {
        return decryptCredentialType;
    }

    /**
     * Sets the value of the decryptCredentialType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmJWTCredType }
     *     
     */
    public void setDecryptCredentialType(DmJWTCredType value) {
        this.decryptCredentialType = value;
    }

    /**
     * Gets the value of the decryptKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDecryptKey() {
        return decryptKey;
    }

    /**
     * Sets the value of the decryptKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDecryptKey(DmReference value) {
        this.decryptKey = value;
    }

    /**
     * Gets the value of the decryptSSecret property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDecryptSSecret() {
        return decryptSSecret;
    }

    /**
     * Sets the value of the decryptSSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDecryptSSecret(DmReference value) {
        this.decryptSSecret = value;
    }

    /**
     * Gets the value of the decryptJWK property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecryptJWK() {
        return decryptJWK;
    }

    /**
     * Sets the value of the decryptJWK property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecryptJWK(String value) {
        this.decryptJWK = value;
    }

    /**
     * Gets the value of the decryptFetchCredURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecryptFetchCredURL() {
        return decryptFetchCredURL;
    }

    /**
     * Sets the value of the decryptFetchCredURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecryptFetchCredURL(String value) {
        this.decryptFetchCredURL = value;
    }

    /**
     * Gets the value of the decryptFetchCredSSLProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDecryptFetchCredSSLProfile() {
        return decryptFetchCredSSLProfile;
    }

    /**
     * Sets the value of the decryptFetchCredSSLProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDecryptFetchCredSSLProfile(DmReference value) {
        this.decryptFetchCredSSLProfile = value;
    }

    /**
     * Gets the value of the validateCustom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidateCustom() {
        return validateCustom;
    }

    /**
     * Sets the value of the validateCustom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidateCustom(String value) {
        this.validateCustom = value;
    }

    /**
     * Gets the value of the verifyCredentialType property.
     * 
     * @return
     *     possible object is
     *     {@link DmJWTCredType }
     *     
     */
    public DmJWTCredType getVerifyCredentialType() {
        return verifyCredentialType;
    }

    /**
     * Sets the value of the verifyCredentialType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmJWTCredType }
     *     
     */
    public void setVerifyCredentialType(DmJWTCredType value) {
        this.verifyCredentialType = value;
    }

    /**
     * Gets the value of the verifyCertificate property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getVerifyCertificate() {
        return verifyCertificate;
    }

    /**
     * Sets the value of the verifyCertificate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setVerifyCertificate(DmReference value) {
        this.verifyCertificate = value;
    }

    /**
     * Gets the value of the verifyCertificateAgainstValCred property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerifyCertificateAgainstValCred() {
        return verifyCertificateAgainstValCred;
    }

    /**
     * Sets the value of the verifyCertificateAgainstValCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerifyCertificateAgainstValCred(String value) {
        this.verifyCertificateAgainstValCred = value;
    }

    /**
     * Gets the value of the verifyValCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getVerifyValCred() {
        return verifyValCred;
    }

    /**
     * Sets the value of the verifyValCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setVerifyValCred(DmReference value) {
        this.verifyValCred = value;
    }

    /**
     * Gets the value of the verifySSecret property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getVerifySSecret() {
        return verifySSecret;
    }

    /**
     * Sets the value of the verifySSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setVerifySSecret(DmReference value) {
        this.verifySSecret = value;
    }

    /**
     * Gets the value of the verifyJWK property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerifyJWK() {
        return verifyJWK;
    }

    /**
     * Sets the value of the verifyJWK property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerifyJWK(String value) {
        this.verifyJWK = value;
    }

    /**
     * Gets the value of the verifyFetchCredURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerifyFetchCredURL() {
        return verifyFetchCredURL;
    }

    /**
     * Sets the value of the verifyFetchCredURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerifyFetchCredURL(String value) {
        this.verifyFetchCredURL = value;
    }

    /**
     * Gets the value of the verifyFetchCredSSLProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getVerifyFetchCredSSLProfile() {
        return verifyFetchCredSSLProfile;
    }

    /**
     * Sets the value of the verifyFetchCredSSLProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setVerifyFetchCredSSLProfile(DmReference value) {
        this.verifyFetchCredSSLProfile = value;
    }

    /**
     * Gets the value of the claims property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claims property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClaims().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmClaim }
     * 
     * 
     */
    public List<DmClaim> getClaims() {
        if (claims == null) {
            claims = new ArrayList<DmClaim>();
        }
        return this.claims;
    }

    /**
     * Gets the value of the usernameClaim property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsernameClaim() {
        return usernameClaim;
    }

    /**
     * Sets the value of the usernameClaim property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsernameClaim(String value) {
        this.usernameClaim = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
