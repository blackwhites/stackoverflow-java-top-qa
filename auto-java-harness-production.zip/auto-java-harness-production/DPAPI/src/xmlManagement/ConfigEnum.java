
package xmlManagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ConfigEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="AAAPolicy"/&gt;
 *     &lt;enumeration value="Domain"/&gt;
 *     &lt;enumeration value="LDAPSearchParameters"/&gt;
 *     &lt;enumeration value="ProcessingMetadata"/&gt;
 *     &lt;enumeration value="RADIUSSettings"/&gt;
 *     &lt;enumeration value="RBMSettings"/&gt;
 *     &lt;enumeration value="SAMLAttributes"/&gt;
 *     &lt;enumeration value="SOAPHeaderDisposition"/&gt;
 *     &lt;enumeration value="TAM"/&gt;
 *     &lt;enumeration value="TFIMEndpoint"/&gt;
 *     &lt;enumeration value="XACMLPDP"/&gt;
 *     &lt;enumeration value="AccessControlList"/&gt;
 *     &lt;enumeration value="AppSecurityPolicy"/&gt;
 *     &lt;enumeration value="AuditLog"/&gt;
 *     &lt;enumeration value="B2BCPA"/&gt;
 *     &lt;enumeration value="B2BCPACollaboration"/&gt;
 *     &lt;enumeration value="B2BCPAReceiverSetting"/&gt;
 *     &lt;enumeration value="B2BCPASenderSetting"/&gt;
 *     &lt;enumeration value="B2BGateway"/&gt;
 *     &lt;enumeration value="B2BPersistence"/&gt;
 *     &lt;enumeration value="B2BProfile"/&gt;
 *     &lt;enumeration value="B2BProfileGroup"/&gt;
 *     &lt;enumeration value="B2BXPathRoutingPolicy"/&gt;
 *     &lt;enumeration value="WXSGrid"/&gt;
 *     &lt;enumeration value="XC10Grid"/&gt;
 *     &lt;enumeration value="CloudConnectorService"/&gt;
 *     &lt;enumeration value="CloudGatewayService"/&gt;
 *     &lt;enumeration value="CompactFlash"/&gt;
 *     &lt;enumeration value="CompileOptionsPolicy"/&gt;
 *     &lt;enumeration value="ConfigDeploymentPolicy"/&gt;
 *     &lt;enumeration value="ConformancePolicy"/&gt;
 *     &lt;enumeration value="AAAJWTGenerator"/&gt;
 *     &lt;enumeration value="AAAJWTValidator"/&gt;
 *     &lt;enumeration value="CertMonitor"/&gt;
 *     &lt;enumeration value="CookieAttributePolicy"/&gt;
 *     &lt;enumeration value="CRLFetch"/&gt;
 *     &lt;enumeration value="CryptoCertificate"/&gt;
 *     &lt;enumeration value="CryptoFWCred"/&gt;
 *     &lt;enumeration value="CryptoIdentCred"/&gt;
 *     &lt;enumeration value="CryptoKerberosKDC"/&gt;
 *     &lt;enumeration value="CryptoKerberosKeytab"/&gt;
 *     &lt;enumeration value="CryptoKey"/&gt;
 *     &lt;enumeration value="CryptoProfile"/&gt;
 *     &lt;enumeration value="CryptoSSKey"/&gt;
 *     &lt;enumeration value="CryptoValCred"/&gt;
 *     &lt;enumeration value="JOSERecipientIdentifier"/&gt;
 *     &lt;enumeration value="JOSESignatureIdentifier"/&gt;
 *     &lt;enumeration value="JWEHeader"/&gt;
 *     &lt;enumeration value="JWERecipient"/&gt;
 *     &lt;enumeration value="JWSSignature"/&gt;
 *     &lt;enumeration value="OAuthSupportedClient"/&gt;
 *     &lt;enumeration value="OAuthSupportedClientGroup"/&gt;
 *     &lt;enumeration value="SocialLoginPolicy"/&gt;
 *     &lt;enumeration value="SSHClientProfile"/&gt;
 *     &lt;enumeration value="SSHDomainClientProfile"/&gt;
 *     &lt;enumeration value="SSHServerProfile"/&gt;
 *     &lt;enumeration value="SSLClientProfile"/&gt;
 *     &lt;enumeration value="SSLProxyProfile"/&gt;
 *     &lt;enumeration value="SSLServerProfile"/&gt;
 *     &lt;enumeration value="SSLSNIMapping"/&gt;
 *     &lt;enumeration value="SSLSNIServerProfile"/&gt;
 *     &lt;enumeration value="DeploymentPolicyParametersBinding"/&gt;
 *     &lt;enumeration value="ErrorReportSettings"/&gt;
 *     &lt;enumeration value="SystemSettings"/&gt;
 *     &lt;enumeration value="TimeSettings"/&gt;
 *     &lt;enumeration value="DFDLSettings"/&gt;
 *     &lt;enumeration value="DomainAvailability"/&gt;
 *     &lt;enumeration value="DomainSettings"/&gt;
 *     &lt;enumeration value="SchemaExceptionMap"/&gt;
 *     &lt;enumeration value="DocumentCryptoMap"/&gt;
 *     &lt;enumeration value="XPathRoutingMap"/&gt;
 *     &lt;enumeration value="LogTarget"/&gt;
 *     &lt;enumeration value="FormsLoginPolicy"/&gt;
 *     &lt;enumeration value="FTPQuoteCommands"/&gt;
 *     &lt;enumeration value="MultiProtocolGateway"/&gt;
 *     &lt;enumeration value="WSGateway"/&gt;
 *     &lt;enumeration value="GeneratedPolicy"/&gt;
 *     &lt;enumeration value="HTTPInputConversionMap"/&gt;
 *     &lt;enumeration value="HTTPUserAgent"/&gt;
 *     &lt;enumeration value="ILMTAgent"/&gt;
 *     &lt;enumeration value="ImportPackage"/&gt;
 *     &lt;enumeration value="IMSConnect"/&gt;
 *     &lt;enumeration value="IncludeConfig"/&gt;
 *     &lt;enumeration value="InteropService"/&gt;
 *     &lt;enumeration value="EthernetInterface"/&gt;
 *     &lt;enumeration value="LinkAggregation"/&gt;
 *     &lt;enumeration value="VLANInterface"/&gt;
 *     &lt;enumeration value="IPMILanChannel"/&gt;
 *     &lt;enumeration value="IPMIUser"/&gt;
 *     &lt;enumeration value="IPMulticast"/&gt;
 *     &lt;enumeration value="ISAMReverseProxy"/&gt;
 *     &lt;enumeration value="ISAMReverseProxyJunction"/&gt;
 *     &lt;enumeration value="ISAMRuntime"/&gt;
 *     &lt;enumeration value="IScsiChapConfig"/&gt;
 *     &lt;enumeration value="IScsiHBAConfig"/&gt;
 *     &lt;enumeration value="IScsiInitiatorConfig"/&gt;
 *     &lt;enumeration value="IScsiTargetConfig"/&gt;
 *     &lt;enumeration value="IScsiVolumeConfig"/&gt;
 *     &lt;enumeration value="TibcoEMSServer"/&gt;
 *     &lt;enumeration value="WebSphereJMSServer"/&gt;
 *     &lt;enumeration value="JSONSettings"/&gt;
 *     &lt;enumeration value="Language"/&gt;
 *     &lt;enumeration value="LDAPConnectionPool"/&gt;
 *     &lt;enumeration value="LoadBalancerGroup"/&gt;
 *     &lt;enumeration value="LogLabel"/&gt;
 *     &lt;enumeration value="Luna"/&gt;
 *     &lt;enumeration value="LunaPartition"/&gt;
 *     &lt;enumeration value="Matching"/&gt;
 *     &lt;enumeration value="MCFCustomRule"/&gt;
 *     &lt;enumeration value="MCFHttpHeader"/&gt;
 *     &lt;enumeration value="MCFHttpMethod"/&gt;
 *     &lt;enumeration value="MCFHttpURL"/&gt;
 *     &lt;enumeration value="MCFXPath"/&gt;
 *     &lt;enumeration value="MessageContentFilters"/&gt;
 *     &lt;enumeration value="FilterAction"/&gt;
 *     &lt;enumeration value="MessageMatching"/&gt;
 *     &lt;enumeration value="CountMonitor"/&gt;
 *     &lt;enumeration value="DurationMonitor"/&gt;
 *     &lt;enumeration value="MessageType"/&gt;
 *     &lt;enumeration value="MPGWErrorAction"/&gt;
 *     &lt;enumeration value="MPGWErrorHandlingPolicy"/&gt;
 *     &lt;enumeration value="MQAUI"/&gt;
 *     &lt;enumeration value="MQGW"/&gt;
 *     &lt;enumeration value="MQhost"/&gt;
 *     &lt;enumeration value="MQproxy"/&gt;
 *     &lt;enumeration value="MQQM"/&gt;
 *     &lt;enumeration value="MQQMGroup"/&gt;
 *     &lt;enumeration value="MTOMPolicy"/&gt;
 *     &lt;enumeration value="NameValueProfile"/&gt;
 *     &lt;enumeration value="DNSNameService"/&gt;
 *     &lt;enumeration value="HostAlias"/&gt;
 *     &lt;enumeration value="NetworkSettings"/&gt;
 *     &lt;enumeration value="NTPService"/&gt;
 *     &lt;enumeration value="NFSClientSettings"/&gt;
 *     &lt;enumeration value="NFSDynamicMounts"/&gt;
 *     &lt;enumeration value="NFSStaticMount"/&gt;
 *     &lt;enumeration value="ODR"/&gt;
 *     &lt;enumeration value="ODRConnectorGroup"/&gt;
 *     &lt;enumeration value="PasswordAlias"/&gt;
 *     &lt;enumeration value="Pattern"/&gt;
 *     &lt;enumeration value="PeerGroup"/&gt;
 *     &lt;enumeration value="PolicyAttachments"/&gt;
 *     &lt;enumeration value="PolicyParameters"/&gt;
 *     &lt;enumeration value="QuotaEnforcementServer"/&gt;
 *     &lt;enumeration value="RaidVolume"/&gt;
 *     &lt;enumeration value="SQLRuntimeSettings"/&gt;
 *     &lt;enumeration value="SecureBackupMode"/&gt;
 *     &lt;enumeration value="SecureCloudConnector"/&gt;
 *     &lt;enumeration value="SecureGatewayClient"/&gt;
 *     &lt;enumeration value="MgmtInterface"/&gt;
 *     &lt;enumeration value="RestMgmtInterface"/&gt;
 *     &lt;enumeration value="SSHService"/&gt;
 *     &lt;enumeration value="TelnetService"/&gt;
 *     &lt;enumeration value="WebB2BViewer"/&gt;
 *     &lt;enumeration value="WebGUI"/&gt;
 *     &lt;enumeration value="XMLFirewallService"/&gt;
 *     &lt;enumeration value="XSLProxyService"/&gt;
 *     &lt;enumeration value="HTTPService"/&gt;
 *     &lt;enumeration value="SSLProxyService"/&gt;
 *     &lt;enumeration value="TCPProxyService"/&gt;
 *     &lt;enumeration value="XSLCoprocService"/&gt;
 *     &lt;enumeration value="ShellAlias"/&gt;
 *     &lt;enumeration value="SimpleCountMonitor"/&gt;
 *     &lt;enumeration value="SLMAction"/&gt;
 *     &lt;enumeration value="SLMCredClass"/&gt;
 *     &lt;enumeration value="SLMPolicy"/&gt;
 *     &lt;enumeration value="SLMRsrcClass"/&gt;
 *     &lt;enumeration value="SLMSchedule"/&gt;
 *     &lt;enumeration value="SMTPServerConnection"/&gt;
 *     &lt;enumeration value="SNMPSettings"/&gt;
 *     &lt;enumeration value="AS2ProxySourceProtocolHandler"/&gt;
 *     &lt;enumeration value="AS2SourceProtocolHandler"/&gt;
 *     &lt;enumeration value="AS3SourceProtocolHandler"/&gt;
 *     &lt;enumeration value="EBMS2SourceProtocolHandler"/&gt;
 *     &lt;enumeration value="EBMS3SourceProtocolHandler"/&gt;
 *     &lt;enumeration value="FTPFilePollerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="NFSFilePollerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="SFTPFilePollerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="FTPServerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="HTTPSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="HTTPSSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="IMSCalloutSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="IMSConnectSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="TibcoEMSSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="WebSphereJMSSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="MQFTESourceProtocolHandler"/&gt;
 *     &lt;enumeration value="MQSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="AS1PollerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="POPPollerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="SSHServerSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="StatelessTCPSourceProtocolHandler"/&gt;
 *     &lt;enumeration value="XTCProtocolHandler"/&gt;
 *     &lt;enumeration value="SQLDataSource"/&gt;
 *     &lt;enumeration value="StandaloneStandbyControl"/&gt;
 *     &lt;enumeration value="StandaloneStandbyControlInterface"/&gt;
 *     &lt;enumeration value="Statistics"/&gt;
 *     &lt;enumeration value="StylePolicy"/&gt;
 *     &lt;enumeration value="StylePolicyAction"/&gt;
 *     &lt;enumeration value="StylePolicyRule"/&gt;
 *     &lt;enumeration value="WSStylePolicyRule"/&gt;
 *     &lt;enumeration value="Throttler"/&gt;
 *     &lt;enumeration value="UDDIRegistry"/&gt;
 *     &lt;enumeration value="URLMap"/&gt;
 *     &lt;enumeration value="URLRefreshPolicy"/&gt;
 *     &lt;enumeration value="URLRewritePolicy"/&gt;
 *     &lt;enumeration value="User"/&gt;
 *     &lt;enumeration value="UserGroup"/&gt;
 *     &lt;enumeration value="WCCService"/&gt;
 *     &lt;enumeration value="WebAppErrorHandlingPolicy"/&gt;
 *     &lt;enumeration value="WebAppFW"/&gt;
 *     &lt;enumeration value="WebAppRequest"/&gt;
 *     &lt;enumeration value="WebAppResponse"/&gt;
 *     &lt;enumeration value="WebAppSessionPolicy"/&gt;
 *     &lt;enumeration value="WebServiceMonitor"/&gt;
 *     &lt;enumeration value="WebServicesAgent"/&gt;
 *     &lt;enumeration value="UDDISubscription"/&gt;
 *     &lt;enumeration value="WSRRSavedSearchSubscription"/&gt;
 *     &lt;enumeration value="WSRRSubscription"/&gt;
 *     &lt;enumeration value="WebTokenService"/&gt;
 *     &lt;enumeration value="WSEndpointRewritePolicy"/&gt;
 *     &lt;enumeration value="WSRRServer"/&gt;
 *     &lt;enumeration value="WSStylePolicy"/&gt;
 *     &lt;enumeration value="XMLManager"/&gt;
 *     &lt;enumeration value="xmltrace"/&gt;
 *     &lt;enumeration value="ZHybridTargetControlService"/&gt;
 *     &lt;enumeration value="ZosNSSClient"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ConfigEnum")
@XmlEnum
public enum ConfigEnum {

    @XmlEnumValue("AAAPolicy")
    AAA_POLICY("AAAPolicy"),
    @XmlEnumValue("Domain")
    DOMAIN("Domain"),
    @XmlEnumValue("LDAPSearchParameters")
    LDAP_SEARCH_PARAMETERS("LDAPSearchParameters"),
    @XmlEnumValue("ProcessingMetadata")
    PROCESSING_METADATA("ProcessingMetadata"),
    @XmlEnumValue("RADIUSSettings")
    RADIUS_SETTINGS("RADIUSSettings"),
    @XmlEnumValue("RBMSettings")
    RBM_SETTINGS("RBMSettings"),
    @XmlEnumValue("SAMLAttributes")
    SAML_ATTRIBUTES("SAMLAttributes"),
    @XmlEnumValue("SOAPHeaderDisposition")
    SOAP_HEADER_DISPOSITION("SOAPHeaderDisposition"),
    TAM("TAM"),
    @XmlEnumValue("TFIMEndpoint")
    TFIM_ENDPOINT("TFIMEndpoint"),
    XACMLPDP("XACMLPDP"),
    @XmlEnumValue("AccessControlList")
    ACCESS_CONTROL_LIST("AccessControlList"),
    @XmlEnumValue("AppSecurityPolicy")
    APP_SECURITY_POLICY("AppSecurityPolicy"),
    @XmlEnumValue("AuditLog")
    AUDIT_LOG("AuditLog"),
    @XmlEnumValue("B2BCPA")
    B_2_BCPA("B2BCPA"),
    @XmlEnumValue("B2BCPACollaboration")
    B_2_BCPA_COLLABORATION("B2BCPACollaboration"),
    @XmlEnumValue("B2BCPAReceiverSetting")
    B_2_BCPA_RECEIVER_SETTING("B2BCPAReceiverSetting"),
    @XmlEnumValue("B2BCPASenderSetting")
    B_2_BCPA_SENDER_SETTING("B2BCPASenderSetting"),
    @XmlEnumValue("B2BGateway")
    B_2_B_GATEWAY("B2BGateway"),
    @XmlEnumValue("B2BPersistence")
    B_2_B_PERSISTENCE("B2BPersistence"),
    @XmlEnumValue("B2BProfile")
    B_2_B_PROFILE("B2BProfile"),
    @XmlEnumValue("B2BProfileGroup")
    B_2_B_PROFILE_GROUP("B2BProfileGroup"),
    @XmlEnumValue("B2BXPathRoutingPolicy")
    B_2_BX_PATH_ROUTING_POLICY("B2BXPathRoutingPolicy"),
    @XmlEnumValue("WXSGrid")
    WXS_GRID("WXSGrid"),
    @XmlEnumValue("XC10Grid")
    XC_10_GRID("XC10Grid"),
    @XmlEnumValue("CloudConnectorService")
    CLOUD_CONNECTOR_SERVICE("CloudConnectorService"),
    @XmlEnumValue("CloudGatewayService")
    CLOUD_GATEWAY_SERVICE("CloudGatewayService"),
    @XmlEnumValue("CompactFlash")
    COMPACT_FLASH("CompactFlash"),
    @XmlEnumValue("CompileOptionsPolicy")
    COMPILE_OPTIONS_POLICY("CompileOptionsPolicy"),
    @XmlEnumValue("ConfigDeploymentPolicy")
    CONFIG_DEPLOYMENT_POLICY("ConfigDeploymentPolicy"),
    @XmlEnumValue("ConformancePolicy")
    CONFORMANCE_POLICY("ConformancePolicy"),
    @XmlEnumValue("AAAJWTGenerator")
    AAAJWT_GENERATOR("AAAJWTGenerator"),
    @XmlEnumValue("AAAJWTValidator")
    AAAJWT_VALIDATOR("AAAJWTValidator"),
    @XmlEnumValue("CertMonitor")
    CERT_MONITOR("CertMonitor"),
    @XmlEnumValue("CookieAttributePolicy")
    COOKIE_ATTRIBUTE_POLICY("CookieAttributePolicy"),
    @XmlEnumValue("CRLFetch")
    CRL_FETCH("CRLFetch"),
    @XmlEnumValue("CryptoCertificate")
    CRYPTO_CERTIFICATE("CryptoCertificate"),
    @XmlEnumValue("CryptoFWCred")
    CRYPTO_FW_CRED("CryptoFWCred"),
    @XmlEnumValue("CryptoIdentCred")
    CRYPTO_IDENT_CRED("CryptoIdentCred"),
    @XmlEnumValue("CryptoKerberosKDC")
    CRYPTO_KERBEROS_KDC("CryptoKerberosKDC"),
    @XmlEnumValue("CryptoKerberosKeytab")
    CRYPTO_KERBEROS_KEYTAB("CryptoKerberosKeytab"),
    @XmlEnumValue("CryptoKey")
    CRYPTO_KEY("CryptoKey"),
    @XmlEnumValue("CryptoProfile")
    CRYPTO_PROFILE("CryptoProfile"),
    @XmlEnumValue("CryptoSSKey")
    CRYPTO_SS_KEY("CryptoSSKey"),
    @XmlEnumValue("CryptoValCred")
    CRYPTO_VAL_CRED("CryptoValCred"),
    @XmlEnumValue("JOSERecipientIdentifier")
    JOSE_RECIPIENT_IDENTIFIER("JOSERecipientIdentifier"),
    @XmlEnumValue("JOSESignatureIdentifier")
    JOSE_SIGNATURE_IDENTIFIER("JOSESignatureIdentifier"),
    @XmlEnumValue("JWEHeader")
    JWE_HEADER("JWEHeader"),
    @XmlEnumValue("JWERecipient")
    JWE_RECIPIENT("JWERecipient"),
    @XmlEnumValue("JWSSignature")
    JWS_SIGNATURE("JWSSignature"),
    @XmlEnumValue("OAuthSupportedClient")
    O_AUTH_SUPPORTED_CLIENT("OAuthSupportedClient"),
    @XmlEnumValue("OAuthSupportedClientGroup")
    O_AUTH_SUPPORTED_CLIENT_GROUP("OAuthSupportedClientGroup"),
    @XmlEnumValue("SocialLoginPolicy")
    SOCIAL_LOGIN_POLICY("SocialLoginPolicy"),
    @XmlEnumValue("SSHClientProfile")
    SSH_CLIENT_PROFILE("SSHClientProfile"),
    @XmlEnumValue("SSHDomainClientProfile")
    SSH_DOMAIN_CLIENT_PROFILE("SSHDomainClientProfile"),
    @XmlEnumValue("SSHServerProfile")
    SSH_SERVER_PROFILE("SSHServerProfile"),
    @XmlEnumValue("SSLClientProfile")
    SSL_CLIENT_PROFILE("SSLClientProfile"),
    @XmlEnumValue("SSLProxyProfile")
    SSL_PROXY_PROFILE("SSLProxyProfile"),
    @XmlEnumValue("SSLServerProfile")
    SSL_SERVER_PROFILE("SSLServerProfile"),
    @XmlEnumValue("SSLSNIMapping")
    SSLSNI_MAPPING("SSLSNIMapping"),
    @XmlEnumValue("SSLSNIServerProfile")
    SSLSNI_SERVER_PROFILE("SSLSNIServerProfile"),
    @XmlEnumValue("DeploymentPolicyParametersBinding")
    DEPLOYMENT_POLICY_PARAMETERS_BINDING("DeploymentPolicyParametersBinding"),
    @XmlEnumValue("ErrorReportSettings")
    ERROR_REPORT_SETTINGS("ErrorReportSettings"),
    @XmlEnumValue("SystemSettings")
    SYSTEM_SETTINGS("SystemSettings"),
    @XmlEnumValue("TimeSettings")
    TIME_SETTINGS("TimeSettings"),
    @XmlEnumValue("DFDLSettings")
    DFDL_SETTINGS("DFDLSettings"),
    @XmlEnumValue("DomainAvailability")
    DOMAIN_AVAILABILITY("DomainAvailability"),
    @XmlEnumValue("DomainSettings")
    DOMAIN_SETTINGS("DomainSettings"),
    @XmlEnumValue("SchemaExceptionMap")
    SCHEMA_EXCEPTION_MAP("SchemaExceptionMap"),
    @XmlEnumValue("DocumentCryptoMap")
    DOCUMENT_CRYPTO_MAP("DocumentCryptoMap"),
    @XmlEnumValue("XPathRoutingMap")
    X_PATH_ROUTING_MAP("XPathRoutingMap"),
    @XmlEnumValue("LogTarget")
    LOG_TARGET("LogTarget"),
    @XmlEnumValue("FormsLoginPolicy")
    FORMS_LOGIN_POLICY("FormsLoginPolicy"),
    @XmlEnumValue("FTPQuoteCommands")
    FTP_QUOTE_COMMANDS("FTPQuoteCommands"),
    @XmlEnumValue("MultiProtocolGateway")
    MULTI_PROTOCOL_GATEWAY("MultiProtocolGateway"),
    @XmlEnumValue("WSGateway")
    WS_GATEWAY("WSGateway"),
    @XmlEnumValue("GeneratedPolicy")
    GENERATED_POLICY("GeneratedPolicy"),
    @XmlEnumValue("HTTPInputConversionMap")
    HTTP_INPUT_CONVERSION_MAP("HTTPInputConversionMap"),
    @XmlEnumValue("HTTPUserAgent")
    HTTP_USER_AGENT("HTTPUserAgent"),
    @XmlEnumValue("ILMTAgent")
    ILMT_AGENT("ILMTAgent"),
    @XmlEnumValue("ImportPackage")
    IMPORT_PACKAGE("ImportPackage"),
    @XmlEnumValue("IMSConnect")
    IMS_CONNECT("IMSConnect"),
    @XmlEnumValue("IncludeConfig")
    INCLUDE_CONFIG("IncludeConfig"),
    @XmlEnumValue("InteropService")
    INTEROP_SERVICE("InteropService"),
    @XmlEnumValue("EthernetInterface")
    ETHERNET_INTERFACE("EthernetInterface"),
    @XmlEnumValue("LinkAggregation")
    LINK_AGGREGATION("LinkAggregation"),
    @XmlEnumValue("VLANInterface")
    VLAN_INTERFACE("VLANInterface"),
    @XmlEnumValue("IPMILanChannel")
    IPMI_LAN_CHANNEL("IPMILanChannel"),
    @XmlEnumValue("IPMIUser")
    IPMI_USER("IPMIUser"),
    @XmlEnumValue("IPMulticast")
    IP_MULTICAST("IPMulticast"),
    @XmlEnumValue("ISAMReverseProxy")
    ISAM_REVERSE_PROXY("ISAMReverseProxy"),
    @XmlEnumValue("ISAMReverseProxyJunction")
    ISAM_REVERSE_PROXY_JUNCTION("ISAMReverseProxyJunction"),
    @XmlEnumValue("ISAMRuntime")
    ISAM_RUNTIME("ISAMRuntime"),
    @XmlEnumValue("IScsiChapConfig")
    I_SCSI_CHAP_CONFIG("IScsiChapConfig"),
    @XmlEnumValue("IScsiHBAConfig")
    I_SCSI_HBA_CONFIG("IScsiHBAConfig"),
    @XmlEnumValue("IScsiInitiatorConfig")
    I_SCSI_INITIATOR_CONFIG("IScsiInitiatorConfig"),
    @XmlEnumValue("IScsiTargetConfig")
    I_SCSI_TARGET_CONFIG("IScsiTargetConfig"),
    @XmlEnumValue("IScsiVolumeConfig")
    I_SCSI_VOLUME_CONFIG("IScsiVolumeConfig"),
    @XmlEnumValue("TibcoEMSServer")
    TIBCO_EMS_SERVER("TibcoEMSServer"),
    @XmlEnumValue("WebSphereJMSServer")
    WEB_SPHERE_JMS_SERVER("WebSphereJMSServer"),
    @XmlEnumValue("JSONSettings")
    JSON_SETTINGS("JSONSettings"),
    @XmlEnumValue("Language")
    LANGUAGE("Language"),
    @XmlEnumValue("LDAPConnectionPool")
    LDAP_CONNECTION_POOL("LDAPConnectionPool"),
    @XmlEnumValue("LoadBalancerGroup")
    LOAD_BALANCER_GROUP("LoadBalancerGroup"),
    @XmlEnumValue("LogLabel")
    LOG_LABEL("LogLabel"),
    @XmlEnumValue("Luna")
    LUNA("Luna"),
    @XmlEnumValue("LunaPartition")
    LUNA_PARTITION("LunaPartition"),
    @XmlEnumValue("Matching")
    MATCHING("Matching"),
    @XmlEnumValue("MCFCustomRule")
    MCF_CUSTOM_RULE("MCFCustomRule"),
    @XmlEnumValue("MCFHttpHeader")
    MCF_HTTP_HEADER("MCFHttpHeader"),
    @XmlEnumValue("MCFHttpMethod")
    MCF_HTTP_METHOD("MCFHttpMethod"),
    @XmlEnumValue("MCFHttpURL")
    MCF_HTTP_URL("MCFHttpURL"),
    @XmlEnumValue("MCFXPath")
    MCFX_PATH("MCFXPath"),
    @XmlEnumValue("MessageContentFilters")
    MESSAGE_CONTENT_FILTERS("MessageContentFilters"),
    @XmlEnumValue("FilterAction")
    FILTER_ACTION("FilterAction"),
    @XmlEnumValue("MessageMatching")
    MESSAGE_MATCHING("MessageMatching"),
    @XmlEnumValue("CountMonitor")
    COUNT_MONITOR("CountMonitor"),
    @XmlEnumValue("DurationMonitor")
    DURATION_MONITOR("DurationMonitor"),
    @XmlEnumValue("MessageType")
    MESSAGE_TYPE("MessageType"),
    @XmlEnumValue("MPGWErrorAction")
    MPGW_ERROR_ACTION("MPGWErrorAction"),
    @XmlEnumValue("MPGWErrorHandlingPolicy")
    MPGW_ERROR_HANDLING_POLICY("MPGWErrorHandlingPolicy"),
    MQAUI("MQAUI"),
    MQGW("MQGW"),
    @XmlEnumValue("MQhost")
    M_QHOST("MQhost"),
    @XmlEnumValue("MQproxy")
    M_QPROXY("MQproxy"),
    MQQM("MQQM"),
    @XmlEnumValue("MQQMGroup")
    MQQM_GROUP("MQQMGroup"),
    @XmlEnumValue("MTOMPolicy")
    MTOM_POLICY("MTOMPolicy"),
    @XmlEnumValue("NameValueProfile")
    NAME_VALUE_PROFILE("NameValueProfile"),
    @XmlEnumValue("DNSNameService")
    DNS_NAME_SERVICE("DNSNameService"),
    @XmlEnumValue("HostAlias")
    HOST_ALIAS("HostAlias"),
    @XmlEnumValue("NetworkSettings")
    NETWORK_SETTINGS("NetworkSettings"),
    @XmlEnumValue("NTPService")
    NTP_SERVICE("NTPService"),
    @XmlEnumValue("NFSClientSettings")
    NFS_CLIENT_SETTINGS("NFSClientSettings"),
    @XmlEnumValue("NFSDynamicMounts")
    NFS_DYNAMIC_MOUNTS("NFSDynamicMounts"),
    @XmlEnumValue("NFSStaticMount")
    NFS_STATIC_MOUNT("NFSStaticMount"),
    ODR("ODR"),
    @XmlEnumValue("ODRConnectorGroup")
    ODR_CONNECTOR_GROUP("ODRConnectorGroup"),
    @XmlEnumValue("PasswordAlias")
    PASSWORD_ALIAS("PasswordAlias"),
    @XmlEnumValue("Pattern")
    PATTERN("Pattern"),
    @XmlEnumValue("PeerGroup")
    PEER_GROUP("PeerGroup"),
    @XmlEnumValue("PolicyAttachments")
    POLICY_ATTACHMENTS("PolicyAttachments"),
    @XmlEnumValue("PolicyParameters")
    POLICY_PARAMETERS("PolicyParameters"),
    @XmlEnumValue("QuotaEnforcementServer")
    QUOTA_ENFORCEMENT_SERVER("QuotaEnforcementServer"),
    @XmlEnumValue("RaidVolume")
    RAID_VOLUME("RaidVolume"),
    @XmlEnumValue("SQLRuntimeSettings")
    SQL_RUNTIME_SETTINGS("SQLRuntimeSettings"),
    @XmlEnumValue("SecureBackupMode")
    SECURE_BACKUP_MODE("SecureBackupMode"),
    @XmlEnumValue("SecureCloudConnector")
    SECURE_CLOUD_CONNECTOR("SecureCloudConnector"),
    @XmlEnumValue("SecureGatewayClient")
    SECURE_GATEWAY_CLIENT("SecureGatewayClient"),
    @XmlEnumValue("MgmtInterface")
    MGMT_INTERFACE("MgmtInterface"),
    @XmlEnumValue("RestMgmtInterface")
    REST_MGMT_INTERFACE("RestMgmtInterface"),
    @XmlEnumValue("SSHService")
    SSH_SERVICE("SSHService"),
    @XmlEnumValue("TelnetService")
    TELNET_SERVICE("TelnetService"),
    @XmlEnumValue("WebB2BViewer")
    WEB_B_2_B_VIEWER("WebB2BViewer"),
    @XmlEnumValue("WebGUI")
    WEB_GUI("WebGUI"),
    @XmlEnumValue("XMLFirewallService")
    XML_FIREWALL_SERVICE("XMLFirewallService"),
    @XmlEnumValue("XSLProxyService")
    XSL_PROXY_SERVICE("XSLProxyService"),
    @XmlEnumValue("HTTPService")
    HTTP_SERVICE("HTTPService"),
    @XmlEnumValue("SSLProxyService")
    SSL_PROXY_SERVICE("SSLProxyService"),
    @XmlEnumValue("TCPProxyService")
    TCP_PROXY_SERVICE("TCPProxyService"),
    @XmlEnumValue("XSLCoprocService")
    XSL_COPROC_SERVICE("XSLCoprocService"),
    @XmlEnumValue("ShellAlias")
    SHELL_ALIAS("ShellAlias"),
    @XmlEnumValue("SimpleCountMonitor")
    SIMPLE_COUNT_MONITOR("SimpleCountMonitor"),
    @XmlEnumValue("SLMAction")
    SLM_ACTION("SLMAction"),
    @XmlEnumValue("SLMCredClass")
    SLM_CRED_CLASS("SLMCredClass"),
    @XmlEnumValue("SLMPolicy")
    SLM_POLICY("SLMPolicy"),
    @XmlEnumValue("SLMRsrcClass")
    SLM_RSRC_CLASS("SLMRsrcClass"),
    @XmlEnumValue("SLMSchedule")
    SLM_SCHEDULE("SLMSchedule"),
    @XmlEnumValue("SMTPServerConnection")
    SMTP_SERVER_CONNECTION("SMTPServerConnection"),
    @XmlEnumValue("SNMPSettings")
    SNMP_SETTINGS("SNMPSettings"),
    @XmlEnumValue("AS2ProxySourceProtocolHandler")
    AS_2_PROXY_SOURCE_PROTOCOL_HANDLER("AS2ProxySourceProtocolHandler"),
    @XmlEnumValue("AS2SourceProtocolHandler")
    AS_2_SOURCE_PROTOCOL_HANDLER("AS2SourceProtocolHandler"),
    @XmlEnumValue("AS3SourceProtocolHandler")
    AS_3_SOURCE_PROTOCOL_HANDLER("AS3SourceProtocolHandler"),
    @XmlEnumValue("EBMS2SourceProtocolHandler")
    EBMS_2_SOURCE_PROTOCOL_HANDLER("EBMS2SourceProtocolHandler"),
    @XmlEnumValue("EBMS3SourceProtocolHandler")
    EBMS_3_SOURCE_PROTOCOL_HANDLER("EBMS3SourceProtocolHandler"),
    @XmlEnumValue("FTPFilePollerSourceProtocolHandler")
    FTP_FILE_POLLER_SOURCE_PROTOCOL_HANDLER("FTPFilePollerSourceProtocolHandler"),
    @XmlEnumValue("NFSFilePollerSourceProtocolHandler")
    NFS_FILE_POLLER_SOURCE_PROTOCOL_HANDLER("NFSFilePollerSourceProtocolHandler"),
    @XmlEnumValue("SFTPFilePollerSourceProtocolHandler")
    SFTP_FILE_POLLER_SOURCE_PROTOCOL_HANDLER("SFTPFilePollerSourceProtocolHandler"),
    @XmlEnumValue("FTPServerSourceProtocolHandler")
    FTP_SERVER_SOURCE_PROTOCOL_HANDLER("FTPServerSourceProtocolHandler"),
    @XmlEnumValue("HTTPSourceProtocolHandler")
    HTTP_SOURCE_PROTOCOL_HANDLER("HTTPSourceProtocolHandler"),
    @XmlEnumValue("HTTPSSourceProtocolHandler")
    HTTPS_SOURCE_PROTOCOL_HANDLER("HTTPSSourceProtocolHandler"),
    @XmlEnumValue("IMSCalloutSourceProtocolHandler")
    IMS_CALLOUT_SOURCE_PROTOCOL_HANDLER("IMSCalloutSourceProtocolHandler"),
    @XmlEnumValue("IMSConnectSourceProtocolHandler")
    IMS_CONNECT_SOURCE_PROTOCOL_HANDLER("IMSConnectSourceProtocolHandler"),
    @XmlEnumValue("TibcoEMSSourceProtocolHandler")
    TIBCO_EMS_SOURCE_PROTOCOL_HANDLER("TibcoEMSSourceProtocolHandler"),
    @XmlEnumValue("WebSphereJMSSourceProtocolHandler")
    WEB_SPHERE_JMS_SOURCE_PROTOCOL_HANDLER("WebSphereJMSSourceProtocolHandler"),
    @XmlEnumValue("MQFTESourceProtocolHandler")
    MQFTE_SOURCE_PROTOCOL_HANDLER("MQFTESourceProtocolHandler"),
    @XmlEnumValue("MQSourceProtocolHandler")
    MQ_SOURCE_PROTOCOL_HANDLER("MQSourceProtocolHandler"),
    @XmlEnumValue("AS1PollerSourceProtocolHandler")
    AS_1_POLLER_SOURCE_PROTOCOL_HANDLER("AS1PollerSourceProtocolHandler"),
    @XmlEnumValue("POPPollerSourceProtocolHandler")
    POP_POLLER_SOURCE_PROTOCOL_HANDLER("POPPollerSourceProtocolHandler"),
    @XmlEnumValue("SSHServerSourceProtocolHandler")
    SSH_SERVER_SOURCE_PROTOCOL_HANDLER("SSHServerSourceProtocolHandler"),
    @XmlEnumValue("StatelessTCPSourceProtocolHandler")
    STATELESS_TCP_SOURCE_PROTOCOL_HANDLER("StatelessTCPSourceProtocolHandler"),
    @XmlEnumValue("XTCProtocolHandler")
    XTC_PROTOCOL_HANDLER("XTCProtocolHandler"),
    @XmlEnumValue("SQLDataSource")
    SQL_DATA_SOURCE("SQLDataSource"),
    @XmlEnumValue("StandaloneStandbyControl")
    STANDALONE_STANDBY_CONTROL("StandaloneStandbyControl"),
    @XmlEnumValue("StandaloneStandbyControlInterface")
    STANDALONE_STANDBY_CONTROL_INTERFACE("StandaloneStandbyControlInterface"),
    @XmlEnumValue("Statistics")
    STATISTICS("Statistics"),
    @XmlEnumValue("StylePolicy")
    STYLE_POLICY("StylePolicy"),
    @XmlEnumValue("StylePolicyAction")
    STYLE_POLICY_ACTION("StylePolicyAction"),
    @XmlEnumValue("StylePolicyRule")
    STYLE_POLICY_RULE("StylePolicyRule"),
    @XmlEnumValue("WSStylePolicyRule")
    WS_STYLE_POLICY_RULE("WSStylePolicyRule"),
    @XmlEnumValue("Throttler")
    THROTTLER("Throttler"),
    @XmlEnumValue("UDDIRegistry")
    UDDI_REGISTRY("UDDIRegistry"),
    @XmlEnumValue("URLMap")
    URL_MAP("URLMap"),
    @XmlEnumValue("URLRefreshPolicy")
    URL_REFRESH_POLICY("URLRefreshPolicy"),
    @XmlEnumValue("URLRewritePolicy")
    URL_REWRITE_POLICY("URLRewritePolicy"),
    @XmlEnumValue("User")
    USER("User"),
    @XmlEnumValue("UserGroup")
    USER_GROUP("UserGroup"),
    @XmlEnumValue("WCCService")
    WCC_SERVICE("WCCService"),
    @XmlEnumValue("WebAppErrorHandlingPolicy")
    WEB_APP_ERROR_HANDLING_POLICY("WebAppErrorHandlingPolicy"),
    @XmlEnumValue("WebAppFW")
    WEB_APP_FW("WebAppFW"),
    @XmlEnumValue("WebAppRequest")
    WEB_APP_REQUEST("WebAppRequest"),
    @XmlEnumValue("WebAppResponse")
    WEB_APP_RESPONSE("WebAppResponse"),
    @XmlEnumValue("WebAppSessionPolicy")
    WEB_APP_SESSION_POLICY("WebAppSessionPolicy"),
    @XmlEnumValue("WebServiceMonitor")
    WEB_SERVICE_MONITOR("WebServiceMonitor"),
    @XmlEnumValue("WebServicesAgent")
    WEB_SERVICES_AGENT("WebServicesAgent"),
    @XmlEnumValue("UDDISubscription")
    UDDI_SUBSCRIPTION("UDDISubscription"),
    @XmlEnumValue("WSRRSavedSearchSubscription")
    WSRR_SAVED_SEARCH_SUBSCRIPTION("WSRRSavedSearchSubscription"),
    @XmlEnumValue("WSRRSubscription")
    WSRR_SUBSCRIPTION("WSRRSubscription"),
    @XmlEnumValue("WebTokenService")
    WEB_TOKEN_SERVICE("WebTokenService"),
    @XmlEnumValue("WSEndpointRewritePolicy")
    WS_ENDPOINT_REWRITE_POLICY("WSEndpointRewritePolicy"),
    @XmlEnumValue("WSRRServer")
    WSRR_SERVER("WSRRServer"),
    @XmlEnumValue("WSStylePolicy")
    WS_STYLE_POLICY("WSStylePolicy"),
    @XmlEnumValue("XMLManager")
    XML_MANAGER("XMLManager"),
    @XmlEnumValue("xmltrace")
    XMLTRACE("xmltrace"),
    @XmlEnumValue("ZHybridTargetControlService")
    Z_HYBRID_TARGET_CONTROL_SERVICE("ZHybridTargetControlService"),
    @XmlEnumValue("ZosNSSClient")
    ZOS_NSS_CLIENT("ZosNSSClient");
    private final String value;

    ConfigEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ConfigEnum fromValue(String v) {
        for (ConfigEnum c: ConfigEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
