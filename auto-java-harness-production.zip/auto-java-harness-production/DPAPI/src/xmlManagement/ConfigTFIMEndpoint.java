
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigTFIMEndpoint complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigTFIMEndpoint"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigAccessControl"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mEndpointType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEndpointType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mServerURL"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mServerPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mCompatibleMode"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTFIMMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mReqToken60Format" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTFIMReq60Format {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mReqToken61Format" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTFIMReq61Format {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mReqToken62Format" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTFIMReq62Format {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mReqCustomURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mAppliesToAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mIssuer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mPortType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mOperation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mSSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="mSchemaValidate" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mLTPAValueTypeMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLTPAValueTypeMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mSTSUsername" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mSTSPassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mSTSPasswordAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="mSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="mSSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigTFIMEndpoint", propOrder = {
    "userSummary",
    "mEndpointType",
    "mServerURL",
    "mServerPort",
    "mCompatibleMode",
    "mReqToken60Format",
    "mReqToken61Format",
    "mReqToken62Format",
    "mReqCustomURL",
    "mAppliesToAddress",
    "mIssuer",
    "mPortType",
    "mOperation",
    "msslProxy",
    "mSchemaValidate",
    "mltpaValueTypeMode",
    "mstsUsername",
    "mstsPassword",
    "mstsPasswordAlias",
    "msslClientConfigType",
    "msslClient"
})
public class ConfigTFIMEndpoint
    extends ConfigAccessControl
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    protected String mEndpointType;
    protected String mServerURL;
    protected String mServerPort;
    protected String mCompatibleMode;
    protected String mReqToken60Format;
    protected String mReqToken61Format;
    protected String mReqToken62Format;
    protected String mReqCustomURL;
    protected String mAppliesToAddress;
    protected String mIssuer;
    protected String mPortType;
    protected String mOperation;
    @XmlElement(name = "mSSLProxy")
    protected DmReference msslProxy;
    protected String mSchemaValidate;
    @XmlElement(name = "mLTPAValueTypeMode")
    protected String mltpaValueTypeMode;
    @XmlElement(name = "mSTSUsername")
    protected String mstsUsername;
    @XmlElement(name = "mSTSPassword")
    protected String mstsPassword;
    @XmlElement(name = "mSTSPasswordAlias")
    protected DmReference mstsPasswordAlias;
    @XmlElement(name = "mSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType msslClientConfigType;
    @XmlElement(name = "mSSLClient")
    protected DmReference msslClient;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the mEndpointType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMEndpointType() {
        return mEndpointType;
    }

    /**
     * Sets the value of the mEndpointType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMEndpointType(String value) {
        this.mEndpointType = value;
    }

    /**
     * Gets the value of the mServerURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMServerURL() {
        return mServerURL;
    }

    /**
     * Sets the value of the mServerURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMServerURL(String value) {
        this.mServerURL = value;
    }

    /**
     * Gets the value of the mServerPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMServerPort() {
        return mServerPort;
    }

    /**
     * Sets the value of the mServerPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMServerPort(String value) {
        this.mServerPort = value;
    }

    /**
     * Gets the value of the mCompatibleMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCompatibleMode() {
        return mCompatibleMode;
    }

    /**
     * Sets the value of the mCompatibleMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCompatibleMode(String value) {
        this.mCompatibleMode = value;
    }

    /**
     * Gets the value of the mReqToken60Format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMReqToken60Format() {
        return mReqToken60Format;
    }

    /**
     * Sets the value of the mReqToken60Format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMReqToken60Format(String value) {
        this.mReqToken60Format = value;
    }

    /**
     * Gets the value of the mReqToken61Format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMReqToken61Format() {
        return mReqToken61Format;
    }

    /**
     * Sets the value of the mReqToken61Format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMReqToken61Format(String value) {
        this.mReqToken61Format = value;
    }

    /**
     * Gets the value of the mReqToken62Format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMReqToken62Format() {
        return mReqToken62Format;
    }

    /**
     * Sets the value of the mReqToken62Format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMReqToken62Format(String value) {
        this.mReqToken62Format = value;
    }

    /**
     * Gets the value of the mReqCustomURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMReqCustomURL() {
        return mReqCustomURL;
    }

    /**
     * Sets the value of the mReqCustomURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMReqCustomURL(String value) {
        this.mReqCustomURL = value;
    }

    /**
     * Gets the value of the mAppliesToAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMAppliesToAddress() {
        return mAppliesToAddress;
    }

    /**
     * Sets the value of the mAppliesToAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMAppliesToAddress(String value) {
        this.mAppliesToAddress = value;
    }

    /**
     * Gets the value of the mIssuer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIssuer() {
        return mIssuer;
    }

    /**
     * Sets the value of the mIssuer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIssuer(String value) {
        this.mIssuer = value;
    }

    /**
     * Gets the value of the mPortType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMPortType() {
        return mPortType;
    }

    /**
     * Sets the value of the mPortType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMPortType(String value) {
        this.mPortType = value;
    }

    /**
     * Gets the value of the mOperation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMOperation() {
        return mOperation;
    }

    /**
     * Sets the value of the mOperation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMOperation(String value) {
        this.mOperation = value;
    }

    /**
     * Gets the value of the msslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMSSLProxy() {
        return msslProxy;
    }

    /**
     * Sets the value of the msslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMSSLProxy(DmReference value) {
        this.msslProxy = value;
    }

    /**
     * Gets the value of the mSchemaValidate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSchemaValidate() {
        return mSchemaValidate;
    }

    /**
     * Sets the value of the mSchemaValidate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSchemaValidate(String value) {
        this.mSchemaValidate = value;
    }

    /**
     * Gets the value of the mltpaValueTypeMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMLTPAValueTypeMode() {
        return mltpaValueTypeMode;
    }

    /**
     * Sets the value of the mltpaValueTypeMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMLTPAValueTypeMode(String value) {
        this.mltpaValueTypeMode = value;
    }

    /**
     * Gets the value of the mstsUsername property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSTSUsername() {
        return mstsUsername;
    }

    /**
     * Sets the value of the mstsUsername property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSTSUsername(String value) {
        this.mstsUsername = value;
    }

    /**
     * Gets the value of the mstsPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSTSPassword() {
        return mstsPassword;
    }

    /**
     * Sets the value of the mstsPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSTSPassword(String value) {
        this.mstsPassword = value;
    }

    /**
     * Gets the value of the mstsPasswordAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMSTSPasswordAlias() {
        return mstsPasswordAlias;
    }

    /**
     * Sets the value of the mstsPasswordAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMSTSPasswordAlias(DmReference value) {
        this.mstsPasswordAlias = value;
    }

    /**
     * Gets the value of the msslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getMSSLClientConfigType() {
        return msslClientConfigType;
    }

    /**
     * Sets the value of the msslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setMSSLClientConfigType(DmSSLClientConfigType value) {
        this.msslClientConfigType = value;
    }

    /**
     * Gets the value of the msslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMSSLClient() {
        return msslClient;
    }

    /**
     * Sets the value of the msslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMSSLClient(DmReference value) {
        this.msslClient = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
