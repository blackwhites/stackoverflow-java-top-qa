
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSSLServerProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSSLServerProfile"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigCrypto"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Protocols" type="{http://www.datapower.com/schemas/management}dmSSLProtoVersionsBitmap" minOccurs="0"/&gt;
 *         &lt;element name="Ciphers" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSSLCipherSuite {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Idcred" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="RequestClientAuth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequireClientAuth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ValidateClientCert" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SendClientAuthCAList" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Valcred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Caching" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CacheTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLOptions" type="{http://www.datapower.com/schemas/management}dmSSLOptions" minOccurs="0"/&gt;
 *         &lt;element name="MaxSSLDuration" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumberOfRenegotiationAllowed" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProhibitResumeOnReneg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Compression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowLegacyRenegotiation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PreferServerCiphers" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EllipticCurves" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTLSEllipticCurves {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSSLServerProfile", propOrder = {
    "userSummary",
    "protocols",
    "ciphers",
    "idcred",
    "requestClientAuth",
    "requireClientAuth",
    "validateClientCert",
    "sendClientAuthCAList",
    "valcred",
    "caching",
    "cacheTimeout",
    "cacheSize",
    "sslOptions",
    "maxSSLDuration",
    "numberOfRenegotiationAllowed",
    "prohibitResumeOnReneg",
    "compression",
    "allowLegacyRenegotiation",
    "preferServerCiphers",
    "ellipticCurves"
})
public class ConfigSSLServerProfile
    extends ConfigCrypto
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Protocols")
    protected DmSSLProtoVersionsBitmap protocols;
    @XmlElement(name = "Ciphers")
    protected List<String> ciphers;
    @XmlElement(name = "Idcred")
    protected DmReference idcred;
    @XmlElement(name = "RequestClientAuth")
    protected String requestClientAuth;
    @XmlElement(name = "RequireClientAuth")
    protected String requireClientAuth;
    @XmlElement(name = "ValidateClientCert")
    protected String validateClientCert;
    @XmlElement(name = "SendClientAuthCAList")
    protected String sendClientAuthCAList;
    @XmlElement(name = "Valcred")
    protected DmReference valcred;
    @XmlElement(name = "Caching")
    protected String caching;
    @XmlElement(name = "CacheTimeout")
    protected String cacheTimeout;
    @XmlElement(name = "CacheSize")
    protected String cacheSize;
    @XmlElement(name = "SSLOptions")
    protected DmSSLOptions sslOptions;
    @XmlElement(name = "MaxSSLDuration")
    protected String maxSSLDuration;
    @XmlElement(name = "NumberOfRenegotiationAllowed")
    protected String numberOfRenegotiationAllowed;
    @XmlElement(name = "ProhibitResumeOnReneg")
    protected String prohibitResumeOnReneg;
    @XmlElement(name = "Compression")
    protected String compression;
    @XmlElement(name = "AllowLegacyRenegotiation")
    protected String allowLegacyRenegotiation;
    @XmlElement(name = "PreferServerCiphers")
    protected String preferServerCiphers;
    @XmlElement(name = "EllipticCurves")
    protected List<String> ellipticCurves;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the protocols property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLProtoVersionsBitmap }
     *     
     */
    public DmSSLProtoVersionsBitmap getProtocols() {
        return protocols;
    }

    /**
     * Sets the value of the protocols property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLProtoVersionsBitmap }
     *     
     */
    public void setProtocols(DmSSLProtoVersionsBitmap value) {
        this.protocols = value;
    }

    /**
     * Gets the value of the ciphers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ciphers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCiphers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCiphers() {
        if (ciphers == null) {
            ciphers = new ArrayList<String>();
        }
        return this.ciphers;
    }

    /**
     * Gets the value of the idcred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getIdcred() {
        return idcred;
    }

    /**
     * Sets the value of the idcred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setIdcred(DmReference value) {
        this.idcred = value;
    }

    /**
     * Gets the value of the requestClientAuth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestClientAuth() {
        return requestClientAuth;
    }

    /**
     * Sets the value of the requestClientAuth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestClientAuth(String value) {
        this.requestClientAuth = value;
    }

    /**
     * Gets the value of the requireClientAuth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequireClientAuth() {
        return requireClientAuth;
    }

    /**
     * Sets the value of the requireClientAuth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequireClientAuth(String value) {
        this.requireClientAuth = value;
    }

    /**
     * Gets the value of the validateClientCert property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidateClientCert() {
        return validateClientCert;
    }

    /**
     * Sets the value of the validateClientCert property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidateClientCert(String value) {
        this.validateClientCert = value;
    }

    /**
     * Gets the value of the sendClientAuthCAList property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendClientAuthCAList() {
        return sendClientAuthCAList;
    }

    /**
     * Sets the value of the sendClientAuthCAList property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendClientAuthCAList(String value) {
        this.sendClientAuthCAList = value;
    }

    /**
     * Gets the value of the valcred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getValcred() {
        return valcred;
    }

    /**
     * Sets the value of the valcred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setValcred(DmReference value) {
        this.valcred = value;
    }

    /**
     * Gets the value of the caching property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaching() {
        return caching;
    }

    /**
     * Sets the value of the caching property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaching(String value) {
        this.caching = value;
    }

    /**
     * Gets the value of the cacheTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheTimeout() {
        return cacheTimeout;
    }

    /**
     * Sets the value of the cacheTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheTimeout(String value) {
        this.cacheTimeout = value;
    }

    /**
     * Gets the value of the cacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheSize() {
        return cacheSize;
    }

    /**
     * Sets the value of the cacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheSize(String value) {
        this.cacheSize = value;
    }

    /**
     * Gets the value of the sslOptions property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLOptions }
     *     
     */
    public DmSSLOptions getSSLOptions() {
        return sslOptions;
    }

    /**
     * Sets the value of the sslOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLOptions }
     *     
     */
    public void setSSLOptions(DmSSLOptions value) {
        this.sslOptions = value;
    }

    /**
     * Gets the value of the maxSSLDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxSSLDuration() {
        return maxSSLDuration;
    }

    /**
     * Sets the value of the maxSSLDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxSSLDuration(String value) {
        this.maxSSLDuration = value;
    }

    /**
     * Gets the value of the numberOfRenegotiationAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumberOfRenegotiationAllowed() {
        return numberOfRenegotiationAllowed;
    }

    /**
     * Sets the value of the numberOfRenegotiationAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumberOfRenegotiationAllowed(String value) {
        this.numberOfRenegotiationAllowed = value;
    }

    /**
     * Gets the value of the prohibitResumeOnReneg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProhibitResumeOnReneg() {
        return prohibitResumeOnReneg;
    }

    /**
     * Sets the value of the prohibitResumeOnReneg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProhibitResumeOnReneg(String value) {
        this.prohibitResumeOnReneg = value;
    }

    /**
     * Gets the value of the compression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompression() {
        return compression;
    }

    /**
     * Sets the value of the compression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompression(String value) {
        this.compression = value;
    }

    /**
     * Gets the value of the allowLegacyRenegotiation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowLegacyRenegotiation() {
        return allowLegacyRenegotiation;
    }

    /**
     * Sets the value of the allowLegacyRenegotiation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowLegacyRenegotiation(String value) {
        this.allowLegacyRenegotiation = value;
    }

    /**
     * Gets the value of the preferServerCiphers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferServerCiphers() {
        return preferServerCiphers;
    }

    /**
     * Sets the value of the preferServerCiphers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferServerCiphers(String value) {
        this.preferServerCiphers = value;
    }

    /**
     * Gets the value of the ellipticCurves property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ellipticCurves property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEllipticCurves().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEllipticCurves() {
        if (ellipticCurves == null) {
            ellipticCurves = new ArrayList<String>();
        }
        return this.ellipticCurves;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
