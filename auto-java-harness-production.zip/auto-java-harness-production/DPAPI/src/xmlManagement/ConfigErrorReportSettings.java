
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigErrorReportSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigErrorReportSettings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigDeviceSettings"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UploadReport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseSmtp" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InternalState" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FFDCPacketCapture" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FFDCEventLogCapture" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FFDCMemoryLeakCapture" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AlwaysOnStartup" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AlwaysOnShutdown" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Protocol" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmErrorReportDestinationProtocol {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocationIdentifier" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SmtpServer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EmailAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EmailSenderAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FTPServer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FTPPath" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FTPUserAgent" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="NFSMount" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="NFSPath" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RaidVolume" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="RaidPath" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IScsiVolume" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="IScsiPath" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ReportHistoryKept" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigErrorReportSettings", propOrder = {
    "userSummary",
    "uploadReport",
    "useSmtp",
    "internalState",
    "ffdcPacketCapture",
    "ffdcEventLogCapture",
    "ffdcMemoryLeakCapture",
    "alwaysOnStartup",
    "alwaysOnShutdown",
    "protocol",
    "locationIdentifier",
    "smtpServer",
    "emailAddress",
    "emailSenderAddress",
    "ftpServer",
    "ftpPath",
    "ftpUserAgent",
    "nfsMount",
    "nfsPath",
    "raidVolume",
    "raidPath",
    "iScsiVolume",
    "iScsiPath",
    "reportHistoryKept"
})
public class ConfigErrorReportSettings
    extends ConfigDeviceSettings
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "UploadReport")
    protected String uploadReport;
    @XmlElement(name = "UseSmtp")
    protected String useSmtp;
    @XmlElement(name = "InternalState")
    protected String internalState;
    @XmlElement(name = "FFDCPacketCapture")
    protected String ffdcPacketCapture;
    @XmlElement(name = "FFDCEventLogCapture")
    protected String ffdcEventLogCapture;
    @XmlElement(name = "FFDCMemoryLeakCapture")
    protected String ffdcMemoryLeakCapture;
    @XmlElement(name = "AlwaysOnStartup")
    protected String alwaysOnStartup;
    @XmlElement(name = "AlwaysOnShutdown")
    protected String alwaysOnShutdown;
    @XmlElement(name = "Protocol")
    protected String protocol;
    @XmlElement(name = "LocationIdentifier")
    protected String locationIdentifier;
    @XmlElement(name = "SmtpServer")
    protected String smtpServer;
    @XmlElement(name = "EmailAddress")
    protected String emailAddress;
    @XmlElement(name = "EmailSenderAddress")
    protected String emailSenderAddress;
    @XmlElement(name = "FTPServer")
    protected String ftpServer;
    @XmlElement(name = "FTPPath")
    protected String ftpPath;
    @XmlElement(name = "FTPUserAgent")
    protected DmReference ftpUserAgent;
    @XmlElement(name = "NFSMount")
    protected DmReference nfsMount;
    @XmlElement(name = "NFSPath")
    protected String nfsPath;
    @XmlElement(name = "RaidVolume")
    protected DmReference raidVolume;
    @XmlElement(name = "RaidPath")
    protected String raidPath;
    @XmlElement(name = "IScsiVolume")
    protected DmReference iScsiVolume;
    @XmlElement(name = "IScsiPath")
    protected String iScsiPath;
    @XmlElement(name = "ReportHistoryKept")
    protected String reportHistoryKept;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the uploadReport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUploadReport() {
        return uploadReport;
    }

    /**
     * Sets the value of the uploadReport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUploadReport(String value) {
        this.uploadReport = value;
    }

    /**
     * Gets the value of the useSmtp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseSmtp() {
        return useSmtp;
    }

    /**
     * Sets the value of the useSmtp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseSmtp(String value) {
        this.useSmtp = value;
    }

    /**
     * Gets the value of the internalState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalState() {
        return internalState;
    }

    /**
     * Sets the value of the internalState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalState(String value) {
        this.internalState = value;
    }

    /**
     * Gets the value of the ffdcPacketCapture property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFFDCPacketCapture() {
        return ffdcPacketCapture;
    }

    /**
     * Sets the value of the ffdcPacketCapture property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFFDCPacketCapture(String value) {
        this.ffdcPacketCapture = value;
    }

    /**
     * Gets the value of the ffdcEventLogCapture property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFFDCEventLogCapture() {
        return ffdcEventLogCapture;
    }

    /**
     * Sets the value of the ffdcEventLogCapture property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFFDCEventLogCapture(String value) {
        this.ffdcEventLogCapture = value;
    }

    /**
     * Gets the value of the ffdcMemoryLeakCapture property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFFDCMemoryLeakCapture() {
        return ffdcMemoryLeakCapture;
    }

    /**
     * Sets the value of the ffdcMemoryLeakCapture property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFFDCMemoryLeakCapture(String value) {
        this.ffdcMemoryLeakCapture = value;
    }

    /**
     * Gets the value of the alwaysOnStartup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlwaysOnStartup() {
        return alwaysOnStartup;
    }

    /**
     * Sets the value of the alwaysOnStartup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlwaysOnStartup(String value) {
        this.alwaysOnStartup = value;
    }

    /**
     * Gets the value of the alwaysOnShutdown property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlwaysOnShutdown() {
        return alwaysOnShutdown;
    }

    /**
     * Sets the value of the alwaysOnShutdown property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlwaysOnShutdown(String value) {
        this.alwaysOnShutdown = value;
    }

    /**
     * Gets the value of the protocol property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProtocol() {
        return protocol;
    }

    /**
     * Sets the value of the protocol property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProtocol(String value) {
        this.protocol = value;
    }

    /**
     * Gets the value of the locationIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationIdentifier() {
        return locationIdentifier;
    }

    /**
     * Sets the value of the locationIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationIdentifier(String value) {
        this.locationIdentifier = value;
    }

    /**
     * Gets the value of the smtpServer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSmtpServer() {
        return smtpServer;
    }

    /**
     * Sets the value of the smtpServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSmtpServer(String value) {
        this.smtpServer = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the emailSenderAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailSenderAddress() {
        return emailSenderAddress;
    }

    /**
     * Sets the value of the emailSenderAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailSenderAddress(String value) {
        this.emailSenderAddress = value;
    }

    /**
     * Gets the value of the ftpServer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFTPServer() {
        return ftpServer;
    }

    /**
     * Sets the value of the ftpServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFTPServer(String value) {
        this.ftpServer = value;
    }

    /**
     * Gets the value of the ftpPath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFTPPath() {
        return ftpPath;
    }

    /**
     * Sets the value of the ftpPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFTPPath(String value) {
        this.ftpPath = value;
    }

    /**
     * Gets the value of the ftpUserAgent property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getFTPUserAgent() {
        return ftpUserAgent;
    }

    /**
     * Sets the value of the ftpUserAgent property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setFTPUserAgent(DmReference value) {
        this.ftpUserAgent = value;
    }

    /**
     * Gets the value of the nfsMount property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getNFSMount() {
        return nfsMount;
    }

    /**
     * Sets the value of the nfsMount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setNFSMount(DmReference value) {
        this.nfsMount = value;
    }

    /**
     * Gets the value of the nfsPath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNFSPath() {
        return nfsPath;
    }

    /**
     * Sets the value of the nfsPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNFSPath(String value) {
        this.nfsPath = value;
    }

    /**
     * Gets the value of the raidVolume property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getRaidVolume() {
        return raidVolume;
    }

    /**
     * Sets the value of the raidVolume property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setRaidVolume(DmReference value) {
        this.raidVolume = value;
    }

    /**
     * Gets the value of the raidPath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRaidPath() {
        return raidPath;
    }

    /**
     * Sets the value of the raidPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRaidPath(String value) {
        this.raidPath = value;
    }

    /**
     * Gets the value of the iScsiVolume property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getIScsiVolume() {
        return iScsiVolume;
    }

    /**
     * Sets the value of the iScsiVolume property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setIScsiVolume(DmReference value) {
        this.iScsiVolume = value;
    }

    /**
     * Gets the value of the iScsiPath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIScsiPath() {
        return iScsiPath;
    }

    /**
     * Sets the value of the iScsiPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIScsiPath(String value) {
        this.iScsiPath = value;
    }

    /**
     * Gets the value of the reportHistoryKept property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReportHistoryKept() {
        return reportHistoryKept;
    }

    /**
     * Sets the value of the reportHistoryKept property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReportHistoryKept(String value) {
        this.reportHistoryKept = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
