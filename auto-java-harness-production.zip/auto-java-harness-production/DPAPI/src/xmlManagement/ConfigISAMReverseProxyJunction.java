
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigISAMReverseProxyJunction complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigISAMReverseProxyJunction"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionPointName"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyJunctionType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TransparentPathJunction" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StatefulJunction" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DSCEnvironment" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VirtualHostLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VirtualHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VirtualHostPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionTypeStandard" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyJunctionTypeStandard {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionTypeVirtual" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyJunctionTypeVirtual {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TargetBackendServersStandard" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyBackendServersStandard" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TargetBackendServersStandardProxy" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyBackendServersStandardProxy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TargetBackendServersStandardMutual" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyBackendServersStandardMutual" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TargetBackendServersVirtual" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyBackendServersVirtual" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TargetBackendServersVirtualProxy" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyBackendServersVirtualProxy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BasicAuth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasicAuthUser" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasicAuthPass" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasicAuthPassAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MutualAuth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MutualAuthKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MutualAuthKeyLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BasicAuthHeader" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyBasicAuthHeader {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="GSOResource" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HeaderIdentityInfo" type="{http://www.datapower.com/schemas/management}dmISAMReverseProxyHeaderIdentityInfo" minOccurs="0"/&gt;
 *         &lt;element name="HeaderEncoding" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyHeaderEncoding {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JunctionCookieJSBlock" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmISAMReverseProxyJunctionCookieJSBlock {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UniqueCookieNames" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PreserveJuncName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IncludeSessionCookie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IncludeJuncName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InsertClientIP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TFIMSSO" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPACookie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAV2Cookie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAKeyFilePw" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LTPAKeyFilePwAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="FSSOConfigFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PercentHardLimitWT" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PercentSoftLimitWT" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IncludeAuthRules" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigISAMReverseProxyJunction", propOrder = {
    "userSummary",
    "junctionPointName",
    "junctionType",
    "transparentPathJunction",
    "statefulJunction",
    "dscEnvironment",
    "virtualHostLabel",
    "virtualHost",
    "virtualHostPort",
    "junctionTypeStandard",
    "junctionTypeVirtual",
    "targetBackendServersStandard",
    "targetBackendServersStandardProxy",
    "targetBackendServersStandardMutual",
    "targetBackendServersVirtual",
    "targetBackendServersVirtualProxy",
    "basicAuth",
    "basicAuthUser",
    "basicAuthPass",
    "basicAuthPassAlias",
    "mutualAuth",
    "mutualAuthKeyFile",
    "mutualAuthKeyLabel",
    "basicAuthHeader",
    "gsoResource",
    "headerIdentityInfo",
    "headerEncoding",
    "junctionCookieJSBlock",
    "uniqueCookieNames",
    "preserveJuncName",
    "includeSessionCookie",
    "includeJuncName",
    "insertClientIP",
    "tfimsso",
    "ltpaCookie",
    "ltpav2Cookie",
    "ltpaKeyFile",
    "ltpaKeyFilePw",
    "ltpaKeyFilePwAlias",
    "fssoConfigFile",
    "percentHardLimitWT",
    "percentSoftLimitWT",
    "includeAuthRules"
})
public class ConfigISAMReverseProxyJunction
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "JunctionPointName")
    protected String junctionPointName;
    @XmlElement(name = "JunctionType")
    protected String junctionType;
    @XmlElement(name = "TransparentPathJunction")
    protected String transparentPathJunction;
    @XmlElement(name = "StatefulJunction")
    protected String statefulJunction;
    @XmlElement(name = "DSCEnvironment")
    protected String dscEnvironment;
    @XmlElement(name = "VirtualHostLabel")
    protected String virtualHostLabel;
    @XmlElement(name = "VirtualHost")
    protected String virtualHost;
    @XmlElement(name = "VirtualHostPort")
    protected String virtualHostPort;
    @XmlElement(name = "JunctionTypeStandard")
    protected String junctionTypeStandard;
    @XmlElement(name = "JunctionTypeVirtual")
    protected String junctionTypeVirtual;
    @XmlElement(name = "TargetBackendServersStandard")
    protected List<DmISAMReverseProxyBackendServersStandard> targetBackendServersStandard;
    @XmlElement(name = "TargetBackendServersStandardProxy")
    protected List<DmISAMReverseProxyBackendServersStandardProxy> targetBackendServersStandardProxy;
    @XmlElement(name = "TargetBackendServersStandardMutual")
    protected List<DmISAMReverseProxyBackendServersStandardMutual> targetBackendServersStandardMutual;
    @XmlElement(name = "TargetBackendServersVirtual")
    protected List<DmISAMReverseProxyBackendServersVirtual> targetBackendServersVirtual;
    @XmlElement(name = "TargetBackendServersVirtualProxy")
    protected List<DmISAMReverseProxyBackendServersVirtualProxy> targetBackendServersVirtualProxy;
    @XmlElement(name = "BasicAuth")
    protected String basicAuth;
    @XmlElement(name = "BasicAuthUser")
    protected String basicAuthUser;
    @XmlElement(name = "BasicAuthPass")
    protected String basicAuthPass;
    @XmlElement(name = "BasicAuthPassAlias")
    protected DmReference basicAuthPassAlias;
    @XmlElement(name = "MutualAuth")
    protected String mutualAuth;
    @XmlElement(name = "MutualAuthKeyFile")
    protected String mutualAuthKeyFile;
    @XmlElement(name = "MutualAuthKeyLabel")
    protected String mutualAuthKeyLabel;
    @XmlElement(name = "BasicAuthHeader")
    protected String basicAuthHeader;
    @XmlElement(name = "GSOResource")
    protected String gsoResource;
    @XmlElement(name = "HeaderIdentityInfo")
    protected DmISAMReverseProxyHeaderIdentityInfo headerIdentityInfo;
    @XmlElement(name = "HeaderEncoding")
    protected String headerEncoding;
    @XmlElement(name = "JunctionCookieJSBlock")
    protected String junctionCookieJSBlock;
    @XmlElement(name = "UniqueCookieNames")
    protected String uniqueCookieNames;
    @XmlElement(name = "PreserveJuncName")
    protected String preserveJuncName;
    @XmlElement(name = "IncludeSessionCookie")
    protected String includeSessionCookie;
    @XmlElement(name = "IncludeJuncName")
    protected String includeJuncName;
    @XmlElement(name = "InsertClientIP")
    protected String insertClientIP;
    @XmlElement(name = "TFIMSSO")
    protected String tfimsso;
    @XmlElement(name = "LTPACookie")
    protected String ltpaCookie;
    @XmlElement(name = "LTPAV2Cookie")
    protected String ltpav2Cookie;
    @XmlElement(name = "LTPAKeyFile")
    protected String ltpaKeyFile;
    @XmlElement(name = "LTPAKeyFilePw")
    protected String ltpaKeyFilePw;
    @XmlElement(name = "LTPAKeyFilePwAlias")
    protected DmReference ltpaKeyFilePwAlias;
    @XmlElement(name = "FSSOConfigFile")
    protected String fssoConfigFile;
    @XmlElement(name = "PercentHardLimitWT")
    protected String percentHardLimitWT;
    @XmlElement(name = "PercentSoftLimitWT")
    protected String percentSoftLimitWT;
    @XmlElement(name = "IncludeAuthRules")
    protected String includeAuthRules;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the junctionPointName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionPointName() {
        return junctionPointName;
    }

    /**
     * Sets the value of the junctionPointName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionPointName(String value) {
        this.junctionPointName = value;
    }

    /**
     * Gets the value of the junctionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionType() {
        return junctionType;
    }

    /**
     * Sets the value of the junctionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionType(String value) {
        this.junctionType = value;
    }

    /**
     * Gets the value of the transparentPathJunction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransparentPathJunction() {
        return transparentPathJunction;
    }

    /**
     * Sets the value of the transparentPathJunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransparentPathJunction(String value) {
        this.transparentPathJunction = value;
    }

    /**
     * Gets the value of the statefulJunction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatefulJunction() {
        return statefulJunction;
    }

    /**
     * Sets the value of the statefulJunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatefulJunction(String value) {
        this.statefulJunction = value;
    }

    /**
     * Gets the value of the dscEnvironment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDSCEnvironment() {
        return dscEnvironment;
    }

    /**
     * Sets the value of the dscEnvironment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDSCEnvironment(String value) {
        this.dscEnvironment = value;
    }

    /**
     * Gets the value of the virtualHostLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVirtualHostLabel() {
        return virtualHostLabel;
    }

    /**
     * Sets the value of the virtualHostLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVirtualHostLabel(String value) {
        this.virtualHostLabel = value;
    }

    /**
     * Gets the value of the virtualHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVirtualHost() {
        return virtualHost;
    }

    /**
     * Sets the value of the virtualHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVirtualHost(String value) {
        this.virtualHost = value;
    }

    /**
     * Gets the value of the virtualHostPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVirtualHostPort() {
        return virtualHostPort;
    }

    /**
     * Sets the value of the virtualHostPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVirtualHostPort(String value) {
        this.virtualHostPort = value;
    }

    /**
     * Gets the value of the junctionTypeStandard property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionTypeStandard() {
        return junctionTypeStandard;
    }

    /**
     * Sets the value of the junctionTypeStandard property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionTypeStandard(String value) {
        this.junctionTypeStandard = value;
    }

    /**
     * Gets the value of the junctionTypeVirtual property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionTypeVirtual() {
        return junctionTypeVirtual;
    }

    /**
     * Sets the value of the junctionTypeVirtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionTypeVirtual(String value) {
        this.junctionTypeVirtual = value;
    }

    /**
     * Gets the value of the targetBackendServersStandard property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the targetBackendServersStandard property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTargetBackendServersStandard().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyBackendServersStandard }
     * 
     * 
     */
    public List<DmISAMReverseProxyBackendServersStandard> getTargetBackendServersStandard() {
        if (targetBackendServersStandard == null) {
            targetBackendServersStandard = new ArrayList<DmISAMReverseProxyBackendServersStandard>();
        }
        return this.targetBackendServersStandard;
    }

    /**
     * Gets the value of the targetBackendServersStandardProxy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the targetBackendServersStandardProxy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTargetBackendServersStandardProxy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyBackendServersStandardProxy }
     * 
     * 
     */
    public List<DmISAMReverseProxyBackendServersStandardProxy> getTargetBackendServersStandardProxy() {
        if (targetBackendServersStandardProxy == null) {
            targetBackendServersStandardProxy = new ArrayList<DmISAMReverseProxyBackendServersStandardProxy>();
        }
        return this.targetBackendServersStandardProxy;
    }

    /**
     * Gets the value of the targetBackendServersStandardMutual property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the targetBackendServersStandardMutual property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTargetBackendServersStandardMutual().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyBackendServersStandardMutual }
     * 
     * 
     */
    public List<DmISAMReverseProxyBackendServersStandardMutual> getTargetBackendServersStandardMutual() {
        if (targetBackendServersStandardMutual == null) {
            targetBackendServersStandardMutual = new ArrayList<DmISAMReverseProxyBackendServersStandardMutual>();
        }
        return this.targetBackendServersStandardMutual;
    }

    /**
     * Gets the value of the targetBackendServersVirtual property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the targetBackendServersVirtual property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTargetBackendServersVirtual().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyBackendServersVirtual }
     * 
     * 
     */
    public List<DmISAMReverseProxyBackendServersVirtual> getTargetBackendServersVirtual() {
        if (targetBackendServersVirtual == null) {
            targetBackendServersVirtual = new ArrayList<DmISAMReverseProxyBackendServersVirtual>();
        }
        return this.targetBackendServersVirtual;
    }

    /**
     * Gets the value of the targetBackendServersVirtualProxy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the targetBackendServersVirtualProxy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTargetBackendServersVirtualProxy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmISAMReverseProxyBackendServersVirtualProxy }
     * 
     * 
     */
    public List<DmISAMReverseProxyBackendServersVirtualProxy> getTargetBackendServersVirtualProxy() {
        if (targetBackendServersVirtualProxy == null) {
            targetBackendServersVirtualProxy = new ArrayList<DmISAMReverseProxyBackendServersVirtualProxy>();
        }
        return this.targetBackendServersVirtualProxy;
    }

    /**
     * Gets the value of the basicAuth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicAuth() {
        return basicAuth;
    }

    /**
     * Sets the value of the basicAuth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicAuth(String value) {
        this.basicAuth = value;
    }

    /**
     * Gets the value of the basicAuthUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicAuthUser() {
        return basicAuthUser;
    }

    /**
     * Sets the value of the basicAuthUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicAuthUser(String value) {
        this.basicAuthUser = value;
    }

    /**
     * Gets the value of the basicAuthPass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicAuthPass() {
        return basicAuthPass;
    }

    /**
     * Sets the value of the basicAuthPass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicAuthPass(String value) {
        this.basicAuthPass = value;
    }

    /**
     * Gets the value of the basicAuthPassAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getBasicAuthPassAlias() {
        return basicAuthPassAlias;
    }

    /**
     * Sets the value of the basicAuthPassAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setBasicAuthPassAlias(DmReference value) {
        this.basicAuthPassAlias = value;
    }

    /**
     * Gets the value of the mutualAuth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMutualAuth() {
        return mutualAuth;
    }

    /**
     * Sets the value of the mutualAuth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMutualAuth(String value) {
        this.mutualAuth = value;
    }

    /**
     * Gets the value of the mutualAuthKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMutualAuthKeyFile() {
        return mutualAuthKeyFile;
    }

    /**
     * Sets the value of the mutualAuthKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMutualAuthKeyFile(String value) {
        this.mutualAuthKeyFile = value;
    }

    /**
     * Gets the value of the mutualAuthKeyLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMutualAuthKeyLabel() {
        return mutualAuthKeyLabel;
    }

    /**
     * Sets the value of the mutualAuthKeyLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMutualAuthKeyLabel(String value) {
        this.mutualAuthKeyLabel = value;
    }

    /**
     * Gets the value of the basicAuthHeader property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicAuthHeader() {
        return basicAuthHeader;
    }

    /**
     * Sets the value of the basicAuthHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicAuthHeader(String value) {
        this.basicAuthHeader = value;
    }

    /**
     * Gets the value of the gsoResource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGSOResource() {
        return gsoResource;
    }

    /**
     * Sets the value of the gsoResource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGSOResource(String value) {
        this.gsoResource = value;
    }

    /**
     * Gets the value of the headerIdentityInfo property.
     * 
     * @return
     *     possible object is
     *     {@link DmISAMReverseProxyHeaderIdentityInfo }
     *     
     */
    public DmISAMReverseProxyHeaderIdentityInfo getHeaderIdentityInfo() {
        return headerIdentityInfo;
    }

    /**
     * Sets the value of the headerIdentityInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmISAMReverseProxyHeaderIdentityInfo }
     *     
     */
    public void setHeaderIdentityInfo(DmISAMReverseProxyHeaderIdentityInfo value) {
        this.headerIdentityInfo = value;
    }

    /**
     * Gets the value of the headerEncoding property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeaderEncoding() {
        return headerEncoding;
    }

    /**
     * Sets the value of the headerEncoding property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeaderEncoding(String value) {
        this.headerEncoding = value;
    }

    /**
     * Gets the value of the junctionCookieJSBlock property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJunctionCookieJSBlock() {
        return junctionCookieJSBlock;
    }

    /**
     * Sets the value of the junctionCookieJSBlock property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJunctionCookieJSBlock(String value) {
        this.junctionCookieJSBlock = value;
    }

    /**
     * Gets the value of the uniqueCookieNames property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueCookieNames() {
        return uniqueCookieNames;
    }

    /**
     * Sets the value of the uniqueCookieNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueCookieNames(String value) {
        this.uniqueCookieNames = value;
    }

    /**
     * Gets the value of the preserveJuncName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreserveJuncName() {
        return preserveJuncName;
    }

    /**
     * Sets the value of the preserveJuncName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreserveJuncName(String value) {
        this.preserveJuncName = value;
    }

    /**
     * Gets the value of the includeSessionCookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncludeSessionCookie() {
        return includeSessionCookie;
    }

    /**
     * Sets the value of the includeSessionCookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncludeSessionCookie(String value) {
        this.includeSessionCookie = value;
    }

    /**
     * Gets the value of the includeJuncName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncludeJuncName() {
        return includeJuncName;
    }

    /**
     * Sets the value of the includeJuncName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncludeJuncName(String value) {
        this.includeJuncName = value;
    }

    /**
     * Gets the value of the insertClientIP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsertClientIP() {
        return insertClientIP;
    }

    /**
     * Sets the value of the insertClientIP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsertClientIP(String value) {
        this.insertClientIP = value;
    }

    /**
     * Gets the value of the tfimsso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTFIMSSO() {
        return tfimsso;
    }

    /**
     * Sets the value of the tfimsso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTFIMSSO(String value) {
        this.tfimsso = value;
    }

    /**
     * Gets the value of the ltpaCookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPACookie() {
        return ltpaCookie;
    }

    /**
     * Sets the value of the ltpaCookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPACookie(String value) {
        this.ltpaCookie = value;
    }

    /**
     * Gets the value of the ltpav2Cookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPAV2Cookie() {
        return ltpav2Cookie;
    }

    /**
     * Sets the value of the ltpav2Cookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPAV2Cookie(String value) {
        this.ltpav2Cookie = value;
    }

    /**
     * Gets the value of the ltpaKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPAKeyFile() {
        return ltpaKeyFile;
    }

    /**
     * Sets the value of the ltpaKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPAKeyFile(String value) {
        this.ltpaKeyFile = value;
    }

    /**
     * Gets the value of the ltpaKeyFilePw property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLTPAKeyFilePw() {
        return ltpaKeyFilePw;
    }

    /**
     * Sets the value of the ltpaKeyFilePw property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLTPAKeyFilePw(String value) {
        this.ltpaKeyFilePw = value;
    }

    /**
     * Gets the value of the ltpaKeyFilePwAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLTPAKeyFilePwAlias() {
        return ltpaKeyFilePwAlias;
    }

    /**
     * Sets the value of the ltpaKeyFilePwAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLTPAKeyFilePwAlias(DmReference value) {
        this.ltpaKeyFilePwAlias = value;
    }

    /**
     * Gets the value of the fssoConfigFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFSSOConfigFile() {
        return fssoConfigFile;
    }

    /**
     * Sets the value of the fssoConfigFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFSSOConfigFile(String value) {
        this.fssoConfigFile = value;
    }

    /**
     * Gets the value of the percentHardLimitWT property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPercentHardLimitWT() {
        return percentHardLimitWT;
    }

    /**
     * Sets the value of the percentHardLimitWT property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPercentHardLimitWT(String value) {
        this.percentHardLimitWT = value;
    }

    /**
     * Gets the value of the percentSoftLimitWT property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPercentSoftLimitWT() {
        return percentSoftLimitWT;
    }

    /**
     * Sets the value of the percentSoftLimitWT property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPercentSoftLimitWT(String value) {
        this.percentSoftLimitWT = value;
    }

    /**
     * Gets the value of the includeAuthRules property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncludeAuthRules() {
        return includeAuthRules;
    }

    /**
     * Sets the value of the includeAuthRules property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncludeAuthRules(String value) {
        this.includeAuthRules = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
