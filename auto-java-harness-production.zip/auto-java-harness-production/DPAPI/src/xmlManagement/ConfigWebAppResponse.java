
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigWebAppResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigWebAppResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PolicyType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSatisfactionPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OKCodes" type="{http://www.datapower.com/schemas/management}dmHTTPResponseCodes" minOccurs="0"/&gt;
 *         &lt;element name="OKVersions" type="{http://www.datapower.com/schemas/management}dmHTTPVersionMask" minOccurs="0"/&gt;
 *         &lt;element name="MinBodySize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxBodySize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HeaderGNVC" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ContentTypes" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWebAppXMLPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLRule" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="NonXMLPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWebAppNonXMLPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NonXMLRule" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ErrorPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigWebAppResponse", propOrder = {
    "userSummary",
    "policyType",
    "okCodes",
    "okVersions",
    "minBodySize",
    "maxBodySize",
    "headerGNVC",
    "contentTypes",
    "xmlPolicy",
    "xmlRule",
    "nonXMLPolicy",
    "nonXMLRule",
    "errorPolicy"
})
public class ConfigWebAppResponse
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "PolicyType")
    protected String policyType;
    @XmlElement(name = "OKCodes")
    protected DmHTTPResponseCodes okCodes;
    @XmlElement(name = "OKVersions")
    protected DmHTTPVersionMask okVersions;
    @XmlElement(name = "MinBodySize")
    protected String minBodySize;
    @XmlElement(name = "MaxBodySize")
    protected String maxBodySize;
    @XmlElement(name = "HeaderGNVC")
    protected DmReference headerGNVC;
    @XmlElement(name = "ContentTypes")
    protected List<String> contentTypes;
    @XmlElement(name = "XMLPolicy")
    protected String xmlPolicy;
    @XmlElement(name = "XMLRule")
    protected DmReference xmlRule;
    @XmlElement(name = "NonXMLPolicy")
    protected String nonXMLPolicy;
    @XmlElement(name = "NonXMLRule")
    protected DmReference nonXMLRule;
    @XmlElement(name = "ErrorPolicy")
    protected DmReference errorPolicy;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the policyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyType() {
        return policyType;
    }

    /**
     * Sets the value of the policyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyType(String value) {
        this.policyType = value;
    }

    /**
     * Gets the value of the okCodes property.
     * 
     * @return
     *     possible object is
     *     {@link DmHTTPResponseCodes }
     *     
     */
    public DmHTTPResponseCodes getOKCodes() {
        return okCodes;
    }

    /**
     * Sets the value of the okCodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmHTTPResponseCodes }
     *     
     */
    public void setOKCodes(DmHTTPResponseCodes value) {
        this.okCodes = value;
    }

    /**
     * Gets the value of the okVersions property.
     * 
     * @return
     *     possible object is
     *     {@link DmHTTPVersionMask }
     *     
     */
    public DmHTTPVersionMask getOKVersions() {
        return okVersions;
    }

    /**
     * Sets the value of the okVersions property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmHTTPVersionMask }
     *     
     */
    public void setOKVersions(DmHTTPVersionMask value) {
        this.okVersions = value;
    }

    /**
     * Gets the value of the minBodySize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinBodySize() {
        return minBodySize;
    }

    /**
     * Sets the value of the minBodySize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinBodySize(String value) {
        this.minBodySize = value;
    }

    /**
     * Gets the value of the maxBodySize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxBodySize() {
        return maxBodySize;
    }

    /**
     * Sets the value of the maxBodySize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxBodySize(String value) {
        this.maxBodySize = value;
    }

    /**
     * Gets the value of the headerGNVC property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getHeaderGNVC() {
        return headerGNVC;
    }

    /**
     * Sets the value of the headerGNVC property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setHeaderGNVC(DmReference value) {
        this.headerGNVC = value;
    }

    /**
     * Gets the value of the contentTypes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contentTypes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContentTypes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getContentTypes() {
        if (contentTypes == null) {
            contentTypes = new ArrayList<String>();
        }
        return this.contentTypes;
    }

    /**
     * Gets the value of the xmlPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXMLPolicy() {
        return xmlPolicy;
    }

    /**
     * Sets the value of the xmlPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXMLPolicy(String value) {
        this.xmlPolicy = value;
    }

    /**
     * Gets the value of the xmlRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLRule() {
        return xmlRule;
    }

    /**
     * Sets the value of the xmlRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLRule(DmReference value) {
        this.xmlRule = value;
    }

    /**
     * Gets the value of the nonXMLPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonXMLPolicy() {
        return nonXMLPolicy;
    }

    /**
     * Sets the value of the nonXMLPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonXMLPolicy(String value) {
        this.nonXMLPolicy = value;
    }

    /**
     * Gets the value of the nonXMLRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getNonXMLRule() {
        return nonXMLRule;
    }

    /**
     * Sets the value of the nonXMLRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setNonXMLRule(DmReference value) {
        this.nonXMLRule = value;
    }

    /**
     * Gets the value of the errorPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getErrorPolicy() {
        return errorPolicy;
    }

    /**
     * Sets the value of the errorPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setErrorPolicy(DmReference value) {
        this.errorPolicy = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
