
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigEventlog complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigEventlog"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Type"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSchedulerPriority {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SoapVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSoapVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Format" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TimestampFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogTimestampFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FixedFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalIdentifier" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EmailAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SenderAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SMTPDomain" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Size" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="URL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NFSMount" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LocalFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NFSFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogFileArchiveMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UploadMethod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogFileUploadMethod {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Rotate" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseANSIColor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemotePort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteLogin" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemotePassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteDirectory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLocalIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SyslogFacility" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSyslogFacility {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RateLimit" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ConnectTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IdleTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ActiveTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FeedbackDetection" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IdenticalEventSuppression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IdenticalEventPeriod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogEventCode" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEventCode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogEventFilter" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEventCode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogObjects" type="{http://www.datapower.com/schemas/management}dmLogObject" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LogIPFilter" type="{http://www.datapower.com/schemas/management}dmLogIPFilter" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LogTriggers" type="{http://www.datapower.com/schemas/management}dmLogTrigger" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SSLClientProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigEventlog", propOrder = {
    "userSummary",
    "type",
    "priority",
    "soapVersion",
    "format",
    "timestampFormat",
    "fixedFormat",
    "localIdentifier",
    "emailAddress",
    "senderAddress",
    "smtpDomain",
    "size",
    "url",
    "nfsMount",
    "sslProxyProfile",
    "localFile",
    "nfsFile",
    "archiveMode",
    "uploadMethod",
    "rotate",
    "useANSIColor",
    "remoteAddress",
    "remotePort",
    "remoteLogin",
    "remotePassword",
    "remoteDirectory",
    "localAddress",
    "syslogFacility",
    "rateLimit",
    "connectTimeout",
    "idleTimeout",
    "activeTimeout",
    "feedbackDetection",
    "identicalEventSuppression",
    "identicalEventPeriod",
    "logEventCode",
    "logEventFilter",
    "logObjects",
    "logIPFilter",
    "logTriggers",
    "sslClientProfile",
    "sslClientConfigType"
})
@XmlSeeAlso({
    ConfigLogTarget.class
})
public class ConfigEventlog
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "SoapVersion")
    protected String soapVersion;
    @XmlElement(name = "Format")
    protected String format;
    @XmlElement(name = "TimestampFormat")
    protected String timestampFormat;
    @XmlElement(name = "FixedFormat")
    protected String fixedFormat;
    @XmlElement(name = "LocalIdentifier")
    protected String localIdentifier;
    @XmlElement(name = "EmailAddress")
    protected String emailAddress;
    @XmlElement(name = "SenderAddress")
    protected String senderAddress;
    @XmlElement(name = "SMTPDomain")
    protected String smtpDomain;
    @XmlElement(name = "Size")
    protected String size;
    @XmlElement(name = "URL")
    protected String url;
    @XmlElement(name = "NFSMount")
    protected DmReference nfsMount;
    @XmlElement(name = "SSLProxyProfile")
    protected DmReference sslProxyProfile;
    @XmlElement(name = "LocalFile")
    protected String localFile;
    @XmlElement(name = "NFSFile")
    protected String nfsFile;
    @XmlElement(name = "ArchiveMode")
    protected String archiveMode;
    @XmlElement(name = "UploadMethod")
    protected String uploadMethod;
    @XmlElement(name = "Rotate")
    protected String rotate;
    @XmlElement(name = "UseANSIColor")
    protected String useANSIColor;
    @XmlElement(name = "RemoteAddress")
    protected String remoteAddress;
    @XmlElement(name = "RemotePort")
    protected String remotePort;
    @XmlElement(name = "RemoteLogin")
    protected String remoteLogin;
    @XmlElement(name = "RemotePassword")
    protected String remotePassword;
    @XmlElement(name = "RemoteDirectory")
    protected String remoteDirectory;
    @XmlElement(name = "LocalAddress")
    protected String localAddress;
    @XmlElement(name = "SyslogFacility")
    protected String syslogFacility;
    @XmlElement(name = "RateLimit")
    protected String rateLimit;
    @XmlElement(name = "ConnectTimeout")
    protected String connectTimeout;
    @XmlElement(name = "IdleTimeout")
    protected String idleTimeout;
    @XmlElement(name = "ActiveTimeout")
    protected String activeTimeout;
    @XmlElement(name = "FeedbackDetection")
    protected String feedbackDetection;
    @XmlElement(name = "IdenticalEventSuppression")
    protected String identicalEventSuppression;
    @XmlElement(name = "IdenticalEventPeriod")
    protected String identicalEventPeriod;
    @XmlElement(name = "LogEventCode")
    protected List<String> logEventCode;
    @XmlElement(name = "LogEventFilter")
    protected List<String> logEventFilter;
    @XmlElement(name = "LogObjects")
    protected List<DmLogObject> logObjects;
    @XmlElement(name = "LogIPFilter")
    protected List<DmLogIPFilter> logIPFilter;
    @XmlElement(name = "LogTriggers")
    protected List<DmLogTrigger> logTriggers;
    @XmlElement(name = "SSLClientProfile")
    protected DmReference sslClientProfile;
    @XmlElement(name = "SSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType sslClientConfigType;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the soapVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoapVersion() {
        return soapVersion;
    }

    /**
     * Sets the value of the soapVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoapVersion(String value) {
        this.soapVersion = value;
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets the value of the timestampFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimestampFormat() {
        return timestampFormat;
    }

    /**
     * Sets the value of the timestampFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestampFormat(String value) {
        this.timestampFormat = value;
    }

    /**
     * Gets the value of the fixedFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFixedFormat() {
        return fixedFormat;
    }

    /**
     * Sets the value of the fixedFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFixedFormat(String value) {
        this.fixedFormat = value;
    }

    /**
     * Gets the value of the localIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalIdentifier() {
        return localIdentifier;
    }

    /**
     * Sets the value of the localIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalIdentifier(String value) {
        this.localIdentifier = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the senderAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderAddress() {
        return senderAddress;
    }

    /**
     * Sets the value of the senderAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderAddress(String value) {
        this.senderAddress = value;
    }

    /**
     * Gets the value of the smtpDomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSMTPDomain() {
        return smtpDomain;
    }

    /**
     * Sets the value of the smtpDomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSMTPDomain(String value) {
        this.smtpDomain = value;
    }

    /**
     * Gets the value of the size property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSize() {
        return size;
    }

    /**
     * Sets the value of the size property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSize(String value) {
        this.size = value;
    }

    /**
     * Gets the value of the url property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURL() {
        return url;
    }

    /**
     * Sets the value of the url property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURL(String value) {
        this.url = value;
    }

    /**
     * Gets the value of the nfsMount property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getNFSMount() {
        return nfsMount;
    }

    /**
     * Sets the value of the nfsMount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setNFSMount(DmReference value) {
        this.nfsMount = value;
    }

    /**
     * Gets the value of the sslProxyProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxyProfile() {
        return sslProxyProfile;
    }

    /**
     * Sets the value of the sslProxyProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxyProfile(DmReference value) {
        this.sslProxyProfile = value;
    }

    /**
     * Gets the value of the localFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalFile() {
        return localFile;
    }

    /**
     * Sets the value of the localFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalFile(String value) {
        this.localFile = value;
    }

    /**
     * Gets the value of the nfsFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNFSFile() {
        return nfsFile;
    }

    /**
     * Sets the value of the nfsFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNFSFile(String value) {
        this.nfsFile = value;
    }

    /**
     * Gets the value of the archiveMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveMode() {
        return archiveMode;
    }

    /**
     * Sets the value of the archiveMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveMode(String value) {
        this.archiveMode = value;
    }

    /**
     * Gets the value of the uploadMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUploadMethod() {
        return uploadMethod;
    }

    /**
     * Sets the value of the uploadMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUploadMethod(String value) {
        this.uploadMethod = value;
    }

    /**
     * Gets the value of the rotate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRotate() {
        return rotate;
    }

    /**
     * Sets the value of the rotate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRotate(String value) {
        this.rotate = value;
    }

    /**
     * Gets the value of the useANSIColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseANSIColor() {
        return useANSIColor;
    }

    /**
     * Sets the value of the useANSIColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseANSIColor(String value) {
        this.useANSIColor = value;
    }

    /**
     * Gets the value of the remoteAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteAddress() {
        return remoteAddress;
    }

    /**
     * Sets the value of the remoteAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteAddress(String value) {
        this.remoteAddress = value;
    }

    /**
     * Gets the value of the remotePort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemotePort() {
        return remotePort;
    }

    /**
     * Sets the value of the remotePort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemotePort(String value) {
        this.remotePort = value;
    }

    /**
     * Gets the value of the remoteLogin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteLogin() {
        return remoteLogin;
    }

    /**
     * Sets the value of the remoteLogin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteLogin(String value) {
        this.remoteLogin = value;
    }

    /**
     * Gets the value of the remotePassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemotePassword() {
        return remotePassword;
    }

    /**
     * Sets the value of the remotePassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemotePassword(String value) {
        this.remotePassword = value;
    }

    /**
     * Gets the value of the remoteDirectory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteDirectory() {
        return remoteDirectory;
    }

    /**
     * Sets the value of the remoteDirectory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteDirectory(String value) {
        this.remoteDirectory = value;
    }

    /**
     * Gets the value of the localAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAddress() {
        return localAddress;
    }

    /**
     * Sets the value of the localAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAddress(String value) {
        this.localAddress = value;
    }

    /**
     * Gets the value of the syslogFacility property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSyslogFacility() {
        return syslogFacility;
    }

    /**
     * Sets the value of the syslogFacility property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSyslogFacility(String value) {
        this.syslogFacility = value;
    }

    /**
     * Gets the value of the rateLimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateLimit() {
        return rateLimit;
    }

    /**
     * Sets the value of the rateLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateLimit(String value) {
        this.rateLimit = value;
    }

    /**
     * Gets the value of the connectTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConnectTimeout() {
        return connectTimeout;
    }

    /**
     * Sets the value of the connectTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConnectTimeout(String value) {
        this.connectTimeout = value;
    }

    /**
     * Gets the value of the idleTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdleTimeout() {
        return idleTimeout;
    }

    /**
     * Sets the value of the idleTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdleTimeout(String value) {
        this.idleTimeout = value;
    }

    /**
     * Gets the value of the activeTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActiveTimeout() {
        return activeTimeout;
    }

    /**
     * Sets the value of the activeTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActiveTimeout(String value) {
        this.activeTimeout = value;
    }

    /**
     * Gets the value of the feedbackDetection property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeedbackDetection() {
        return feedbackDetection;
    }

    /**
     * Sets the value of the feedbackDetection property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeedbackDetection(String value) {
        this.feedbackDetection = value;
    }

    /**
     * Gets the value of the identicalEventSuppression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdenticalEventSuppression() {
        return identicalEventSuppression;
    }

    /**
     * Sets the value of the identicalEventSuppression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdenticalEventSuppression(String value) {
        this.identicalEventSuppression = value;
    }

    /**
     * Gets the value of the identicalEventPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdenticalEventPeriod() {
        return identicalEventPeriod;
    }

    /**
     * Sets the value of the identicalEventPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdenticalEventPeriod(String value) {
        this.identicalEventPeriod = value;
    }

    /**
     * Gets the value of the logEventCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logEventCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogEventCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLogEventCode() {
        if (logEventCode == null) {
            logEventCode = new ArrayList<String>();
        }
        return this.logEventCode;
    }

    /**
     * Gets the value of the logEventFilter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logEventFilter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogEventFilter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLogEventFilter() {
        if (logEventFilter == null) {
            logEventFilter = new ArrayList<String>();
        }
        return this.logEventFilter;
    }

    /**
     * Gets the value of the logObjects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logObjects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogObjects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmLogObject }
     * 
     * 
     */
    public List<DmLogObject> getLogObjects() {
        if (logObjects == null) {
            logObjects = new ArrayList<DmLogObject>();
        }
        return this.logObjects;
    }

    /**
     * Gets the value of the logIPFilter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logIPFilter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogIPFilter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmLogIPFilter }
     * 
     * 
     */
    public List<DmLogIPFilter> getLogIPFilter() {
        if (logIPFilter == null) {
            logIPFilter = new ArrayList<DmLogIPFilter>();
        }
        return this.logIPFilter;
    }

    /**
     * Gets the value of the logTriggers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logTriggers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogTriggers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmLogTrigger }
     * 
     * 
     */
    public List<DmLogTrigger> getLogTriggers() {
        if (logTriggers == null) {
            logTriggers = new ArrayList<DmLogTrigger>();
        }
        return this.logTriggers;
    }

    /**
     * Gets the value of the sslClientProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClientProfile() {
        return sslClientProfile;
    }

    /**
     * Sets the value of the sslClientProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClientProfile(DmReference value) {
        this.sslClientProfile = value;
    }

    /**
     * Gets the value of the sslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getSSLClientConfigType() {
        return sslClientConfigType;
    }

    /**
     * Sets the value of the sslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setSSLClientConfigType(DmSSLClientConfigType value) {
        this.sslClientConfigType = value;
    }

}
