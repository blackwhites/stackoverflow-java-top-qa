
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSourceProtocolHandler complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSourceProtocolHandler"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSourceProtocolHandler")
@XmlSeeAlso({
    ConfigAS2ProxySourceProtocolHandler.class,
    ConfigAS2SourceProtocolHandler.class,
    ConfigAS3SourceProtocolHandler.class,
    ConfigEBMS2SourceProtocolHandler.class,
    ConfigEBMS3SourceProtocolHandler.class,
    ConfigFilePollerSourceProtocolHandler.class,
    ConfigFTPDemonSourceProtocolHandler.class,
    ConfigHTTPSourceProtocolHandler.class,
    ConfigHTTPSSourceProtocolHandler.class,
    ConfigIMSCalloutSourceProtocolHandler.class,
    ConfigIMSConnectSourceProtocolHandler.class,
    ConfigJMSSourceProtocolHandler.class,
    ConfigMQFTESourceProtocolHandler.class,
    ConfigMQSourceProtocolHandler.class,
    ConfigPOPPollerSourceProtocolHandlerBase.class,
    ConfigSSHServerSourceProtocolHandler.class,
    ConfigStatelessTCPSourceProtocolHandler.class,
    ConfigXTCProtocolHandler.class
})
public class ConfigSourceProtocolHandler
    extends ConfigConfigBase
{


}
