
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigHTTPUserAgent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigHTTPUserAgent"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Identifier" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxRedirects" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Timeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProxyPolicies" type="{http://www.datapower.com/schemas/management}dmProxyPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SSLPolicies" type="{http://www.datapower.com/schemas/management}dmSSLPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BasicAuthPolicies" type="{http://www.datapower.com/schemas/management}dmBasicAuthPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SoapActionPolicies" type="{http://www.datapower.com/schemas/management}dmSoapActionPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PubkeyAuthPolicies" type="{http://www.datapower.com/schemas/management}dmPubkeyAuthPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AllowCompressionPolicies" type="{http://www.datapower.com/schemas/management}dmAllowCompressionPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HeaderRetentionPolicies" type="{http://www.datapower.com/schemas/management}dmHeaderRetentionPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Restrict10Policies" type="{http://www.datapower.com/schemas/management}dmRestrict10Policy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AddHeaderPolicies" type="{http://www.datapower.com/schemas/management}dmAddHeaderPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UploadChunkedPolicies" type="{http://www.datapower.com/schemas/management}dmUploadChunkedPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FTPPolicies" type="{http://www.datapower.com/schemas/management}dmFTPPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SMTPPolicies" type="{http://www.datapower.com/schemas/management}dmSMTPPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SFTPPolicies" type="{http://www.datapower.com/schemas/management}dmSFTPPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigHTTPUserAgent", propOrder = {
    "userSummary",
    "identifier",
    "maxRedirects",
    "timeout",
    "proxyPolicies",
    "sslPolicies",
    "basicAuthPolicies",
    "soapActionPolicies",
    "pubkeyAuthPolicies",
    "allowCompressionPolicies",
    "headerRetentionPolicies",
    "restrict10Policies",
    "addHeaderPolicies",
    "uploadChunkedPolicies",
    "ftpPolicies",
    "smtpPolicies",
    "sftpPolicies"
})
public class ConfigHTTPUserAgent
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Identifier")
    protected String identifier;
    @XmlElement(name = "MaxRedirects")
    protected String maxRedirects;
    @XmlElement(name = "Timeout")
    protected String timeout;
    @XmlElement(name = "ProxyPolicies")
    protected List<DmProxyPolicy> proxyPolicies;
    @XmlElement(name = "SSLPolicies")
    protected List<DmSSLPolicy> sslPolicies;
    @XmlElement(name = "BasicAuthPolicies")
    protected List<DmBasicAuthPolicy> basicAuthPolicies;
    @XmlElement(name = "SoapActionPolicies")
    protected List<DmSoapActionPolicy> soapActionPolicies;
    @XmlElement(name = "PubkeyAuthPolicies")
    protected List<DmPubkeyAuthPolicy> pubkeyAuthPolicies;
    @XmlElement(name = "AllowCompressionPolicies")
    protected List<DmAllowCompressionPolicy> allowCompressionPolicies;
    @XmlElement(name = "HeaderRetentionPolicies")
    protected List<DmHeaderRetentionPolicy> headerRetentionPolicies;
    @XmlElement(name = "Restrict10Policies")
    protected List<DmRestrict10Policy> restrict10Policies;
    @XmlElement(name = "AddHeaderPolicies")
    protected List<DmAddHeaderPolicy> addHeaderPolicies;
    @XmlElement(name = "UploadChunkedPolicies")
    protected List<DmUploadChunkedPolicy> uploadChunkedPolicies;
    @XmlElement(name = "FTPPolicies")
    protected List<DmFTPPolicy> ftpPolicies;
    @XmlElement(name = "SMTPPolicies")
    protected List<DmSMTPPolicy> smtpPolicies;
    @XmlElement(name = "SFTPPolicies")
    protected List<DmSFTPPolicy> sftpPolicies;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the identifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Sets the value of the identifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifier(String value) {
        this.identifier = value;
    }

    /**
     * Gets the value of the maxRedirects property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxRedirects() {
        return maxRedirects;
    }

    /**
     * Sets the value of the maxRedirects property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxRedirects(String value) {
        this.maxRedirects = value;
    }

    /**
     * Gets the value of the timeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeout() {
        return timeout;
    }

    /**
     * Sets the value of the timeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeout(String value) {
        this.timeout = value;
    }

    /**
     * Gets the value of the proxyPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the proxyPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProxyPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmProxyPolicy }
     * 
     * 
     */
    public List<DmProxyPolicy> getProxyPolicies() {
        if (proxyPolicies == null) {
            proxyPolicies = new ArrayList<DmProxyPolicy>();
        }
        return this.proxyPolicies;
    }

    /**
     * Gets the value of the sslPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sslPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSSLPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmSSLPolicy }
     * 
     * 
     */
    public List<DmSSLPolicy> getSSLPolicies() {
        if (sslPolicies == null) {
            sslPolicies = new ArrayList<DmSSLPolicy>();
        }
        return this.sslPolicies;
    }

    /**
     * Gets the value of the basicAuthPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the basicAuthPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBasicAuthPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmBasicAuthPolicy }
     * 
     * 
     */
    public List<DmBasicAuthPolicy> getBasicAuthPolicies() {
        if (basicAuthPolicies == null) {
            basicAuthPolicies = new ArrayList<DmBasicAuthPolicy>();
        }
        return this.basicAuthPolicies;
    }

    /**
     * Gets the value of the soapActionPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the soapActionPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSoapActionPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmSoapActionPolicy }
     * 
     * 
     */
    public List<DmSoapActionPolicy> getSoapActionPolicies() {
        if (soapActionPolicies == null) {
            soapActionPolicies = new ArrayList<DmSoapActionPolicy>();
        }
        return this.soapActionPolicies;
    }

    /**
     * Gets the value of the pubkeyAuthPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pubkeyAuthPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPubkeyAuthPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmPubkeyAuthPolicy }
     * 
     * 
     */
    public List<DmPubkeyAuthPolicy> getPubkeyAuthPolicies() {
        if (pubkeyAuthPolicies == null) {
            pubkeyAuthPolicies = new ArrayList<DmPubkeyAuthPolicy>();
        }
        return this.pubkeyAuthPolicies;
    }

    /**
     * Gets the value of the allowCompressionPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allowCompressionPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllowCompressionPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmAllowCompressionPolicy }
     * 
     * 
     */
    public List<DmAllowCompressionPolicy> getAllowCompressionPolicies() {
        if (allowCompressionPolicies == null) {
            allowCompressionPolicies = new ArrayList<DmAllowCompressionPolicy>();
        }
        return this.allowCompressionPolicies;
    }

    /**
     * Gets the value of the headerRetentionPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerRetentionPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderRetentionPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmHeaderRetentionPolicy }
     * 
     * 
     */
    public List<DmHeaderRetentionPolicy> getHeaderRetentionPolicies() {
        if (headerRetentionPolicies == null) {
            headerRetentionPolicies = new ArrayList<DmHeaderRetentionPolicy>();
        }
        return this.headerRetentionPolicies;
    }

    /**
     * Gets the value of the restrict10Policies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the restrict10Policies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRestrict10Policies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmRestrict10Policy }
     * 
     * 
     */
    public List<DmRestrict10Policy> getRestrict10Policies() {
        if (restrict10Policies == null) {
            restrict10Policies = new ArrayList<DmRestrict10Policy>();
        }
        return this.restrict10Policies;
    }

    /**
     * Gets the value of the addHeaderPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addHeaderPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddHeaderPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmAddHeaderPolicy }
     * 
     * 
     */
    public List<DmAddHeaderPolicy> getAddHeaderPolicies() {
        if (addHeaderPolicies == null) {
            addHeaderPolicies = new ArrayList<DmAddHeaderPolicy>();
        }
        return this.addHeaderPolicies;
    }

    /**
     * Gets the value of the uploadChunkedPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the uploadChunkedPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUploadChunkedPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmUploadChunkedPolicy }
     * 
     * 
     */
    public List<DmUploadChunkedPolicy> getUploadChunkedPolicies() {
        if (uploadChunkedPolicies == null) {
            uploadChunkedPolicies = new ArrayList<DmUploadChunkedPolicy>();
        }
        return this.uploadChunkedPolicies;
    }

    /**
     * Gets the value of the ftpPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ftpPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFTPPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmFTPPolicy }
     * 
     * 
     */
    public List<DmFTPPolicy> getFTPPolicies() {
        if (ftpPolicies == null) {
            ftpPolicies = new ArrayList<DmFTPPolicy>();
        }
        return this.ftpPolicies;
    }

    /**
     * Gets the value of the smtpPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the smtpPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSMTPPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmSMTPPolicy }
     * 
     * 
     */
    public List<DmSMTPPolicy> getSMTPPolicies() {
        if (smtpPolicies == null) {
            smtpPolicies = new ArrayList<DmSMTPPolicy>();
        }
        return this.smtpPolicies;
    }

    /**
     * Gets the value of the sftpPolicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sftpPolicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSFTPPolicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmSFTPPolicy }
     * 
     * 
     */
    public List<DmSFTPPolicy> getSFTPPolicies() {
        if (sftpPolicies == null) {
            sftpPolicies = new ArrayList<DmSFTPPolicy>();
        }
        return this.sftpPolicies;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
