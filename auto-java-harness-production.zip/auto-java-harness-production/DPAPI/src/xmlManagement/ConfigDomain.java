
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigDomain complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigDomain"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigAccessControl"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NeighborDomain" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DomainUser" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FileMap" type="{http://www.datapower.com/schemas/management}dmDomainFileMap" minOccurs="0"/&gt;
 *         &lt;element name="MonitoringMap" type="{http://www.datapower.com/schemas/management}dmDomainMonitoringMap" minOccurs="0"/&gt;
 *         &lt;element name="ConfigMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDomainConfigMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ImportURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ImportFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmImportFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DeploymentPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DeploymentPolicyParameters" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LocalIPRewrite" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxChkpoints" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigDomain", propOrder = {
    "userSummary",
    "neighborDomain",
    "domainUser",
    "fileMap",
    "monitoringMap",
    "configMode",
    "importURL",
    "importFormat",
    "deploymentPolicy",
    "deploymentPolicyParameters",
    "localIPRewrite",
    "maxChkpoints"
})
public class ConfigDomain
    extends ConfigAccessControl
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "NeighborDomain")
    protected List<DmReference> neighborDomain;
    @XmlElement(name = "DomainUser")
    protected List<DmReference> domainUser;
    @XmlElement(name = "FileMap")
    protected DmDomainFileMap fileMap;
    @XmlElement(name = "MonitoringMap")
    protected DmDomainMonitoringMap monitoringMap;
    @XmlElement(name = "ConfigMode")
    protected String configMode;
    @XmlElement(name = "ImportURL")
    protected String importURL;
    @XmlElement(name = "ImportFormat")
    protected String importFormat;
    @XmlElement(name = "DeploymentPolicy")
    protected DmReference deploymentPolicy;
    @XmlElement(name = "DeploymentPolicyParameters")
    protected DmReference deploymentPolicyParameters;
    @XmlElement(name = "LocalIPRewrite")
    protected String localIPRewrite;
    @XmlElement(name = "MaxChkpoints")
    protected String maxChkpoints;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the neighborDomain property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the neighborDomain property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNeighborDomain().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getNeighborDomain() {
        if (neighborDomain == null) {
            neighborDomain = new ArrayList<DmReference>();
        }
        return this.neighborDomain;
    }

    /**
     * Gets the value of the domainUser property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the domainUser property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDomainUser().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getDomainUser() {
        if (domainUser == null) {
            domainUser = new ArrayList<DmReference>();
        }
        return this.domainUser;
    }

    /**
     * Gets the value of the fileMap property.
     * 
     * @return
     *     possible object is
     *     {@link DmDomainFileMap }
     *     
     */
    public DmDomainFileMap getFileMap() {
        return fileMap;
    }

    /**
     * Sets the value of the fileMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmDomainFileMap }
     *     
     */
    public void setFileMap(DmDomainFileMap value) {
        this.fileMap = value;
    }

    /**
     * Gets the value of the monitoringMap property.
     * 
     * @return
     *     possible object is
     *     {@link DmDomainMonitoringMap }
     *     
     */
    public DmDomainMonitoringMap getMonitoringMap() {
        return monitoringMap;
    }

    /**
     * Sets the value of the monitoringMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmDomainMonitoringMap }
     *     
     */
    public void setMonitoringMap(DmDomainMonitoringMap value) {
        this.monitoringMap = value;
    }

    /**
     * Gets the value of the configMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigMode() {
        return configMode;
    }

    /**
     * Sets the value of the configMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigMode(String value) {
        this.configMode = value;
    }

    /**
     * Gets the value of the importURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImportURL() {
        return importURL;
    }

    /**
     * Sets the value of the importURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImportURL(String value) {
        this.importURL = value;
    }

    /**
     * Gets the value of the importFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImportFormat() {
        return importFormat;
    }

    /**
     * Sets the value of the importFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImportFormat(String value) {
        this.importFormat = value;
    }

    /**
     * Gets the value of the deploymentPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDeploymentPolicy() {
        return deploymentPolicy;
    }

    /**
     * Sets the value of the deploymentPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDeploymentPolicy(DmReference value) {
        this.deploymentPolicy = value;
    }

    /**
     * Gets the value of the deploymentPolicyParameters property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDeploymentPolicyParameters() {
        return deploymentPolicyParameters;
    }

    /**
     * Sets the value of the deploymentPolicyParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDeploymentPolicyParameters(DmReference value) {
        this.deploymentPolicyParameters = value;
    }

    /**
     * Gets the value of the localIPRewrite property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalIPRewrite() {
        return localIPRewrite;
    }

    /**
     * Sets the value of the localIPRewrite property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalIPRewrite(String value) {
        this.localIPRewrite = value;
    }

    /**
     * Gets the value of the maxChkpoints property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxChkpoints() {
        return maxChkpoints;
    }

    /**
     * Sets the value of the maxChkpoints property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxChkpoints(String value) {
        this.maxChkpoints = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
