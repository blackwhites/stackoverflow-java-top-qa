
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigMQproxy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigMQproxy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigMQConfiguration"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontQueueManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="BackQueueManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="Concurrent" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WaitTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FirewallExtensions" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestGetQueue"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestPutQueue"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseGetQueue"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponsePutQueue"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="ContentType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Credentials" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="StylesheetParameters" type="{http://www.datapower.com/schemas/management}dmStylesheetParameter" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DefaultParameterNamespace" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestStylePolicyRule" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="ResponseStylePolicyRule" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="ErrorStylePolicyRule" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="RequestAttachments" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseAttachments" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RootPartNotFirstAction" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmRootPartNotFirstAction {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontAttachmentFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackAttachmentFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDebugMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugHistory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugTrigger" type="{http://www.datapower.com/schemas/management}dmMQMSDebugTriggerType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SOAPSchemaURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CountMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DurationMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigMQproxy", propOrder = {
    "userSummary",
    "frontQueueManager",
    "backQueueManager",
    "concurrent",
    "waitTimeout",
    "firewallExtensions",
    "requestGetQueue",
    "requestPutQueue",
    "responseGetQueue",
    "responsePutQueue",
    "xmlManager",
    "contentType",
    "requestType",
    "responseType",
    "credentials",
    "stylesheetParameters",
    "defaultParameterNamespace",
    "requestStylePolicyRule",
    "responseStylePolicyRule",
    "errorStylePolicyRule",
    "requestAttachments",
    "responseAttachments",
    "rootPartNotFirstAction",
    "frontAttachmentFormat",
    "backAttachmentFormat",
    "debugMode",
    "debugHistory",
    "debugTrigger",
    "soapSchemaURL",
    "countMonitors",
    "durationMonitors"
})
public class ConfigMQproxy
    extends ConfigMQConfiguration
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "FrontQueueManager")
    protected DmReference frontQueueManager;
    @XmlElement(name = "BackQueueManager")
    protected DmReference backQueueManager;
    @XmlElement(name = "Concurrent")
    protected String concurrent;
    @XmlElement(name = "WaitTimeout")
    protected String waitTimeout;
    @XmlElement(name = "FirewallExtensions")
    protected String firewallExtensions;
    @XmlElement(name = "RequestGetQueue")
    protected String requestGetQueue;
    @XmlElement(name = "RequestPutQueue")
    protected String requestPutQueue;
    @XmlElement(name = "ResponseGetQueue")
    protected String responseGetQueue;
    @XmlElement(name = "ResponsePutQueue")
    protected String responsePutQueue;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "ContentType")
    protected String contentType;
    @XmlElement(name = "RequestType")
    protected String requestType;
    @XmlElement(name = "ResponseType")
    protected String responseType;
    @XmlElement(name = "Credentials")
    protected DmReference credentials;
    @XmlElement(name = "StylesheetParameters")
    protected List<DmStylesheetParameter> stylesheetParameters;
    @XmlElement(name = "DefaultParameterNamespace")
    protected String defaultParameterNamespace;
    @XmlElement(name = "RequestStylePolicyRule")
    protected DmReference requestStylePolicyRule;
    @XmlElement(name = "ResponseStylePolicyRule")
    protected DmReference responseStylePolicyRule;
    @XmlElement(name = "ErrorStylePolicyRule")
    protected DmReference errorStylePolicyRule;
    @XmlElement(name = "RequestAttachments")
    protected String requestAttachments;
    @XmlElement(name = "ResponseAttachments")
    protected String responseAttachments;
    @XmlElement(name = "RootPartNotFirstAction")
    protected String rootPartNotFirstAction;
    @XmlElement(name = "FrontAttachmentFormat")
    protected String frontAttachmentFormat;
    @XmlElement(name = "BackAttachmentFormat")
    protected String backAttachmentFormat;
    @XmlElement(name = "DebugMode")
    protected String debugMode;
    @XmlElement(name = "DebugHistory")
    protected String debugHistory;
    @XmlElement(name = "DebugTrigger")
    protected List<DmMQMSDebugTriggerType> debugTrigger;
    @XmlElement(name = "SOAPSchemaURL")
    protected String soapSchemaURL;
    @XmlElement(name = "CountMonitors")
    protected List<DmReference> countMonitors;
    @XmlElement(name = "DurationMonitors")
    protected List<DmReference> durationMonitors;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the frontQueueManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getFrontQueueManager() {
        return frontQueueManager;
    }

    /**
     * Sets the value of the frontQueueManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setFrontQueueManager(DmReference value) {
        this.frontQueueManager = value;
    }

    /**
     * Gets the value of the backQueueManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getBackQueueManager() {
        return backQueueManager;
    }

    /**
     * Sets the value of the backQueueManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setBackQueueManager(DmReference value) {
        this.backQueueManager = value;
    }

    /**
     * Gets the value of the concurrent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConcurrent() {
        return concurrent;
    }

    /**
     * Sets the value of the concurrent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConcurrent(String value) {
        this.concurrent = value;
    }

    /**
     * Gets the value of the waitTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaitTimeout() {
        return waitTimeout;
    }

    /**
     * Sets the value of the waitTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaitTimeout(String value) {
        this.waitTimeout = value;
    }

    /**
     * Gets the value of the firewallExtensions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirewallExtensions() {
        return firewallExtensions;
    }

    /**
     * Sets the value of the firewallExtensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirewallExtensions(String value) {
        this.firewallExtensions = value;
    }

    /**
     * Gets the value of the requestGetQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestGetQueue() {
        return requestGetQueue;
    }

    /**
     * Sets the value of the requestGetQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestGetQueue(String value) {
        this.requestGetQueue = value;
    }

    /**
     * Gets the value of the requestPutQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestPutQueue() {
        return requestPutQueue;
    }

    /**
     * Sets the value of the requestPutQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestPutQueue(String value) {
        this.requestPutQueue = value;
    }

    /**
     * Gets the value of the responseGetQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseGetQueue() {
        return responseGetQueue;
    }

    /**
     * Sets the value of the responseGetQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseGetQueue(String value) {
        this.responseGetQueue = value;
    }

    /**
     * Gets the value of the responsePutQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponsePutQueue() {
        return responsePutQueue;
    }

    /**
     * Sets the value of the responsePutQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponsePutQueue(String value) {
        this.responsePutQueue = value;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the contentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Sets the value of the contentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentType(String value) {
        this.contentType = value;
    }

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the credentials property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getCredentials() {
        return credentials;
    }

    /**
     * Sets the value of the credentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setCredentials(DmReference value) {
        this.credentials = value;
    }

    /**
     * Gets the value of the stylesheetParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stylesheetParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStylesheetParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmStylesheetParameter }
     * 
     * 
     */
    public List<DmStylesheetParameter> getStylesheetParameters() {
        if (stylesheetParameters == null) {
            stylesheetParameters = new ArrayList<DmStylesheetParameter>();
        }
        return this.stylesheetParameters;
    }

    /**
     * Gets the value of the defaultParameterNamespace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultParameterNamespace() {
        return defaultParameterNamespace;
    }

    /**
     * Sets the value of the defaultParameterNamespace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultParameterNamespace(String value) {
        this.defaultParameterNamespace = value;
    }

    /**
     * Gets the value of the requestStylePolicyRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getRequestStylePolicyRule() {
        return requestStylePolicyRule;
    }

    /**
     * Sets the value of the requestStylePolicyRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setRequestStylePolicyRule(DmReference value) {
        this.requestStylePolicyRule = value;
    }

    /**
     * Gets the value of the responseStylePolicyRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getResponseStylePolicyRule() {
        return responseStylePolicyRule;
    }

    /**
     * Sets the value of the responseStylePolicyRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setResponseStylePolicyRule(DmReference value) {
        this.responseStylePolicyRule = value;
    }

    /**
     * Gets the value of the errorStylePolicyRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getErrorStylePolicyRule() {
        return errorStylePolicyRule;
    }

    /**
     * Sets the value of the errorStylePolicyRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setErrorStylePolicyRule(DmReference value) {
        this.errorStylePolicyRule = value;
    }

    /**
     * Gets the value of the requestAttachments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestAttachments() {
        return requestAttachments;
    }

    /**
     * Sets the value of the requestAttachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestAttachments(String value) {
        this.requestAttachments = value;
    }

    /**
     * Gets the value of the responseAttachments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseAttachments() {
        return responseAttachments;
    }

    /**
     * Sets the value of the responseAttachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseAttachments(String value) {
        this.responseAttachments = value;
    }

    /**
     * Gets the value of the rootPartNotFirstAction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRootPartNotFirstAction() {
        return rootPartNotFirstAction;
    }

    /**
     * Sets the value of the rootPartNotFirstAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRootPartNotFirstAction(String value) {
        this.rootPartNotFirstAction = value;
    }

    /**
     * Gets the value of the frontAttachmentFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontAttachmentFormat() {
        return frontAttachmentFormat;
    }

    /**
     * Sets the value of the frontAttachmentFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontAttachmentFormat(String value) {
        this.frontAttachmentFormat = value;
    }

    /**
     * Gets the value of the backAttachmentFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackAttachmentFormat() {
        return backAttachmentFormat;
    }

    /**
     * Sets the value of the backAttachmentFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackAttachmentFormat(String value) {
        this.backAttachmentFormat = value;
    }

    /**
     * Gets the value of the debugMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugMode() {
        return debugMode;
    }

    /**
     * Sets the value of the debugMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugMode(String value) {
        this.debugMode = value;
    }

    /**
     * Gets the value of the debugHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugHistory() {
        return debugHistory;
    }

    /**
     * Sets the value of the debugHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugHistory(String value) {
        this.debugHistory = value;
    }

    /**
     * Gets the value of the debugTrigger property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the debugTrigger property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDebugTrigger().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmMQMSDebugTriggerType }
     * 
     * 
     */
    public List<DmMQMSDebugTriggerType> getDebugTrigger() {
        if (debugTrigger == null) {
            debugTrigger = new ArrayList<DmMQMSDebugTriggerType>();
        }
        return this.debugTrigger;
    }

    /**
     * Gets the value of the soapSchemaURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOAPSchemaURL() {
        return soapSchemaURL;
    }

    /**
     * Sets the value of the soapSchemaURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOAPSchemaURL(String value) {
        this.soapSchemaURL = value;
    }

    /**
     * Gets the value of the countMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the countMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCountMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getCountMonitors() {
        if (countMonitors == null) {
            countMonitors = new ArrayList<DmReference>();
        }
        return this.countMonitors;
    }

    /**
     * Gets the value of the durationMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the durationMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDurationMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getDurationMonitors() {
        if (durationMonitors == null) {
            durationMonitors = new ArrayList<DmReference>();
        }
        return this.durationMonitors;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
