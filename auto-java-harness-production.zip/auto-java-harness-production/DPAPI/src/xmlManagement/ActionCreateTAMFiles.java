
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionCreateTAMFiles complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionCreateTAMFiles"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CreateCopy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OutputConfigFile"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Administrator"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Password"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMVersion"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTAMVersionType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMDomain"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Application"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Host"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Port"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLKeyFileLifetime"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalMode"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ListenMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseADRegistry" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADPrimaryDomain" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADPrimaryHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADPrimaryReplicas" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPServer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPBindPassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPAuthenticateTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSearchTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADClientTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnableRegistryCache" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPUserCacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPPolicyCacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADLdapCacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADLdapCacheLife" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADDnforpd" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADUseMultiDomain" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADDomaindomain" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADDomainHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADDomainReplicas" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADUseEmailUid" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADGcHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionCreateTAMFiles", propOrder = {
    "createCopy",
    "outputConfigFile",
    "administrator",
    "password",
    "tamVersion",
    "tamDomain",
    "application",
    "host",
    "port",
    "sslKeyFileLifetime",
    "sslTimeout",
    "localMode",
    "listenMode",
    "localHost",
    "localPort",
    "useADRegistry",
    "adPrimaryDomain",
    "adPrimaryHost",
    "adPrimaryReplicas",
    "ldapServer",
    "ldapPort",
    "ldapBindPassword",
    "ldapAuthenticateTimeout",
    "ldapSearchTimeout",
    "adClientTimeout",
    "enableRegistryCache",
    "ldapUserCacheSize",
    "ldapPolicyCacheSize",
    "adLdapCacheSize",
    "adLdapCacheLife",
    "adDnforpd",
    "adUseMultiDomain",
    "adDomaindomain",
    "adDomainHost",
    "adDomainReplicas",
    "adUseEmailUid",
    "adGcHost"
})
public class ActionCreateTAMFiles {

    @XmlElement(name = "CreateCopy")
    protected String createCopy;
    @XmlElement(name = "OutputConfigFile", required = true)
    protected String outputConfigFile;
    @XmlElement(name = "Administrator", required = true)
    protected String administrator;
    @XmlElement(name = "Password", required = true)
    protected String password;
    @XmlElement(name = "TAMVersion", required = true)
    protected String tamVersion;
    @XmlElement(name = "TAMDomain", required = true)
    protected String tamDomain;
    @XmlElement(name = "Application", required = true)
    protected String application;
    @XmlElement(name = "Host", required = true)
    protected String host;
    @XmlElement(name = "Port", required = true)
    protected String port;
    @XmlElement(name = "SSLKeyFileLifetime", required = true)
    protected String sslKeyFileLifetime;
    @XmlElement(name = "SSLTimeout", required = true)
    protected String sslTimeout;
    @XmlElement(name = "LocalMode", required = true)
    protected String localMode;
    @XmlElement(name = "ListenMode")
    protected String listenMode;
    @XmlElement(name = "LocalHost")
    protected String localHost;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "UseADRegistry")
    protected String useADRegistry;
    @XmlElement(name = "ADPrimaryDomain")
    protected String adPrimaryDomain;
    @XmlElement(name = "ADPrimaryHost")
    protected String adPrimaryHost;
    @XmlElement(name = "ADPrimaryReplicas")
    protected String adPrimaryReplicas;
    @XmlElement(name = "LDAPServer")
    protected String ldapServer;
    @XmlElement(name = "LDAPPort")
    protected String ldapPort;
    @XmlElement(name = "LDAPBindPassword")
    protected String ldapBindPassword;
    @XmlElement(name = "LDAPAuthenticateTimeout")
    protected String ldapAuthenticateTimeout;
    @XmlElement(name = "LDAPSearchTimeout")
    protected String ldapSearchTimeout;
    @XmlElement(name = "ADClientTimeout")
    protected String adClientTimeout;
    @XmlElement(name = "EnableRegistryCache")
    protected String enableRegistryCache;
    @XmlElement(name = "LDAPUserCacheSize")
    protected String ldapUserCacheSize;
    @XmlElement(name = "LDAPPolicyCacheSize")
    protected String ldapPolicyCacheSize;
    @XmlElement(name = "ADLdapCacheSize")
    protected String adLdapCacheSize;
    @XmlElement(name = "ADLdapCacheLife")
    protected String adLdapCacheLife;
    @XmlElement(name = "ADDnforpd")
    protected String adDnforpd;
    @XmlElement(name = "ADUseMultiDomain")
    protected String adUseMultiDomain;
    @XmlElement(name = "ADDomaindomain")
    protected String adDomaindomain;
    @XmlElement(name = "ADDomainHost")
    protected String adDomainHost;
    @XmlElement(name = "ADDomainReplicas")
    protected String adDomainReplicas;
    @XmlElement(name = "ADUseEmailUid")
    protected String adUseEmailUid;
    @XmlElement(name = "ADGcHost")
    protected String adGcHost;

    /**
     * Gets the value of the createCopy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreateCopy() {
        return createCopy;
    }

    /**
     * Sets the value of the createCopy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreateCopy(String value) {
        this.createCopy = value;
    }

    /**
     * Gets the value of the outputConfigFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutputConfigFile() {
        return outputConfigFile;
    }

    /**
     * Sets the value of the outputConfigFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutputConfigFile(String value) {
        this.outputConfigFile = value;
    }

    /**
     * Gets the value of the administrator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdministrator() {
        return administrator;
    }

    /**
     * Sets the value of the administrator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdministrator(String value) {
        this.administrator = value;
    }

    /**
     * Gets the value of the password property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassword(String value) {
        this.password = value;
    }

    /**
     * Gets the value of the tamVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAMVersion() {
        return tamVersion;
    }

    /**
     * Sets the value of the tamVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAMVersion(String value) {
        this.tamVersion = value;
    }

    /**
     * Gets the value of the tamDomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAMDomain() {
        return tamDomain;
    }

    /**
     * Sets the value of the tamDomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAMDomain(String value) {
        this.tamDomain = value;
    }

    /**
     * Gets the value of the application property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplication() {
        return application;
    }

    /**
     * Sets the value of the application property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplication(String value) {
        this.application = value;
    }

    /**
     * Gets the value of the host property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHost() {
        return host;
    }

    /**
     * Sets the value of the host property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHost(String value) {
        this.host = value;
    }

    /**
     * Gets the value of the port property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPort() {
        return port;
    }

    /**
     * Sets the value of the port property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPort(String value) {
        this.port = value;
    }

    /**
     * Gets the value of the sslKeyFileLifetime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLKeyFileLifetime() {
        return sslKeyFileLifetime;
    }

    /**
     * Sets the value of the sslKeyFileLifetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLKeyFileLifetime(String value) {
        this.sslKeyFileLifetime = value;
    }

    /**
     * Gets the value of the sslTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLTimeout() {
        return sslTimeout;
    }

    /**
     * Sets the value of the sslTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLTimeout(String value) {
        this.sslTimeout = value;
    }

    /**
     * Gets the value of the localMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalMode() {
        return localMode;
    }

    /**
     * Sets the value of the localMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalMode(String value) {
        this.localMode = value;
    }

    /**
     * Gets the value of the listenMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListenMode() {
        return listenMode;
    }

    /**
     * Sets the value of the listenMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListenMode(String value) {
        this.listenMode = value;
    }

    /**
     * Gets the value of the localHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalHost() {
        return localHost;
    }

    /**
     * Sets the value of the localHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalHost(String value) {
        this.localHost = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the useADRegistry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseADRegistry() {
        return useADRegistry;
    }

    /**
     * Sets the value of the useADRegistry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseADRegistry(String value) {
        this.useADRegistry = value;
    }

    /**
     * Gets the value of the adPrimaryDomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADPrimaryDomain() {
        return adPrimaryDomain;
    }

    /**
     * Sets the value of the adPrimaryDomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADPrimaryDomain(String value) {
        this.adPrimaryDomain = value;
    }

    /**
     * Gets the value of the adPrimaryHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADPrimaryHost() {
        return adPrimaryHost;
    }

    /**
     * Sets the value of the adPrimaryHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADPrimaryHost(String value) {
        this.adPrimaryHost = value;
    }

    /**
     * Gets the value of the adPrimaryReplicas property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADPrimaryReplicas() {
        return adPrimaryReplicas;
    }

    /**
     * Sets the value of the adPrimaryReplicas property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADPrimaryReplicas(String value) {
        this.adPrimaryReplicas = value;
    }

    /**
     * Gets the value of the ldapServer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPServer() {
        return ldapServer;
    }

    /**
     * Sets the value of the ldapServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPServer(String value) {
        this.ldapServer = value;
    }

    /**
     * Gets the value of the ldapPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPPort() {
        return ldapPort;
    }

    /**
     * Sets the value of the ldapPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPPort(String value) {
        this.ldapPort = value;
    }

    /**
     * Gets the value of the ldapBindPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPBindPassword() {
        return ldapBindPassword;
    }

    /**
     * Sets the value of the ldapBindPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPBindPassword(String value) {
        this.ldapBindPassword = value;
    }

    /**
     * Gets the value of the ldapAuthenticateTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPAuthenticateTimeout() {
        return ldapAuthenticateTimeout;
    }

    /**
     * Sets the value of the ldapAuthenticateTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPAuthenticateTimeout(String value) {
        this.ldapAuthenticateTimeout = value;
    }

    /**
     * Gets the value of the ldapSearchTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPSearchTimeout() {
        return ldapSearchTimeout;
    }

    /**
     * Sets the value of the ldapSearchTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPSearchTimeout(String value) {
        this.ldapSearchTimeout = value;
    }

    /**
     * Gets the value of the adClientTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADClientTimeout() {
        return adClientTimeout;
    }

    /**
     * Sets the value of the adClientTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADClientTimeout(String value) {
        this.adClientTimeout = value;
    }

    /**
     * Gets the value of the enableRegistryCache property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableRegistryCache() {
        return enableRegistryCache;
    }

    /**
     * Sets the value of the enableRegistryCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableRegistryCache(String value) {
        this.enableRegistryCache = value;
    }

    /**
     * Gets the value of the ldapUserCacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPUserCacheSize() {
        return ldapUserCacheSize;
    }

    /**
     * Sets the value of the ldapUserCacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPUserCacheSize(String value) {
        this.ldapUserCacheSize = value;
    }

    /**
     * Gets the value of the ldapPolicyCacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPPolicyCacheSize() {
        return ldapPolicyCacheSize;
    }

    /**
     * Sets the value of the ldapPolicyCacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPPolicyCacheSize(String value) {
        this.ldapPolicyCacheSize = value;
    }

    /**
     * Gets the value of the adLdapCacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADLdapCacheSize() {
        return adLdapCacheSize;
    }

    /**
     * Sets the value of the adLdapCacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADLdapCacheSize(String value) {
        this.adLdapCacheSize = value;
    }

    /**
     * Gets the value of the adLdapCacheLife property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADLdapCacheLife() {
        return adLdapCacheLife;
    }

    /**
     * Sets the value of the adLdapCacheLife property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADLdapCacheLife(String value) {
        this.adLdapCacheLife = value;
    }

    /**
     * Gets the value of the adDnforpd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDnforpd() {
        return adDnforpd;
    }

    /**
     * Sets the value of the adDnforpd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDnforpd(String value) {
        this.adDnforpd = value;
    }

    /**
     * Gets the value of the adUseMultiDomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADUseMultiDomain() {
        return adUseMultiDomain;
    }

    /**
     * Sets the value of the adUseMultiDomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADUseMultiDomain(String value) {
        this.adUseMultiDomain = value;
    }

    /**
     * Gets the value of the adDomaindomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDomaindomain() {
        return adDomaindomain;
    }

    /**
     * Sets the value of the adDomaindomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDomaindomain(String value) {
        this.adDomaindomain = value;
    }

    /**
     * Gets the value of the adDomainHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDomainHost() {
        return adDomainHost;
    }

    /**
     * Sets the value of the adDomainHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDomainHost(String value) {
        this.adDomainHost = value;
    }

    /**
     * Gets the value of the adDomainReplicas property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDomainReplicas() {
        return adDomainReplicas;
    }

    /**
     * Sets the value of the adDomainReplicas property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDomainReplicas(String value) {
        this.adDomainReplicas = value;
    }

    /**
     * Gets the value of the adUseEmailUid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADUseEmailUid() {
        return adUseEmailUid;
    }

    /**
     * Sets the value of the adUseEmailUid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADUseEmailUid(String value) {
        this.adUseEmailUid = value;
    }

    /**
     * Gets the value of the adGcHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADGcHost() {
        return adGcHost;
    }

    /**
     * Sets the value of the adGcHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADGcHost(String value) {
        this.adGcHost = value;
    }

}
