
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigWebAppFW complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigWebAppFW"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSchedulerPriority {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontSide" type="{http://www.datapower.com/schemas/management}dmFrontSide" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RemoteAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemotePort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StylePolicy" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="ErrorPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="URINormalization" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RewriteErrors" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DelayErrors" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DelayErrorsDuration" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StreamOutputToBack" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmQuarantineMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StreamOutputToFront" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmQuarantineMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontPersistentTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCacheControlHeader" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackPersistentTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontHTTPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackHTTPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestSideSecurity" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseSideSecurity" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoChunkedUpload" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FollowRedirects" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPClientIPLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPLogCorIDLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDebugMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugHistory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugTrigger" type="{http://www.datapower.com/schemas/management}dmMSDebugTriggerType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="URLRewritePolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DoHostRewriting" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLConfigType" type="{http://www.datapower.com/schemas/management}dmSSLConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLSNIServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigWebAppFW", propOrder = {
    "userSummary",
    "priority",
    "frontSide",
    "remoteAddress",
    "remotePort",
    "stylePolicy",
    "xmlManager",
    "errorPolicy",
    "uriNormalization",
    "rewriteErrors",
    "delayErrors",
    "delayErrorsDuration",
    "streamOutputToBack",
    "streamOutputToFront",
    "frontTimeout",
    "backTimeout",
    "frontPersistentTimeout",
    "allowCacheControlHeader",
    "backPersistentTimeout",
    "frontHTTPVersion",
    "backHTTPVersion",
    "requestSideSecurity",
    "responseSideSecurity",
    "doChunkedUpload",
    "followRedirects",
    "httpClientIPLabel",
    "httpLogCorIDLabel",
    "debugMode",
    "debugHistory",
    "debugTrigger",
    "urlRewritePolicy",
    "doHostRewriting",
    "sslConfigType",
    "sslProxyProfile",
    "sslServer",
    "sslsniServer",
    "sslClient"
})
public class ConfigWebAppFW
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "FrontSide")
    protected List<DmFrontSide> frontSide;
    @XmlElement(name = "RemoteAddress")
    protected String remoteAddress;
    @XmlElement(name = "RemotePort")
    protected String remotePort;
    @XmlElement(name = "StylePolicy")
    protected DmReference stylePolicy;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "ErrorPolicy")
    protected DmReference errorPolicy;
    @XmlElement(name = "URINormalization")
    protected String uriNormalization;
    @XmlElement(name = "RewriteErrors")
    protected String rewriteErrors;
    @XmlElement(name = "DelayErrors")
    protected String delayErrors;
    @XmlElement(name = "DelayErrorsDuration")
    protected String delayErrorsDuration;
    @XmlElement(name = "StreamOutputToBack")
    protected String streamOutputToBack;
    @XmlElement(name = "StreamOutputToFront")
    protected String streamOutputToFront;
    @XmlElement(name = "FrontTimeout")
    protected String frontTimeout;
    @XmlElement(name = "BackTimeout")
    protected String backTimeout;
    @XmlElement(name = "FrontPersistentTimeout")
    protected String frontPersistentTimeout;
    @XmlElement(name = "AllowCacheControlHeader")
    protected String allowCacheControlHeader;
    @XmlElement(name = "BackPersistentTimeout")
    protected String backPersistentTimeout;
    @XmlElement(name = "FrontHTTPVersion")
    protected String frontHTTPVersion;
    @XmlElement(name = "BackHTTPVersion")
    protected String backHTTPVersion;
    @XmlElement(name = "RequestSideSecurity")
    protected String requestSideSecurity;
    @XmlElement(name = "ResponseSideSecurity")
    protected String responseSideSecurity;
    @XmlElement(name = "DoChunkedUpload")
    protected String doChunkedUpload;
    @XmlElement(name = "FollowRedirects")
    protected String followRedirects;
    @XmlElement(name = "HTTPClientIPLabel")
    protected String httpClientIPLabel;
    @XmlElement(name = "HTTPLogCorIDLabel")
    protected String httpLogCorIDLabel;
    @XmlElement(name = "DebugMode")
    protected String debugMode;
    @XmlElement(name = "DebugHistory")
    protected String debugHistory;
    @XmlElement(name = "DebugTrigger")
    protected List<DmMSDebugTriggerType> debugTrigger;
    @XmlElement(name = "URLRewritePolicy")
    protected DmReference urlRewritePolicy;
    @XmlElement(name = "DoHostRewriting")
    protected String doHostRewriting;
    @XmlElement(name = "SSLConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLConfigType sslConfigType;
    @XmlElement(name = "SSLProxyProfile")
    protected DmReference sslProxyProfile;
    @XmlElement(name = "SSLServer")
    protected DmReference sslServer;
    @XmlElement(name = "SSLSNIServer")
    protected DmReference sslsniServer;
    @XmlElement(name = "SSLClient")
    protected DmReference sslClient;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the frontSide property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frontSide property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrontSide().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmFrontSide }
     * 
     * 
     */
    public List<DmFrontSide> getFrontSide() {
        if (frontSide == null) {
            frontSide = new ArrayList<DmFrontSide>();
        }
        return this.frontSide;
    }

    /**
     * Gets the value of the remoteAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteAddress() {
        return remoteAddress;
    }

    /**
     * Sets the value of the remoteAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteAddress(String value) {
        this.remoteAddress = value;
    }

    /**
     * Gets the value of the remotePort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemotePort() {
        return remotePort;
    }

    /**
     * Sets the value of the remotePort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemotePort(String value) {
        this.remotePort = value;
    }

    /**
     * Gets the value of the stylePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getStylePolicy() {
        return stylePolicy;
    }

    /**
     * Sets the value of the stylePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setStylePolicy(DmReference value) {
        this.stylePolicy = value;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the errorPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getErrorPolicy() {
        return errorPolicy;
    }

    /**
     * Sets the value of the errorPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setErrorPolicy(DmReference value) {
        this.errorPolicy = value;
    }

    /**
     * Gets the value of the uriNormalization property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURINormalization() {
        return uriNormalization;
    }

    /**
     * Sets the value of the uriNormalization property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURINormalization(String value) {
        this.uriNormalization = value;
    }

    /**
     * Gets the value of the rewriteErrors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRewriteErrors() {
        return rewriteErrors;
    }

    /**
     * Sets the value of the rewriteErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRewriteErrors(String value) {
        this.rewriteErrors = value;
    }

    /**
     * Gets the value of the delayErrors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayErrors() {
        return delayErrors;
    }

    /**
     * Sets the value of the delayErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayErrors(String value) {
        this.delayErrors = value;
    }

    /**
     * Gets the value of the delayErrorsDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayErrorsDuration() {
        return delayErrorsDuration;
    }

    /**
     * Sets the value of the delayErrorsDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayErrorsDuration(String value) {
        this.delayErrorsDuration = value;
    }

    /**
     * Gets the value of the streamOutputToBack property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreamOutputToBack() {
        return streamOutputToBack;
    }

    /**
     * Sets the value of the streamOutputToBack property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreamOutputToBack(String value) {
        this.streamOutputToBack = value;
    }

    /**
     * Gets the value of the streamOutputToFront property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreamOutputToFront() {
        return streamOutputToFront;
    }

    /**
     * Sets the value of the streamOutputToFront property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreamOutputToFront(String value) {
        this.streamOutputToFront = value;
    }

    /**
     * Gets the value of the frontTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontTimeout() {
        return frontTimeout;
    }

    /**
     * Sets the value of the frontTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontTimeout(String value) {
        this.frontTimeout = value;
    }

    /**
     * Gets the value of the backTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackTimeout() {
        return backTimeout;
    }

    /**
     * Sets the value of the backTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackTimeout(String value) {
        this.backTimeout = value;
    }

    /**
     * Gets the value of the frontPersistentTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontPersistentTimeout() {
        return frontPersistentTimeout;
    }

    /**
     * Sets the value of the frontPersistentTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontPersistentTimeout(String value) {
        this.frontPersistentTimeout = value;
    }

    /**
     * Gets the value of the allowCacheControlHeader property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCacheControlHeader() {
        return allowCacheControlHeader;
    }

    /**
     * Sets the value of the allowCacheControlHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCacheControlHeader(String value) {
        this.allowCacheControlHeader = value;
    }

    /**
     * Gets the value of the backPersistentTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackPersistentTimeout() {
        return backPersistentTimeout;
    }

    /**
     * Sets the value of the backPersistentTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackPersistentTimeout(String value) {
        this.backPersistentTimeout = value;
    }

    /**
     * Gets the value of the frontHTTPVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontHTTPVersion() {
        return frontHTTPVersion;
    }

    /**
     * Sets the value of the frontHTTPVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontHTTPVersion(String value) {
        this.frontHTTPVersion = value;
    }

    /**
     * Gets the value of the backHTTPVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackHTTPVersion() {
        return backHTTPVersion;
    }

    /**
     * Sets the value of the backHTTPVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackHTTPVersion(String value) {
        this.backHTTPVersion = value;
    }

    /**
     * Gets the value of the requestSideSecurity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSideSecurity() {
        return requestSideSecurity;
    }

    /**
     * Sets the value of the requestSideSecurity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSideSecurity(String value) {
        this.requestSideSecurity = value;
    }

    /**
     * Gets the value of the responseSideSecurity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseSideSecurity() {
        return responseSideSecurity;
    }

    /**
     * Sets the value of the responseSideSecurity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseSideSecurity(String value) {
        this.responseSideSecurity = value;
    }

    /**
     * Gets the value of the doChunkedUpload property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoChunkedUpload() {
        return doChunkedUpload;
    }

    /**
     * Sets the value of the doChunkedUpload property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoChunkedUpload(String value) {
        this.doChunkedUpload = value;
    }

    /**
     * Gets the value of the followRedirects property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFollowRedirects() {
        return followRedirects;
    }

    /**
     * Sets the value of the followRedirects property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFollowRedirects(String value) {
        this.followRedirects = value;
    }

    /**
     * Gets the value of the httpClientIPLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPClientIPLabel() {
        return httpClientIPLabel;
    }

    /**
     * Sets the value of the httpClientIPLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPClientIPLabel(String value) {
        this.httpClientIPLabel = value;
    }

    /**
     * Gets the value of the httpLogCorIDLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPLogCorIDLabel() {
        return httpLogCorIDLabel;
    }

    /**
     * Sets the value of the httpLogCorIDLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPLogCorIDLabel(String value) {
        this.httpLogCorIDLabel = value;
    }

    /**
     * Gets the value of the debugMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugMode() {
        return debugMode;
    }

    /**
     * Sets the value of the debugMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugMode(String value) {
        this.debugMode = value;
    }

    /**
     * Gets the value of the debugHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugHistory() {
        return debugHistory;
    }

    /**
     * Sets the value of the debugHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugHistory(String value) {
        this.debugHistory = value;
    }

    /**
     * Gets the value of the debugTrigger property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the debugTrigger property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDebugTrigger().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmMSDebugTriggerType }
     * 
     * 
     */
    public List<DmMSDebugTriggerType> getDebugTrigger() {
        if (debugTrigger == null) {
            debugTrigger = new ArrayList<DmMSDebugTriggerType>();
        }
        return this.debugTrigger;
    }

    /**
     * Gets the value of the urlRewritePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getURLRewritePolicy() {
        return urlRewritePolicy;
    }

    /**
     * Sets the value of the urlRewritePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setURLRewritePolicy(DmReference value) {
        this.urlRewritePolicy = value;
    }

    /**
     * Gets the value of the doHostRewriting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoHostRewriting() {
        return doHostRewriting;
    }

    /**
     * Sets the value of the doHostRewriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoHostRewriting(String value) {
        this.doHostRewriting = value;
    }

    /**
     * Gets the value of the sslConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLConfigType }
     *     
     */
    public DmSSLConfigType getSSLConfigType() {
        return sslConfigType;
    }

    /**
     * Sets the value of the sslConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLConfigType }
     *     
     */
    public void setSSLConfigType(DmSSLConfigType value) {
        this.sslConfigType = value;
    }

    /**
     * Gets the value of the sslProxyProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxyProfile() {
        return sslProxyProfile;
    }

    /**
     * Sets the value of the sslProxyProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxyProfile(DmReference value) {
        this.sslProxyProfile = value;
    }

    /**
     * Gets the value of the sslServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLServer() {
        return sslServer;
    }

    /**
     * Sets the value of the sslServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLServer(DmReference value) {
        this.sslServer = value;
    }

    /**
     * Gets the value of the sslsniServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLSNIServer() {
        return sslsniServer;
    }

    /**
     * Sets the value of the sslsniServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLSNIServer(DmReference value) {
        this.sslsniServer = value;
    }

    /**
     * Gets the value of the sslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClient() {
        return sslClient;
    }

    /**
     * Sets the value of the sslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClient(DmReference value) {
        this.sslClient = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
