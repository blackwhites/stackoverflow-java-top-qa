
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionFlushNSSCache complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionFlushNSSCache"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ZosNSSClient" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionFlushNSSCache", propOrder = {
    "zosNSSClient"
})
public class ActionFlushNSSCache {

    @XmlElement(name = "ZosNSSClient", required = true)
    protected DmReference zosNSSClient;

    /**
     * Gets the value of the zosNSSClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getZosNSSClient() {
        return zosNSSClient;
    }

    /**
     * Sets the value of the zosNSSClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setZosNSSClient(DmReference value) {
        this.zosNSSClient = value;
    }

}
