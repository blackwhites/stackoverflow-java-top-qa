
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigIPInterface complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigIPInterface"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IPConfigMode" type="{http://www.datapower.com/schemas/management}dmIPConfigMode" minOccurs="0"/&gt;
 *         &lt;element name="IPAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPNetAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DefaultGateway" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DefaultIPv6Gateway" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SecondaryAddress" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPNetAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StaticRoutes" type="{http://www.datapower.com/schemas/management}dmStaticRoute" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DADTransmits" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DADRetransmitTimer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StandbyControl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Group" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VirtualIP" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SecondaryVirtualIP" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Preempt" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SelfBalance" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Authentication" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt64 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HelloTimer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HoldTimer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DistAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLVSDistributionAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigIPInterface", propOrder = {
    "userSummary",
    "ipConfigMode",
    "ipAddress",
    "defaultGateway",
    "defaultIPv6Gateway",
    "secondaryAddress",
    "staticRoutes",
    "dadTransmits",
    "dadRetransmitTimer",
    "standbyControl",
    "group",
    "virtualIP",
    "secondaryVirtualIP",
    "preempt",
    "priority",
    "selfBalance",
    "authentication",
    "helloTimer",
    "holdTimer",
    "distAlg"
})
@XmlSeeAlso({
    ConfigEthernetInterface.class,
    ConfigLinkAggregation.class,
    ConfigVLANInterface.class
})
public class ConfigIPInterface
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "IPConfigMode")
    protected DmIPConfigMode ipConfigMode;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "DefaultGateway")
    protected String defaultGateway;
    @XmlElement(name = "DefaultIPv6Gateway")
    protected String defaultIPv6Gateway;
    @XmlElement(name = "SecondaryAddress")
    protected List<String> secondaryAddress;
    @XmlElement(name = "StaticRoutes")
    protected List<DmStaticRoute> staticRoutes;
    @XmlElement(name = "DADTransmits")
    protected String dadTransmits;
    @XmlElement(name = "DADRetransmitTimer")
    protected String dadRetransmitTimer;
    @XmlElement(name = "StandbyControl")
    protected String standbyControl;
    @XmlElement(name = "Group")
    protected String group;
    @XmlElement(name = "VirtualIP")
    protected String virtualIP;
    @XmlElement(name = "SecondaryVirtualIP")
    protected List<String> secondaryVirtualIP;
    @XmlElement(name = "Preempt")
    protected String preempt;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "SelfBalance")
    protected String selfBalance;
    @XmlElement(name = "Authentication")
    protected String authentication;
    @XmlElement(name = "HelloTimer")
    protected String helloTimer;
    @XmlElement(name = "HoldTimer")
    protected String holdTimer;
    @XmlElement(name = "DistAlg")
    protected String distAlg;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the ipConfigMode property.
     * 
     * @return
     *     possible object is
     *     {@link DmIPConfigMode }
     *     
     */
    public DmIPConfigMode getIPConfigMode() {
        return ipConfigMode;
    }

    /**
     * Sets the value of the ipConfigMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmIPConfigMode }
     *     
     */
    public void setIPConfigMode(DmIPConfigMode value) {
        this.ipConfigMode = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the defaultGateway property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultGateway() {
        return defaultGateway;
    }

    /**
     * Sets the value of the defaultGateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultGateway(String value) {
        this.defaultGateway = value;
    }

    /**
     * Gets the value of the defaultIPv6Gateway property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultIPv6Gateway() {
        return defaultIPv6Gateway;
    }

    /**
     * Sets the value of the defaultIPv6Gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultIPv6Gateway(String value) {
        this.defaultIPv6Gateway = value;
    }

    /**
     * Gets the value of the secondaryAddress property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the secondaryAddress property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecondaryAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getSecondaryAddress() {
        if (secondaryAddress == null) {
            secondaryAddress = new ArrayList<String>();
        }
        return this.secondaryAddress;
    }

    /**
     * Gets the value of the staticRoutes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the staticRoutes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStaticRoutes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmStaticRoute }
     * 
     * 
     */
    public List<DmStaticRoute> getStaticRoutes() {
        if (staticRoutes == null) {
            staticRoutes = new ArrayList<DmStaticRoute>();
        }
        return this.staticRoutes;
    }

    /**
     * Gets the value of the dadTransmits property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDADTransmits() {
        return dadTransmits;
    }

    /**
     * Sets the value of the dadTransmits property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDADTransmits(String value) {
        this.dadTransmits = value;
    }

    /**
     * Gets the value of the dadRetransmitTimer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDADRetransmitTimer() {
        return dadRetransmitTimer;
    }

    /**
     * Sets the value of the dadRetransmitTimer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDADRetransmitTimer(String value) {
        this.dadRetransmitTimer = value;
    }

    /**
     * Gets the value of the standbyControl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStandbyControl() {
        return standbyControl;
    }

    /**
     * Sets the value of the standbyControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStandbyControl(String value) {
        this.standbyControl = value;
    }

    /**
     * Gets the value of the group property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroup() {
        return group;
    }

    /**
     * Sets the value of the group property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroup(String value) {
        this.group = value;
    }

    /**
     * Gets the value of the virtualIP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVirtualIP() {
        return virtualIP;
    }

    /**
     * Sets the value of the virtualIP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVirtualIP(String value) {
        this.virtualIP = value;
    }

    /**
     * Gets the value of the secondaryVirtualIP property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the secondaryVirtualIP property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecondaryVirtualIP().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getSecondaryVirtualIP() {
        if (secondaryVirtualIP == null) {
            secondaryVirtualIP = new ArrayList<String>();
        }
        return this.secondaryVirtualIP;
    }

    /**
     * Gets the value of the preempt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreempt() {
        return preempt;
    }

    /**
     * Sets the value of the preempt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreempt(String value) {
        this.preempt = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the selfBalance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelfBalance() {
        return selfBalance;
    }

    /**
     * Sets the value of the selfBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelfBalance(String value) {
        this.selfBalance = value;
    }

    /**
     * Gets the value of the authentication property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthentication() {
        return authentication;
    }

    /**
     * Sets the value of the authentication property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthentication(String value) {
        this.authentication = value;
    }

    /**
     * Gets the value of the helloTimer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHelloTimer() {
        return helloTimer;
    }

    /**
     * Sets the value of the helloTimer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHelloTimer(String value) {
        this.helloTimer = value;
    }

    /**
     * Gets the value of the holdTimer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldTimer() {
        return holdTimer;
    }

    /**
     * Sets the value of the holdTimer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldTimer(String value) {
        this.holdTimer = value;
    }

    /**
     * Gets the value of the distAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistAlg() {
        return distAlg;
    }

    /**
     * Sets the value of the distAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistAlg(String value) {
        this.distAlg = value;
    }

}
