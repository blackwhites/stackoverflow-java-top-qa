
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigTAM complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigTAM"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigAccessControl"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADUseAD" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTAMVersionType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ConfigurationFile"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ADConfigurationFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLKeyFile"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLKeyStashFile"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseLocalMode"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PollInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ListenMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ListenPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ReturningUserAttributes" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPUseSSL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSSLPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSSLKeyFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSSLKeyFilePassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSSLKeyFilePasswordAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LDAPSSLKeyFileLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMUseFIPS" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMChooseNIST" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmNISTComplianceMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMUseBasicUser"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserPrincipalAttribute" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserNoDuplicates" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserSearchSuffixes" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserSuffixOptimiser" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TAMFedDirs" type="{http://www.datapower.com/schemas/management}dmTAMFedDir" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TAMAZReplicas" type="{http://www.datapower.com/schemas/management}dmTAMAZReplica" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TAMRASTrace" type="{http://www.datapower.com/schemas/management}dmTAMRASTrace" minOccurs="0"/&gt;
 *         &lt;element name="AutoRetry" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetryInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetryAttempts" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LongRetryInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigTAM", propOrder = {
    "userSummary",
    "adUseAD",
    "tamVersion",
    "configurationFile",
    "adConfigurationFile",
    "sslKeyFile",
    "sslKeyStashFile",
    "useLocalMode",
    "pollInterval",
    "listenMode",
    "listenPort",
    "returningUserAttributes",
    "ldapUseSSL",
    "ldapsslPort",
    "ldapsslKeyFile",
    "ldapsslKeyFilePassword",
    "ldapsslKeyFilePasswordAlias",
    "ldapsslKeyFileLabel",
    "tamUseFIPS",
    "tamChooseNIST",
    "tamUseBasicUser",
    "userPrincipalAttribute",
    "userNoDuplicates",
    "userSearchSuffixes",
    "userSuffixOptimiser",
    "tamFedDirs",
    "tamazReplicas",
    "tamrasTrace",
    "autoRetry",
    "retryInterval",
    "retryAttempts",
    "longRetryInterval"
})
public class ConfigTAM
    extends ConfigAccessControl
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "ADUseAD")
    protected String adUseAD;
    @XmlElement(name = "TAMVersion")
    protected String tamVersion;
    @XmlElement(name = "ConfigurationFile")
    protected String configurationFile;
    @XmlElement(name = "ADConfigurationFile")
    protected String adConfigurationFile;
    @XmlElement(name = "SSLKeyFile")
    protected String sslKeyFile;
    @XmlElement(name = "SSLKeyStashFile")
    protected String sslKeyStashFile;
    @XmlElement(name = "UseLocalMode")
    protected String useLocalMode;
    @XmlElement(name = "PollInterval")
    protected String pollInterval;
    @XmlElement(name = "ListenMode")
    protected String listenMode;
    @XmlElement(name = "ListenPort")
    protected String listenPort;
    @XmlElement(name = "ReturningUserAttributes")
    protected String returningUserAttributes;
    @XmlElement(name = "LDAPUseSSL")
    protected String ldapUseSSL;
    @XmlElement(name = "LDAPSSLPort")
    protected String ldapsslPort;
    @XmlElement(name = "LDAPSSLKeyFile")
    protected String ldapsslKeyFile;
    @XmlElement(name = "LDAPSSLKeyFilePassword")
    protected String ldapsslKeyFilePassword;
    @XmlElement(name = "LDAPSSLKeyFilePasswordAlias")
    protected DmReference ldapsslKeyFilePasswordAlias;
    @XmlElement(name = "LDAPSSLKeyFileLabel")
    protected String ldapsslKeyFileLabel;
    @XmlElement(name = "TAMUseFIPS")
    protected String tamUseFIPS;
    @XmlElement(name = "TAMChooseNIST")
    protected String tamChooseNIST;
    @XmlElement(name = "TAMUseBasicUser")
    protected String tamUseBasicUser;
    @XmlElement(name = "UserPrincipalAttribute")
    protected String userPrincipalAttribute;
    @XmlElement(name = "UserNoDuplicates")
    protected String userNoDuplicates;
    @XmlElement(name = "UserSearchSuffixes")
    protected List<String> userSearchSuffixes;
    @XmlElement(name = "UserSuffixOptimiser")
    protected String userSuffixOptimiser;
    @XmlElement(name = "TAMFedDirs")
    protected List<DmTAMFedDir> tamFedDirs;
    @XmlElement(name = "TAMAZReplicas")
    protected List<DmTAMAZReplica> tamazReplicas;
    @XmlElement(name = "TAMRASTrace")
    protected DmTAMRASTrace tamrasTrace;
    @XmlElement(name = "AutoRetry")
    protected String autoRetry;
    @XmlElement(name = "RetryInterval")
    protected String retryInterval;
    @XmlElement(name = "RetryAttempts")
    protected String retryAttempts;
    @XmlElement(name = "LongRetryInterval")
    protected String longRetryInterval;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the adUseAD property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADUseAD() {
        return adUseAD;
    }

    /**
     * Sets the value of the adUseAD property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADUseAD(String value) {
        this.adUseAD = value;
    }

    /**
     * Gets the value of the tamVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAMVersion() {
        return tamVersion;
    }

    /**
     * Sets the value of the tamVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAMVersion(String value) {
        this.tamVersion = value;
    }

    /**
     * Gets the value of the configurationFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigurationFile() {
        return configurationFile;
    }

    /**
     * Sets the value of the configurationFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigurationFile(String value) {
        this.configurationFile = value;
    }

    /**
     * Gets the value of the adConfigurationFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADConfigurationFile() {
        return adConfigurationFile;
    }

    /**
     * Sets the value of the adConfigurationFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADConfigurationFile(String value) {
        this.adConfigurationFile = value;
    }

    /**
     * Gets the value of the sslKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLKeyFile() {
        return sslKeyFile;
    }

    /**
     * Sets the value of the sslKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLKeyFile(String value) {
        this.sslKeyFile = value;
    }

    /**
     * Gets the value of the sslKeyStashFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLKeyStashFile() {
        return sslKeyStashFile;
    }

    /**
     * Sets the value of the sslKeyStashFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLKeyStashFile(String value) {
        this.sslKeyStashFile = value;
    }

    /**
     * Gets the value of the useLocalMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseLocalMode() {
        return useLocalMode;
    }

    /**
     * Sets the value of the useLocalMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseLocalMode(String value) {
        this.useLocalMode = value;
    }

    /**
     * Gets the value of the pollInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPollInterval() {
        return pollInterval;
    }

    /**
     * Sets the value of the pollInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPollInterval(String value) {
        this.pollInterval = value;
    }

    /**
     * Gets the value of the listenMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListenMode() {
        return listenMode;
    }

    /**
     * Sets the value of the listenMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListenMode(String value) {
        this.listenMode = value;
    }

    /**
     * Gets the value of the listenPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListenPort() {
        return listenPort;
    }

    /**
     * Sets the value of the listenPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListenPort(String value) {
        this.listenPort = value;
    }

    /**
     * Gets the value of the returningUserAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturningUserAttributes() {
        return returningUserAttributes;
    }

    /**
     * Sets the value of the returningUserAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturningUserAttributes(String value) {
        this.returningUserAttributes = value;
    }

    /**
     * Gets the value of the ldapUseSSL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPUseSSL() {
        return ldapUseSSL;
    }

    /**
     * Sets the value of the ldapUseSSL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPUseSSL(String value) {
        this.ldapUseSSL = value;
    }

    /**
     * Gets the value of the ldapsslPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPSSLPort() {
        return ldapsslPort;
    }

    /**
     * Sets the value of the ldapsslPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPSSLPort(String value) {
        this.ldapsslPort = value;
    }

    /**
     * Gets the value of the ldapsslKeyFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPSSLKeyFile() {
        return ldapsslKeyFile;
    }

    /**
     * Sets the value of the ldapsslKeyFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPSSLKeyFile(String value) {
        this.ldapsslKeyFile = value;
    }

    /**
     * Gets the value of the ldapsslKeyFilePassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPSSLKeyFilePassword() {
        return ldapsslKeyFilePassword;
    }

    /**
     * Sets the value of the ldapsslKeyFilePassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPSSLKeyFilePassword(String value) {
        this.ldapsslKeyFilePassword = value;
    }

    /**
     * Gets the value of the ldapsslKeyFilePasswordAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLDAPSSLKeyFilePasswordAlias() {
        return ldapsslKeyFilePasswordAlias;
    }

    /**
     * Sets the value of the ldapsslKeyFilePasswordAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLDAPSSLKeyFilePasswordAlias(DmReference value) {
        this.ldapsslKeyFilePasswordAlias = value;
    }

    /**
     * Gets the value of the ldapsslKeyFileLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPSSLKeyFileLabel() {
        return ldapsslKeyFileLabel;
    }

    /**
     * Sets the value of the ldapsslKeyFileLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPSSLKeyFileLabel(String value) {
        this.ldapsslKeyFileLabel = value;
    }

    /**
     * Gets the value of the tamUseFIPS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAMUseFIPS() {
        return tamUseFIPS;
    }

    /**
     * Sets the value of the tamUseFIPS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAMUseFIPS(String value) {
        this.tamUseFIPS = value;
    }

    /**
     * Gets the value of the tamChooseNIST property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAMChooseNIST() {
        return tamChooseNIST;
    }

    /**
     * Sets the value of the tamChooseNIST property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAMChooseNIST(String value) {
        this.tamChooseNIST = value;
    }

    /**
     * Gets the value of the tamUseBasicUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAMUseBasicUser() {
        return tamUseBasicUser;
    }

    /**
     * Sets the value of the tamUseBasicUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAMUseBasicUser(String value) {
        this.tamUseBasicUser = value;
    }

    /**
     * Gets the value of the userPrincipalAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserPrincipalAttribute() {
        return userPrincipalAttribute;
    }

    /**
     * Sets the value of the userPrincipalAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserPrincipalAttribute(String value) {
        this.userPrincipalAttribute = value;
    }

    /**
     * Gets the value of the userNoDuplicates property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserNoDuplicates() {
        return userNoDuplicates;
    }

    /**
     * Sets the value of the userNoDuplicates property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserNoDuplicates(String value) {
        this.userNoDuplicates = value;
    }

    /**
     * Gets the value of the userSearchSuffixes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the userSearchSuffixes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUserSearchSuffixes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getUserSearchSuffixes() {
        if (userSearchSuffixes == null) {
            userSearchSuffixes = new ArrayList<String>();
        }
        return this.userSearchSuffixes;
    }

    /**
     * Gets the value of the userSuffixOptimiser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSuffixOptimiser() {
        return userSuffixOptimiser;
    }

    /**
     * Sets the value of the userSuffixOptimiser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSuffixOptimiser(String value) {
        this.userSuffixOptimiser = value;
    }

    /**
     * Gets the value of the tamFedDirs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tamFedDirs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTAMFedDirs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmTAMFedDir }
     * 
     * 
     */
    public List<DmTAMFedDir> getTAMFedDirs() {
        if (tamFedDirs == null) {
            tamFedDirs = new ArrayList<DmTAMFedDir>();
        }
        return this.tamFedDirs;
    }

    /**
     * Gets the value of the tamazReplicas property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tamazReplicas property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTAMAZReplicas().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmTAMAZReplica }
     * 
     * 
     */
    public List<DmTAMAZReplica> getTAMAZReplicas() {
        if (tamazReplicas == null) {
            tamazReplicas = new ArrayList<DmTAMAZReplica>();
        }
        return this.tamazReplicas;
    }

    /**
     * Gets the value of the tamrasTrace property.
     * 
     * @return
     *     possible object is
     *     {@link DmTAMRASTrace }
     *     
     */
    public DmTAMRASTrace getTAMRASTrace() {
        return tamrasTrace;
    }

    /**
     * Sets the value of the tamrasTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmTAMRASTrace }
     *     
     */
    public void setTAMRASTrace(DmTAMRASTrace value) {
        this.tamrasTrace = value;
    }

    /**
     * Gets the value of the autoRetry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoRetry() {
        return autoRetry;
    }

    /**
     * Sets the value of the autoRetry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoRetry(String value) {
        this.autoRetry = value;
    }

    /**
     * Gets the value of the retryInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryInterval() {
        return retryInterval;
    }

    /**
     * Sets the value of the retryInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryInterval(String value) {
        this.retryInterval = value;
    }

    /**
     * Gets the value of the retryAttempts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryAttempts() {
        return retryAttempts;
    }

    /**
     * Sets the value of the retryAttempts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryAttempts(String value) {
        this.retryAttempts = value;
    }

    /**
     * Gets the value of the longRetryInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongRetryInterval() {
        return longRetryInterval;
    }

    /**
     * Sets the value of the longRetryInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongRetryInterval(String value) {
        this.longRetryInterval = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
