package xmlManagement;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Import", propOrder = {
	"InputFile",
    "Format",
    "OverwriteObjects",
    "OverwriteFiles",
    "DryRun",
    "RewriteLocalIP",
    "DeploymentPolicy",
    "DeploymentPolicyParams",
    "Object",
    "File",
    "Domain"
    
})
public class ActionRMIImport {
	
	@XmlElement(name = "InputFile", required = true)
	protected String inputFile;
	@XmlElement(name = "Format", required = true)
	protected DmRMIImportFormat format; 
	@XmlElement(name = "OverwriteObjects", required = false)
	protected DmToggle overwriteObjects;
	@XmlElement(name = "OverwriteFiles", required = false)
	protected DmToggle overwriteFiles;
	@XmlElement(name = "DryRun", required = false)
	protected DmToggle dryRun;
	@XmlElement(name = "RewriteLocalIP", required = false)
	protected DmToggle rewriteLocalIP;
	@XmlElement(name = "DeploymentPolicy", required = false)
	protected String deploymentPolicy;
	@XmlElement(name = "DeploymentPolicyParams", required = false)
	protected String deploymentPolicyParams;
	@XmlElement(name = "Domain", required = false)
	protected List<DmRMIImportDomain> domain;
	@XmlElement(name = "Object", required = false)
	protected List<DmRMIImportObject> object;
	@XmlElement(name = "File", required = false)
	protected List<DmRMIImportFile> file;
	
	/**
	 * @return the inputFile
	 */
	public String getInputFile() {
		return inputFile;
	}
	
	/**
	 * @param inputFile the inputFile to set
	 */
	public void setInputFile(String inputFile) {
		this.inputFile = inputFile;
	}
	
	/**
	 * @return the format
	 */
	public DmRMIImportFormat getFormat() {
		return format;
	}
	
	/**
	 * @param format the format to set
	 */
	public void setFormat(DmRMIImportFormat format) {
		this.format = format;
	}
	
	/**
	 * @return the overwriteObjects
	 */
	public DmToggle getOverwriteObjects() {
		return overwriteObjects;
	}
	
	/**
	 * @param overwriteObjects the overwriteObjects to set
	 */
	public void setOverwriteObjects(DmToggle overwriteObjects) {
		this.overwriteObjects = overwriteObjects;
	}
	
	/**
	 * @return the overwriteFiles
	 */
	public DmToggle getOverwriteFiles() {
		return overwriteFiles;
	}
	
	/**
	 * @param overwriteFiles the overwriteFiles to set
	 */
	public void setOverwriteFiles(DmToggle overwriteFiles) {
		this.overwriteFiles = overwriteFiles;
	}
	
	/**
	 * @return the dryRun
	 */
	public DmToggle getDryRun() {
		return dryRun;
	}
	
	/**
	 * @param dryRun the dryRun to set
	 */
	public void setDryRun(DmToggle dryRun) {
		this.dryRun = dryRun;
	}
	
	/**
	 * @return the rewriteLocalIP
	 */
	public DmToggle getRewriteLocalIP() {
		return rewriteLocalIP;
	}
	
	/**
	 * @param rewriteLocalIP the rewriteLocalIP to set
	 */
	public void setRewriteLocalIP(DmToggle rewriteLocalIP) {
		this.rewriteLocalIP = rewriteLocalIP;
	}
	
	/**
	 * @return the deploymentPolicy
	 */
	public String getDeploymentPolicy() {
		return deploymentPolicy;
	}
	
	/**
	 * @param deploymentPolicy the deploymentPolicy to set
	 */
	public void setDeploymentPolicy(String deploymentPolicy) {
		this.deploymentPolicy = deploymentPolicy;
	}
	
	/**
	 * @return the deploymentPolicyParams
	 */
	public String getDeploymentPolicyParams() {
		return deploymentPolicyParams;
	}
	
	/**
	 * @param deploymentPolicyParams the deploymentPolicyParams to set
	 */
	public void setDeploymentPolicyParams(String deploymentPolicyParams) {
		this.deploymentPolicyParams = deploymentPolicyParams;
	}
	
	/**
	 * @return the domain
	 */
	public List<DmRMIImportDomain> getDomain() {
		if(domain == null){
			domain = new ArrayList<>();
		}
		return domain;
	}

	/**
	 * @return the object
	 */
	public List<DmRMIImportObject> getObject() {
		if(object == null){
			object = new ArrayList<>();
		}
		return object;
	}


	/**
	 * @return the file
	 */
	public List<DmRMIImportFile> getFile() {
		if(file == null){
			file = new ArrayList<>();
		}
		return file;
	}
}
