
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigAAAPolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigAAAPolicy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigAccessControl"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AuthorizedCounter" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="RejectedCounter" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="NamespaceMapping" type="{http://www.datapower.com/schemas/management}dmNamespaceMapping" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExtractIdentity" type="{http://www.datapower.com/schemas/management}dmAAAPExtractIdentity"/&gt;
 *         &lt;element name="Authenticate" type="{http://www.datapower.com/schemas/management}dmAAAPAuthenticate"/&gt;
 *         &lt;element name="MapCredentials" type="{http://www.datapower.com/schemas/management}dmAAAPMapCredentials"/&gt;
 *         &lt;element name="ExtractResource" type="{http://www.datapower.com/schemas/management}dmAAAPExtractResource"/&gt;
 *         &lt;element name="MapResource" type="{http://www.datapower.com/schemas/management}dmAAAPMapResource"/&gt;
 *         &lt;element name="Authorize" type="{http://www.datapower.com/schemas/management}dmAAAPAuthorize"/&gt;
 *         &lt;element name="PostProcess" type="{http://www.datapower.com/schemas/management}dmAAAPPostProcess"/&gt;
 *         &lt;element name="SAMLAttribute" type="{http://www.datapower.com/schemas/management}dmSAMLAttributeNameAndValue" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LTPAAttributes" type="{http://www.datapower.com/schemas/management}dmLTPAUserAttributeNameAndValue" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TransactionPriority" type="{http://www.datapower.com/schemas/management}dmAAATransactionPriority" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SAMLValcred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SAMLSigningKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SAMLSigningCert" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SAMLSigningHashAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCryptoHashAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SAMLSigningAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCryptoSigningAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPsuffix" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogAllowed"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogAllowedLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogRejected"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogRejectedLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSSecureConversationCryptoKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SAMLSourceIDMappingFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PingIdentityCompatibility" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SAML2MetadataFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoSValve" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLDAPVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnforceSOAPActor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSSecActorRoleID" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUSMHTTPHeader" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AZSMHTTPHeader" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DynConfig"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDynConfigType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ExternalAAATemplate" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DynConfigCustomURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigAAAPolicy", propOrder = {
    "userSummary",
    "authorizedCounter",
    "rejectedCounter",
    "namespaceMapping",
    "extractIdentity",
    "authenticate",
    "mapCredentials",
    "extractResource",
    "mapResource",
    "authorize",
    "postProcess",
    "samlAttribute",
    "ltpaAttributes",
    "transactionPriority",
    "samlValcred",
    "samlSigningKey",
    "samlSigningCert",
    "samlSigningHashAlg",
    "samlSigningAlg",
    "ldaPsuffix",
    "logAllowed",
    "logAllowedLevel",
    "logRejected",
    "logRejectedLevel",
    "wsSecureConversationCryptoKey",
    "samlSourceIDMappingFile",
    "pingIdentityCompatibility",
    "saml2MetadataFile",
    "doSValve",
    "ldapVersion",
    "enforceSOAPActor",
    "wsSecActorRoleID",
    "ausmhttpHeader",
    "azsmhttpHeader",
    "dynConfig",
    "externalAAATemplate",
    "dynConfigCustomURL"
})
public class ConfigAAAPolicy
    extends ConfigAccessControl
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "AuthorizedCounter")
    protected DmReference authorizedCounter;
    @XmlElement(name = "RejectedCounter")
    protected DmReference rejectedCounter;
    @XmlElement(name = "NamespaceMapping")
    protected List<DmNamespaceMapping> namespaceMapping;
    @XmlElement(name = "ExtractIdentity")
    protected DmAAAPExtractIdentity extractIdentity;
    @XmlElement(name = "Authenticate")
    protected DmAAAPAuthenticate authenticate;
    @XmlElement(name = "MapCredentials")
    protected DmAAAPMapCredentials mapCredentials;
    @XmlElement(name = "ExtractResource")
    protected DmAAAPExtractResource extractResource;
    @XmlElement(name = "MapResource")
    protected DmAAAPMapResource mapResource;
    @XmlElement(name = "Authorize")
    protected DmAAAPAuthorize authorize;
    @XmlElement(name = "PostProcess")
    protected DmAAAPPostProcess postProcess;
    @XmlElement(name = "SAMLAttribute")
    protected List<DmSAMLAttributeNameAndValue> samlAttribute;
    @XmlElement(name = "LTPAAttributes")
    protected List<DmLTPAUserAttributeNameAndValue> ltpaAttributes;
    @XmlElement(name = "TransactionPriority")
    protected List<DmAAATransactionPriority> transactionPriority;
    @XmlElement(name = "SAMLValcred")
    protected DmReference samlValcred;
    @XmlElement(name = "SAMLSigningKey")
    protected DmReference samlSigningKey;
    @XmlElement(name = "SAMLSigningCert")
    protected DmReference samlSigningCert;
    @XmlElement(name = "SAMLSigningHashAlg")
    protected String samlSigningHashAlg;
    @XmlElement(name = "SAMLSigningAlg")
    protected String samlSigningAlg;
    @XmlElement(name = "LDAPsuffix")
    protected String ldaPsuffix;
    @XmlElement(name = "LogAllowed")
    protected String logAllowed;
    @XmlElement(name = "LogAllowedLevel")
    protected String logAllowedLevel;
    @XmlElement(name = "LogRejected")
    protected String logRejected;
    @XmlElement(name = "LogRejectedLevel")
    protected String logRejectedLevel;
    @XmlElement(name = "WSSecureConversationCryptoKey")
    protected DmReference wsSecureConversationCryptoKey;
    @XmlElement(name = "SAMLSourceIDMappingFile")
    protected String samlSourceIDMappingFile;
    @XmlElement(name = "PingIdentityCompatibility")
    protected String pingIdentityCompatibility;
    @XmlElement(name = "SAML2MetadataFile")
    protected String saml2MetadataFile;
    @XmlElement(name = "DoSValve")
    protected String doSValve;
    @XmlElement(name = "LDAPVersion")
    protected String ldapVersion;
    @XmlElement(name = "EnforceSOAPActor")
    protected String enforceSOAPActor;
    @XmlElement(name = "WSSecActorRoleID")
    protected String wsSecActorRoleID;
    @XmlElement(name = "AUSMHTTPHeader")
    protected List<String> ausmhttpHeader;
    @XmlElement(name = "AZSMHTTPHeader")
    protected List<String> azsmhttpHeader;
    @XmlElement(name = "DynConfig")
    protected String dynConfig;
    @XmlElement(name = "ExternalAAATemplate")
    protected DmReference externalAAATemplate;
    @XmlElement(name = "DynConfigCustomURL")
    protected String dynConfigCustomURL;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the authorizedCounter property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAuthorizedCounter() {
        return authorizedCounter;
    }

    /**
     * Sets the value of the authorizedCounter property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAuthorizedCounter(DmReference value) {
        this.authorizedCounter = value;
    }

    /**
     * Gets the value of the rejectedCounter property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getRejectedCounter() {
        return rejectedCounter;
    }

    /**
     * Sets the value of the rejectedCounter property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setRejectedCounter(DmReference value) {
        this.rejectedCounter = value;
    }

    /**
     * Gets the value of the namespaceMapping property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namespaceMapping property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamespaceMapping().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmNamespaceMapping }
     * 
     * 
     */
    public List<DmNamespaceMapping> getNamespaceMapping() {
        if (namespaceMapping == null) {
            namespaceMapping = new ArrayList<DmNamespaceMapping>();
        }
        return this.namespaceMapping;
    }

    /**
     * Gets the value of the extractIdentity property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPExtractIdentity }
     *     
     */
    public DmAAAPExtractIdentity getExtractIdentity() {
        return extractIdentity;
    }

    /**
     * Sets the value of the extractIdentity property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPExtractIdentity }
     *     
     */
    public void setExtractIdentity(DmAAAPExtractIdentity value) {
        this.extractIdentity = value;
    }

    /**
     * Gets the value of the authenticate property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPAuthenticate }
     *     
     */
    public DmAAAPAuthenticate getAuthenticate() {
        return authenticate;
    }

    /**
     * Sets the value of the authenticate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPAuthenticate }
     *     
     */
    public void setAuthenticate(DmAAAPAuthenticate value) {
        this.authenticate = value;
    }

    /**
     * Gets the value of the mapCredentials property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPMapCredentials }
     *     
     */
    public DmAAAPMapCredentials getMapCredentials() {
        return mapCredentials;
    }

    /**
     * Sets the value of the mapCredentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPMapCredentials }
     *     
     */
    public void setMapCredentials(DmAAAPMapCredentials value) {
        this.mapCredentials = value;
    }

    /**
     * Gets the value of the extractResource property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPExtractResource }
     *     
     */
    public DmAAAPExtractResource getExtractResource() {
        return extractResource;
    }

    /**
     * Sets the value of the extractResource property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPExtractResource }
     *     
     */
    public void setExtractResource(DmAAAPExtractResource value) {
        this.extractResource = value;
    }

    /**
     * Gets the value of the mapResource property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPMapResource }
     *     
     */
    public DmAAAPMapResource getMapResource() {
        return mapResource;
    }

    /**
     * Sets the value of the mapResource property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPMapResource }
     *     
     */
    public void setMapResource(DmAAAPMapResource value) {
        this.mapResource = value;
    }

    /**
     * Gets the value of the authorize property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPAuthorize }
     *     
     */
    public DmAAAPAuthorize getAuthorize() {
        return authorize;
    }

    /**
     * Sets the value of the authorize property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPAuthorize }
     *     
     */
    public void setAuthorize(DmAAAPAuthorize value) {
        this.authorize = value;
    }

    /**
     * Gets the value of the postProcess property.
     * 
     * @return
     *     possible object is
     *     {@link DmAAAPPostProcess }
     *     
     */
    public DmAAAPPostProcess getPostProcess() {
        return postProcess;
    }

    /**
     * Sets the value of the postProcess property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAAAPPostProcess }
     *     
     */
    public void setPostProcess(DmAAAPPostProcess value) {
        this.postProcess = value;
    }

    /**
     * Gets the value of the samlAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the samlAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSAMLAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmSAMLAttributeNameAndValue }
     * 
     * 
     */
    public List<DmSAMLAttributeNameAndValue> getSAMLAttribute() {
        if (samlAttribute == null) {
            samlAttribute = new ArrayList<DmSAMLAttributeNameAndValue>();
        }
        return this.samlAttribute;
    }

    /**
     * Gets the value of the ltpaAttributes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ltpaAttributes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLTPAAttributes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmLTPAUserAttributeNameAndValue }
     * 
     * 
     */
    public List<DmLTPAUserAttributeNameAndValue> getLTPAAttributes() {
        if (ltpaAttributes == null) {
            ltpaAttributes = new ArrayList<DmLTPAUserAttributeNameAndValue>();
        }
        return this.ltpaAttributes;
    }

    /**
     * Gets the value of the transactionPriority property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transactionPriority property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransactionPriority().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmAAATransactionPriority }
     * 
     * 
     */
    public List<DmAAATransactionPriority> getTransactionPriority() {
        if (transactionPriority == null) {
            transactionPriority = new ArrayList<DmAAATransactionPriority>();
        }
        return this.transactionPriority;
    }

    /**
     * Gets the value of the samlValcred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSAMLValcred() {
        return samlValcred;
    }

    /**
     * Sets the value of the samlValcred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSAMLValcred(DmReference value) {
        this.samlValcred = value;
    }

    /**
     * Gets the value of the samlSigningKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSAMLSigningKey() {
        return samlSigningKey;
    }

    /**
     * Sets the value of the samlSigningKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSAMLSigningKey(DmReference value) {
        this.samlSigningKey = value;
    }

    /**
     * Gets the value of the samlSigningCert property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSAMLSigningCert() {
        return samlSigningCert;
    }

    /**
     * Sets the value of the samlSigningCert property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSAMLSigningCert(DmReference value) {
        this.samlSigningCert = value;
    }

    /**
     * Gets the value of the samlSigningHashAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAMLSigningHashAlg() {
        return samlSigningHashAlg;
    }

    /**
     * Sets the value of the samlSigningHashAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAMLSigningHashAlg(String value) {
        this.samlSigningHashAlg = value;
    }

    /**
     * Gets the value of the samlSigningAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAMLSigningAlg() {
        return samlSigningAlg;
    }

    /**
     * Sets the value of the samlSigningAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAMLSigningAlg(String value) {
        this.samlSigningAlg = value;
    }

    /**
     * Gets the value of the ldaPsuffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPsuffix() {
        return ldaPsuffix;
    }

    /**
     * Sets the value of the ldaPsuffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPsuffix(String value) {
        this.ldaPsuffix = value;
    }

    /**
     * Gets the value of the logAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogAllowed() {
        return logAllowed;
    }

    /**
     * Sets the value of the logAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogAllowed(String value) {
        this.logAllowed = value;
    }

    /**
     * Gets the value of the logAllowedLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogAllowedLevel() {
        return logAllowedLevel;
    }

    /**
     * Sets the value of the logAllowedLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogAllowedLevel(String value) {
        this.logAllowedLevel = value;
    }

    /**
     * Gets the value of the logRejected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogRejected() {
        return logRejected;
    }

    /**
     * Sets the value of the logRejected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogRejected(String value) {
        this.logRejected = value;
    }

    /**
     * Gets the value of the logRejectedLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogRejectedLevel() {
        return logRejectedLevel;
    }

    /**
     * Sets the value of the logRejectedLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogRejectedLevel(String value) {
        this.logRejectedLevel = value;
    }

    /**
     * Gets the value of the wsSecureConversationCryptoKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSSecureConversationCryptoKey() {
        return wsSecureConversationCryptoKey;
    }

    /**
     * Sets the value of the wsSecureConversationCryptoKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSSecureConversationCryptoKey(DmReference value) {
        this.wsSecureConversationCryptoKey = value;
    }

    /**
     * Gets the value of the samlSourceIDMappingFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAMLSourceIDMappingFile() {
        return samlSourceIDMappingFile;
    }

    /**
     * Sets the value of the samlSourceIDMappingFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAMLSourceIDMappingFile(String value) {
        this.samlSourceIDMappingFile = value;
    }

    /**
     * Gets the value of the pingIdentityCompatibility property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPingIdentityCompatibility() {
        return pingIdentityCompatibility;
    }

    /**
     * Sets the value of the pingIdentityCompatibility property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPingIdentityCompatibility(String value) {
        this.pingIdentityCompatibility = value;
    }

    /**
     * Gets the value of the saml2MetadataFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAML2MetadataFile() {
        return saml2MetadataFile;
    }

    /**
     * Sets the value of the saml2MetadataFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAML2MetadataFile(String value) {
        this.saml2MetadataFile = value;
    }

    /**
     * Gets the value of the doSValve property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoSValve() {
        return doSValve;
    }

    /**
     * Sets the value of the doSValve property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoSValve(String value) {
        this.doSValve = value;
    }

    /**
     * Gets the value of the ldapVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPVersion() {
        return ldapVersion;
    }

    /**
     * Sets the value of the ldapVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPVersion(String value) {
        this.ldapVersion = value;
    }

    /**
     * Gets the value of the enforceSOAPActor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnforceSOAPActor() {
        return enforceSOAPActor;
    }

    /**
     * Sets the value of the enforceSOAPActor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnforceSOAPActor(String value) {
        this.enforceSOAPActor = value;
    }

    /**
     * Gets the value of the wsSecActorRoleID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSSecActorRoleID() {
        return wsSecActorRoleID;
    }

    /**
     * Sets the value of the wsSecActorRoleID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSSecActorRoleID(String value) {
        this.wsSecActorRoleID = value;
    }

    /**
     * Gets the value of the ausmhttpHeader property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ausmhttpHeader property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAUSMHTTPHeader().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAUSMHTTPHeader() {
        if (ausmhttpHeader == null) {
            ausmhttpHeader = new ArrayList<String>();
        }
        return this.ausmhttpHeader;
    }

    /**
     * Gets the value of the azsmhttpHeader property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the azsmhttpHeader property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAZSMHTTPHeader().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAZSMHTTPHeader() {
        if (azsmhttpHeader == null) {
            azsmhttpHeader = new ArrayList<String>();
        }
        return this.azsmhttpHeader;
    }

    /**
     * Gets the value of the dynConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDynConfig() {
        return dynConfig;
    }

    /**
     * Sets the value of the dynConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDynConfig(String value) {
        this.dynConfig = value;
    }

    /**
     * Gets the value of the externalAAATemplate property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getExternalAAATemplate() {
        return externalAAATemplate;
    }

    /**
     * Sets the value of the externalAAATemplate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setExternalAAATemplate(DmReference value) {
        this.externalAAATemplate = value;
    }

    /**
     * Gets the value of the dynConfigCustomURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDynConfigCustomURL() {
        return dynConfigCustomURL;
    }

    /**
     * Sets the value of the dynConfigCustomURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDynConfigCustomURL(String value) {
        this.dynConfigCustomURL = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
