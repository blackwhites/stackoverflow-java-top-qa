
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigConfigBase complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigConfigBase"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="mAdminState" type="{http://www.datapower.com/schemas/management}dmAdminState" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigConfigBase", propOrder = {
    "mAdminState"
})
@XmlSeeAlso({
    ConfigAccessControl.class,
    ConfigAccessControlList.class,
    ConfigAppSecurityPolicy.class,
    ConfigAuditLog.class,
    ConfigB2BCPA.class,
    ConfigB2BCPACollaboration.class,
    ConfigB2BCPAReceiverSetting.class,
    ConfigB2BCPASenderSetting.class,
    ConfigB2BGateway.class,
    ConfigB2BPersistence.class,
    ConfigB2BProfile.class,
    ConfigB2BProfileGroup.class,
    ConfigB2BXPathRoutingPolicy.class,
    ConfigCacheGrid.class,
    ConfigCloudConnectorService.class,
    ConfigCloudGatewayService.class,
    ConfigCompactFlash.class,
    ConfigCompileOptionsPolicy.class,
    ConfigConfigDeploymentPolicy.class,
    ConfigConformancePolicy.class,
    ConfigCrypto.class,
    ConfigDeploymentPolicyParametersBinding.class,
    ConfigDeviceSettings.class,
    ConfigDFDLSettings.class,
    ConfigDomainAvailability.class,
    ConfigDomainSettings.class,
    ConfigDynamicXMLContentMap.class,
    ConfigEventlog.class,
    ConfigFormsLoginPolicy.class,
    ConfigFTPQuoteCommands.class,
    ConfigGatewayBase.class,
    ConfigGeneratedPolicy.class,
    ConfigHTTPInputConversionMap.class,
    ConfigHTTPUserAgent.class,
    ConfigILMTAgent.class,
    ConfigImportPackage.class,
    ConfigIMSConnect.class,
    ConfigIncludeConfig.class,
    ConfigInteropService.class,
    ConfigIPInterface.class,
    ConfigIPMILanChannel.class,
    ConfigIPMIUser.class,
    ConfigIPMulticast.class,
    ConfigISAMReverseProxy.class,
    ConfigISAMReverseProxyJunction.class,
    ConfigISAMRuntime.class,
    ConfigIScsiChapConfig.class,
    ConfigIScsiHBAConfig.class,
    ConfigIScsiInitiatorConfig.class,
    ConfigIScsiTargetConfig.class,
    ConfigIScsiVolumeConfig.class,
    ConfigJMSServer.class,
    ConfigJSONSettings.class,
    ConfigLanguage.class,
    ConfigLDAPConnectionPool.class,
    ConfigLLMPolicyBase.class,
    ConfigLLMRouteBase.class,
    ConfigLoadBalancerGroup.class,
    ConfigLogLabel.class,
    ConfigLuna.class,
    ConfigLunaPartition.class,
    ConfigMatching.class,
    ConfigMCFBase.class,
    ConfigMessageContentFilters.class,
    ConfigMessageFlowControl.class,
    ConfigMPGWErrorAction.class,
    ConfigMPGWErrorHandlingPolicy.class,
    ConfigMQAUI.class,
    ConfigMQConfiguration.class,
    ConfigMTOMPolicy.class,
    ConfigNameValueProfile.class,
    ConfigNetworkConfiguration.class,
    ConfigNFSClientSettings.class,
    ConfigNFSDynamicMounts.class,
    ConfigNFSStaticMount.class,
    ConfigODR.class,
    ConfigODRConnectorGroup.class,
    ConfigPasswordAlias.class,
    ConfigPattern.class,
    ConfigPeerGroup.class,
    ConfigPolicyAttachments.class,
    ConfigPolicyParameters.class,
    ConfigQuotaEnforcementServer.class,
    ConfigRaidVolume.class,
    ConfigRuntimeSettings.class,
    ConfigSecureBackupMode.class,
    ConfigSecureCloudConnector.class,
    ConfigSecureGatewayClient.class,
    ConfigService.class,
    ConfigShellAlias.class,
    ConfigSimpleCountMonitor.class,
    ConfigSLMAction.class,
    ConfigSLMCredClass.class,
    ConfigSLMPolicy.class,
    ConfigSLMRsrcClass.class,
    ConfigSLMSchedule.class,
    ConfigSMTPServerConnection.class,
    ConfigSNMPSettings.class,
    ConfigSourceProtocolHandler.class,
    ConfigSQLDataSource.class,
    ConfigStandaloneStandbyControl.class,
    ConfigStandaloneStandbyControlInterface.class,
    ConfigStatistics.class,
    ConfigStylePolicy.class,
    ConfigStylePolicyAction.class,
    ConfigStylePolicyRuleBase.class,
    ConfigThrottler.class,
    ConfigUDDIRegistry.class,
    ConfigURLMap.class,
    ConfigURLRefreshPolicy.class,
    ConfigURLRewritePolicy.class,
    ConfigUser.class,
    ConfigUserGroup.class,
    ConfigWCCService.class,
    ConfigWebAppErrorHandlingPolicy.class,
    ConfigWebAppFW.class,
    ConfigWebAppRequest.class,
    ConfigWebAppResponse.class,
    ConfigWebAppSessionPolicy.class,
    ConfigWebServiceMonitor.class,
    ConfigWebServicesAgent.class,
    ConfigWebServiceSubscription.class,
    ConfigWebTokenService.class,
    ConfigWSEndpointRewritePolicy.class,
    ConfigWSRRServer.class,
    ConfigWSStylePolicy.class,
    ConfigXMLManager.class,
    Configxmltrace.class,
    ConfigZHybridTargetControlService.class,
    ConfigZosNSSClient.class
})
public class ConfigConfigBase {

    @XmlSchemaType(name = "string")
    @XmlElement(name = "mAdminState")
    protected DmAdminState mAdminState;
    @XmlElement(name = "state")
    protected DmRMIConfigState state;
    
    

    /**
	 * @return the state
	 */
	public DmRMIConfigState getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(DmRMIConfigState state) {
		this.state = state;
	}

	/**
     * Gets the value of the mAdminState property.
     * 
     * @return
     *     possible object is
     *     {@link DmAdminState }
     *     
     */
    public DmAdminState getMAdminState() {
        return mAdminState;
    }

    /**
     * Sets the value of the mAdminState property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmAdminState }
     *     
     */
    public void setMAdminState(DmAdminState value) {
        this.mAdminState = value;
    }

}
