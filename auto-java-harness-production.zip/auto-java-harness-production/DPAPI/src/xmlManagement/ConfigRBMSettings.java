
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigRBMSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigRBMSettings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigAccessControl"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUMethod"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmRBMAuthenticateType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUZOSNSSConfig" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AUKerberosKeytab" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AUCustomURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUInfoURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUSSLValcred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AUHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AULDAPSearchForDN" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AULDAPBindDN" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AULDAPBindPassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AULDAPBindPasswordAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AULDAPSearchParameters" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AULDAPPrefix" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUForceDNLDAPOrder" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPsuffix" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AULDAPLoadBalanceGroup" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AUCacheAllow"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAAACacheType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUCacheTTL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AULDAPReadTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCMethod"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmRBMMapType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCCustomURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCLDAPSearchForGroup" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCHost" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCLDAPSSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MCLDAPLoadBalanceGroup" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MCLDAPBindDN" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCLDAPBindPassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCLDAPBindPasswordAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MCLDAPSearchParameters" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MCInfoURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCLDAPReadTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLDAPVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FallbackLogin" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmRBMFallbackLoginType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FallbackUser" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ApplyToCLI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RestrictAdminToSerialPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MinPasswordLength"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequireMixedCase"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequireDigit"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequireNonAlphaNumeric"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisallowUsernameSubstring"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoPasswordAging"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxPasswordAge" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoPasswordHistory"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumOldPasswords" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CliTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxFailedLogin"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LockoutPeriod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MCForceDNLDAPOrder" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PasswordHashAlgorithm" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPasswordFileHashAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LDAPSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="LDAPSSLClientProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MCLDAPSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="MCLDAPSSLClientProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigRBMSettings", propOrder = {
    "userSummary",
    "auMethod",
    "auzosnssConfig",
    "auKerberosKeytab",
    "auCustomURL",
    "auInfoURL",
    "ausslValcred",
    "auHost",
    "auPort",
    "auldapSearchForDN",
    "auldapBindDN",
    "auldapBindPassword",
    "auldapBindPasswordAlias",
    "auldapSearchParameters",
    "auldapPrefix",
    "auForceDNLDAPOrder",
    "ldaPsuffix",
    "ldapsslProxyProfile",
    "auldapLoadBalanceGroup",
    "auCacheAllow",
    "auCacheTTL",
    "auldapReadTimeout",
    "mcMethod",
    "mcCustomURL",
    "mcldapSearchForGroup",
    "mcHost",
    "mcPort",
    "mcldapsslProxyProfile",
    "mcldapLoadBalanceGroup",
    "mcldapBindDN",
    "mcldapBindPassword",
    "mcldapBindPasswordAlias",
    "mcldapSearchParameters",
    "mcInfoURL",
    "mcldapReadTimeout",
    "ldapVersion",
    "fallbackLogin",
    "fallbackUser",
    "applyToCLI",
    "restrictAdminToSerialPort",
    "minPasswordLength",
    "requireMixedCase",
    "requireDigit",
    "requireNonAlphaNumeric",
    "disallowUsernameSubstring",
    "doPasswordAging",
    "maxPasswordAge",
    "doPasswordHistory",
    "numOldPasswords",
    "cliTimeout",
    "maxFailedLogin",
    "lockoutPeriod",
    "mcForceDNLDAPOrder",
    "passwordHashAlgorithm",
    "ldapsslClientConfigType",
    "ldapsslClientProfile",
    "mcldapsslClientConfigType",
    "mcldapsslClientProfile"
})
public class ConfigRBMSettings
    extends ConfigAccessControl
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "AUMethod")
    protected String auMethod;
    @XmlElement(name = "AUZOSNSSConfig")
    protected DmReference auzosnssConfig;
    @XmlElement(name = "AUKerberosKeytab")
    protected DmReference auKerberosKeytab;
    @XmlElement(name = "AUCustomURL")
    protected String auCustomURL;
    @XmlElement(name = "AUInfoURL")
    protected String auInfoURL;
    @XmlElement(name = "AUSSLValcred")
    protected DmReference ausslValcred;
    @XmlElement(name = "AUHost")
    protected String auHost;
    @XmlElement(name = "AUPort")
    protected String auPort;
    @XmlElement(name = "AULDAPSearchForDN")
    protected String auldapSearchForDN;
    @XmlElement(name = "AULDAPBindDN")
    protected String auldapBindDN;
    @XmlElement(name = "AULDAPBindPassword")
    protected String auldapBindPassword;
    @XmlElement(name = "AULDAPBindPasswordAlias")
    protected DmReference auldapBindPasswordAlias;
    @XmlElement(name = "AULDAPSearchParameters")
    protected DmReference auldapSearchParameters;
    @XmlElement(name = "AULDAPPrefix")
    protected String auldapPrefix;
    @XmlElement(name = "AUForceDNLDAPOrder")
    protected String auForceDNLDAPOrder;
    @XmlElement(name = "LDAPsuffix")
    protected String ldaPsuffix;
    @XmlElement(name = "LDAPSSLProxyProfile")
    protected DmReference ldapsslProxyProfile;
    @XmlElement(name = "AULDAPLoadBalanceGroup")
    protected DmReference auldapLoadBalanceGroup;
    @XmlElement(name = "AUCacheAllow")
    protected String auCacheAllow;
    @XmlElement(name = "AUCacheTTL")
    protected String auCacheTTL;
    @XmlElement(name = "AULDAPReadTimeout")
    protected String auldapReadTimeout;
    @XmlElement(name = "MCMethod")
    protected String mcMethod;
    @XmlElement(name = "MCCustomURL")
    protected String mcCustomURL;
    @XmlElement(name = "MCLDAPSearchForGroup")
    protected String mcldapSearchForGroup;
    @XmlElement(name = "MCHost")
    protected String mcHost;
    @XmlElement(name = "MCPort")
    protected String mcPort;
    @XmlElement(name = "MCLDAPSSLProxyProfile")
    protected DmReference mcldapsslProxyProfile;
    @XmlElement(name = "MCLDAPLoadBalanceGroup")
    protected DmReference mcldapLoadBalanceGroup;
    @XmlElement(name = "MCLDAPBindDN")
    protected String mcldapBindDN;
    @XmlElement(name = "MCLDAPBindPassword")
    protected String mcldapBindPassword;
    @XmlElement(name = "MCLDAPBindPasswordAlias")
    protected DmReference mcldapBindPasswordAlias;
    @XmlElement(name = "MCLDAPSearchParameters")
    protected DmReference mcldapSearchParameters;
    @XmlElement(name = "MCInfoURL")
    protected String mcInfoURL;
    @XmlElement(name = "MCLDAPReadTimeout")
    protected String mcldapReadTimeout;
    @XmlElement(name = "LDAPVersion")
    protected String ldapVersion;
    @XmlElement(name = "FallbackLogin")
    protected String fallbackLogin;
    @XmlElement(name = "FallbackUser")
    protected List<DmReference> fallbackUser;
    @XmlElement(name = "ApplyToCLI")
    protected String applyToCLI;
    @XmlElement(name = "RestrictAdminToSerialPort")
    protected String restrictAdminToSerialPort;
    @XmlElement(name = "MinPasswordLength")
    protected String minPasswordLength;
    @XmlElement(name = "RequireMixedCase")
    protected String requireMixedCase;
    @XmlElement(name = "RequireDigit")
    protected String requireDigit;
    @XmlElement(name = "RequireNonAlphaNumeric")
    protected String requireNonAlphaNumeric;
    @XmlElement(name = "DisallowUsernameSubstring")
    protected String disallowUsernameSubstring;
    @XmlElement(name = "DoPasswordAging")
    protected String doPasswordAging;
    @XmlElement(name = "MaxPasswordAge")
    protected String maxPasswordAge;
    @XmlElement(name = "DoPasswordHistory")
    protected String doPasswordHistory;
    @XmlElement(name = "NumOldPasswords")
    protected String numOldPasswords;
    @XmlElement(name = "CliTimeout")
    protected String cliTimeout;
    @XmlElement(name = "MaxFailedLogin")
    protected String maxFailedLogin;
    @XmlElement(name = "LockoutPeriod")
    protected String lockoutPeriod;
    @XmlElement(name = "MCForceDNLDAPOrder")
    protected String mcForceDNLDAPOrder;
    @XmlElement(name = "PasswordHashAlgorithm")
    protected String passwordHashAlgorithm;
    @XmlElement(name = "LDAPSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType ldapsslClientConfigType;
    @XmlElement(name = "LDAPSSLClientProfile")
    protected DmReference ldapsslClientProfile;
    @XmlElement(name = "MCLDAPSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType mcldapsslClientConfigType;
    @XmlElement(name = "MCLDAPSSLClientProfile")
    protected DmReference mcldapsslClientProfile;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the auMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUMethod() {
        return auMethod;
    }

    /**
     * Sets the value of the auMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUMethod(String value) {
        this.auMethod = value;
    }

    /**
     * Gets the value of the auzosnssConfig property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAUZOSNSSConfig() {
        return auzosnssConfig;
    }

    /**
     * Sets the value of the auzosnssConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAUZOSNSSConfig(DmReference value) {
        this.auzosnssConfig = value;
    }

    /**
     * Gets the value of the auKerberosKeytab property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAUKerberosKeytab() {
        return auKerberosKeytab;
    }

    /**
     * Sets the value of the auKerberosKeytab property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAUKerberosKeytab(DmReference value) {
        this.auKerberosKeytab = value;
    }

    /**
     * Gets the value of the auCustomURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUCustomURL() {
        return auCustomURL;
    }

    /**
     * Sets the value of the auCustomURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUCustomURL(String value) {
        this.auCustomURL = value;
    }

    /**
     * Gets the value of the auInfoURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUInfoURL() {
        return auInfoURL;
    }

    /**
     * Sets the value of the auInfoURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUInfoURL(String value) {
        this.auInfoURL = value;
    }

    /**
     * Gets the value of the ausslValcred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAUSSLValcred() {
        return ausslValcred;
    }

    /**
     * Sets the value of the ausslValcred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAUSSLValcred(DmReference value) {
        this.ausslValcred = value;
    }

    /**
     * Gets the value of the auHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUHost() {
        return auHost;
    }

    /**
     * Sets the value of the auHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUHost(String value) {
        this.auHost = value;
    }

    /**
     * Gets the value of the auPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUPort() {
        return auPort;
    }

    /**
     * Sets the value of the auPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUPort(String value) {
        this.auPort = value;
    }

    /**
     * Gets the value of the auldapSearchForDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAULDAPSearchForDN() {
        return auldapSearchForDN;
    }

    /**
     * Sets the value of the auldapSearchForDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAULDAPSearchForDN(String value) {
        this.auldapSearchForDN = value;
    }

    /**
     * Gets the value of the auldapBindDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAULDAPBindDN() {
        return auldapBindDN;
    }

    /**
     * Sets the value of the auldapBindDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAULDAPBindDN(String value) {
        this.auldapBindDN = value;
    }

    /**
     * Gets the value of the auldapBindPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAULDAPBindPassword() {
        return auldapBindPassword;
    }

    /**
     * Sets the value of the auldapBindPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAULDAPBindPassword(String value) {
        this.auldapBindPassword = value;
    }

    /**
     * Gets the value of the auldapBindPasswordAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAULDAPBindPasswordAlias() {
        return auldapBindPasswordAlias;
    }

    /**
     * Sets the value of the auldapBindPasswordAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAULDAPBindPasswordAlias(DmReference value) {
        this.auldapBindPasswordAlias = value;
    }

    /**
     * Gets the value of the auldapSearchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAULDAPSearchParameters() {
        return auldapSearchParameters;
    }

    /**
     * Sets the value of the auldapSearchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAULDAPSearchParameters(DmReference value) {
        this.auldapSearchParameters = value;
    }

    /**
     * Gets the value of the auldapPrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAULDAPPrefix() {
        return auldapPrefix;
    }

    /**
     * Sets the value of the auldapPrefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAULDAPPrefix(String value) {
        this.auldapPrefix = value;
    }

    /**
     * Gets the value of the auForceDNLDAPOrder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUForceDNLDAPOrder() {
        return auForceDNLDAPOrder;
    }

    /**
     * Sets the value of the auForceDNLDAPOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUForceDNLDAPOrder(String value) {
        this.auForceDNLDAPOrder = value;
    }

    /**
     * Gets the value of the ldaPsuffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPsuffix() {
        return ldaPsuffix;
    }

    /**
     * Sets the value of the ldaPsuffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPsuffix(String value) {
        this.ldaPsuffix = value;
    }

    /**
     * Gets the value of the ldapsslProxyProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLDAPSSLProxyProfile() {
        return ldapsslProxyProfile;
    }

    /**
     * Sets the value of the ldapsslProxyProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLDAPSSLProxyProfile(DmReference value) {
        this.ldapsslProxyProfile = value;
    }

    /**
     * Gets the value of the auldapLoadBalanceGroup property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAULDAPLoadBalanceGroup() {
        return auldapLoadBalanceGroup;
    }

    /**
     * Sets the value of the auldapLoadBalanceGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAULDAPLoadBalanceGroup(DmReference value) {
        this.auldapLoadBalanceGroup = value;
    }

    /**
     * Gets the value of the auCacheAllow property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUCacheAllow() {
        return auCacheAllow;
    }

    /**
     * Sets the value of the auCacheAllow property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUCacheAllow(String value) {
        this.auCacheAllow = value;
    }

    /**
     * Gets the value of the auCacheTTL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUCacheTTL() {
        return auCacheTTL;
    }

    /**
     * Sets the value of the auCacheTTL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUCacheTTL(String value) {
        this.auCacheTTL = value;
    }

    /**
     * Gets the value of the auldapReadTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAULDAPReadTimeout() {
        return auldapReadTimeout;
    }

    /**
     * Sets the value of the auldapReadTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAULDAPReadTimeout(String value) {
        this.auldapReadTimeout = value;
    }

    /**
     * Gets the value of the mcMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCMethod() {
        return mcMethod;
    }

    /**
     * Sets the value of the mcMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCMethod(String value) {
        this.mcMethod = value;
    }

    /**
     * Gets the value of the mcCustomURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCCustomURL() {
        return mcCustomURL;
    }

    /**
     * Sets the value of the mcCustomURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCCustomURL(String value) {
        this.mcCustomURL = value;
    }

    /**
     * Gets the value of the mcldapSearchForGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCLDAPSearchForGroup() {
        return mcldapSearchForGroup;
    }

    /**
     * Sets the value of the mcldapSearchForGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCLDAPSearchForGroup(String value) {
        this.mcldapSearchForGroup = value;
    }

    /**
     * Gets the value of the mcHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCHost() {
        return mcHost;
    }

    /**
     * Sets the value of the mcHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCHost(String value) {
        this.mcHost = value;
    }

    /**
     * Gets the value of the mcPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCPort() {
        return mcPort;
    }

    /**
     * Sets the value of the mcPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCPort(String value) {
        this.mcPort = value;
    }

    /**
     * Gets the value of the mcldapsslProxyProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMCLDAPSSLProxyProfile() {
        return mcldapsslProxyProfile;
    }

    /**
     * Sets the value of the mcldapsslProxyProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMCLDAPSSLProxyProfile(DmReference value) {
        this.mcldapsslProxyProfile = value;
    }

    /**
     * Gets the value of the mcldapLoadBalanceGroup property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMCLDAPLoadBalanceGroup() {
        return mcldapLoadBalanceGroup;
    }

    /**
     * Sets the value of the mcldapLoadBalanceGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMCLDAPLoadBalanceGroup(DmReference value) {
        this.mcldapLoadBalanceGroup = value;
    }

    /**
     * Gets the value of the mcldapBindDN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCLDAPBindDN() {
        return mcldapBindDN;
    }

    /**
     * Sets the value of the mcldapBindDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCLDAPBindDN(String value) {
        this.mcldapBindDN = value;
    }

    /**
     * Gets the value of the mcldapBindPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCLDAPBindPassword() {
        return mcldapBindPassword;
    }

    /**
     * Sets the value of the mcldapBindPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCLDAPBindPassword(String value) {
        this.mcldapBindPassword = value;
    }

    /**
     * Gets the value of the mcldapBindPasswordAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMCLDAPBindPasswordAlias() {
        return mcldapBindPasswordAlias;
    }

    /**
     * Sets the value of the mcldapBindPasswordAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMCLDAPBindPasswordAlias(DmReference value) {
        this.mcldapBindPasswordAlias = value;
    }

    /**
     * Gets the value of the mcldapSearchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMCLDAPSearchParameters() {
        return mcldapSearchParameters;
    }

    /**
     * Sets the value of the mcldapSearchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMCLDAPSearchParameters(DmReference value) {
        this.mcldapSearchParameters = value;
    }

    /**
     * Gets the value of the mcInfoURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCInfoURL() {
        return mcInfoURL;
    }

    /**
     * Sets the value of the mcInfoURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCInfoURL(String value) {
        this.mcInfoURL = value;
    }

    /**
     * Gets the value of the mcldapReadTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCLDAPReadTimeout() {
        return mcldapReadTimeout;
    }

    /**
     * Sets the value of the mcldapReadTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCLDAPReadTimeout(String value) {
        this.mcldapReadTimeout = value;
    }

    /**
     * Gets the value of the ldapVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLDAPVersion() {
        return ldapVersion;
    }

    /**
     * Sets the value of the ldapVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLDAPVersion(String value) {
        this.ldapVersion = value;
    }

    /**
     * Gets the value of the fallbackLogin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFallbackLogin() {
        return fallbackLogin;
    }

    /**
     * Sets the value of the fallbackLogin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFallbackLogin(String value) {
        this.fallbackLogin = value;
    }

    /**
     * Gets the value of the fallbackUser property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fallbackUser property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFallbackUser().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getFallbackUser() {
        if (fallbackUser == null) {
            fallbackUser = new ArrayList<DmReference>();
        }
        return this.fallbackUser;
    }

    /**
     * Gets the value of the applyToCLI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplyToCLI() {
        return applyToCLI;
    }

    /**
     * Sets the value of the applyToCLI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplyToCLI(String value) {
        this.applyToCLI = value;
    }

    /**
     * Gets the value of the restrictAdminToSerialPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictAdminToSerialPort() {
        return restrictAdminToSerialPort;
    }

    /**
     * Sets the value of the restrictAdminToSerialPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictAdminToSerialPort(String value) {
        this.restrictAdminToSerialPort = value;
    }

    /**
     * Gets the value of the minPasswordLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinPasswordLength() {
        return minPasswordLength;
    }

    /**
     * Sets the value of the minPasswordLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinPasswordLength(String value) {
        this.minPasswordLength = value;
    }

    /**
     * Gets the value of the requireMixedCase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequireMixedCase() {
        return requireMixedCase;
    }

    /**
     * Sets the value of the requireMixedCase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequireMixedCase(String value) {
        this.requireMixedCase = value;
    }

    /**
     * Gets the value of the requireDigit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequireDigit() {
        return requireDigit;
    }

    /**
     * Sets the value of the requireDigit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequireDigit(String value) {
        this.requireDigit = value;
    }

    /**
     * Gets the value of the requireNonAlphaNumeric property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequireNonAlphaNumeric() {
        return requireNonAlphaNumeric;
    }

    /**
     * Sets the value of the requireNonAlphaNumeric property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequireNonAlphaNumeric(String value) {
        this.requireNonAlphaNumeric = value;
    }

    /**
     * Gets the value of the disallowUsernameSubstring property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisallowUsernameSubstring() {
        return disallowUsernameSubstring;
    }

    /**
     * Sets the value of the disallowUsernameSubstring property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisallowUsernameSubstring(String value) {
        this.disallowUsernameSubstring = value;
    }

    /**
     * Gets the value of the doPasswordAging property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoPasswordAging() {
        return doPasswordAging;
    }

    /**
     * Sets the value of the doPasswordAging property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoPasswordAging(String value) {
        this.doPasswordAging = value;
    }

    /**
     * Gets the value of the maxPasswordAge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxPasswordAge() {
        return maxPasswordAge;
    }

    /**
     * Sets the value of the maxPasswordAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxPasswordAge(String value) {
        this.maxPasswordAge = value;
    }

    /**
     * Gets the value of the doPasswordHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoPasswordHistory() {
        return doPasswordHistory;
    }

    /**
     * Sets the value of the doPasswordHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoPasswordHistory(String value) {
        this.doPasswordHistory = value;
    }

    /**
     * Gets the value of the numOldPasswords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumOldPasswords() {
        return numOldPasswords;
    }

    /**
     * Sets the value of the numOldPasswords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumOldPasswords(String value) {
        this.numOldPasswords = value;
    }

    /**
     * Gets the value of the cliTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCliTimeout() {
        return cliTimeout;
    }

    /**
     * Sets the value of the cliTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCliTimeout(String value) {
        this.cliTimeout = value;
    }

    /**
     * Gets the value of the maxFailedLogin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxFailedLogin() {
        return maxFailedLogin;
    }

    /**
     * Sets the value of the maxFailedLogin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxFailedLogin(String value) {
        this.maxFailedLogin = value;
    }

    /**
     * Gets the value of the lockoutPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLockoutPeriod() {
        return lockoutPeriod;
    }

    /**
     * Sets the value of the lockoutPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLockoutPeriod(String value) {
        this.lockoutPeriod = value;
    }

    /**
     * Gets the value of the mcForceDNLDAPOrder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCForceDNLDAPOrder() {
        return mcForceDNLDAPOrder;
    }

    /**
     * Sets the value of the mcForceDNLDAPOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCForceDNLDAPOrder(String value) {
        this.mcForceDNLDAPOrder = value;
    }

    /**
     * Gets the value of the passwordHashAlgorithm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPasswordHashAlgorithm() {
        return passwordHashAlgorithm;
    }

    /**
     * Sets the value of the passwordHashAlgorithm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPasswordHashAlgorithm(String value) {
        this.passwordHashAlgorithm = value;
    }

    /**
     * Gets the value of the ldapsslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getLDAPSSLClientConfigType() {
        return ldapsslClientConfigType;
    }

    /**
     * Sets the value of the ldapsslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setLDAPSSLClientConfigType(DmSSLClientConfigType value) {
        this.ldapsslClientConfigType = value;
    }

    /**
     * Gets the value of the ldapsslClientProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLDAPSSLClientProfile() {
        return ldapsslClientProfile;
    }

    /**
     * Sets the value of the ldapsslClientProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLDAPSSLClientProfile(DmReference value) {
        this.ldapsslClientProfile = value;
    }

    /**
     * Gets the value of the mcldapsslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getMCLDAPSSLClientConfigType() {
        return mcldapsslClientConfigType;
    }

    /**
     * Sets the value of the mcldapsslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setMCLDAPSSLClientConfigType(DmSSLClientConfigType value) {
        this.mcldapsslClientConfigType = value;
    }

    /**
     * Gets the value of the mcldapsslClientProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMCLDAPSSLClientProfile() {
        return mcldapsslClientProfile;
    }

    /**
     * Sets the value of the mcldapsslClientProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMCLDAPSSLClientProfile(DmReference value) {
        this.mcldapsslClientProfile = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
