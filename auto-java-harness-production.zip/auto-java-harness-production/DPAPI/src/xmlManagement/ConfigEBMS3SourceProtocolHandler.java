
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigEBMS3SourceProtocolHandler complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigEBMS3SourceProtocolHandler"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigSourceProtocolHandler"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLocalIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PersistentConnections" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCompression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxURLLen" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxTotalHdrLen" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxHdrCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxNameHdrLen" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxValueHdrLen" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxQueryStringLen" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ACL" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AAAPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="CredentialCharset" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCredentialCharset {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLServerConfigType" type="{http://www.datapower.com/schemas/management}dmSSLConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLSNIServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigEBMS3SourceProtocolHandler", propOrder = {
    "userSummary",
    "localAddress",
    "localPort",
    "httpVersion",
    "persistentConnections",
    "allowCompression",
    "maxURLLen",
    "maxTotalHdrLen",
    "maxHdrCount",
    "maxNameHdrLen",
    "maxValueHdrLen",
    "maxQueryStringLen",
    "sslProxy",
    "acl",
    "aaaPolicy",
    "credentialCharset",
    "sslServerConfigType",
    "sslServer",
    "sslsniServer"
})
public class ConfigEBMS3SourceProtocolHandler
    extends ConfigSourceProtocolHandler
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "LocalAddress")
    protected String localAddress;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "HTTPVersion")
    protected String httpVersion;
    @XmlElement(name = "PersistentConnections")
    protected String persistentConnections;
    @XmlElement(name = "AllowCompression")
    protected String allowCompression;
    @XmlElement(name = "MaxURLLen")
    protected String maxURLLen;
    @XmlElement(name = "MaxTotalHdrLen")
    protected String maxTotalHdrLen;
    @XmlElement(name = "MaxHdrCount")
    protected String maxHdrCount;
    @XmlElement(name = "MaxNameHdrLen")
    protected String maxNameHdrLen;
    @XmlElement(name = "MaxValueHdrLen")
    protected String maxValueHdrLen;
    @XmlElement(name = "MaxQueryStringLen")
    protected String maxQueryStringLen;
    @XmlElement(name = "SSLProxy")
    protected DmReference sslProxy;
    @XmlElement(name = "ACL")
    protected DmReference acl;
    @XmlElement(name = "AAAPolicy")
    protected DmReference aaaPolicy;
    @XmlElement(name = "CredentialCharset")
    protected String credentialCharset;
    @XmlElement(name = "SSLServerConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLConfigType sslServerConfigType;
    @XmlElement(name = "SSLServer")
    protected DmReference sslServer;
    @XmlElement(name = "SSLSNIServer")
    protected DmReference sslsniServer;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the localAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAddress() {
        return localAddress;
    }

    /**
     * Sets the value of the localAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAddress(String value) {
        this.localAddress = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the httpVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPVersion() {
        return httpVersion;
    }

    /**
     * Sets the value of the httpVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPVersion(String value) {
        this.httpVersion = value;
    }

    /**
     * Gets the value of the persistentConnections property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersistentConnections() {
        return persistentConnections;
    }

    /**
     * Sets the value of the persistentConnections property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersistentConnections(String value) {
        this.persistentConnections = value;
    }

    /**
     * Gets the value of the allowCompression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCompression() {
        return allowCompression;
    }

    /**
     * Sets the value of the allowCompression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCompression(String value) {
        this.allowCompression = value;
    }

    /**
     * Gets the value of the maxURLLen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxURLLen() {
        return maxURLLen;
    }

    /**
     * Sets the value of the maxURLLen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxURLLen(String value) {
        this.maxURLLen = value;
    }

    /**
     * Gets the value of the maxTotalHdrLen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxTotalHdrLen() {
        return maxTotalHdrLen;
    }

    /**
     * Sets the value of the maxTotalHdrLen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxTotalHdrLen(String value) {
        this.maxTotalHdrLen = value;
    }

    /**
     * Gets the value of the maxHdrCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxHdrCount() {
        return maxHdrCount;
    }

    /**
     * Sets the value of the maxHdrCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxHdrCount(String value) {
        this.maxHdrCount = value;
    }

    /**
     * Gets the value of the maxNameHdrLen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxNameHdrLen() {
        return maxNameHdrLen;
    }

    /**
     * Sets the value of the maxNameHdrLen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxNameHdrLen(String value) {
        this.maxNameHdrLen = value;
    }

    /**
     * Gets the value of the maxValueHdrLen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxValueHdrLen() {
        return maxValueHdrLen;
    }

    /**
     * Sets the value of the maxValueHdrLen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxValueHdrLen(String value) {
        this.maxValueHdrLen = value;
    }

    /**
     * Gets the value of the maxQueryStringLen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxQueryStringLen() {
        return maxQueryStringLen;
    }

    /**
     * Sets the value of the maxQueryStringLen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxQueryStringLen(String value) {
        this.maxQueryStringLen = value;
    }

    /**
     * Gets the value of the sslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxy() {
        return sslProxy;
    }

    /**
     * Sets the value of the sslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxy(DmReference value) {
        this.sslProxy = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getACL() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setACL(DmReference value) {
        this.acl = value;
    }

    /**
     * Gets the value of the aaaPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAAAPolicy() {
        return aaaPolicy;
    }

    /**
     * Sets the value of the aaaPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAAAPolicy(DmReference value) {
        this.aaaPolicy = value;
    }

    /**
     * Gets the value of the credentialCharset property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCredentialCharset() {
        return credentialCharset;
    }

    /**
     * Sets the value of the credentialCharset property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCredentialCharset(String value) {
        this.credentialCharset = value;
    }

    /**
     * Gets the value of the sslServerConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLConfigType }
     *     
     */
    public DmSSLConfigType getSSLServerConfigType() {
        return sslServerConfigType;
    }

    /**
     * Sets the value of the sslServerConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLConfigType }
     *     
     */
    public void setSSLServerConfigType(DmSSLConfigType value) {
        this.sslServerConfigType = value;
    }

    /**
     * Gets the value of the sslServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLServer() {
        return sslServer;
    }

    /**
     * Sets the value of the sslServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLServer(DmReference value) {
        this.sslServer = value;
    }

    /**
     * Gets the value of the sslsniServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLSNIServer() {
        return sslsniServer;
    }

    /**
     * Sets the value of the sslsniServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLSNIServer(DmReference value) {
        this.sslsniServer = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
