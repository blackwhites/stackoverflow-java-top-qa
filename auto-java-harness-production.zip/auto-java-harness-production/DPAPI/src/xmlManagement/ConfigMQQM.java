
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigMQQM complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigMQQM"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigMQQMBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HostName"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="QMname" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CCSID" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ChannelName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CSPUserId" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CSPPassword" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CSPPasswordAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Heartbeat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UserName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaximumMessageSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CacheTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UnitsOfWork" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AutomaticBackout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackoutThreshold" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackoutQueueName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TotalConnectionLimit" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InitialConnections" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SharingConversations" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ShareSingleConversation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLkey" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PermitInsecureServers" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PermitSSLv3" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLcipher" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmMQSSLCiphers {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ConvertInput" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AutoRetry" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetryInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetryAttempts" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LongRetryInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ReportingInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AlternateUser" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalAddress" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="SSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigMQQM", propOrder = {
    "userSummary",
    "hostName",
    "qMname",
    "ccsid",
    "channelName",
    "cspUserId",
    "cspPassword",
    "cspPasswordAlias",
    "heartbeat",
    "userName",
    "maximumMessageSize",
    "cacheTimeout",
    "unitsOfWork",
    "automaticBackout",
    "backoutThreshold",
    "backoutQueueName",
    "totalConnectionLimit",
    "initialConnections",
    "sharingConversations",
    "shareSingleConversation",
    "ssLkey",
    "permitInsecureServers",
    "permitSSLv3",
    "ssLcipher",
    "sslProxyProfile",
    "convertInput",
    "autoRetry",
    "retryInterval",
    "retryAttempts",
    "longRetryInterval",
    "reportingInterval",
    "alternateUser",
    "localAddress",
    "xmlManager",
    "sslClientConfigType",
    "sslClient"
})
public class ConfigMQQM
    extends ConfigMQQMBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "HostName")
    protected String hostName;
    @XmlElement(name = "QMname")
    protected String qMname;
    @XmlElement(name = "CCSID")
    protected String ccsid;
    @XmlElement(name = "ChannelName")
    protected String channelName;
    @XmlElement(name = "CSPUserId")
    protected String cspUserId;
    @XmlElement(name = "CSPPassword")
    protected String cspPassword;
    @XmlElement(name = "CSPPasswordAlias")
    protected DmReference cspPasswordAlias;
    @XmlElement(name = "Heartbeat")
    protected String heartbeat;
    @XmlElement(name = "UserName")
    protected String userName;
    @XmlElement(name = "MaximumMessageSize")
    protected String maximumMessageSize;
    @XmlElement(name = "CacheTimeout")
    protected String cacheTimeout;
    @XmlElement(name = "UnitsOfWork")
    protected String unitsOfWork;
    @XmlElement(name = "AutomaticBackout")
    protected String automaticBackout;
    @XmlElement(name = "BackoutThreshold")
    protected String backoutThreshold;
    @XmlElement(name = "BackoutQueueName")
    protected String backoutQueueName;
    @XmlElement(name = "TotalConnectionLimit")
    protected String totalConnectionLimit;
    @XmlElement(name = "InitialConnections")
    protected String initialConnections;
    @XmlElement(name = "SharingConversations")
    protected String sharingConversations;
    @XmlElement(name = "ShareSingleConversation")
    protected String shareSingleConversation;
    @XmlElement(name = "SSLkey")
    protected String ssLkey;
    @XmlElement(name = "PermitInsecureServers")
    protected String permitInsecureServers;
    @XmlElement(name = "PermitSSLv3")
    protected String permitSSLv3;
    @XmlElement(name = "SSLcipher")
    protected String ssLcipher;
    @XmlElement(name = "SSLProxyProfile")
    protected DmReference sslProxyProfile;
    @XmlElement(name = "ConvertInput")
    protected String convertInput;
    @XmlElement(name = "AutoRetry")
    protected String autoRetry;
    @XmlElement(name = "RetryInterval")
    protected String retryInterval;
    @XmlElement(name = "RetryAttempts")
    protected String retryAttempts;
    @XmlElement(name = "LongRetryInterval")
    protected String longRetryInterval;
    @XmlElement(name = "ReportingInterval")
    protected String reportingInterval;
    @XmlElement(name = "AlternateUser")
    protected String alternateUser;
    @XmlElement(name = "LocalAddress")
    protected String localAddress;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "SSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType sslClientConfigType;
    @XmlElement(name = "SSLClient")
    protected DmReference sslClient;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the hostName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * Sets the value of the hostName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostName(String value) {
        this.hostName = value;
    }

    /**
     * Gets the value of the qMname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQMname() {
        return qMname;
    }

    /**
     * Sets the value of the qMname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQMname(String value) {
        this.qMname = value;
    }

    /**
     * Gets the value of the ccsid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCCSID() {
        return ccsid;
    }

    /**
     * Sets the value of the ccsid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCCSID(String value) {
        this.ccsid = value;
    }

    /**
     * Gets the value of the channelName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelName() {
        return channelName;
    }

    /**
     * Sets the value of the channelName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelName(String value) {
        this.channelName = value;
    }

    /**
     * Gets the value of the cspUserId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSPUserId() {
        return cspUserId;
    }

    /**
     * Sets the value of the cspUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSPUserId(String value) {
        this.cspUserId = value;
    }

    /**
     * Gets the value of the cspPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSPPassword() {
        return cspPassword;
    }

    /**
     * Sets the value of the cspPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSPPassword(String value) {
        this.cspPassword = value;
    }

    /**
     * Gets the value of the cspPasswordAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getCSPPasswordAlias() {
        return cspPasswordAlias;
    }

    /**
     * Sets the value of the cspPasswordAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setCSPPasswordAlias(DmReference value) {
        this.cspPasswordAlias = value;
    }

    /**
     * Gets the value of the heartbeat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeartbeat() {
        return heartbeat;
    }

    /**
     * Sets the value of the heartbeat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeartbeat(String value) {
        this.heartbeat = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the maximumMessageSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumMessageSize() {
        return maximumMessageSize;
    }

    /**
     * Sets the value of the maximumMessageSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumMessageSize(String value) {
        this.maximumMessageSize = value;
    }

    /**
     * Gets the value of the cacheTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheTimeout() {
        return cacheTimeout;
    }

    /**
     * Sets the value of the cacheTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheTimeout(String value) {
        this.cacheTimeout = value;
    }

    /**
     * Gets the value of the unitsOfWork property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitsOfWork() {
        return unitsOfWork;
    }

    /**
     * Sets the value of the unitsOfWork property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitsOfWork(String value) {
        this.unitsOfWork = value;
    }

    /**
     * Gets the value of the automaticBackout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutomaticBackout() {
        return automaticBackout;
    }

    /**
     * Sets the value of the automaticBackout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutomaticBackout(String value) {
        this.automaticBackout = value;
    }

    /**
     * Gets the value of the backoutThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackoutThreshold() {
        return backoutThreshold;
    }

    /**
     * Sets the value of the backoutThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackoutThreshold(String value) {
        this.backoutThreshold = value;
    }

    /**
     * Gets the value of the backoutQueueName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackoutQueueName() {
        return backoutQueueName;
    }

    /**
     * Sets the value of the backoutQueueName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackoutQueueName(String value) {
        this.backoutQueueName = value;
    }

    /**
     * Gets the value of the totalConnectionLimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalConnectionLimit() {
        return totalConnectionLimit;
    }

    /**
     * Sets the value of the totalConnectionLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalConnectionLimit(String value) {
        this.totalConnectionLimit = value;
    }

    /**
     * Gets the value of the initialConnections property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialConnections() {
        return initialConnections;
    }

    /**
     * Sets the value of the initialConnections property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialConnections(String value) {
        this.initialConnections = value;
    }

    /**
     * Gets the value of the sharingConversations property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSharingConversations() {
        return sharingConversations;
    }

    /**
     * Sets the value of the sharingConversations property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSharingConversations(String value) {
        this.sharingConversations = value;
    }

    /**
     * Gets the value of the shareSingleConversation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShareSingleConversation() {
        return shareSingleConversation;
    }

    /**
     * Sets the value of the shareSingleConversation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShareSingleConversation(String value) {
        this.shareSingleConversation = value;
    }

    /**
     * Gets the value of the ssLkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLkey() {
        return ssLkey;
    }

    /**
     * Sets the value of the ssLkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLkey(String value) {
        this.ssLkey = value;
    }

    /**
     * Gets the value of the permitInsecureServers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermitInsecureServers() {
        return permitInsecureServers;
    }

    /**
     * Sets the value of the permitInsecureServers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermitInsecureServers(String value) {
        this.permitInsecureServers = value;
    }

    /**
     * Gets the value of the permitSSLv3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermitSSLv3() {
        return permitSSLv3;
    }

    /**
     * Sets the value of the permitSSLv3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermitSSLv3(String value) {
        this.permitSSLv3 = value;
    }

    /**
     * Gets the value of the ssLcipher property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLcipher() {
        return ssLcipher;
    }

    /**
     * Sets the value of the ssLcipher property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLcipher(String value) {
        this.ssLcipher = value;
    }

    /**
     * Gets the value of the sslProxyProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxyProfile() {
        return sslProxyProfile;
    }

    /**
     * Sets the value of the sslProxyProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxyProfile(DmReference value) {
        this.sslProxyProfile = value;
    }

    /**
     * Gets the value of the convertInput property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvertInput() {
        return convertInput;
    }

    /**
     * Sets the value of the convertInput property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvertInput(String value) {
        this.convertInput = value;
    }

    /**
     * Gets the value of the autoRetry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoRetry() {
        return autoRetry;
    }

    /**
     * Sets the value of the autoRetry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoRetry(String value) {
        this.autoRetry = value;
    }

    /**
     * Gets the value of the retryInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryInterval() {
        return retryInterval;
    }

    /**
     * Sets the value of the retryInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryInterval(String value) {
        this.retryInterval = value;
    }

    /**
     * Gets the value of the retryAttempts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryAttempts() {
        return retryAttempts;
    }

    /**
     * Sets the value of the retryAttempts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryAttempts(String value) {
        this.retryAttempts = value;
    }

    /**
     * Gets the value of the longRetryInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongRetryInterval() {
        return longRetryInterval;
    }

    /**
     * Sets the value of the longRetryInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongRetryInterval(String value) {
        this.longRetryInterval = value;
    }

    /**
     * Gets the value of the reportingInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReportingInterval() {
        return reportingInterval;
    }

    /**
     * Sets the value of the reportingInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReportingInterval(String value) {
        this.reportingInterval = value;
    }

    /**
     * Gets the value of the alternateUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternateUser() {
        return alternateUser;
    }

    /**
     * Sets the value of the alternateUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternateUser(String value) {
        this.alternateUser = value;
    }

    /**
     * Gets the value of the localAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAddress() {
        return localAddress;
    }

    /**
     * Sets the value of the localAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAddress(String value) {
        this.localAddress = value;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the sslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getSSLClientConfigType() {
        return sslClientConfigType;
    }

    /**
     * Sets the value of the sslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setSSLClientConfigType(DmSSLClientConfigType value) {
        this.sslClientConfigType = value;
    }

    /**
     * Gets the value of the sslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClient() {
        return sslClient;
    }

    /**
     * Sets the value of the sslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClient(DmReference value) {
        this.sslClient = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
