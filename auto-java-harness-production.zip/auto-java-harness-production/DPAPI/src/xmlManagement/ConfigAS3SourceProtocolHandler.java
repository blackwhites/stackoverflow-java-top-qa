
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigAS3SourceProtocolHandler complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigAS3SourceProtocolHandler"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigSourceProtocolHandler"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLocalIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FilesystemType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFTPFilesystemType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PersistentFilesystemTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VirtualDirectories" type="{http://www.datapower.com/schemas/management}dmFTPServerVirtualDirectory" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DefaultDirectory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxFilenameLength" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ACL" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="RequireTLS" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="PasswordAAAPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="CertificateAAAPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AllowCCC" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Passive" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFTPPassive {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UsePasvPortRange" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PasvMinPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PasvMaxPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PasvIdleTimeOut" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisablePASVIPCheck" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DisablePORTIPCheck" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseAlternatePASVAddr" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AlternatePASVAddr" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowLISTCmd" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowDELECmd" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DataEncryption" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFTPDataEncryption {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCompression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowSTOU" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UniqueFilenamePrefix" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowREST" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RestartTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IdleTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFTPResponseType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseStorage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFTPResponseStorage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TemporaryStorageSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseNFSMount" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ResponseSuffix" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLServerConfigType" type="{http://www.datapower.com/schemas/management}dmSSLConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLSNIServer" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigAS3SourceProtocolHandler", propOrder = {
    "userSummary",
    "localAddress",
    "localPort",
    "filesystemType",
    "persistentFilesystemTimeout",
    "virtualDirectories",
    "defaultDirectory",
    "maxFilenameLength",
    "acl",
    "requireTLS",
    "sslProxy",
    "passwordAAAPolicy",
    "certificateAAAPolicy",
    "allowCCC",
    "passive",
    "usePasvPortRange",
    "pasvMinPort",
    "pasvMaxPort",
    "pasvIdleTimeOut",
    "disablePASVIPCheck",
    "disablePORTIPCheck",
    "useAlternatePASVAddr",
    "alternatePASVAddr",
    "allowLISTCmd",
    "allowDELECmd",
    "dataEncryption",
    "allowCompression",
    "allowSTOU",
    "uniqueFilenamePrefix",
    "allowREST",
    "restartTimeout",
    "idleTimeout",
    "responseType",
    "responseStorage",
    "temporaryStorageSize",
    "responseNFSMount",
    "responseSuffix",
    "responseURL",
    "sslServerConfigType",
    "sslServer",
    "sslsniServer"
})
public class ConfigAS3SourceProtocolHandler
    extends ConfigSourceProtocolHandler
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "LocalAddress")
    protected String localAddress;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "FilesystemType")
    protected String filesystemType;
    @XmlElement(name = "PersistentFilesystemTimeout")
    protected String persistentFilesystemTimeout;
    @XmlElement(name = "VirtualDirectories")
    protected List<DmFTPServerVirtualDirectory> virtualDirectories;
    @XmlElement(name = "DefaultDirectory")
    protected String defaultDirectory;
    @XmlElement(name = "MaxFilenameLength")
    protected String maxFilenameLength;
    @XmlElement(name = "ACL")
    protected DmReference acl;
    @XmlElement(name = "RequireTLS")
    protected String requireTLS;
    @XmlElement(name = "SSLProxy")
    protected DmReference sslProxy;
    @XmlElement(name = "PasswordAAAPolicy")
    protected DmReference passwordAAAPolicy;
    @XmlElement(name = "CertificateAAAPolicy")
    protected DmReference certificateAAAPolicy;
    @XmlElement(name = "AllowCCC")
    protected String allowCCC;
    @XmlElement(name = "Passive")
    protected String passive;
    @XmlElement(name = "UsePasvPortRange")
    protected String usePasvPortRange;
    @XmlElement(name = "PasvMinPort")
    protected String pasvMinPort;
    @XmlElement(name = "PasvMaxPort")
    protected String pasvMaxPort;
    @XmlElement(name = "PasvIdleTimeOut")
    protected String pasvIdleTimeOut;
    @XmlElement(name = "DisablePASVIPCheck")
    protected String disablePASVIPCheck;
    @XmlElement(name = "DisablePORTIPCheck")
    protected String disablePORTIPCheck;
    @XmlElement(name = "UseAlternatePASVAddr")
    protected String useAlternatePASVAddr;
    @XmlElement(name = "AlternatePASVAddr")
    protected String alternatePASVAddr;
    @XmlElement(name = "AllowLISTCmd")
    protected String allowLISTCmd;
    @XmlElement(name = "AllowDELECmd")
    protected String allowDELECmd;
    @XmlElement(name = "DataEncryption")
    protected String dataEncryption;
    @XmlElement(name = "AllowCompression")
    protected String allowCompression;
    @XmlElement(name = "AllowSTOU")
    protected String allowSTOU;
    @XmlElement(name = "UniqueFilenamePrefix")
    protected String uniqueFilenamePrefix;
    @XmlElement(name = "AllowREST")
    protected String allowREST;
    @XmlElement(name = "RestartTimeout")
    protected String restartTimeout;
    @XmlElement(name = "IdleTimeout")
    protected String idleTimeout;
    @XmlElement(name = "ResponseType")
    protected String responseType;
    @XmlElement(name = "ResponseStorage")
    protected String responseStorage;
    @XmlElement(name = "TemporaryStorageSize")
    protected String temporaryStorageSize;
    @XmlElement(name = "ResponseNFSMount")
    protected DmReference responseNFSMount;
    @XmlElement(name = "ResponseSuffix")
    protected String responseSuffix;
    @XmlElement(name = "ResponseURL")
    protected String responseURL;
    @XmlElement(name = "SSLServerConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLConfigType sslServerConfigType;
    @XmlElement(name = "SSLServer")
    protected DmReference sslServer;
    @XmlElement(name = "SSLSNIServer")
    protected DmReference sslsniServer;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the localAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAddress() {
        return localAddress;
    }

    /**
     * Sets the value of the localAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAddress(String value) {
        this.localAddress = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the filesystemType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilesystemType() {
        return filesystemType;
    }

    /**
     * Sets the value of the filesystemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilesystemType(String value) {
        this.filesystemType = value;
    }

    /**
     * Gets the value of the persistentFilesystemTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersistentFilesystemTimeout() {
        return persistentFilesystemTimeout;
    }

    /**
     * Sets the value of the persistentFilesystemTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersistentFilesystemTimeout(String value) {
        this.persistentFilesystemTimeout = value;
    }

    /**
     * Gets the value of the virtualDirectories property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the virtualDirectories property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVirtualDirectories().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmFTPServerVirtualDirectory }
     * 
     * 
     */
    public List<DmFTPServerVirtualDirectory> getVirtualDirectories() {
        if (virtualDirectories == null) {
            virtualDirectories = new ArrayList<DmFTPServerVirtualDirectory>();
        }
        return this.virtualDirectories;
    }

    /**
     * Gets the value of the defaultDirectory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultDirectory() {
        return defaultDirectory;
    }

    /**
     * Sets the value of the defaultDirectory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultDirectory(String value) {
        this.defaultDirectory = value;
    }

    /**
     * Gets the value of the maxFilenameLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxFilenameLength() {
        return maxFilenameLength;
    }

    /**
     * Sets the value of the maxFilenameLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxFilenameLength(String value) {
        this.maxFilenameLength = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getACL() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setACL(DmReference value) {
        this.acl = value;
    }

    /**
     * Gets the value of the requireTLS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequireTLS() {
        return requireTLS;
    }

    /**
     * Sets the value of the requireTLS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequireTLS(String value) {
        this.requireTLS = value;
    }

    /**
     * Gets the value of the sslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxy() {
        return sslProxy;
    }

    /**
     * Sets the value of the sslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxy(DmReference value) {
        this.sslProxy = value;
    }

    /**
     * Gets the value of the passwordAAAPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getPasswordAAAPolicy() {
        return passwordAAAPolicy;
    }

    /**
     * Sets the value of the passwordAAAPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setPasswordAAAPolicy(DmReference value) {
        this.passwordAAAPolicy = value;
    }

    /**
     * Gets the value of the certificateAAAPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getCertificateAAAPolicy() {
        return certificateAAAPolicy;
    }

    /**
     * Sets the value of the certificateAAAPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setCertificateAAAPolicy(DmReference value) {
        this.certificateAAAPolicy = value;
    }

    /**
     * Gets the value of the allowCCC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCCC() {
        return allowCCC;
    }

    /**
     * Sets the value of the allowCCC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCCC(String value) {
        this.allowCCC = value;
    }

    /**
     * Gets the value of the passive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassive() {
        return passive;
    }

    /**
     * Sets the value of the passive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassive(String value) {
        this.passive = value;
    }

    /**
     * Gets the value of the usePasvPortRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsePasvPortRange() {
        return usePasvPortRange;
    }

    /**
     * Sets the value of the usePasvPortRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsePasvPortRange(String value) {
        this.usePasvPortRange = value;
    }

    /**
     * Gets the value of the pasvMinPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPasvMinPort() {
        return pasvMinPort;
    }

    /**
     * Sets the value of the pasvMinPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPasvMinPort(String value) {
        this.pasvMinPort = value;
    }

    /**
     * Gets the value of the pasvMaxPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPasvMaxPort() {
        return pasvMaxPort;
    }

    /**
     * Sets the value of the pasvMaxPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPasvMaxPort(String value) {
        this.pasvMaxPort = value;
    }

    /**
     * Gets the value of the pasvIdleTimeOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPasvIdleTimeOut() {
        return pasvIdleTimeOut;
    }

    /**
     * Sets the value of the pasvIdleTimeOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPasvIdleTimeOut(String value) {
        this.pasvIdleTimeOut = value;
    }

    /**
     * Gets the value of the disablePASVIPCheck property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisablePASVIPCheck() {
        return disablePASVIPCheck;
    }

    /**
     * Sets the value of the disablePASVIPCheck property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisablePASVIPCheck(String value) {
        this.disablePASVIPCheck = value;
    }

    /**
     * Gets the value of the disablePORTIPCheck property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisablePORTIPCheck() {
        return disablePORTIPCheck;
    }

    /**
     * Sets the value of the disablePORTIPCheck property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisablePORTIPCheck(String value) {
        this.disablePORTIPCheck = value;
    }

    /**
     * Gets the value of the useAlternatePASVAddr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseAlternatePASVAddr() {
        return useAlternatePASVAddr;
    }

    /**
     * Sets the value of the useAlternatePASVAddr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseAlternatePASVAddr(String value) {
        this.useAlternatePASVAddr = value;
    }

    /**
     * Gets the value of the alternatePASVAddr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternatePASVAddr() {
        return alternatePASVAddr;
    }

    /**
     * Sets the value of the alternatePASVAddr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternatePASVAddr(String value) {
        this.alternatePASVAddr = value;
    }

    /**
     * Gets the value of the allowLISTCmd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowLISTCmd() {
        return allowLISTCmd;
    }

    /**
     * Sets the value of the allowLISTCmd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowLISTCmd(String value) {
        this.allowLISTCmd = value;
    }

    /**
     * Gets the value of the allowDELECmd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowDELECmd() {
        return allowDELECmd;
    }

    /**
     * Sets the value of the allowDELECmd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowDELECmd(String value) {
        this.allowDELECmd = value;
    }

    /**
     * Gets the value of the dataEncryption property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataEncryption() {
        return dataEncryption;
    }

    /**
     * Sets the value of the dataEncryption property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataEncryption(String value) {
        this.dataEncryption = value;
    }

    /**
     * Gets the value of the allowCompression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCompression() {
        return allowCompression;
    }

    /**
     * Sets the value of the allowCompression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCompression(String value) {
        this.allowCompression = value;
    }

    /**
     * Gets the value of the allowSTOU property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowSTOU() {
        return allowSTOU;
    }

    /**
     * Sets the value of the allowSTOU property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowSTOU(String value) {
        this.allowSTOU = value;
    }

    /**
     * Gets the value of the uniqueFilenamePrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueFilenamePrefix() {
        return uniqueFilenamePrefix;
    }

    /**
     * Sets the value of the uniqueFilenamePrefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueFilenamePrefix(String value) {
        this.uniqueFilenamePrefix = value;
    }

    /**
     * Gets the value of the allowREST property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowREST() {
        return allowREST;
    }

    /**
     * Sets the value of the allowREST property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowREST(String value) {
        this.allowREST = value;
    }

    /**
     * Gets the value of the restartTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestartTimeout() {
        return restartTimeout;
    }

    /**
     * Sets the value of the restartTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestartTimeout(String value) {
        this.restartTimeout = value;
    }

    /**
     * Gets the value of the idleTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdleTimeout() {
        return idleTimeout;
    }

    /**
     * Sets the value of the idleTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdleTimeout(String value) {
        this.idleTimeout = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the responseStorage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseStorage() {
        return responseStorage;
    }

    /**
     * Sets the value of the responseStorage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseStorage(String value) {
        this.responseStorage = value;
    }

    /**
     * Gets the value of the temporaryStorageSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemporaryStorageSize() {
        return temporaryStorageSize;
    }

    /**
     * Sets the value of the temporaryStorageSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemporaryStorageSize(String value) {
        this.temporaryStorageSize = value;
    }

    /**
     * Gets the value of the responseNFSMount property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getResponseNFSMount() {
        return responseNFSMount;
    }

    /**
     * Sets the value of the responseNFSMount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setResponseNFSMount(DmReference value) {
        this.responseNFSMount = value;
    }

    /**
     * Gets the value of the responseSuffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseSuffix() {
        return responseSuffix;
    }

    /**
     * Sets the value of the responseSuffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseSuffix(String value) {
        this.responseSuffix = value;
    }

    /**
     * Gets the value of the responseURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseURL() {
        return responseURL;
    }

    /**
     * Sets the value of the responseURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseURL(String value) {
        this.responseURL = value;
    }

    /**
     * Gets the value of the sslServerConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLConfigType }
     *     
     */
    public DmSSLConfigType getSSLServerConfigType() {
        return sslServerConfigType;
    }

    /**
     * Sets the value of the sslServerConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLConfigType }
     *     
     */
    public void setSSLServerConfigType(DmSSLConfigType value) {
        this.sslServerConfigType = value;
    }

    /**
     * Gets the value of the sslServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLServer() {
        return sslServer;
    }

    /**
     * Sets the value of the sslServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLServer(DmReference value) {
        this.sslServer = value;
    }

    /**
     * Gets the value of the sslsniServer property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLSNIServer() {
        return sslsniServer;
    }

    /**
     * Sets the value of the sslsniServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLSNIServer(DmReference value) {
        this.sslsniServer = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
