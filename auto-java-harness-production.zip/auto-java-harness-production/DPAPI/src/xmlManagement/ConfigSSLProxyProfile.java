
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSSLProxyProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSSLProxyProfile"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigCrypto"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="Direction"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSSLProxyDirection {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ForwardCryptoProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ReverseCryptoProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ServerCaching" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SessionTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientCache" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientSessionTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientCacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientAuthOptional" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientAuthAlwaysRequest" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PermitInsecureServers" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSSLProxyProfile", propOrder = {
    "direction",
    "forwardCryptoProfile",
    "reverseCryptoProfile",
    "serverCaching",
    "sessionTimeout",
    "cacheSize",
    "clientCache",
    "clientSessionTimeout",
    "clientCacheSize",
    "clientAuthOptional",
    "clientAuthAlwaysRequest",
    "permitInsecureServers"
})
public class ConfigSSLProxyProfile
    extends ConfigCrypto
{

    @XmlElement(name = "Direction")
    protected String direction;
    @XmlElement(name = "ForwardCryptoProfile")
    protected DmReference forwardCryptoProfile;
    @XmlElement(name = "ReverseCryptoProfile")
    protected DmReference reverseCryptoProfile;
    @XmlElement(name = "ServerCaching")
    protected String serverCaching;
    @XmlElement(name = "SessionTimeout")
    protected String sessionTimeout;
    @XmlElement(name = "CacheSize")
    protected String cacheSize;
    @XmlElement(name = "ClientCache")
    protected String clientCache;
    @XmlElement(name = "ClientSessionTimeout")
    protected String clientSessionTimeout;
    @XmlElement(name = "ClientCacheSize")
    protected String clientCacheSize;
    @XmlElement(name = "ClientAuthOptional")
    protected String clientAuthOptional;
    @XmlElement(name = "ClientAuthAlwaysRequest")
    protected String clientAuthAlwaysRequest;
    @XmlElement(name = "PermitInsecureServers")
    protected String permitInsecureServers;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the direction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDirection() {
        return direction;
    }

    /**
     * Sets the value of the direction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDirection(String value) {
        this.direction = value;
    }

    /**
     * Gets the value of the forwardCryptoProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getForwardCryptoProfile() {
        return forwardCryptoProfile;
    }

    /**
     * Sets the value of the forwardCryptoProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setForwardCryptoProfile(DmReference value) {
        this.forwardCryptoProfile = value;
    }

    /**
     * Gets the value of the reverseCryptoProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getReverseCryptoProfile() {
        return reverseCryptoProfile;
    }

    /**
     * Sets the value of the reverseCryptoProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setReverseCryptoProfile(DmReference value) {
        this.reverseCryptoProfile = value;
    }

    /**
     * Gets the value of the serverCaching property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServerCaching() {
        return serverCaching;
    }

    /**
     * Sets the value of the serverCaching property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServerCaching(String value) {
        this.serverCaching = value;
    }

    /**
     * Gets the value of the sessionTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionTimeout() {
        return sessionTimeout;
    }

    /**
     * Sets the value of the sessionTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionTimeout(String value) {
        this.sessionTimeout = value;
    }

    /**
     * Gets the value of the cacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheSize() {
        return cacheSize;
    }

    /**
     * Sets the value of the cacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheSize(String value) {
        this.cacheSize = value;
    }

    /**
     * Gets the value of the clientCache property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientCache() {
        return clientCache;
    }

    /**
     * Sets the value of the clientCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientCache(String value) {
        this.clientCache = value;
    }

    /**
     * Gets the value of the clientSessionTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientSessionTimeout() {
        return clientSessionTimeout;
    }

    /**
     * Sets the value of the clientSessionTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientSessionTimeout(String value) {
        this.clientSessionTimeout = value;
    }

    /**
     * Gets the value of the clientCacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientCacheSize() {
        return clientCacheSize;
    }

    /**
     * Sets the value of the clientCacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientCacheSize(String value) {
        this.clientCacheSize = value;
    }

    /**
     * Gets the value of the clientAuthOptional property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientAuthOptional() {
        return clientAuthOptional;
    }

    /**
     * Sets the value of the clientAuthOptional property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientAuthOptional(String value) {
        this.clientAuthOptional = value;
    }

    /**
     * Gets the value of the clientAuthAlwaysRequest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientAuthAlwaysRequest() {
        return clientAuthAlwaysRequest;
    }

    /**
     * Sets the value of the clientAuthAlwaysRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientAuthAlwaysRequest(String value) {
        this.clientAuthAlwaysRequest = value;
    }

    /**
     * Gets the value of the permitInsecureServers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermitInsecureServers() {
        return permitInsecureServers;
    }

    /**
     * Sets the value of the permitInsecureServers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermitInsecureServers(String value) {
        this.permitInsecureServers = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
