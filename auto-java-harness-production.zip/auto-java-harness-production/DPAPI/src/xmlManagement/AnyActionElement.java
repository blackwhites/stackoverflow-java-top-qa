
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnyActionElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AnyActionElement"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded"&gt;
 *         &lt;element name="AddKnownHost" type="{http://www.datapower.com/schemas/management}ActionAddKnownHost"/&gt;
 *         &lt;element name="AddPasswordMap" type="{http://www.datapower.com/schemas/management}ActionAddPasswordMap"/&gt;
 *         &lt;element name="AddSelTestEntry" type="{http://www.datapower.com/schemas/management}ActionAddSelTestEntry"/&gt;
 *         &lt;element name="AddTrustedHost" type="{http://www.datapower.com/schemas/management}ActionAddTrustedHost"/&gt;
 *         &lt;element name="ApplyPatch" type="{http://www.datapower.com/schemas/management}ActionApplyPatch"/&gt;
 *         &lt;element name="AuthCookieCacheDelete" type="{http://www.datapower.com/schemas/management}ActionAuthCookieCacheDelete"/&gt;
 *         &lt;element name="B2BArchiveNow" type="{http://www.datapower.com/schemas/management}ActionB2BArchiveNow"/&gt;
 *         &lt;element name="B2BHASwitchPrimary" type="{http://www.datapower.com/schemas/management}ActionB2BHASwitchPrimary"/&gt;
 *         &lt;element name="B2BMPCMsgDeleteDomain" type="{http://www.datapower.com/schemas/management}ActionB2BMPCMsgDeleteDomain"/&gt;
 *         &lt;element name="B2BMPCMsgDeleteDomainAll" type="{http://www.datapower.com/schemas/management}ActionB2BMPCMsgDeleteDomainAll"/&gt;
 *         &lt;element name="B2BMPCMsgDeleteId" type="{http://www.datapower.com/schemas/management}ActionB2BMPCMsgDeleteId"/&gt;
 *         &lt;element name="B2BMPCMsgViewId" type="{http://www.datapower.com/schemas/management}ActionB2BMPCMsgViewId"/&gt;
 *         &lt;element name="BackupConfig" type="{http://www.datapower.com/schemas/management}ActionBackupConfig"/&gt;
 *         &lt;element name="BootDelete" type="{http://www.datapower.com/schemas/management}ActionBootDelete"/&gt;
 *         &lt;element name="BootSwitch" type="{http://www.datapower.com/schemas/management}ActionBootSwitch"/&gt;
 *         &lt;element name="CacheSchema" type="{http://www.datapower.com/schemas/management}ActionCacheSchema"/&gt;
 *         &lt;element name="CacheStylesheet" type="{http://www.datapower.com/schemas/management}ActionCacheStylesheet"/&gt;
 *         &lt;element name="CacheWSDL" type="{http://www.datapower.com/schemas/management}ActionCacheWSDL"/&gt;
 *         &lt;element name="ChangePassword" type="{http://www.datapower.com/schemas/management}ActionChangePassword"/&gt;
 *         &lt;element name="ClearSel" type="{http://www.datapower.com/schemas/management}ActionClearSel"/&gt;
 *         &lt;element name="ConvertCertificate" type="{http://www.datapower.com/schemas/management}ActionConvertCertificate"/&gt;
 *         &lt;element name="ConvertKey" type="{http://www.datapower.com/schemas/management}ActionConvertKey"/&gt;
 *         &lt;element name="CopyLocalTAMDb" type="{http://www.datapower.com/schemas/management}ActionCopyLocalTAMDb"/&gt;
 *         &lt;element name="CreateDir" type="{http://www.datapower.com/schemas/management}ActionCreateDir"/&gt;
 *         &lt;element name="CreateLunaClientCert" type="{http://www.datapower.com/schemas/management}ActionCreateLunaClientCert"/&gt;
 *         &lt;element name="CreateTAMFiles" type="{http://www.datapower.com/schemas/management}ActionCreateTAMFiles"/&gt;
 *         &lt;element name="CryptoExport" type="{http://www.datapower.com/schemas/management}ActionCryptoExport"/&gt;
 *         &lt;element name="CryptoHwDisable" type="{http://www.datapower.com/schemas/management}ActionCryptoHwDisable"/&gt;
 *         &lt;element name="CryptoImport" type="{http://www.datapower.com/schemas/management}ActionCryptoImport"/&gt;
 *         &lt;element name="CryptoModeSet" type="{http://www.datapower.com/schemas/management}ActionCryptoModeSet"/&gt;
 *         &lt;element name="DeleteFile" type="{http://www.datapower.com/schemas/management}ActionDeleteFile"/&gt;
 *         &lt;element name="DeleteHSMKey" type="{http://www.datapower.com/schemas/management}ActionDeleteHSMKey"/&gt;
 *         &lt;element name="DeleteKnownHost" type="{http://www.datapower.com/schemas/management}ActionDeleteKnownHost"/&gt;
 *         &lt;element name="DeleteKnownHostTable" type="{http://www.datapower.com/schemas/management}ActionDeleteKnownHostTable"/&gt;
 *         &lt;element name="DeletePasswordMap" type="{http://www.datapower.com/schemas/management}ActionDeletePasswordMap"/&gt;
 *         &lt;element name="DeleteTrustedHost" type="{http://www.datapower.com/schemas/management}ActionDeleteTrustedHost"/&gt;
 *         &lt;element name="DeviceCertificate" type="{http://www.datapower.com/schemas/management}ActionDeviceCertificate"/&gt;
 *         &lt;element name="DisableEthernetHardwareOffload" type="{http://www.datapower.com/schemas/management}ActionDisableEthernetHardwareOffload"/&gt;
 *         &lt;element name="DisableLinkAggregationHardwareOffload" type="{http://www.datapower.com/schemas/management}ActionDisableLinkAggregationHardwareOffload"/&gt;
 *         &lt;element name="DisableVLANHardwareOffload" type="{http://www.datapower.com/schemas/management}ActionDisableVLANHardwareOffload"/&gt;
 *         &lt;element name="Disconnect" type="{http://www.datapower.com/schemas/management}ActionDisconnect"/&gt;
 *         &lt;element name="DomainQuiesce" type="{http://www.datapower.com/schemas/management}ActionDomainQuiesce"/&gt;
 *         &lt;element name="DomainUnquiesce" type="{http://www.datapower.com/schemas/management}ActionDomainUnquiesce"/&gt;
 *         &lt;element name="ebMS2Ping" type="{http://www.datapower.com/schemas/management}ActionebMS2Ping"/&gt;
 *         &lt;element name="ErrorReport" type="{http://www.datapower.com/schemas/management}ActionErrorReport"/&gt;
 *         &lt;element name="ExecConfig" type="{http://www.datapower.com/schemas/management}ActionExecConfig"/&gt;
 *         &lt;element name="FetchFile" type="{http://www.datapower.com/schemas/management}ActionFetchFile"/&gt;
 *         &lt;element name="FileCapture" type="{http://www.datapower.com/schemas/management}ActionFileCapture"/&gt;
 *         &lt;element name="FlushAAACache" type="{http://www.datapower.com/schemas/management}ActionFlushAAACache"/&gt;
 *         &lt;element name="FlushArpCache" type="{http://www.datapower.com/schemas/management}ActionFlushArpCache"/&gt;
 *         &lt;element name="FlushDNSCache" type="{http://www.datapower.com/schemas/management}ActionFlushDNSCache"/&gt;
 *         &lt;element name="FlushDocumentCache" type="{http://www.datapower.com/schemas/management}ActionFlushDocumentCache"/&gt;
 *         &lt;element name="FlushGatewayScriptCache" type="{http://www.datapower.com/schemas/management}ActionFlushGatewayScriptCache"/&gt;
 *         &lt;element name="FlushLDAPPoolCache" type="{http://www.datapower.com/schemas/management}ActionFlushLDAPPoolCache"/&gt;
 *         &lt;element name="FlushNDCache" type="{http://www.datapower.com/schemas/management}ActionFlushNDCache"/&gt;
 *         &lt;element name="FlushNSSCache" type="{http://www.datapower.com/schemas/management}ActionFlushNSSCache"/&gt;
 *         &lt;element name="FlushPDPCache" type="{http://www.datapower.com/schemas/management}ActionFlushPDPCache"/&gt;
 *         &lt;element name="FlushRBMCache" type="{http://www.datapower.com/schemas/management}ActionFlushRBMCache"/&gt;
 *         &lt;element name="FlushStylesheetCache" type="{http://www.datapower.com/schemas/management}ActionFlushStylesheetCache"/&gt;
 *         &lt;element name="HSMCloneKWK" type="{http://www.datapower.com/schemas/management}ActionHSMCloneKWK"/&gt;
 *         &lt;element name="HSMSetRole" type="{http://www.datapower.com/schemas/management}ActionHSMSetRole"/&gt;
 *         &lt;element name="ImportExecute" type="{http://www.datapower.com/schemas/management}ActionImportExecute"/&gt;
 *         &lt;element name="ImportLunaClientCert" type="{http://www.datapower.com/schemas/management}ActionImportLunaClientCert"/&gt;
 *         &lt;element name="InitFibreChannelFilesystem" type="{http://www.datapower.com/schemas/management}ActionInitFibreChannelFilesystem"/&gt;
 *         &lt;element name="InitializeCompactFlashFilesystem" type="{http://www.datapower.com/schemas/management}ActionInitializeCompactFlashFilesystem"/&gt;
 *         &lt;element name="InitializeRaidVolumeFilesystem" type="{http://www.datapower.com/schemas/management}ActionInitializeRaidVolumeFilesystem"/&gt;
 *         &lt;element name="InitializeRaidVolumeFilesystem2" type="{http://www.datapower.com/schemas/management}ActionInitializeRaidVolumeFilesystem2"/&gt;
 *         &lt;element name="InitializeRaidVolumeFilesystemNoEncryption" type="{http://www.datapower.com/schemas/management}ActionInitializeRaidVolumeFilesystemNoEncryption"/&gt;
 *         &lt;element name="InitializeRaidVolumeFilesystemNoEncryptionMpt2Sas" type="{http://www.datapower.com/schemas/management}ActionInitializeRaidVolumeFilesystemNoEncryptionMpt2Sas"/&gt;
 *         &lt;element name="InitializeRaidVolumeFilesystemVirtual" type="{http://www.datapower.com/schemas/management}ActionInitializeRaidVolumeFilesystemVirtual"/&gt;
 *         &lt;element name="InitIScsiFilesystem" type="{http://www.datapower.com/schemas/management}ActionInitIScsiFilesystem"/&gt;
 *         &lt;element name="InvalidateDocumentCache" type="{http://www.datapower.com/schemas/management}ActionInvalidateDocumentCache"/&gt;
 *         &lt;element name="KerberosTicketDelete" type="{http://www.datapower.com/schemas/management}ActionKerberosTicketDelete"/&gt;
 *         &lt;element name="Keygen" type="{http://www.datapower.com/schemas/management}ActionKeygen"/&gt;
 *         &lt;element name="LinkAggregationPacketCapture" type="{http://www.datapower.com/schemas/management}ActionLinkAggregationPacketCapture"/&gt;
 *         &lt;element name="LinkAggregationStopPacketCapture" type="{http://www.datapower.com/schemas/management}ActionLinkAggregationStopPacketCapture"/&gt;
 *         &lt;element name="LocateDevice" type="{http://www.datapower.com/schemas/management}ActionLocateDevice"/&gt;
 *         &lt;element name="LunaHARecover" type="{http://www.datapower.com/schemas/management}ActionLunaHARecover"/&gt;
 *         &lt;element name="LunaHASync" type="{http://www.datapower.com/schemas/management}ActionLunaHASync"/&gt;
 *         &lt;element name="LunaOTTUpdate" type="{http://www.datapower.com/schemas/management}ActionLunaOTTUpdate"/&gt;
 *         &lt;element name="MoveFile" type="{http://www.datapower.com/schemas/management}ActionMoveFile"/&gt;
 *         &lt;element name="NoDebugAction" type="{http://www.datapower.com/schemas/management}ActionNoDebugAction"/&gt;
 *         &lt;element name="NoPasswordMap" type="{http://www.datapower.com/schemas/management}ActionNoPasswordMap"/&gt;
 *         &lt;element name="OAuthCacheDelete" type="{http://www.datapower.com/schemas/management}ActionOAuthCacheDelete"/&gt;
 *         &lt;element name="PacketCapture" type="{http://www.datapower.com/schemas/management}ActionPacketCapture"/&gt;
 *         &lt;element name="PacketCaptureDebug" type="{http://www.datapower.com/schemas/management}ActionPacketCaptureDebug"/&gt;
 *         &lt;element name="Ping" type="{http://www.datapower.com/schemas/management}ActionPing"/&gt;
 *         &lt;element name="Quiesce" type="{http://www.datapower.com/schemas/management}ActionQuiesce"/&gt;
 *         &lt;element name="QuiesceDP" type="{http://www.datapower.com/schemas/management}ActionQuiesceDP"/&gt;
 *         &lt;element name="QuotaEnforcementSwitchMaster" type="{http://www.datapower.com/schemas/management}ActionQuotaEnforcementSwitchMaster"/&gt;
 *         &lt;element name="RaidActivate" type="{http://www.datapower.com/schemas/management}ActionRaidActivate"/&gt;
 *         &lt;element name="RaidChangeEncryptionSettings2" type="{http://www.datapower.com/schemas/management}ActionRaidChangeEncryptionSettings2"/&gt;
 *         &lt;element name="RaidDelete" type="{http://www.datapower.com/schemas/management}ActionRaidDelete"/&gt;
 *         &lt;element name="RaidInitialize" type="{http://www.datapower.com/schemas/management}ActionRaidInitialize"/&gt;
 *         &lt;element name="RaidLearnBattery" type="{http://www.datapower.com/schemas/management}ActionRaidLearnBattery"/&gt;
 *         &lt;element name="RaidMakeHotSpare" type="{http://www.datapower.com/schemas/management}ActionRaidMakeHotSpare"/&gt;
 *         &lt;element name="RaidRebuild" type="{http://www.datapower.com/schemas/management}ActionRaidRebuild"/&gt;
 *         &lt;element name="RaidReconcileEncryptionSettings2" type="{http://www.datapower.com/schemas/management}ActionRaidReconcileEncryptionSettings2"/&gt;
 *         &lt;element name="RateLimitConcurrentDeleteDomain" type="{http://www.datapower.com/schemas/management}ActionRateLimitConcurrentDeleteDomain"/&gt;
 *         &lt;element name="RateLimitConcurrentDeleteKey" type="{http://www.datapower.com/schemas/management}ActionRateLimitConcurrentDeleteKey"/&gt;
 *         &lt;element name="RateLimitConcurrentDeleteType" type="{http://www.datapower.com/schemas/management}ActionRateLimitConcurrentDeleteType"/&gt;
 *         &lt;element name="RateLimitCountDeleteDomain" type="{http://www.datapower.com/schemas/management}ActionRateLimitCountDeleteDomain"/&gt;
 *         &lt;element name="RateLimitCountDeleteKey" type="{http://www.datapower.com/schemas/management}ActionRateLimitCountDeleteKey"/&gt;
 *         &lt;element name="RateLimitCountDeleteType" type="{http://www.datapower.com/schemas/management}ActionRateLimitCountDeleteType"/&gt;
 *         &lt;element name="RateLimitRateDeleteDomain" type="{http://www.datapower.com/schemas/management}ActionRateLimitRateDeleteDomain"/&gt;
 *         &lt;element name="RateLimitRateDeleteKey" type="{http://www.datapower.com/schemas/management}ActionRateLimitRateDeleteKey"/&gt;
 *         &lt;element name="RateLimitRateDeleteType" type="{http://www.datapower.com/schemas/management}ActionRateLimitRateDeleteType"/&gt;
 *         &lt;element name="RateLimitTokenBucketDeleteDomain" type="{http://www.datapower.com/schemas/management}ActionRateLimitTokenBucketDeleteDomain"/&gt;
 *         &lt;element name="RateLimitTokenBucketDeleteKey" type="{http://www.datapower.com/schemas/management}ActionRateLimitTokenBucketDeleteKey"/&gt;
 *         &lt;element name="RateLimitTokenBucketDeleteType" type="{http://www.datapower.com/schemas/management}ActionRateLimitTokenBucketDeleteType"/&gt;
 *         &lt;element name="RefreshDocument" type="{http://www.datapower.com/schemas/management}ActionRefreshDocument"/&gt;
 *         &lt;element name="RefreshStylesheet" type="{http://www.datapower.com/schemas/management}ActionRefreshStylesheet"/&gt;
 *         &lt;element name="RefreshTAMCerts" type="{http://www.datapower.com/schemas/management}ActionRefreshTAMCerts"/&gt;
 *         &lt;element name="RefreshTAMKeystorePwd" type="{http://www.datapower.com/schemas/management}ActionRefreshTAMKeystorePwd"/&gt;
 *         &lt;element name="RefreshWSDL" type="{http://www.datapower.com/schemas/management}ActionRefreshWSDL"/&gt;
 *         &lt;element name="RemoveCheckpoint" type="{http://www.datapower.com/schemas/management}ActionRemoveCheckpoint"/&gt;
 *         &lt;element name="RemoveDir" type="{http://www.datapower.com/schemas/management}ActionRemoveDir"/&gt;
 *         &lt;element name="RemoveStylesheet" type="{http://www.datapower.com/schemas/management}ActionRemoveStylesheet"/&gt;
 *         &lt;element name="RepairCompactFlashFilesystem" type="{http://www.datapower.com/schemas/management}ActionRepairCompactFlashFilesystem"/&gt;
 *         &lt;element name="RepairFibreChannelFilesystem" type="{http://www.datapower.com/schemas/management}ActionRepairFibreChannelFilesystem"/&gt;
 *         &lt;element name="RepairIScsiFilesystem" type="{http://www.datapower.com/schemas/management}ActionRepairIScsiFilesystem"/&gt;
 *         &lt;element name="RepairRaidVolumeFilesystem" type="{http://www.datapower.com/schemas/management}ActionRepairRaidVolumeFilesystem"/&gt;
 *         &lt;element name="Reserved152" type="{http://www.datapower.com/schemas/management}ActionReserved152"/&gt;
 *         &lt;element name="ResetDomain" type="{http://www.datapower.com/schemas/management}ActionResetDomain"/&gt;
 *         &lt;element name="ResetThisDomain" type="{http://www.datapower.com/schemas/management}ActionResetThisDomain"/&gt;
 *         &lt;element name="RestartDomain" type="{http://www.datapower.com/schemas/management}ActionRestartDomain"/&gt;
 *         &lt;element name="RestartThisDomain" type="{http://www.datapower.com/schemas/management}ActionRestartThisDomain"/&gt;
 *         &lt;element name="RollbackCheckpoint" type="{http://www.datapower.com/schemas/management}ActionRollbackCheckpoint"/&gt;
 *         &lt;element name="SaveCheckpoint" type="{http://www.datapower.com/schemas/management}ActionSaveCheckpoint"/&gt;
 *         &lt;element name="SaveConfig" type="{http://www.datapower.com/schemas/management}ActionSaveConfig"/&gt;
 *         &lt;element name="SaveInternalState" type="{http://www.datapower.com/schemas/management}ActionSaveInternalState"/&gt;
 *         &lt;element name="SecureBackup" type="{http://www.datapower.com/schemas/management}ActionSecureBackup"/&gt;
 *         &lt;element name="SecureRestore" type="{http://www.datapower.com/schemas/management}ActionSecureRestore"/&gt;
 *         &lt;element name="SelectConfig" type="{http://www.datapower.com/schemas/management}ActionSelectConfig"/&gt;
 *         &lt;element name="SendErrorReport" type="{http://www.datapower.com/schemas/management}ActionSendErrorReport"/&gt;
 *         &lt;element name="SendFile" type="{http://www.datapower.com/schemas/management}ActionSendFile"/&gt;
 *         &lt;element name="SendLogEvent" type="{http://www.datapower.com/schemas/management}ActionSendLogEvent"/&gt;
 *         &lt;element name="ServiceQuiesce" type="{http://www.datapower.com/schemas/management}ActionServiceQuiesce"/&gt;
 *         &lt;element name="ServiceStatusQuiesce" type="{http://www.datapower.com/schemas/management}ActionServiceStatusQuiesce"/&gt;
 *         &lt;element name="ServiceStatusUnquiesce" type="{http://www.datapower.com/schemas/management}ActionServiceStatusUnquiesce"/&gt;
 *         &lt;element name="ServiceUnquiesce" type="{http://www.datapower.com/schemas/management}ActionServiceUnquiesce"/&gt;
 *         &lt;element name="SetLogLevel" type="{http://www.datapower.com/schemas/management}ActionSetLogLevel"/&gt;
 *         &lt;element name="SetRBMDebugLog" type="{http://www.datapower.com/schemas/management}ActionSetRBMDebugLog"/&gt;
 *         &lt;element name="SetSystemVar" type="{http://www.datapower.com/schemas/management}ActionSetSystemVar"/&gt;
 *         &lt;element name="SetTimeAndDate" type="{http://www.datapower.com/schemas/management}ActionSetTimeAndDate"/&gt;
 *         &lt;element name="Shutdown" type="{http://www.datapower.com/schemas/management}ActionShutdown"/&gt;
 *         &lt;element name="SLMResetStats" type="{http://www.datapower.com/schemas/management}ActionSLMResetStats"/&gt;
 *         &lt;element name="StandalonePacketCapture" type="{http://www.datapower.com/schemas/management}ActionStandalonePacketCapture"/&gt;
 *         &lt;element name="StandaloneStopPacketCapture" type="{http://www.datapower.com/schemas/management}ActionStandaloneStopPacketCapture"/&gt;
 *         &lt;element name="StopPacketCapture" type="{http://www.datapower.com/schemas/management}ActionStopPacketCapture"/&gt;
 *         &lt;element name="TCPConnectionTest" type="{http://www.datapower.com/schemas/management}ActionTCPConnectionTest"/&gt;
 *         &lt;element name="TestHardware" type="{http://www.datapower.com/schemas/management}ActionTestHardware"/&gt;
 *         &lt;element name="TestPasswordMap" type="{http://www.datapower.com/schemas/management}ActionTestPasswordMap"/&gt;
 *         &lt;element name="TestRadius" type="{http://www.datapower.com/schemas/management}ActionTestRadius"/&gt;
 *         &lt;element name="TestURLMap" type="{http://www.datapower.com/schemas/management}ActionTestURLMap"/&gt;
 *         &lt;element name="TestURLRefresh" type="{http://www.datapower.com/schemas/management}ActionTestURLRefresh"/&gt;
 *         &lt;element name="TestURLRewrite" type="{http://www.datapower.com/schemas/management}ActionTestURLRewrite"/&gt;
 *         &lt;element name="TestValidateSchema" type="{http://www.datapower.com/schemas/management}ActionTestValidateSchema"/&gt;
 *         &lt;element name="UnconfigureReverseProxy" type="{http://www.datapower.com/schemas/management}ActionUnconfigureReverseProxy"/&gt;
 *         &lt;element name="UnconfigureRuntime" type="{http://www.datapower.com/schemas/management}ActionUnconfigureRuntime"/&gt;
 *         &lt;element name="UndoConfig" type="{http://www.datapower.com/schemas/management}ActionUndoConfig"/&gt;
 *         &lt;element name="UniversalPacketCaptureDebug" type="{http://www.datapower.com/schemas/management}ActionUniversalPacketCaptureDebug"/&gt;
 *         &lt;element name="UniversalStopPacketCapture" type="{http://www.datapower.com/schemas/management}ActionUniversalStopPacketCapture"/&gt;
 *         &lt;element name="Unquiesce" type="{http://www.datapower.com/schemas/management}ActionUnquiesce"/&gt;
 *         &lt;element name="UnquiesceDP" type="{http://www.datapower.com/schemas/management}ActionUnquiesceDP"/&gt;
 *         &lt;element name="UpgradeWatchdog" type="{http://www.datapower.com/schemas/management}ActionUpgradeWatchdog"/&gt;
 *         &lt;element name="UserForcePasswordChange" type="{http://www.datapower.com/schemas/management}ActionUserForcePasswordChange"/&gt;
 *         &lt;element name="UserResetFailedLogin" type="{http://www.datapower.com/schemas/management}ActionUserResetFailedLogin"/&gt;
 *         &lt;element name="UserResetPassword" type="{http://www.datapower.com/schemas/management}ActionUserResetPassword"/&gt;
 *         &lt;element name="ValCredAddCertsFromDir" type="{http://www.datapower.com/schemas/management}ActionValCredAddCertsFromDir"/&gt;
 *         &lt;element name="VerifyFirmware" type="{http://www.datapower.com/schemas/management}ActionVerifyFirmware"/&gt;
 *         &lt;element name="VLANPacketCapture" type="{http://www.datapower.com/schemas/management}ActionVLANPacketCapture"/&gt;
 *         &lt;element name="VLANStopPacketCapture" type="{http://www.datapower.com/schemas/management}ActionVLANStopPacketCapture"/&gt;
 *         &lt;element name="WsrrSynchronize" type="{http://www.datapower.com/schemas/management}ActionWsrrSynchronize"/&gt;
 *         &lt;element name="WsrrValidateServer" type="{http://www.datapower.com/schemas/management}ActionWsrrValidateServer"/&gt;
 *         &lt;element name="XC10ClearGrid" type="{http://www.datapower.com/schemas/management}ActionXC10ClearGrid"/&gt;
 *         &lt;element name="XC10CreateGrid" type="{http://www.datapower.com/schemas/management}ActionXC10CreateGrid"/&gt;
 *         &lt;element name="XC10DiscoverCollective" type="{http://www.datapower.com/schemas/management}ActionXC10DiscoverCollective"/&gt;
 *         &lt;element name="YieldEthernetStandby" type="{http://www.datapower.com/schemas/management}ActionYieldEthernetStandby"/&gt;
 *         &lt;element name="YieldLinkAggregationStandby" type="{http://www.datapower.com/schemas/management}ActionYieldLinkAggregationStandby"/&gt;
 *         &lt;element name="YieldStandaloneStandby" type="{http://www.datapower.com/schemas/management}ActionYieldStandaloneStandby"/&gt;
 *         &lt;element name="YieldVLANStandby" type="{http://www.datapower.com/schemas/management}ActionYieldVLANStandby"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnyActionElement", propOrder = {
    "actionObjects"
})
public class AnyActionElement {

    @XmlElements({
        @XmlElement(name = "AddKnownHost", type = ActionAddKnownHost.class),
        @XmlElement(name = "AddPasswordMap", type = ActionAddPasswordMap.class),
        @XmlElement(name = "AddSelTestEntry", type = ActionAddSelTestEntry.class),
        @XmlElement(name = "AddTrustedHost", type = ActionAddTrustedHost.class),
        @XmlElement(name = "ApplyPatch", type = ActionApplyPatch.class),
        @XmlElement(name = "AuthCookieCacheDelete", type = ActionAuthCookieCacheDelete.class),
        @XmlElement(name = "B2BArchiveNow", type = ActionB2BArchiveNow.class),
        @XmlElement(name = "B2BHASwitchPrimary", type = ActionB2BHASwitchPrimary.class),
        @XmlElement(name = "B2BMPCMsgDeleteDomain", type = ActionB2BMPCMsgDeleteDomain.class),
        @XmlElement(name = "B2BMPCMsgDeleteDomainAll", type = ActionB2BMPCMsgDeleteDomainAll.class),
        @XmlElement(name = "B2BMPCMsgDeleteId", type = ActionB2BMPCMsgDeleteId.class),
        @XmlElement(name = "B2BMPCMsgViewId", type = ActionB2BMPCMsgViewId.class),
        @XmlElement(name = "BackupConfig", type = ActionBackupConfig.class),
        @XmlElement(name = "BootDelete", type = ActionBootDelete.class),
        @XmlElement(name = "BootSwitch", type = ActionBootSwitch.class),
        @XmlElement(name = "CacheSchema", type = ActionCacheSchema.class),
        @XmlElement(name = "CacheStylesheet", type = ActionCacheStylesheet.class),
        @XmlElement(name = "CacheWSDL", type = ActionCacheWSDL.class),
        @XmlElement(name = "ChangePassword", type = ActionChangePassword.class),
        @XmlElement(name = "ClearSel", type = ActionClearSel.class),
        @XmlElement(name = "ConvertCertificate", type = ActionConvertCertificate.class),
        @XmlElement(name = "ConvertKey", type = ActionConvertKey.class),
        @XmlElement(name = "CopyLocalTAMDb", type = ActionCopyLocalTAMDb.class),
        @XmlElement(name = "CreateDir", type = ActionCreateDir.class),
        @XmlElement(name = "CreateLunaClientCert", type = ActionCreateLunaClientCert.class),
        @XmlElement(name = "CreateTAMFiles", type = ActionCreateTAMFiles.class),
        @XmlElement(name = "CryptoExport", type = ActionCryptoExport.class),
        @XmlElement(name = "CryptoHwDisable", type = ActionCryptoHwDisable.class),
        @XmlElement(name = "CryptoImport", type = ActionCryptoImport.class),
        @XmlElement(name = "CryptoModeSet", type = ActionCryptoModeSet.class),
        @XmlElement(name = "DeleteFile", type = ActionDeleteFile.class),
        @XmlElement(name = "DeleteHSMKey", type = ActionDeleteHSMKey.class),
        @XmlElement(name = "DeleteKnownHost", type = ActionDeleteKnownHost.class),
        @XmlElement(name = "DeleteKnownHostTable", type = ActionDeleteKnownHostTable.class),
        @XmlElement(name = "DeletePasswordMap", type = ActionDeletePasswordMap.class),
        @XmlElement(name = "DeleteTrustedHost", type = ActionDeleteTrustedHost.class),
        @XmlElement(name = "DeviceCertificate", type = ActionDeviceCertificate.class),
        @XmlElement(name = "DisableEthernetHardwareOffload", type = ActionDisableEthernetHardwareOffload.class),
        @XmlElement(name = "DisableLinkAggregationHardwareOffload", type = ActionDisableLinkAggregationHardwareOffload.class),
        @XmlElement(name = "DisableVLANHardwareOffload", type = ActionDisableVLANHardwareOffload.class),
        @XmlElement(name = "Disconnect", type = ActionDisconnect.class),
        @XmlElement(name = "DomainQuiesce", type = ActionDomainQuiesce.class),
        @XmlElement(name = "DomainUnquiesce", type = ActionDomainUnquiesce.class),
        @XmlElement(name = "ebMS2Ping", type = ActionebMS2Ping.class),
        @XmlElement(name = "ErrorReport", type = ActionErrorReport.class),
        @XmlElement(name = "ExecConfig", type = ActionExecConfig.class),
        @XmlElement(name = "FetchFile", type = ActionFetchFile.class),
        @XmlElement(name = "FileCapture", type = ActionFileCapture.class),
        @XmlElement(name = "FlushAAACache", type = ActionFlushAAACache.class),
        @XmlElement(name = "FlushArpCache", type = ActionFlushArpCache.class),
        @XmlElement(name = "FlushDNSCache", type = ActionFlushDNSCache.class),
        @XmlElement(name = "FlushDocumentCache", type = ActionFlushDocumentCache.class),
        @XmlElement(name = "FlushGatewayScriptCache", type = ActionFlushGatewayScriptCache.class),
        @XmlElement(name = "FlushLDAPPoolCache", type = ActionFlushLDAPPoolCache.class),
        @XmlElement(name = "FlushNDCache", type = ActionFlushNDCache.class),
        @XmlElement(name = "FlushNSSCache", type = ActionFlushNSSCache.class),
        @XmlElement(name = "FlushPDPCache", type = ActionFlushPDPCache.class),
        @XmlElement(name = "FlushRBMCache", type = ActionFlushRBMCache.class),
        @XmlElement(name = "FlushStylesheetCache", type = ActionFlushStylesheetCache.class),
        @XmlElement(name = "HSMCloneKWK", type = ActionHSMCloneKWK.class),
        @XmlElement(name = "HSMSetRole", type = ActionHSMSetRole.class),
        @XmlElement(name = "ImportExecute", type = ActionImportExecute.class),
        @XmlElement(name = "ImportLunaClientCert", type = ActionImportLunaClientCert.class),
        @XmlElement(name = "InitFibreChannelFilesystem", type = ActionInitFibreChannelFilesystem.class),
        @XmlElement(name = "InitializeCompactFlashFilesystem", type = ActionInitializeCompactFlashFilesystem.class),
        @XmlElement(name = "InitializeRaidVolumeFilesystem", type = ActionInitializeRaidVolumeFilesystem.class),
        @XmlElement(name = "InitializeRaidVolumeFilesystem2", type = ActionInitializeRaidVolumeFilesystem2 .class),
        @XmlElement(name = "InitializeRaidVolumeFilesystemNoEncryption", type = ActionInitializeRaidVolumeFilesystemNoEncryption.class),
        @XmlElement(name = "InitializeRaidVolumeFilesystemNoEncryptionMpt2Sas", type = ActionInitializeRaidVolumeFilesystemNoEncryptionMpt2Sas.class),
        @XmlElement(name = "InitializeRaidVolumeFilesystemVirtual", type = ActionInitializeRaidVolumeFilesystemVirtual.class),
        @XmlElement(name = "InitIScsiFilesystem", type = ActionInitIScsiFilesystem.class),
        @XmlElement(name = "InvalidateDocumentCache", type = ActionInvalidateDocumentCache.class),
        @XmlElement(name = "KerberosTicketDelete", type = ActionKerberosTicketDelete.class),
        @XmlElement(name = "Keygen", type = ActionKeygen.class),
        @XmlElement(name = "LinkAggregationPacketCapture", type = ActionLinkAggregationPacketCapture.class),
        @XmlElement(name = "LinkAggregationStopPacketCapture", type = ActionLinkAggregationStopPacketCapture.class),
        @XmlElement(name = "LocateDevice", type = ActionLocateDevice.class),
        @XmlElement(name = "LunaHARecover", type = ActionLunaHARecover.class),
        @XmlElement(name = "LunaHASync", type = ActionLunaHASync.class),
        @XmlElement(name = "LunaOTTUpdate", type = ActionLunaOTTUpdate.class),
        @XmlElement(name = "MoveFile", type = ActionMoveFile.class),
        @XmlElement(name = "NoDebugAction", type = ActionNoDebugAction.class),
        @XmlElement(name = "NoPasswordMap", type = ActionNoPasswordMap.class),
        @XmlElement(name = "OAuthCacheDelete", type = ActionOAuthCacheDelete.class),
        @XmlElement(name = "PacketCapture", type = ActionPacketCapture.class),
        @XmlElement(name = "PacketCaptureDebug", type = ActionPacketCaptureDebug.class),
        @XmlElement(name = "Ping", type = ActionPing.class),
        @XmlElement(name = "Quiesce", type = ActionQuiesce.class),
        @XmlElement(name = "QuiesceDP", type = ActionQuiesceDP.class),
        @XmlElement(name = "QuotaEnforcementSwitchMaster", type = ActionQuotaEnforcementSwitchMaster.class),
        @XmlElement(name = "RaidActivate", type = ActionRaidActivate.class),
        @XmlElement(name = "RaidChangeEncryptionSettings2", type = ActionRaidChangeEncryptionSettings2 .class),
        @XmlElement(name = "RaidDelete", type = ActionRaidDelete.class),
        @XmlElement(name = "RaidInitialize", type = ActionRaidInitialize.class),
        @XmlElement(name = "RaidLearnBattery", type = ActionRaidLearnBattery.class),
        @XmlElement(name = "RaidMakeHotSpare", type = ActionRaidMakeHotSpare.class),
        @XmlElement(name = "RaidRebuild", type = ActionRaidRebuild.class),
        @XmlElement(name = "RaidReconcileEncryptionSettings2", type = ActionRaidReconcileEncryptionSettings2 .class),
        @XmlElement(name = "RateLimitConcurrentDeleteDomain", type = ActionRateLimitConcurrentDeleteDomain.class),
        @XmlElement(name = "RateLimitConcurrentDeleteKey", type = ActionRateLimitConcurrentDeleteKey.class),
        @XmlElement(name = "RateLimitConcurrentDeleteType", type = ActionRateLimitConcurrentDeleteType.class),
        @XmlElement(name = "RateLimitCountDeleteDomain", type = ActionRateLimitCountDeleteDomain.class),
        @XmlElement(name = "RateLimitCountDeleteKey", type = ActionRateLimitCountDeleteKey.class),
        @XmlElement(name = "RateLimitCountDeleteType", type = ActionRateLimitCountDeleteType.class),
        @XmlElement(name = "RateLimitRateDeleteDomain", type = ActionRateLimitRateDeleteDomain.class),
        @XmlElement(name = "RateLimitRateDeleteKey", type = ActionRateLimitRateDeleteKey.class),
        @XmlElement(name = "RateLimitRateDeleteType", type = ActionRateLimitRateDeleteType.class),
        @XmlElement(name = "RateLimitTokenBucketDeleteDomain", type = ActionRateLimitTokenBucketDeleteDomain.class),
        @XmlElement(name = "RateLimitTokenBucketDeleteKey", type = ActionRateLimitTokenBucketDeleteKey.class),
        @XmlElement(name = "RateLimitTokenBucketDeleteType", type = ActionRateLimitTokenBucketDeleteType.class),
        @XmlElement(name = "RefreshDocument", type = ActionRefreshDocument.class),
        @XmlElement(name = "RefreshStylesheet", type = ActionRefreshStylesheet.class),
        @XmlElement(name = "RefreshTAMCerts", type = ActionRefreshTAMCerts.class),
        @XmlElement(name = "RefreshTAMKeystorePwd", type = ActionRefreshTAMKeystorePwd.class),
        @XmlElement(name = "RefreshWSDL", type = ActionRefreshWSDL.class),
        @XmlElement(name = "RemoveCheckpoint", type = ActionRemoveCheckpoint.class),
        @XmlElement(name = "RemoveDir", type = ActionRemoveDir.class),
        @XmlElement(name = "RemoveStylesheet", type = ActionRemoveStylesheet.class),
        @XmlElement(name = "RepairCompactFlashFilesystem", type = ActionRepairCompactFlashFilesystem.class),
        @XmlElement(name = "RepairFibreChannelFilesystem", type = ActionRepairFibreChannelFilesystem.class),
        @XmlElement(name = "RepairIScsiFilesystem", type = ActionRepairIScsiFilesystem.class),
        @XmlElement(name = "RepairRaidVolumeFilesystem", type = ActionRepairRaidVolumeFilesystem.class),
        @XmlElement(name = "Reserved152", type = ActionReserved152 .class),
        @XmlElement(name = "ResetDomain", type = ActionResetDomain.class),
        @XmlElement(name = "ResetThisDomain", type = ActionResetThisDomain.class),
        @XmlElement(name = "RestartDomain", type = ActionRestartDomain.class),
        @XmlElement(name = "RestartThisDomain", type = ActionRestartThisDomain.class),
        @XmlElement(name = "RollbackCheckpoint", type = ActionRollbackCheckpoint.class),
        @XmlElement(name = "SaveCheckpoint", type = ActionSaveCheckpoint.class),
        @XmlElement(name = "SaveConfig", type = ActionSaveConfig.class),
        @XmlElement(name = "SaveInternalState", type = ActionSaveInternalState.class),
        @XmlElement(name = "SecureBackup", type = ActionSecureBackup.class),
        @XmlElement(name = "SecureRestore", type = ActionSecureRestore.class),
        @XmlElement(name = "SelectConfig", type = ActionSelectConfig.class),
        @XmlElement(name = "SendErrorReport", type = ActionSendErrorReport.class),
        @XmlElement(name = "SendFile", type = ActionSendFile.class),
        @XmlElement(name = "SendLogEvent", type = ActionSendLogEvent.class),
        @XmlElement(name = "ServiceQuiesce", type = ActionServiceQuiesce.class),
        @XmlElement(name = "ServiceStatusQuiesce", type = ActionServiceStatusQuiesce.class),
        @XmlElement(name = "ServiceStatusUnquiesce", type = ActionServiceStatusUnquiesce.class),
        @XmlElement(name = "ServiceUnquiesce", type = ActionServiceUnquiesce.class),
        @XmlElement(name = "SetLogLevel", type = ActionSetLogLevel.class),
        @XmlElement(name = "SetRBMDebugLog", type = ActionSetRBMDebugLog.class),
        @XmlElement(name = "SetSystemVar", type = ActionSetSystemVar.class),
        @XmlElement(name = "SetTimeAndDate", type = ActionSetTimeAndDate.class),
        @XmlElement(name = "Shutdown", type = ActionShutdown.class),
        @XmlElement(name = "SLMResetStats", type = ActionSLMResetStats.class),
        @XmlElement(name = "StandalonePacketCapture", type = ActionStandalonePacketCapture.class),
        @XmlElement(name = "StandaloneStopPacketCapture", type = ActionStandaloneStopPacketCapture.class),
        @XmlElement(name = "StopPacketCapture", type = ActionStopPacketCapture.class),
        @XmlElement(name = "TCPConnectionTest", type = ActionTCPConnectionTest.class),
        @XmlElement(name = "TestHardware", type = ActionTestHardware.class),
        @XmlElement(name = "TestPasswordMap", type = ActionTestPasswordMap.class),
        @XmlElement(name = "TestRadius", type = ActionTestRadius.class),
        @XmlElement(name = "TestURLMap", type = ActionTestURLMap.class),
        @XmlElement(name = "TestURLRefresh", type = ActionTestURLRefresh.class),
        @XmlElement(name = "TestURLRewrite", type = ActionTestURLRewrite.class),
        @XmlElement(name = "TestValidateSchema", type = ActionTestValidateSchema.class),
        @XmlElement(name = "UnconfigureReverseProxy", type = ActionUnconfigureReverseProxy.class),
        @XmlElement(name = "UnconfigureRuntime", type = ActionUnconfigureRuntime.class),
        @XmlElement(name = "UndoConfig", type = ActionUndoConfig.class),
        @XmlElement(name = "UniversalPacketCaptureDebug", type = ActionUniversalPacketCaptureDebug.class),
        @XmlElement(name = "UniversalStopPacketCapture", type = ActionUniversalStopPacketCapture.class),
        @XmlElement(name = "Unquiesce", type = ActionUnquiesce.class),
        @XmlElement(name = "UnquiesceDP", type = ActionUnquiesceDP.class),
        @XmlElement(name = "UpgradeWatchdog", type = ActionUpgradeWatchdog.class),
        @XmlElement(name = "UserForcePasswordChange", type = ActionUserForcePasswordChange.class),
        @XmlElement(name = "UserResetFailedLogin", type = ActionUserResetFailedLogin.class),
        @XmlElement(name = "UserResetPassword", type = ActionUserResetPassword.class),
        @XmlElement(name = "ValCredAddCertsFromDir", type = ActionValCredAddCertsFromDir.class),
        @XmlElement(name = "VerifyFirmware", type = ActionVerifyFirmware.class),
        @XmlElement(name = "VLANPacketCapture", type = ActionVLANPacketCapture.class),
        @XmlElement(name = "VLANStopPacketCapture", type = ActionVLANStopPacketCapture.class),
        @XmlElement(name = "WsrrSynchronize", type = ActionWsrrSynchronize.class),
        @XmlElement(name = "WsrrValidateServer", type = ActionWsrrValidateServer.class),
        @XmlElement(name = "XC10ClearGrid", type = ActionXC10ClearGrid.class),
        @XmlElement(name = "XC10CreateGrid", type = ActionXC10CreateGrid.class),
        @XmlElement(name = "XC10DiscoverCollective", type = ActionXC10DiscoverCollective.class),
        @XmlElement(name = "YieldEthernetStandby", type = ActionYieldEthernetStandby.class),
        @XmlElement(name = "YieldLinkAggregationStandby", type = ActionYieldLinkAggregationStandby.class),
        @XmlElement(name = "YieldStandaloneStandby", type = ActionYieldStandaloneStandby.class),
        @XmlElement(name = "YieldVLANStandby", type = ActionYieldVLANStandby.class)
    })
    protected List<Object> actionObjects;

    /**
     * Gets the value of the actionObjects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actionObjects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActionObjects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActionAddKnownHost }
     * {@link ActionAddPasswordMap }
     * {@link ActionAddSelTestEntry }
     * {@link ActionAddTrustedHost }
     * {@link ActionApplyPatch }
     * {@link ActionAuthCookieCacheDelete }
     * {@link ActionB2BArchiveNow }
     * {@link ActionB2BHASwitchPrimary }
     * {@link ActionB2BMPCMsgDeleteDomain }
     * {@link ActionB2BMPCMsgDeleteDomainAll }
     * {@link ActionB2BMPCMsgDeleteId }
     * {@link ActionB2BMPCMsgViewId }
     * {@link ActionBackupConfig }
     * {@link ActionBootDelete }
     * {@link ActionBootSwitch }
     * {@link ActionCacheSchema }
     * {@link ActionCacheStylesheet }
     * {@link ActionCacheWSDL }
     * {@link ActionChangePassword }
     * {@link ActionClearSel }
     * {@link ActionConvertCertificate }
     * {@link ActionConvertKey }
     * {@link ActionCopyLocalTAMDb }
     * {@link ActionCreateDir }
     * {@link ActionCreateLunaClientCert }
     * {@link ActionCreateTAMFiles }
     * {@link ActionCryptoExport }
     * {@link ActionCryptoHwDisable }
     * {@link ActionCryptoImport }
     * {@link ActionCryptoModeSet }
     * {@link ActionDeleteFile }
     * {@link ActionDeleteHSMKey }
     * {@link ActionDeleteKnownHost }
     * {@link ActionDeleteKnownHostTable }
     * {@link ActionDeletePasswordMap }
     * {@link ActionDeleteTrustedHost }
     * {@link ActionDeviceCertificate }
     * {@link ActionDisableEthernetHardwareOffload }
     * {@link ActionDisableLinkAggregationHardwareOffload }
     * {@link ActionDisableVLANHardwareOffload }
     * {@link ActionDisconnect }
     * {@link ActionDomainQuiesce }
     * {@link ActionDomainUnquiesce }
     * {@link ActionebMS2Ping }
     * {@link ActionErrorReport }
     * {@link ActionExecConfig }
     * {@link ActionFetchFile }
     * {@link ActionFileCapture }
     * {@link ActionFlushAAACache }
     * {@link ActionFlushArpCache }
     * {@link ActionFlushDNSCache }
     * {@link ActionFlushDocumentCache }
     * {@link ActionFlushGatewayScriptCache }
     * {@link ActionFlushLDAPPoolCache }
     * {@link ActionFlushNDCache }
     * {@link ActionFlushNSSCache }
     * {@link ActionFlushPDPCache }
     * {@link ActionFlushRBMCache }
     * {@link ActionFlushStylesheetCache }
     * {@link ActionHSMCloneKWK }
     * {@link ActionHSMSetRole }
     * {@link ActionImportExecute }
     * {@link ActionImportLunaClientCert }
     * {@link ActionInitFibreChannelFilesystem }
     * {@link ActionInitializeCompactFlashFilesystem }
     * {@link ActionInitializeRaidVolumeFilesystem }
     * {@link ActionInitializeRaidVolumeFilesystem2 }
     * {@link ActionInitializeRaidVolumeFilesystemNoEncryption }
     * {@link ActionInitializeRaidVolumeFilesystemNoEncryptionMpt2Sas }
     * {@link ActionInitializeRaidVolumeFilesystemVirtual }
     * {@link ActionInitIScsiFilesystem }
     * {@link ActionInvalidateDocumentCache }
     * {@link ActionKerberosTicketDelete }
     * {@link ActionKeygen }
     * {@link ActionLinkAggregationPacketCapture }
     * {@link ActionLinkAggregationStopPacketCapture }
     * {@link ActionLocateDevice }
     * {@link ActionLunaHARecover }
     * {@link ActionLunaHASync }
     * {@link ActionLunaOTTUpdate }
     * {@link ActionMoveFile }
     * {@link ActionNoDebugAction }
     * {@link ActionNoPasswordMap }
     * {@link ActionOAuthCacheDelete }
     * {@link ActionPacketCapture }
     * {@link ActionPacketCaptureDebug }
     * {@link ActionPing }
     * {@link ActionQuiesce }
     * {@link ActionQuiesceDP }
     * {@link ActionQuotaEnforcementSwitchMaster }
     * {@link ActionRaidActivate }
     * {@link ActionRaidChangeEncryptionSettings2 }
     * {@link ActionRaidDelete }
     * {@link ActionRaidInitialize }
     * {@link ActionRaidLearnBattery }
     * {@link ActionRaidMakeHotSpare }
     * {@link ActionRaidRebuild }
     * {@link ActionRaidReconcileEncryptionSettings2 }
     * {@link ActionRateLimitConcurrentDeleteDomain }
     * {@link ActionRateLimitConcurrentDeleteKey }
     * {@link ActionRateLimitConcurrentDeleteType }
     * {@link ActionRateLimitCountDeleteDomain }
     * {@link ActionRateLimitCountDeleteKey }
     * {@link ActionRateLimitCountDeleteType }
     * {@link ActionRateLimitRateDeleteDomain }
     * {@link ActionRateLimitRateDeleteKey }
     * {@link ActionRateLimitRateDeleteType }
     * {@link ActionRateLimitTokenBucketDeleteDomain }
     * {@link ActionRateLimitTokenBucketDeleteKey }
     * {@link ActionRateLimitTokenBucketDeleteType }
     * {@link ActionRefreshDocument }
     * {@link ActionRefreshStylesheet }
     * {@link ActionRefreshTAMCerts }
     * {@link ActionRefreshTAMKeystorePwd }
     * {@link ActionRefreshWSDL }
     * {@link ActionRemoveCheckpoint }
     * {@link ActionRemoveDir }
     * {@link ActionRemoveStylesheet }
     * {@link ActionRepairCompactFlashFilesystem }
     * {@link ActionRepairFibreChannelFilesystem }
     * {@link ActionRepairIScsiFilesystem }
     * {@link ActionRepairRaidVolumeFilesystem }
     * {@link ActionReserved152 }
     * {@link ActionResetDomain }
     * {@link ActionResetThisDomain }
     * {@link ActionRestartDomain }
     * {@link ActionRestartThisDomain }
     * {@link ActionRollbackCheckpoint }
     * {@link ActionSaveCheckpoint }
     * {@link ActionSaveConfig }
     * {@link ActionSaveInternalState }
     * {@link ActionSecureBackup }
     * {@link ActionSecureRestore }
     * {@link ActionSelectConfig }
     * {@link ActionSendErrorReport }
     * {@link ActionSendFile }
     * {@link ActionSendLogEvent }
     * {@link ActionServiceQuiesce }
     * {@link ActionServiceStatusQuiesce }
     * {@link ActionServiceStatusUnquiesce }
     * {@link ActionServiceUnquiesce }
     * {@link ActionSetLogLevel }
     * {@link ActionSetRBMDebugLog }
     * {@link ActionSetSystemVar }
     * {@link ActionSetTimeAndDate }
     * {@link ActionShutdown }
     * {@link ActionSLMResetStats }
     * {@link ActionStandalonePacketCapture }
     * {@link ActionStandaloneStopPacketCapture }
     * {@link ActionStopPacketCapture }
     * {@link ActionTCPConnectionTest }
     * {@link ActionTestHardware }
     * {@link ActionTestPasswordMap }
     * {@link ActionTestRadius }
     * {@link ActionTestURLMap }
     * {@link ActionTestURLRefresh }
     * {@link ActionTestURLRewrite }
     * {@link ActionTestValidateSchema }
     * {@link ActionUnconfigureReverseProxy }
     * {@link ActionUnconfigureRuntime }
     * {@link ActionUndoConfig }
     * {@link ActionUniversalPacketCaptureDebug }
     * {@link ActionUniversalStopPacketCapture }
     * {@link ActionUnquiesce }
     * {@link ActionUnquiesceDP }
     * {@link ActionUpgradeWatchdog }
     * {@link ActionUserForcePasswordChange }
     * {@link ActionUserResetFailedLogin }
     * {@link ActionUserResetPassword }
     * {@link ActionValCredAddCertsFromDir }
     * {@link ActionVerifyFirmware }
     * {@link ActionVLANPacketCapture }
     * {@link ActionVLANStopPacketCapture }
     * {@link ActionWsrrSynchronize }
     * {@link ActionWsrrValidateServer }
     * {@link ActionXC10ClearGrid }
     * {@link ActionXC10CreateGrid }
     * {@link ActionXC10DiscoverCollective }
     * {@link ActionYieldEthernetStandby }
     * {@link ActionYieldLinkAggregationStandby }
     * {@link ActionYieldStandaloneStandby }
     * {@link ActionYieldVLANStandby }
     * 
     * 
     */
    public List<Object> getActionObjects() {
        if (actionObjects == null) {
            actionObjects = new ArrayList<Object>();
        }
        return this.actionObjects;
    }

}
