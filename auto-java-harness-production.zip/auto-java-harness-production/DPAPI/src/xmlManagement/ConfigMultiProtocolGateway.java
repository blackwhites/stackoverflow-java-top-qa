
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigMultiProtocolGateway complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigMultiProtocolGateway"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigGatewayBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="RequestType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FollowRedirects" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RewriteLocationHeader" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StylePolicy" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="Type"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmGatewayType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCompression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowCacheControlHeader" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRRSavedSearchSubscriptions" type="{http://www.datapower.com/schemas/management}dmWSRRSavedSearchWSDLSource" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="WSRRSubscriptions" type="{http://www.datapower.com/schemas/management}dmWSRRWSDLSource" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PolicyAttachments" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="PolicyParameter" type="{http://www.datapower.com/schemas/management}dmWSPolicyParameters" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="WSMAgentMonitor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSMAgentMonitorPCM" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSMPayloadCaptureMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProxyHTTPResponse" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ErrorPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="TransactionTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeIntervalMillis {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigMultiProtocolGateway", propOrder = {
    "requestType",
    "responseType",
    "followRedirects",
    "rewriteLocationHeader",
    "stylePolicy",
    "type",
    "allowCompression",
    "allowCacheControlHeader",
    "wsrrSavedSearchSubscriptions",
    "wsrrSubscriptions",
    "policyAttachments",
    "policyParameter",
    "wsmAgentMonitor",
    "wsmAgentMonitorPCM",
    "proxyHTTPResponse",
    "errorPolicy",
    "transactionTimeout"
})
public class ConfigMultiProtocolGateway
    extends ConfigGatewayBase
{

    @XmlElement(name = "RequestType")
    protected String requestType;
    @XmlElement(name = "ResponseType")
    protected String responseType;
    @XmlElement(name = "FollowRedirects")
    protected String followRedirects;
    @XmlElement(name = "RewriteLocationHeader")
    protected String rewriteLocationHeader;
    @XmlElement(name = "StylePolicy")
    protected DmReference stylePolicy;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "AllowCompression")
    protected String allowCompression;
    @XmlElement(name = "AllowCacheControlHeader")
    protected String allowCacheControlHeader;
    @XmlElement(name = "WSRRSavedSearchSubscriptions")
    protected List<DmWSRRSavedSearchWSDLSource> wsrrSavedSearchSubscriptions;
    @XmlElement(name = "WSRRSubscriptions")
    protected List<DmWSRRWSDLSource> wsrrSubscriptions;
    @XmlElement(name = "PolicyAttachments")
    protected DmReference policyAttachments;
    @XmlElement(name = "PolicyParameter")
    protected List<DmWSPolicyParameters> policyParameter;
    @XmlElement(name = "WSMAgentMonitor")
    protected String wsmAgentMonitor;
    @XmlElement(name = "WSMAgentMonitorPCM")
    protected String wsmAgentMonitorPCM;
    @XmlElement(name = "ProxyHTTPResponse")
    protected String proxyHTTPResponse;
    @XmlElement(name = "ErrorPolicy")
    protected DmReference errorPolicy;
    @XmlElement(name = "TransactionTimeout")
    protected String transactionTimeout;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the followRedirects property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFollowRedirects() {
        return followRedirects;
    }

    /**
     * Sets the value of the followRedirects property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFollowRedirects(String value) {
        this.followRedirects = value;
    }

    /**
     * Gets the value of the rewriteLocationHeader property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRewriteLocationHeader() {
        return rewriteLocationHeader;
    }

    /**
     * Sets the value of the rewriteLocationHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRewriteLocationHeader(String value) {
        this.rewriteLocationHeader = value;
    }

    /**
     * Gets the value of the stylePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getStylePolicy() {
        return stylePolicy;
    }

    /**
     * Sets the value of the stylePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setStylePolicy(DmReference value) {
        this.stylePolicy = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the allowCompression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCompression() {
        return allowCompression;
    }

    /**
     * Sets the value of the allowCompression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCompression(String value) {
        this.allowCompression = value;
    }

    /**
     * Gets the value of the allowCacheControlHeader property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowCacheControlHeader() {
        return allowCacheControlHeader;
    }

    /**
     * Sets the value of the allowCacheControlHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowCacheControlHeader(String value) {
        this.allowCacheControlHeader = value;
    }

    /**
     * Gets the value of the wsrrSavedSearchSubscriptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wsrrSavedSearchSubscriptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWSRRSavedSearchSubscriptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSRRSavedSearchWSDLSource }
     * 
     * 
     */
    public List<DmWSRRSavedSearchWSDLSource> getWSRRSavedSearchSubscriptions() {
        if (wsrrSavedSearchSubscriptions == null) {
            wsrrSavedSearchSubscriptions = new ArrayList<DmWSRRSavedSearchWSDLSource>();
        }
        return this.wsrrSavedSearchSubscriptions;
    }

    /**
     * Gets the value of the wsrrSubscriptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wsrrSubscriptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWSRRSubscriptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSRRWSDLSource }
     * 
     * 
     */
    public List<DmWSRRWSDLSource> getWSRRSubscriptions() {
        if (wsrrSubscriptions == null) {
            wsrrSubscriptions = new ArrayList<DmWSRRWSDLSource>();
        }
        return this.wsrrSubscriptions;
    }

    /**
     * Gets the value of the policyAttachments property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getPolicyAttachments() {
        return policyAttachments;
    }

    /**
     * Sets the value of the policyAttachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setPolicyAttachments(DmReference value) {
        this.policyAttachments = value;
    }

    /**
     * Gets the value of the policyParameter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the policyParameter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPolicyParameter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmWSPolicyParameters }
     * 
     * 
     */
    public List<DmWSPolicyParameters> getPolicyParameter() {
        if (policyParameter == null) {
            policyParameter = new ArrayList<DmWSPolicyParameters>();
        }
        return this.policyParameter;
    }

    /**
     * Gets the value of the wsmAgentMonitor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSMAgentMonitor() {
        return wsmAgentMonitor;
    }

    /**
     * Sets the value of the wsmAgentMonitor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSMAgentMonitor(String value) {
        this.wsmAgentMonitor = value;
    }

    /**
     * Gets the value of the wsmAgentMonitorPCM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSMAgentMonitorPCM() {
        return wsmAgentMonitorPCM;
    }

    /**
     * Sets the value of the wsmAgentMonitorPCM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSMAgentMonitorPCM(String value) {
        this.wsmAgentMonitorPCM = value;
    }

    /**
     * Gets the value of the proxyHTTPResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProxyHTTPResponse() {
        return proxyHTTPResponse;
    }

    /**
     * Sets the value of the proxyHTTPResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProxyHTTPResponse(String value) {
        this.proxyHTTPResponse = value;
    }

    /**
     * Gets the value of the errorPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getErrorPolicy() {
        return errorPolicy;
    }

    /**
     * Sets the value of the errorPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setErrorPolicy(DmReference value) {
        this.errorPolicy = value;
    }

    /**
     * Gets the value of the transactionTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionTimeout() {
        return transactionTimeout;
    }

    /**
     * Sets the value of the transactionTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionTimeout(String value) {
        this.transactionTimeout = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
