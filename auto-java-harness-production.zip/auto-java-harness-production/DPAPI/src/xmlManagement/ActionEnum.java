
package xmlManagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ActionEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="AddKnownHost"/&gt;
 *     &lt;enumeration value="AddPasswordMap"/&gt;
 *     &lt;enumeration value="AddSelTestEntry"/&gt;
 *     &lt;enumeration value="AddTrustedHost"/&gt;
 *     &lt;enumeration value="ApplyPatch"/&gt;
 *     &lt;enumeration value="AuthCookieCacheDelete"/&gt;
 *     &lt;enumeration value="B2BArchiveNow"/&gt;
 *     &lt;enumeration value="B2BHASwitchPrimary"/&gt;
 *     &lt;enumeration value="B2BMPCMsgDeleteDomain"/&gt;
 *     &lt;enumeration value="B2BMPCMsgDeleteDomainAll"/&gt;
 *     &lt;enumeration value="B2BMPCMsgDeleteId"/&gt;
 *     &lt;enumeration value="B2BMPCMsgViewId"/&gt;
 *     &lt;enumeration value="BackupConfig"/&gt;
 *     &lt;enumeration value="BootDelete"/&gt;
 *     &lt;enumeration value="BootSwitch"/&gt;
 *     &lt;enumeration value="CacheSchema"/&gt;
 *     &lt;enumeration value="CacheStylesheet"/&gt;
 *     &lt;enumeration value="CacheWSDL"/&gt;
 *     &lt;enumeration value="ChangePassword"/&gt;
 *     &lt;enumeration value="ClearSel"/&gt;
 *     &lt;enumeration value="ConvertCertificate"/&gt;
 *     &lt;enumeration value="ConvertKey"/&gt;
 *     &lt;enumeration value="CopyLocalTAMDb"/&gt;
 *     &lt;enumeration value="CreateDir"/&gt;
 *     &lt;enumeration value="CreateLunaClientCert"/&gt;
 *     &lt;enumeration value="CreateTAMFiles"/&gt;
 *     &lt;enumeration value="CryptoExport"/&gt;
 *     &lt;enumeration value="CryptoHwDisable"/&gt;
 *     &lt;enumeration value="CryptoImport"/&gt;
 *     &lt;enumeration value="CryptoModeSet"/&gt;
 *     &lt;enumeration value="DeleteFile"/&gt;
 *     &lt;enumeration value="DeleteHSMKey"/&gt;
 *     &lt;enumeration value="DeleteKnownHost"/&gt;
 *     &lt;enumeration value="DeleteKnownHostTable"/&gt;
 *     &lt;enumeration value="DeletePasswordMap"/&gt;
 *     &lt;enumeration value="DeleteTrustedHost"/&gt;
 *     &lt;enumeration value="DeviceCertificate"/&gt;
 *     &lt;enumeration value="DisableEthernetHardwareOffload"/&gt;
 *     &lt;enumeration value="DisableLinkAggregationHardwareOffload"/&gt;
 *     &lt;enumeration value="DisableVLANHardwareOffload"/&gt;
 *     &lt;enumeration value="Disconnect"/&gt;
 *     &lt;enumeration value="DomainQuiesce"/&gt;
 *     &lt;enumeration value="DomainUnquiesce"/&gt;
 *     &lt;enumeration value="ebMS2Ping"/&gt;
 *     &lt;enumeration value="ErrorReport"/&gt;
 *     &lt;enumeration value="ExecConfig"/&gt;
 *     &lt;enumeration value="FetchFile"/&gt;
 *     &lt;enumeration value="FileCapture"/&gt;
 *     &lt;enumeration value="FlushAAACache"/&gt;
 *     &lt;enumeration value="FlushArpCache"/&gt;
 *     &lt;enumeration value="FlushDNSCache"/&gt;
 *     &lt;enumeration value="FlushDocumentCache"/&gt;
 *     &lt;enumeration value="FlushGatewayScriptCache"/&gt;
 *     &lt;enumeration value="FlushLDAPPoolCache"/&gt;
 *     &lt;enumeration value="FlushNDCache"/&gt;
 *     &lt;enumeration value="FlushNSSCache"/&gt;
 *     &lt;enumeration value="FlushPDPCache"/&gt;
 *     &lt;enumeration value="FlushRBMCache"/&gt;
 *     &lt;enumeration value="FlushStylesheetCache"/&gt;
 *     &lt;enumeration value="HSMCloneKWK"/&gt;
 *     &lt;enumeration value="HSMSetRole"/&gt;
 *     &lt;enumeration value="ImportExecute"/&gt;
 *     &lt;enumeration value="ImportLunaClientCert"/&gt;
 *     &lt;enumeration value="InitFibreChannelFilesystem"/&gt;
 *     &lt;enumeration value="InitializeCompactFlashFilesystem"/&gt;
 *     &lt;enumeration value="InitializeRaidVolumeFilesystem"/&gt;
 *     &lt;enumeration value="InitializeRaidVolumeFilesystem2"/&gt;
 *     &lt;enumeration value="InitializeRaidVolumeFilesystemNoEncryption"/&gt;
 *     &lt;enumeration value="InitializeRaidVolumeFilesystemNoEncryptionMpt2Sas"/&gt;
 *     &lt;enumeration value="InitializeRaidVolumeFilesystemVirtual"/&gt;
 *     &lt;enumeration value="InitIScsiFilesystem"/&gt;
 *     &lt;enumeration value="InvalidateDocumentCache"/&gt;
 *     &lt;enumeration value="KerberosTicketDelete"/&gt;
 *     &lt;enumeration value="Keygen"/&gt;
 *     &lt;enumeration value="LinkAggregationPacketCapture"/&gt;
 *     &lt;enumeration value="LinkAggregationStopPacketCapture"/&gt;
 *     &lt;enumeration value="LocateDevice"/&gt;
 *     &lt;enumeration value="LunaHARecover"/&gt;
 *     &lt;enumeration value="LunaHASync"/&gt;
 *     &lt;enumeration value="LunaOTTUpdate"/&gt;
 *     &lt;enumeration value="MoveFile"/&gt;
 *     &lt;enumeration value="NoDebugAction"/&gt;
 *     &lt;enumeration value="NoPasswordMap"/&gt;
 *     &lt;enumeration value="OAuthCacheDelete"/&gt;
 *     &lt;enumeration value="PacketCapture"/&gt;
 *     &lt;enumeration value="PacketCaptureDebug"/&gt;
 *     &lt;enumeration value="Ping"/&gt;
 *     &lt;enumeration value="Quiesce"/&gt;
 *     &lt;enumeration value="QuiesceDP"/&gt;
 *     &lt;enumeration value="QuotaEnforcementSwitchMaster"/&gt;
 *     &lt;enumeration value="RaidActivate"/&gt;
 *     &lt;enumeration value="RaidChangeEncryptionSettings2"/&gt;
 *     &lt;enumeration value="RaidDelete"/&gt;
 *     &lt;enumeration value="RaidInitialize"/&gt;
 *     &lt;enumeration value="RaidLearnBattery"/&gt;
 *     &lt;enumeration value="RaidMakeHotSpare"/&gt;
 *     &lt;enumeration value="RaidRebuild"/&gt;
 *     &lt;enumeration value="RaidReconcileEncryptionSettings2"/&gt;
 *     &lt;enumeration value="RateLimitConcurrentDeleteDomain"/&gt;
 *     &lt;enumeration value="RateLimitConcurrentDeleteKey"/&gt;
 *     &lt;enumeration value="RateLimitConcurrentDeleteType"/&gt;
 *     &lt;enumeration value="RateLimitCountDeleteDomain"/&gt;
 *     &lt;enumeration value="RateLimitCountDeleteKey"/&gt;
 *     &lt;enumeration value="RateLimitCountDeleteType"/&gt;
 *     &lt;enumeration value="RateLimitRateDeleteDomain"/&gt;
 *     &lt;enumeration value="RateLimitRateDeleteKey"/&gt;
 *     &lt;enumeration value="RateLimitRateDeleteType"/&gt;
 *     &lt;enumeration value="RateLimitTokenBucketDeleteDomain"/&gt;
 *     &lt;enumeration value="RateLimitTokenBucketDeleteKey"/&gt;
 *     &lt;enumeration value="RateLimitTokenBucketDeleteType"/&gt;
 *     &lt;enumeration value="RefreshDocument"/&gt;
 *     &lt;enumeration value="RefreshStylesheet"/&gt;
 *     &lt;enumeration value="RefreshTAMCerts"/&gt;
 *     &lt;enumeration value="RefreshTAMKeystorePwd"/&gt;
 *     &lt;enumeration value="RefreshWSDL"/&gt;
 *     &lt;enumeration value="RemoveCheckpoint"/&gt;
 *     &lt;enumeration value="RemoveDir"/&gt;
 *     &lt;enumeration value="RemoveStylesheet"/&gt;
 *     &lt;enumeration value="RepairCompactFlashFilesystem"/&gt;
 *     &lt;enumeration value="RepairFibreChannelFilesystem"/&gt;
 *     &lt;enumeration value="RepairIScsiFilesystem"/&gt;
 *     &lt;enumeration value="RepairRaidVolumeFilesystem"/&gt;
 *     &lt;enumeration value="Reserved152"/&gt;
 *     &lt;enumeration value="ResetDomain"/&gt;
 *     &lt;enumeration value="ResetThisDomain"/&gt;
 *     &lt;enumeration value="RestartDomain"/&gt;
 *     &lt;enumeration value="RestartThisDomain"/&gt;
 *     &lt;enumeration value="RollbackCheckpoint"/&gt;
 *     &lt;enumeration value="SaveCheckpoint"/&gt;
 *     &lt;enumeration value="SaveConfig"/&gt;
 *     &lt;enumeration value="SaveInternalState"/&gt;
 *     &lt;enumeration value="SecureBackup"/&gt;
 *     &lt;enumeration value="SecureRestore"/&gt;
 *     &lt;enumeration value="SelectConfig"/&gt;
 *     &lt;enumeration value="SendErrorReport"/&gt;
 *     &lt;enumeration value="SendFile"/&gt;
 *     &lt;enumeration value="SendLogEvent"/&gt;
 *     &lt;enumeration value="ServiceQuiesce"/&gt;
 *     &lt;enumeration value="ServiceStatusQuiesce"/&gt;
 *     &lt;enumeration value="ServiceStatusUnquiesce"/&gt;
 *     &lt;enumeration value="ServiceUnquiesce"/&gt;
 *     &lt;enumeration value="SetLogLevel"/&gt;
 *     &lt;enumeration value="SetRBMDebugLog"/&gt;
 *     &lt;enumeration value="SetSystemVar"/&gt;
 *     &lt;enumeration value="SetTimeAndDate"/&gt;
 *     &lt;enumeration value="Shutdown"/&gt;
 *     &lt;enumeration value="SLMResetStats"/&gt;
 *     &lt;enumeration value="StandalonePacketCapture"/&gt;
 *     &lt;enumeration value="StandaloneStopPacketCapture"/&gt;
 *     &lt;enumeration value="StopPacketCapture"/&gt;
 *     &lt;enumeration value="TCPConnectionTest"/&gt;
 *     &lt;enumeration value="TestHardware"/&gt;
 *     &lt;enumeration value="TestPasswordMap"/&gt;
 *     &lt;enumeration value="TestRadius"/&gt;
 *     &lt;enumeration value="TestURLMap"/&gt;
 *     &lt;enumeration value="TestURLRefresh"/&gt;
 *     &lt;enumeration value="TestURLRewrite"/&gt;
 *     &lt;enumeration value="TestValidateSchema"/&gt;
 *     &lt;enumeration value="UnconfigureReverseProxy"/&gt;
 *     &lt;enumeration value="UnconfigureRuntime"/&gt;
 *     &lt;enumeration value="UndoConfig"/&gt;
 *     &lt;enumeration value="UniversalPacketCaptureDebug"/&gt;
 *     &lt;enumeration value="UniversalStopPacketCapture"/&gt;
 *     &lt;enumeration value="Unquiesce"/&gt;
 *     &lt;enumeration value="UnquiesceDP"/&gt;
 *     &lt;enumeration value="UpgradeWatchdog"/&gt;
 *     &lt;enumeration value="UserForcePasswordChange"/&gt;
 *     &lt;enumeration value="UserResetFailedLogin"/&gt;
 *     &lt;enumeration value="UserResetPassword"/&gt;
 *     &lt;enumeration value="ValCredAddCertsFromDir"/&gt;
 *     &lt;enumeration value="VerifyFirmware"/&gt;
 *     &lt;enumeration value="VLANPacketCapture"/&gt;
 *     &lt;enumeration value="VLANStopPacketCapture"/&gt;
 *     &lt;enumeration value="WsrrSynchronize"/&gt;
 *     &lt;enumeration value="WsrrValidateServer"/&gt;
 *     &lt;enumeration value="XC10ClearGrid"/&gt;
 *     &lt;enumeration value="XC10CreateGrid"/&gt;
 *     &lt;enumeration value="XC10DiscoverCollective"/&gt;
 *     &lt;enumeration value="YieldEthernetStandby"/&gt;
 *     &lt;enumeration value="YieldLinkAggregationStandby"/&gt;
 *     &lt;enumeration value="YieldStandaloneStandby"/&gt;
 *     &lt;enumeration value="YieldVLANStandby"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ActionEnum")
@XmlEnum
public enum ActionEnum {

    @XmlEnumValue("AddKnownHost")
    ADD_KNOWN_HOST("AddKnownHost"),
    @XmlEnumValue("AddPasswordMap")
    ADD_PASSWORD_MAP("AddPasswordMap"),
    @XmlEnumValue("AddSelTestEntry")
    ADD_SEL_TEST_ENTRY("AddSelTestEntry"),
    @XmlEnumValue("AddTrustedHost")
    ADD_TRUSTED_HOST("AddTrustedHost"),
    @XmlEnumValue("ApplyPatch")
    APPLY_PATCH("ApplyPatch"),
    @XmlEnumValue("AuthCookieCacheDelete")
    AUTH_COOKIE_CACHE_DELETE("AuthCookieCacheDelete"),
    @XmlEnumValue("B2BArchiveNow")
    B_2_B_ARCHIVE_NOW("B2BArchiveNow"),
    @XmlEnumValue("B2BHASwitchPrimary")
    B_2_BHA_SWITCH_PRIMARY("B2BHASwitchPrimary"),
    @XmlEnumValue("B2BMPCMsgDeleteDomain")
    B_2_BMPC_MSG_DELETE_DOMAIN("B2BMPCMsgDeleteDomain"),
    @XmlEnumValue("B2BMPCMsgDeleteDomainAll")
    B_2_BMPC_MSG_DELETE_DOMAIN_ALL("B2BMPCMsgDeleteDomainAll"),
    @XmlEnumValue("B2BMPCMsgDeleteId")
    B_2_BMPC_MSG_DELETE_ID("B2BMPCMsgDeleteId"),
    @XmlEnumValue("B2BMPCMsgViewId")
    B_2_BMPC_MSG_VIEW_ID("B2BMPCMsgViewId"),
    @XmlEnumValue("BackupConfig")
    BACKUP_CONFIG("BackupConfig"),
    @XmlEnumValue("BootDelete")
    BOOT_DELETE("BootDelete"),
    @XmlEnumValue("BootSwitch")
    BOOT_SWITCH("BootSwitch"),
    @XmlEnumValue("CacheSchema")
    CACHE_SCHEMA("CacheSchema"),
    @XmlEnumValue("CacheStylesheet")
    CACHE_STYLESHEET("CacheStylesheet"),
    @XmlEnumValue("CacheWSDL")
    CACHE_WSDL("CacheWSDL"),
    @XmlEnumValue("ChangePassword")
    CHANGE_PASSWORD("ChangePassword"),
    @XmlEnumValue("ClearSel")
    CLEAR_SEL("ClearSel"),
    @XmlEnumValue("ConvertCertificate")
    CONVERT_CERTIFICATE("ConvertCertificate"),
    @XmlEnumValue("ConvertKey")
    CONVERT_KEY("ConvertKey"),
    @XmlEnumValue("CopyLocalTAMDb")
    COPY_LOCAL_TAM_DB("CopyLocalTAMDb"),
    @XmlEnumValue("CreateDir")
    CREATE_DIR("CreateDir"),
    @XmlEnumValue("CreateLunaClientCert")
    CREATE_LUNA_CLIENT_CERT("CreateLunaClientCert"),
    @XmlEnumValue("CreateTAMFiles")
    CREATE_TAM_FILES("CreateTAMFiles"),
    @XmlEnumValue("CryptoExport")
    CRYPTO_EXPORT("CryptoExport"),
    @XmlEnumValue("CryptoHwDisable")
    CRYPTO_HW_DISABLE("CryptoHwDisable"),
    @XmlEnumValue("CryptoImport")
    CRYPTO_IMPORT("CryptoImport"),
    @XmlEnumValue("CryptoModeSet")
    CRYPTO_MODE_SET("CryptoModeSet"),
    @XmlEnumValue("DeleteFile")
    DELETE_FILE("DeleteFile"),
    @XmlEnumValue("DeleteHSMKey")
    DELETE_HSM_KEY("DeleteHSMKey"),
    @XmlEnumValue("DeleteKnownHost")
    DELETE_KNOWN_HOST("DeleteKnownHost"),
    @XmlEnumValue("DeleteKnownHostTable")
    DELETE_KNOWN_HOST_TABLE("DeleteKnownHostTable"),
    @XmlEnumValue("DeletePasswordMap")
    DELETE_PASSWORD_MAP("DeletePasswordMap"),
    @XmlEnumValue("DeleteTrustedHost")
    DELETE_TRUSTED_HOST("DeleteTrustedHost"),
    @XmlEnumValue("DeviceCertificate")
    DEVICE_CERTIFICATE("DeviceCertificate"),
    @XmlEnumValue("DisableEthernetHardwareOffload")
    DISABLE_ETHERNET_HARDWARE_OFFLOAD("DisableEthernetHardwareOffload"),
    @XmlEnumValue("DisableLinkAggregationHardwareOffload")
    DISABLE_LINK_AGGREGATION_HARDWARE_OFFLOAD("DisableLinkAggregationHardwareOffload"),
    @XmlEnumValue("DisableVLANHardwareOffload")
    DISABLE_VLAN_HARDWARE_OFFLOAD("DisableVLANHardwareOffload"),
    @XmlEnumValue("Disconnect")
    DISCONNECT("Disconnect"),
    @XmlEnumValue("DomainQuiesce")
    DOMAIN_QUIESCE("DomainQuiesce"),
    @XmlEnumValue("DomainUnquiesce")
    DOMAIN_UNQUIESCE("DomainUnquiesce"),
    @XmlEnumValue("ebMS2Ping")
    EB_MS_2_PING("ebMS2Ping"),
    @XmlEnumValue("ErrorReport")
    ERROR_REPORT("ErrorReport"),
    @XmlEnumValue("ExecConfig")
    EXEC_CONFIG("ExecConfig"),
    @XmlEnumValue("FetchFile")
    FETCH_FILE("FetchFile"),
    @XmlEnumValue("FileCapture")
    FILE_CAPTURE("FileCapture"),
    @XmlEnumValue("FlushAAACache")
    FLUSH_AAA_CACHE("FlushAAACache"),
    @XmlEnumValue("FlushArpCache")
    FLUSH_ARP_CACHE("FlushArpCache"),
    @XmlEnumValue("FlushDNSCache")
    FLUSH_DNS_CACHE("FlushDNSCache"),
    @XmlEnumValue("FlushDocumentCache")
    FLUSH_DOCUMENT_CACHE("FlushDocumentCache"),
    @XmlEnumValue("FlushGatewayScriptCache")
    FLUSH_GATEWAY_SCRIPT_CACHE("FlushGatewayScriptCache"),
    @XmlEnumValue("FlushLDAPPoolCache")
    FLUSH_LDAP_POOL_CACHE("FlushLDAPPoolCache"),
    @XmlEnumValue("FlushNDCache")
    FLUSH_ND_CACHE("FlushNDCache"),
    @XmlEnumValue("FlushNSSCache")
    FLUSH_NSS_CACHE("FlushNSSCache"),
    @XmlEnumValue("FlushPDPCache")
    FLUSH_PDP_CACHE("FlushPDPCache"),
    @XmlEnumValue("FlushRBMCache")
    FLUSH_RBM_CACHE("FlushRBMCache"),
    @XmlEnumValue("FlushStylesheetCache")
    FLUSH_STYLESHEET_CACHE("FlushStylesheetCache"),
    @XmlEnumValue("HSMCloneKWK")
    HSM_CLONE_KWK("HSMCloneKWK"),
    @XmlEnumValue("HSMSetRole")
    HSM_SET_ROLE("HSMSetRole"),
    @XmlEnumValue("ImportExecute")
    IMPORT_EXECUTE("ImportExecute"),
    @XmlEnumValue("ImportLunaClientCert")
    IMPORT_LUNA_CLIENT_CERT("ImportLunaClientCert"),
    @XmlEnumValue("InitFibreChannelFilesystem")
    INIT_FIBRE_CHANNEL_FILESYSTEM("InitFibreChannelFilesystem"),
    @XmlEnumValue("InitializeCompactFlashFilesystem")
    INITIALIZE_COMPACT_FLASH_FILESYSTEM("InitializeCompactFlashFilesystem"),
    @XmlEnumValue("InitializeRaidVolumeFilesystem")
    INITIALIZE_RAID_VOLUME_FILESYSTEM("InitializeRaidVolumeFilesystem"),
    @XmlEnumValue("InitializeRaidVolumeFilesystem2")
    INITIALIZE_RAID_VOLUME_FILESYSTEM_2("InitializeRaidVolumeFilesystem2"),
    @XmlEnumValue("InitializeRaidVolumeFilesystemNoEncryption")
    INITIALIZE_RAID_VOLUME_FILESYSTEM_NO_ENCRYPTION("InitializeRaidVolumeFilesystemNoEncryption"),
    @XmlEnumValue("InitializeRaidVolumeFilesystemNoEncryptionMpt2Sas")
    INITIALIZE_RAID_VOLUME_FILESYSTEM_NO_ENCRYPTION_MPT_2_SAS("InitializeRaidVolumeFilesystemNoEncryptionMpt2Sas"),
    @XmlEnumValue("InitializeRaidVolumeFilesystemVirtual")
    INITIALIZE_RAID_VOLUME_FILESYSTEM_VIRTUAL("InitializeRaidVolumeFilesystemVirtual"),
    @XmlEnumValue("InitIScsiFilesystem")
    INIT_I_SCSI_FILESYSTEM("InitIScsiFilesystem"),
    @XmlEnumValue("InvalidateDocumentCache")
    INVALIDATE_DOCUMENT_CACHE("InvalidateDocumentCache"),
    @XmlEnumValue("KerberosTicketDelete")
    KERBEROS_TICKET_DELETE("KerberosTicketDelete"),
    @XmlEnumValue("Keygen")
    KEYGEN("Keygen"),
    @XmlEnumValue("LinkAggregationPacketCapture")
    LINK_AGGREGATION_PACKET_CAPTURE("LinkAggregationPacketCapture"),
    @XmlEnumValue("LinkAggregationStopPacketCapture")
    LINK_AGGREGATION_STOP_PACKET_CAPTURE("LinkAggregationStopPacketCapture"),
    @XmlEnumValue("LocateDevice")
    LOCATE_DEVICE("LocateDevice"),
    @XmlEnumValue("LunaHARecover")
    LUNA_HA_RECOVER("LunaHARecover"),
    @XmlEnumValue("LunaHASync")
    LUNA_HA_SYNC("LunaHASync"),
    @XmlEnumValue("LunaOTTUpdate")
    LUNA_OTT_UPDATE("LunaOTTUpdate"),
    @XmlEnumValue("MoveFile")
    MOVE_FILE("MoveFile"),
    @XmlEnumValue("NoDebugAction")
    NO_DEBUG_ACTION("NoDebugAction"),
    @XmlEnumValue("NoPasswordMap")
    NO_PASSWORD_MAP("NoPasswordMap"),
    @XmlEnumValue("OAuthCacheDelete")
    O_AUTH_CACHE_DELETE("OAuthCacheDelete"),
    @XmlEnumValue("PacketCapture")
    PACKET_CAPTURE("PacketCapture"),
    @XmlEnumValue("PacketCaptureDebug")
    PACKET_CAPTURE_DEBUG("PacketCaptureDebug"),
    @XmlEnumValue("Ping")
    PING("Ping"),
    @XmlEnumValue("Quiesce")
    QUIESCE("Quiesce"),
    @XmlEnumValue("QuiesceDP")
    QUIESCE_DP("QuiesceDP"),
    @XmlEnumValue("QuotaEnforcementSwitchMaster")
    QUOTA_ENFORCEMENT_SWITCH_MASTER("QuotaEnforcementSwitchMaster"),
    @XmlEnumValue("RaidActivate")
    RAID_ACTIVATE("RaidActivate"),
    @XmlEnumValue("RaidChangeEncryptionSettings2")
    RAID_CHANGE_ENCRYPTION_SETTINGS_2("RaidChangeEncryptionSettings2"),
    @XmlEnumValue("RaidDelete")
    RAID_DELETE("RaidDelete"),
    @XmlEnumValue("RaidInitialize")
    RAID_INITIALIZE("RaidInitialize"),
    @XmlEnumValue("RaidLearnBattery")
    RAID_LEARN_BATTERY("RaidLearnBattery"),
    @XmlEnumValue("RaidMakeHotSpare")
    RAID_MAKE_HOT_SPARE("RaidMakeHotSpare"),
    @XmlEnumValue("RaidRebuild")
    RAID_REBUILD("RaidRebuild"),
    @XmlEnumValue("RaidReconcileEncryptionSettings2")
    RAID_RECONCILE_ENCRYPTION_SETTINGS_2("RaidReconcileEncryptionSettings2"),
    @XmlEnumValue("RateLimitConcurrentDeleteDomain")
    RATE_LIMIT_CONCURRENT_DELETE_DOMAIN("RateLimitConcurrentDeleteDomain"),
    @XmlEnumValue("RateLimitConcurrentDeleteKey")
    RATE_LIMIT_CONCURRENT_DELETE_KEY("RateLimitConcurrentDeleteKey"),
    @XmlEnumValue("RateLimitConcurrentDeleteType")
    RATE_LIMIT_CONCURRENT_DELETE_TYPE("RateLimitConcurrentDeleteType"),
    @XmlEnumValue("RateLimitCountDeleteDomain")
    RATE_LIMIT_COUNT_DELETE_DOMAIN("RateLimitCountDeleteDomain"),
    @XmlEnumValue("RateLimitCountDeleteKey")
    RATE_LIMIT_COUNT_DELETE_KEY("RateLimitCountDeleteKey"),
    @XmlEnumValue("RateLimitCountDeleteType")
    RATE_LIMIT_COUNT_DELETE_TYPE("RateLimitCountDeleteType"),
    @XmlEnumValue("RateLimitRateDeleteDomain")
    RATE_LIMIT_RATE_DELETE_DOMAIN("RateLimitRateDeleteDomain"),
    @XmlEnumValue("RateLimitRateDeleteKey")
    RATE_LIMIT_RATE_DELETE_KEY("RateLimitRateDeleteKey"),
    @XmlEnumValue("RateLimitRateDeleteType")
    RATE_LIMIT_RATE_DELETE_TYPE("RateLimitRateDeleteType"),
    @XmlEnumValue("RateLimitTokenBucketDeleteDomain")
    RATE_LIMIT_TOKEN_BUCKET_DELETE_DOMAIN("RateLimitTokenBucketDeleteDomain"),
    @XmlEnumValue("RateLimitTokenBucketDeleteKey")
    RATE_LIMIT_TOKEN_BUCKET_DELETE_KEY("RateLimitTokenBucketDeleteKey"),
    @XmlEnumValue("RateLimitTokenBucketDeleteType")
    RATE_LIMIT_TOKEN_BUCKET_DELETE_TYPE("RateLimitTokenBucketDeleteType"),
    @XmlEnumValue("RefreshDocument")
    REFRESH_DOCUMENT("RefreshDocument"),
    @XmlEnumValue("RefreshStylesheet")
    REFRESH_STYLESHEET("RefreshStylesheet"),
    @XmlEnumValue("RefreshTAMCerts")
    REFRESH_TAM_CERTS("RefreshTAMCerts"),
    @XmlEnumValue("RefreshTAMKeystorePwd")
    REFRESH_TAM_KEYSTORE_PWD("RefreshTAMKeystorePwd"),
    @XmlEnumValue("RefreshWSDL")
    REFRESH_WSDL("RefreshWSDL"),
    @XmlEnumValue("RemoveCheckpoint")
    REMOVE_CHECKPOINT("RemoveCheckpoint"),
    @XmlEnumValue("RemoveDir")
    REMOVE_DIR("RemoveDir"),
    @XmlEnumValue("RemoveStylesheet")
    REMOVE_STYLESHEET("RemoveStylesheet"),
    @XmlEnumValue("RepairCompactFlashFilesystem")
    REPAIR_COMPACT_FLASH_FILESYSTEM("RepairCompactFlashFilesystem"),
    @XmlEnumValue("RepairFibreChannelFilesystem")
    REPAIR_FIBRE_CHANNEL_FILESYSTEM("RepairFibreChannelFilesystem"),
    @XmlEnumValue("RepairIScsiFilesystem")
    REPAIR_I_SCSI_FILESYSTEM("RepairIScsiFilesystem"),
    @XmlEnumValue("RepairRaidVolumeFilesystem")
    REPAIR_RAID_VOLUME_FILESYSTEM("RepairRaidVolumeFilesystem"),
    @XmlEnumValue("Reserved152")
    RESERVED_152("Reserved152"),
    @XmlEnumValue("ResetDomain")
    RESET_DOMAIN("ResetDomain"),
    @XmlEnumValue("ResetThisDomain")
    RESET_THIS_DOMAIN("ResetThisDomain"),
    @XmlEnumValue("RestartDomain")
    RESTART_DOMAIN("RestartDomain"),
    @XmlEnumValue("RestartThisDomain")
    RESTART_THIS_DOMAIN("RestartThisDomain"),
    @XmlEnumValue("RollbackCheckpoint")
    ROLLBACK_CHECKPOINT("RollbackCheckpoint"),
    @XmlEnumValue("SaveCheckpoint")
    SAVE_CHECKPOINT("SaveCheckpoint"),
    @XmlEnumValue("SaveConfig")
    SAVE_CONFIG("SaveConfig"),
    @XmlEnumValue("SaveInternalState")
    SAVE_INTERNAL_STATE("SaveInternalState"),
    @XmlEnumValue("SecureBackup")
    SECURE_BACKUP("SecureBackup"),
    @XmlEnumValue("SecureRestore")
    SECURE_RESTORE("SecureRestore"),
    @XmlEnumValue("SelectConfig")
    SELECT_CONFIG("SelectConfig"),
    @XmlEnumValue("SendErrorReport")
    SEND_ERROR_REPORT("SendErrorReport"),
    @XmlEnumValue("SendFile")
    SEND_FILE("SendFile"),
    @XmlEnumValue("SendLogEvent")
    SEND_LOG_EVENT("SendLogEvent"),
    @XmlEnumValue("ServiceQuiesce")
    SERVICE_QUIESCE("ServiceQuiesce"),
    @XmlEnumValue("ServiceStatusQuiesce")
    SERVICE_STATUS_QUIESCE("ServiceStatusQuiesce"),
    @XmlEnumValue("ServiceStatusUnquiesce")
    SERVICE_STATUS_UNQUIESCE("ServiceStatusUnquiesce"),
    @XmlEnumValue("ServiceUnquiesce")
    SERVICE_UNQUIESCE("ServiceUnquiesce"),
    @XmlEnumValue("SetLogLevel")
    SET_LOG_LEVEL("SetLogLevel"),
    @XmlEnumValue("SetRBMDebugLog")
    SET_RBM_DEBUG_LOG("SetRBMDebugLog"),
    @XmlEnumValue("SetSystemVar")
    SET_SYSTEM_VAR("SetSystemVar"),
    @XmlEnumValue("SetTimeAndDate")
    SET_TIME_AND_DATE("SetTimeAndDate"),
    @XmlEnumValue("Shutdown")
    SHUTDOWN("Shutdown"),
    @XmlEnumValue("SLMResetStats")
    SLM_RESET_STATS("SLMResetStats"),
    @XmlEnumValue("StandalonePacketCapture")
    STANDALONE_PACKET_CAPTURE("StandalonePacketCapture"),
    @XmlEnumValue("StandaloneStopPacketCapture")
    STANDALONE_STOP_PACKET_CAPTURE("StandaloneStopPacketCapture"),
    @XmlEnumValue("StopPacketCapture")
    STOP_PACKET_CAPTURE("StopPacketCapture"),
    @XmlEnumValue("TCPConnectionTest")
    TCP_CONNECTION_TEST("TCPConnectionTest"),
    @XmlEnumValue("TestHardware")
    TEST_HARDWARE("TestHardware"),
    @XmlEnumValue("TestPasswordMap")
    TEST_PASSWORD_MAP("TestPasswordMap"),
    @XmlEnumValue("TestRadius")
    TEST_RADIUS("TestRadius"),
    @XmlEnumValue("TestURLMap")
    TEST_URL_MAP("TestURLMap"),
    @XmlEnumValue("TestURLRefresh")
    TEST_URL_REFRESH("TestURLRefresh"),
    @XmlEnumValue("TestURLRewrite")
    TEST_URL_REWRITE("TestURLRewrite"),
    @XmlEnumValue("TestValidateSchema")
    TEST_VALIDATE_SCHEMA("TestValidateSchema"),
    @XmlEnumValue("UnconfigureReverseProxy")
    UNCONFIGURE_REVERSE_PROXY("UnconfigureReverseProxy"),
    @XmlEnumValue("UnconfigureRuntime")
    UNCONFIGURE_RUNTIME("UnconfigureRuntime"),
    @XmlEnumValue("UndoConfig")
    UNDO_CONFIG("UndoConfig"),
    @XmlEnumValue("UniversalPacketCaptureDebug")
    UNIVERSAL_PACKET_CAPTURE_DEBUG("UniversalPacketCaptureDebug"),
    @XmlEnumValue("UniversalStopPacketCapture")
    UNIVERSAL_STOP_PACKET_CAPTURE("UniversalStopPacketCapture"),
    @XmlEnumValue("Unquiesce")
    UNQUIESCE("Unquiesce"),
    @XmlEnumValue("UnquiesceDP")
    UNQUIESCE_DP("UnquiesceDP"),
    @XmlEnumValue("UpgradeWatchdog")
    UPGRADE_WATCHDOG("UpgradeWatchdog"),
    @XmlEnumValue("UserForcePasswordChange")
    USER_FORCE_PASSWORD_CHANGE("UserForcePasswordChange"),
    @XmlEnumValue("UserResetFailedLogin")
    USER_RESET_FAILED_LOGIN("UserResetFailedLogin"),
    @XmlEnumValue("UserResetPassword")
    USER_RESET_PASSWORD("UserResetPassword"),
    @XmlEnumValue("ValCredAddCertsFromDir")
    VAL_CRED_ADD_CERTS_FROM_DIR("ValCredAddCertsFromDir"),
    @XmlEnumValue("VerifyFirmware")
    VERIFY_FIRMWARE("VerifyFirmware"),
    @XmlEnumValue("VLANPacketCapture")
    VLAN_PACKET_CAPTURE("VLANPacketCapture"),
    @XmlEnumValue("VLANStopPacketCapture")
    VLAN_STOP_PACKET_CAPTURE("VLANStopPacketCapture"),
    @XmlEnumValue("WsrrSynchronize")
    WSRR_SYNCHRONIZE("WsrrSynchronize"),
    @XmlEnumValue("WsrrValidateServer")
    WSRR_VALIDATE_SERVER("WsrrValidateServer"),
    @XmlEnumValue("XC10ClearGrid")
    XC_10_CLEAR_GRID("XC10ClearGrid"),
    @XmlEnumValue("XC10CreateGrid")
    XC_10_CREATE_GRID("XC10CreateGrid"),
    @XmlEnumValue("XC10DiscoverCollective")
    XC_10_DISCOVER_COLLECTIVE("XC10DiscoverCollective"),
    @XmlEnumValue("YieldEthernetStandby")
    YIELD_ETHERNET_STANDBY("YieldEthernetStandby"),
    @XmlEnumValue("YieldLinkAggregationStandby")
    YIELD_LINK_AGGREGATION_STANDBY("YieldLinkAggregationStandby"),
    @XmlEnumValue("YieldStandaloneStandby")
    YIELD_STANDALONE_STANDBY("YieldStandaloneStandby"),
    @XmlEnumValue("YieldVLANStandby")
    YIELD_VLAN_STANDBY("YieldVLANStandby");
    private final String value;

    ActionEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ActionEnum fromValue(String v) {
        for (ActionEnum c: ActionEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
