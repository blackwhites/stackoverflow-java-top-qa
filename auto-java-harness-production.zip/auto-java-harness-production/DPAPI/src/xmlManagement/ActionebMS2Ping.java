
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionebMS2Ping complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionebMS2Ping"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FromPartnerId"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ToPartnerId"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CPAId"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ebMS2URL"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionebMS2Ping", propOrder = {
    "fromPartnerId",
    "toPartnerId",
    "cpaId",
    "ebMS2URL"
})
public class ActionebMS2Ping {

    @XmlElement(name = "FromPartnerId", required = true)
    protected String fromPartnerId;
    @XmlElement(name = "ToPartnerId", required = true)
    protected String toPartnerId;
    @XmlElement(name = "CPAId", required = true)
    protected String cpaId;
    @XmlElement(required = true)
    protected String ebMS2URL;

    /**
     * Gets the value of the fromPartnerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromPartnerId() {
        return fromPartnerId;
    }

    /**
     * Sets the value of the fromPartnerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromPartnerId(String value) {
        this.fromPartnerId = value;
    }

    /**
     * Gets the value of the toPartnerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToPartnerId() {
        return toPartnerId;
    }

    /**
     * Sets the value of the toPartnerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToPartnerId(String value) {
        this.toPartnerId = value;
    }

    /**
     * Gets the value of the cpaId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPAId() {
        return cpaId;
    }

    /**
     * Sets the value of the cpaId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPAId(String value) {
        this.cpaId = value;
    }

    /**
     * Gets the value of the ebMS2URL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbMS2URL() {
        return ebMS2URL;
    }

    /**
     * Sets the value of the ebMS2URL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbMS2URL(String value) {
        this.ebMS2URL = value;
    }

}
