
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnyStatusElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AnyStatusElement"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element name="ActiveUsers" type="{http://www.datapower.com/schemas/management}StatusActiveUsers"/&gt;
 *         &lt;element name="ARPStatus" type="{http://www.datapower.com/schemas/management}StatusARPStatus"/&gt;
 *         &lt;element name="AS1PollerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusAS1PollerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="AS2SourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusAS2SourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="AS3SourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusAS3SourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="AuthCookieCacheStatus" type="{http://www.datapower.com/schemas/management}StatusAuthCookieCacheStatus"/&gt;
 *         &lt;element name="B2BGatewaySummary" type="{http://www.datapower.com/schemas/management}StatusB2BGatewaySummary"/&gt;
 *         &lt;element name="B2BHighAvailabilityStatus" type="{http://www.datapower.com/schemas/management}StatusB2BHighAvailabilityStatus"/&gt;
 *         &lt;element name="B2BMessageArchiveStatus" type="{http://www.datapower.com/schemas/management}StatusB2BMessageArchiveStatus"/&gt;
 *         &lt;element name="B2BMPCStatus" type="{http://www.datapower.com/schemas/management}StatusB2BMPCStatus"/&gt;
 *         &lt;element name="B2BTransactionLog" type="{http://www.datapower.com/schemas/management}StatusB2BTransactionLog"/&gt;
 *         &lt;element name="B2BTransactionLog2" type="{http://www.datapower.com/schemas/management}StatusB2BTransactionLog2"/&gt;
 *         &lt;element name="Battery" type="{http://www.datapower.com/schemas/management}StatusBattery"/&gt;
 *         &lt;element name="ChangeGroupRetryQueue" type="{http://www.datapower.com/schemas/management}StatusChangeGroupRetryQueue"/&gt;
 *         &lt;element name="ChangeGroups" type="{http://www.datapower.com/schemas/management}StatusChangeGroups"/&gt;
 *         &lt;element name="CloudConnectorServiceSummary" type="{http://www.datapower.com/schemas/management}StatusCloudConnectorServiceSummary"/&gt;
 *         &lt;element name="CloudGatewayServiceSummary" type="{http://www.datapower.com/schemas/management}StatusCloudGatewayServiceSummary"/&gt;
 *         &lt;element name="ConnectionsAccepted" type="{http://www.datapower.com/schemas/management}StatusConnectionsAccepted"/&gt;
 *         &lt;element name="CPUUsage" type="{http://www.datapower.com/schemas/management}StatusCPUUsage"/&gt;
 *         &lt;element name="CryptoEngineStatus" type="{http://www.datapower.com/schemas/management}StatusCryptoEngineStatus"/&gt;
 *         &lt;element name="CryptoEngineStatus2" type="{http://www.datapower.com/schemas/management}StatusCryptoEngineStatus2"/&gt;
 *         &lt;element name="CryptoHwDisableStatus" type="{http://www.datapower.com/schemas/management}StatusCryptoHwDisableStatus"/&gt;
 *         &lt;element name="CryptoModeStatus" type="{http://www.datapower.com/schemas/management}StatusCryptoModeStatus"/&gt;
 *         &lt;element name="CurrentSensors" type="{http://www.datapower.com/schemas/management}StatusCurrentSensors"/&gt;
 *         &lt;element name="DateTimeStatus" type="{http://www.datapower.com/schemas/management}StatusDateTimeStatus"/&gt;
 *         &lt;element name="DateTimeStatus2" type="{http://www.datapower.com/schemas/management}StatusDateTimeStatus2"/&gt;
 *         &lt;element name="DebugActionStatus" type="{http://www.datapower.com/schemas/management}StatusDebugActionStatus"/&gt;
 *         &lt;element name="DNSCacheHostStatus" type="{http://www.datapower.com/schemas/management}StatusDNSCacheHostStatus"/&gt;
 *         &lt;element name="DNSCacheHostStatus2" type="{http://www.datapower.com/schemas/management}StatusDNSCacheHostStatus2"/&gt;
 *         &lt;element name="DNSCacheHostStatus3" type="{http://www.datapower.com/schemas/management}StatusDNSCacheHostStatus3"/&gt;
 *         &lt;element name="DNSCacheHostStatus4" type="{http://www.datapower.com/schemas/management}StatusDNSCacheHostStatus4"/&gt;
 *         &lt;element name="DNSNameServerStatus" type="{http://www.datapower.com/schemas/management}StatusDNSNameServerStatus"/&gt;
 *         &lt;element name="DNSNameServerStatus2" type="{http://www.datapower.com/schemas/management}StatusDNSNameServerStatus2"/&gt;
 *         &lt;element name="DNSSearchDomainStatus" type="{http://www.datapower.com/schemas/management}StatusDNSSearchDomainStatus"/&gt;
 *         &lt;element name="DNSStaticHostStatus" type="{http://www.datapower.com/schemas/management}StatusDNSStaticHostStatus"/&gt;
 *         &lt;element name="DocumentCachingSummary" type="{http://www.datapower.com/schemas/management}StatusDocumentCachingSummary"/&gt;
 *         &lt;element name="DocumentCachingSummaryGlobal" type="{http://www.datapower.com/schemas/management}StatusDocumentCachingSummaryGlobal"/&gt;
 *         &lt;element name="DocumentStatus" type="{http://www.datapower.com/schemas/management}StatusDocumentStatus"/&gt;
 *         &lt;element name="DocumentStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusDocumentStatusSimpleIndex"/&gt;
 *         &lt;element name="DomainCheckpointStatus" type="{http://www.datapower.com/schemas/management}StatusDomainCheckpointStatus"/&gt;
 *         &lt;element name="DomainsMemoryStatus" type="{http://www.datapower.com/schemas/management}StatusDomainsMemoryStatus"/&gt;
 *         &lt;element name="DomainsMemoryStatus2" type="{http://www.datapower.com/schemas/management}StatusDomainsMemoryStatus2"/&gt;
 *         &lt;element name="DomainStatus" type="{http://www.datapower.com/schemas/management}StatusDomainStatus"/&gt;
 *         &lt;element name="DomainSummary" type="{http://www.datapower.com/schemas/management}StatusDomainSummary"/&gt;
 *         &lt;element name="DynamicQueueManager" type="{http://www.datapower.com/schemas/management}StatusDynamicQueueManager"/&gt;
 *         &lt;element name="DynamicTibcoEMSStatus" type="{http://www.datapower.com/schemas/management}StatusDynamicTibcoEMSStatus"/&gt;
 *         &lt;element name="EBMS2SourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusEBMS2SourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="EBMS3SourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusEBMS3SourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="EnvironmentalFanSensors" type="{http://www.datapower.com/schemas/management}StatusEnvironmentalFanSensors"/&gt;
 *         &lt;element name="EnvironmentalSensors" type="{http://www.datapower.com/schemas/management}StatusEnvironmentalSensors"/&gt;
 *         &lt;element name="EthernetCountersStatus" type="{http://www.datapower.com/schemas/management}StatusEthernetCountersStatus"/&gt;
 *         &lt;element name="EthernetInterfaceStatus" type="{http://www.datapower.com/schemas/management}StatusEthernetInterfaceStatus"/&gt;
 *         &lt;element name="EthernetMAUStatus" type="{http://www.datapower.com/schemas/management}StatusEthernetMAUStatus"/&gt;
 *         &lt;element name="EthernetMIIRegisterStatus" type="{http://www.datapower.com/schemas/management}StatusEthernetMIIRegisterStatus"/&gt;
 *         &lt;element name="FailureNotificationStatus" type="{http://www.datapower.com/schemas/management}StatusFailureNotificationStatus"/&gt;
 *         &lt;element name="FailureNotificationStatus2" type="{http://www.datapower.com/schemas/management}StatusFailureNotificationStatus2"/&gt;
 *         &lt;element name="FilePollerStatus" type="{http://www.datapower.com/schemas/management}StatusFilePollerStatus"/&gt;
 *         &lt;element name="FilesystemStatus" type="{http://www.datapower.com/schemas/management}StatusFilesystemStatus"/&gt;
 *         &lt;element name="FirmwareStatus" type="{http://www.datapower.com/schemas/management}StatusFirmwareStatus"/&gt;
 *         &lt;element name="FirmwareVersion" type="{http://www.datapower.com/schemas/management}StatusFirmwareVersion"/&gt;
 *         &lt;element name="FirmwareVersion2" type="{http://www.datapower.com/schemas/management}StatusFirmwareVersion2"/&gt;
 *         &lt;element name="FTPFilePollerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusFTPFilePollerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="FTPServerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusFTPServerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="GatewayTransactions" type="{http://www.datapower.com/schemas/management}StatusGatewayTransactions"/&gt;
 *         &lt;element name="HSMKeyStatus" type="{http://www.datapower.com/schemas/management}StatusHSMKeyStatus"/&gt;
 *         &lt;element name="HTTPConnections" type="{http://www.datapower.com/schemas/management}StatusHTTPConnections"/&gt;
 *         &lt;element name="HTTPConnectionsCreated" type="{http://www.datapower.com/schemas/management}StatusHTTPConnectionsCreated"/&gt;
 *         &lt;element name="HTTPConnectionsDestroyed" type="{http://www.datapower.com/schemas/management}StatusHTTPConnectionsDestroyed"/&gt;
 *         &lt;element name="HTTPConnectionsOffered" type="{http://www.datapower.com/schemas/management}StatusHTTPConnectionsOffered"/&gt;
 *         &lt;element name="HTTPConnectionsRequested" type="{http://www.datapower.com/schemas/management}StatusHTTPConnectionsRequested"/&gt;
 *         &lt;element name="HTTPConnectionsReturned" type="{http://www.datapower.com/schemas/management}StatusHTTPConnectionsReturned"/&gt;
 *         &lt;element name="HTTPConnectionsReused" type="{http://www.datapower.com/schemas/management}StatusHTTPConnectionsReused"/&gt;
 *         &lt;element name="HTTPMeanTransactionTime" type="{http://www.datapower.com/schemas/management}StatusHTTPMeanTransactionTime"/&gt;
 *         &lt;element name="HTTPMeanTransactionTime2" type="{http://www.datapower.com/schemas/management}StatusHTTPMeanTransactionTime2"/&gt;
 *         &lt;element name="HTTPServiceSummary" type="{http://www.datapower.com/schemas/management}StatusHTTPServiceSummary"/&gt;
 *         &lt;element name="HTTPSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusHTTPSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="HTTPSSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusHTTPSSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="HTTPTransactions" type="{http://www.datapower.com/schemas/management}StatusHTTPTransactions"/&gt;
 *         &lt;element name="HTTPTransactions2" type="{http://www.datapower.com/schemas/management}StatusHTTPTransactions2"/&gt;
 *         &lt;element name="Hypervisor" type="{http://www.datapower.com/schemas/management}StatusHypervisor"/&gt;
 *         &lt;element name="Hypervisor2" type="{http://www.datapower.com/schemas/management}StatusHypervisor2"/&gt;
 *         &lt;element name="IGMPStatus" type="{http://www.datapower.com/schemas/management}StatusIGMPStatus"/&gt;
 *         &lt;element name="IMSConnectSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusIMSConnectSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="IMSConnectstatus" type="{http://www.datapower.com/schemas/management}StatusIMSConnectstatus"/&gt;
 *         &lt;element name="IPAddressStatus" type="{http://www.datapower.com/schemas/management}StatusIPAddressStatus"/&gt;
 *         &lt;element name="IPMISelEvents" type="{http://www.datapower.com/schemas/management}StatusIPMISelEvents"/&gt;
 *         &lt;element name="IPMulticastStatus" type="{http://www.datapower.com/schemas/management}StatusIPMulticastStatus"/&gt;
 *         &lt;element name="IScsiHBAStatus" type="{http://www.datapower.com/schemas/management}StatusIScsiHBAStatus"/&gt;
 *         &lt;element name="IScsiInitiatorStatus" type="{http://www.datapower.com/schemas/management}StatusIScsiInitiatorStatus"/&gt;
 *         &lt;element name="IScsiTargetStatus" type="{http://www.datapower.com/schemas/management}StatusIScsiTargetStatus"/&gt;
 *         &lt;element name="IScsiVolumeStatus" type="{http://www.datapower.com/schemas/management}StatusIScsiVolumeStatus"/&gt;
 *         &lt;element name="KerberosTickets" type="{http://www.datapower.com/schemas/management}StatusKerberosTickets"/&gt;
 *         &lt;element name="KerberosTickets2" type="{http://www.datapower.com/schemas/management}StatusKerberosTickets2"/&gt;
 *         &lt;element name="LDAPPoolEntries" type="{http://www.datapower.com/schemas/management}StatusLDAPPoolEntries"/&gt;
 *         &lt;element name="LDAPPoolSummary" type="{http://www.datapower.com/schemas/management}StatusLDAPPoolSummary"/&gt;
 *         &lt;element name="LibraryVersion" type="{http://www.datapower.com/schemas/management}StatusLibraryVersion"/&gt;
 *         &lt;element name="LicenseStatus" type="{http://www.datapower.com/schemas/management}StatusLicenseStatus"/&gt;
 *         &lt;element name="LinkAggregationMemberStatus" type="{http://www.datapower.com/schemas/management}StatusLinkAggregationMemberStatus"/&gt;
 *         &lt;element name="LinkAggregationStatus" type="{http://www.datapower.com/schemas/management}StatusLinkAggregationStatus"/&gt;
 *         &lt;element name="LinkStatus" type="{http://www.datapower.com/schemas/management}StatusLinkStatus"/&gt;
 *         &lt;element name="LoadBalancerStatus" type="{http://www.datapower.com/schemas/management}StatusLoadBalancerStatus"/&gt;
 *         &lt;element name="LoadBalancerStatus2" type="{http://www.datapower.com/schemas/management}StatusLoadBalancerStatus2"/&gt;
 *         &lt;element name="LogTargetStatus" type="{http://www.datapower.com/schemas/management}StatusLogTargetStatus"/&gt;
 *         &lt;element name="LunaLatency" type="{http://www.datapower.com/schemas/management}StatusLunaLatency"/&gt;
 *         &lt;element name="MemoryStatus" type="{http://www.datapower.com/schemas/management}StatusMemoryStatus"/&gt;
 *         &lt;element name="MessageCountFilters" type="{http://www.datapower.com/schemas/management}StatusMessageCountFilters"/&gt;
 *         &lt;element name="MessageCounts" type="{http://www.datapower.com/schemas/management}StatusMessageCounts"/&gt;
 *         &lt;element name="MessageDurationFilters" type="{http://www.datapower.com/schemas/management}StatusMessageDurationFilters"/&gt;
 *         &lt;element name="MessageDurations" type="{http://www.datapower.com/schemas/management}StatusMessageDurations"/&gt;
 *         &lt;element name="MessageSources" type="{http://www.datapower.com/schemas/management}StatusMessageSources"/&gt;
 *         &lt;element name="MQConnStatus" type="{http://www.datapower.com/schemas/management}StatusMQConnStatus"/&gt;
 *         &lt;element name="MQFTESourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusMQFTESourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="MQQMstatus" type="{http://www.datapower.com/schemas/management}StatusMQQMstatus"/&gt;
 *         &lt;element name="MQSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusMQSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="MQStatus" type="{http://www.datapower.com/schemas/management}StatusMQStatus"/&gt;
 *         &lt;element name="MultiProtocolGatewaySummary" type="{http://www.datapower.com/schemas/management}StatusMultiProtocolGatewaySummary"/&gt;
 *         &lt;element name="NDCacheStatus" type="{http://www.datapower.com/schemas/management}StatusNDCacheStatus"/&gt;
 *         &lt;element name="NDCacheStatus2" type="{http://www.datapower.com/schemas/management}StatusNDCacheStatus2"/&gt;
 *         &lt;element name="NetworkInterfaceStatus" type="{http://www.datapower.com/schemas/management}StatusNetworkInterfaceStatus"/&gt;
 *         &lt;element name="NetworkReceiveDataThroughput" type="{http://www.datapower.com/schemas/management}StatusNetworkReceiveDataThroughput"/&gt;
 *         &lt;element name="NetworkReceivePacketThroughput" type="{http://www.datapower.com/schemas/management}StatusNetworkReceivePacketThroughput"/&gt;
 *         &lt;element name="NetworkTransmitDataThroughput" type="{http://www.datapower.com/schemas/management}StatusNetworkTransmitDataThroughput"/&gt;
 *         &lt;element name="NetworkTransmitPacketThroughput" type="{http://www.datapower.com/schemas/management}StatusNetworkTransmitPacketThroughput"/&gt;
 *         &lt;element name="NFSFilePollerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusNFSFilePollerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="NFSMountStatus" type="{http://www.datapower.com/schemas/management}StatusNFSMountStatus"/&gt;
 *         &lt;element name="NTPRefreshStatus" type="{http://www.datapower.com/schemas/management}StatusNTPRefreshStatus"/&gt;
 *         &lt;element name="OAuthCachesStatus" type="{http://www.datapower.com/schemas/management}StatusOAuthCachesStatus"/&gt;
 *         &lt;element name="ObjectStatus" type="{http://www.datapower.com/schemas/management}StatusObjectStatus"/&gt;
 *         &lt;element name="ODRConnectorGroupStatus" type="{http://www.datapower.com/schemas/management}StatusODRConnectorGroupStatus"/&gt;
 *         &lt;element name="ODRConnectorGroupStatus2" type="{http://www.datapower.com/schemas/management}StatusODRConnectorGroupStatus2"/&gt;
 *         &lt;element name="ODRLoadBalancerStatus" type="{http://www.datapower.com/schemas/management}StatusODRLoadBalancerStatus"/&gt;
 *         &lt;element name="OtherSensors" type="{http://www.datapower.com/schemas/management}StatusOtherSensors"/&gt;
 *         &lt;element name="PCIBus" type="{http://www.datapower.com/schemas/management}StatusPCIBus"/&gt;
 *         &lt;element name="PolicyDomainStatus" type="{http://www.datapower.com/schemas/management}StatusPolicyDomainStatus"/&gt;
 *         &lt;element name="POPPollerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusPOPPollerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="PortStatus" type="{http://www.datapower.com/schemas/management}StatusPortStatus"/&gt;
 *         &lt;element name="PowerSensors" type="{http://www.datapower.com/schemas/management}StatusPowerSensors"/&gt;
 *         &lt;element name="QueueManagersStatus" type="{http://www.datapower.com/schemas/management}StatusQueueManagersStatus"/&gt;
 *         &lt;element name="QuotaEnforcementStatus" type="{http://www.datapower.com/schemas/management}StatusQuotaEnforcementStatus"/&gt;
 *         &lt;element name="RaidArrayStatus" type="{http://www.datapower.com/schemas/management}StatusRaidArrayStatus"/&gt;
 *         &lt;element name="RaidBatteryBackUpStatus" type="{http://www.datapower.com/schemas/management}StatusRaidBatteryBackUpStatus"/&gt;
 *         &lt;element name="RaidBatteryModuleStatus" type="{http://www.datapower.com/schemas/management}StatusRaidBatteryModuleStatus"/&gt;
 *         &lt;element name="RaidLogicalDriveStatus" type="{http://www.datapower.com/schemas/management}StatusRaidLogicalDriveStatus"/&gt;
 *         &lt;element name="RaidPartitionStatus" type="{http://www.datapower.com/schemas/management}StatusRaidPartitionStatus"/&gt;
 *         &lt;element name="RaidPhysDiskStatus" type="{http://www.datapower.com/schemas/management}StatusRaidPhysDiskStatus"/&gt;
 *         &lt;element name="RaidPhysDiskStatus2" type="{http://www.datapower.com/schemas/management}StatusRaidPhysDiskStatus2"/&gt;
 *         &lt;element name="RaidPhysicalDriveStatus" type="{http://www.datapower.com/schemas/management}StatusRaidPhysicalDriveStatus"/&gt;
 *         &lt;element name="RaidSsdStatus" type="{http://www.datapower.com/schemas/management}StatusRaidSsdStatus"/&gt;
 *         &lt;element name="RaidVolumeStatus" type="{http://www.datapower.com/schemas/management}StatusRaidVolumeStatus"/&gt;
 *         &lt;element name="RaidVolumeStatus2" type="{http://www.datapower.com/schemas/management}StatusRaidVolumeStatus2"/&gt;
 *         &lt;element name="RateLimitConcurrentStatus" type="{http://www.datapower.com/schemas/management}StatusRateLimitConcurrentStatus"/&gt;
 *         &lt;element name="RateLimitCountStatus" type="{http://www.datapower.com/schemas/management}StatusRateLimitCountStatus"/&gt;
 *         &lt;element name="RateLimitRateStatus" type="{http://www.datapower.com/schemas/management}StatusRateLimitRateStatus"/&gt;
 *         &lt;element name="RateLimitTokenBucketStatus" type="{http://www.datapower.com/schemas/management}StatusRateLimitTokenBucketStatus"/&gt;
 *         &lt;element name="ReceiveKbpsThroughput" type="{http://www.datapower.com/schemas/management}StatusReceiveKbpsThroughput"/&gt;
 *         &lt;element name="ReceivePacketThroughput" type="{http://www.datapower.com/schemas/management}StatusReceivePacketThroughput"/&gt;
 *         &lt;element name="RoutingStatus" type="{http://www.datapower.com/schemas/management}StatusRoutingStatus"/&gt;
 *         &lt;element name="RoutingStatus2" type="{http://www.datapower.com/schemas/management}StatusRoutingStatus2"/&gt;
 *         &lt;element name="RoutingStatus3" type="{http://www.datapower.com/schemas/management}StatusRoutingStatus3"/&gt;
 *         &lt;element name="SecureCloudConnectorConnectionsStatus" type="{http://www.datapower.com/schemas/management}StatusSecureCloudConnectorConnectionsStatus"/&gt;
 *         &lt;element name="SelfBalancedStatus" type="{http://www.datapower.com/schemas/management}StatusSelfBalancedStatus"/&gt;
 *         &lt;element name="SelfBalancedStatus2" type="{http://www.datapower.com/schemas/management}StatusSelfBalancedStatus2"/&gt;
 *         &lt;element name="SelfBalancedTable" type="{http://www.datapower.com/schemas/management}StatusSelfBalancedTable"/&gt;
 *         &lt;element name="ServicesMemoryStatus" type="{http://www.datapower.com/schemas/management}StatusServicesMemoryStatus"/&gt;
 *         &lt;element name="ServicesMemoryStatus2" type="{http://www.datapower.com/schemas/management}StatusServicesMemoryStatus2"/&gt;
 *         &lt;element name="ServicesStatus" type="{http://www.datapower.com/schemas/management}StatusServicesStatus"/&gt;
 *         &lt;element name="ServicesStatusPlus" type="{http://www.datapower.com/schemas/management}StatusServicesStatusPlus"/&gt;
 *         &lt;element name="ServiceVersionStatus" type="{http://www.datapower.com/schemas/management}StatusServiceVersionStatus"/&gt;
 *         &lt;element name="SFTPFilePollerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusSFTPFilePollerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="SGClientConnectionStatus" type="{http://www.datapower.com/schemas/management}StatusSGClientConnectionStatus"/&gt;
 *         &lt;element name="SGClientStatus" type="{http://www.datapower.com/schemas/management}StatusSGClientStatus"/&gt;
 *         &lt;element name="SLMPeeringStatus" type="{http://www.datapower.com/schemas/management}StatusSLMPeeringStatus"/&gt;
 *         &lt;element name="SLMSummaryStatus" type="{http://www.datapower.com/schemas/management}StatusSLMSummaryStatus"/&gt;
 *         &lt;element name="SNMPStatus" type="{http://www.datapower.com/schemas/management}StatusSNMPStatus"/&gt;
 *         &lt;element name="SQLConnectionPoolStatus" type="{http://www.datapower.com/schemas/management}StatusSQLConnectionPoolStatus"/&gt;
 *         &lt;element name="SQLRuntimeStatus" type="{http://www.datapower.com/schemas/management}StatusSQLRuntimeStatus"/&gt;
 *         &lt;element name="SQLStatus" type="{http://www.datapower.com/schemas/management}StatusSQLStatus"/&gt;
 *         &lt;element name="SSHKnownHostFileStatus" type="{http://www.datapower.com/schemas/management}StatusSSHKnownHostFileStatus"/&gt;
 *         &lt;element name="SSHKnownHostFileStatus2" type="{http://www.datapower.com/schemas/management}StatusSSHKnownHostFileStatus2"/&gt;
 *         &lt;element name="SSHKnownHostStatus" type="{http://www.datapower.com/schemas/management}StatusSSHKnownHostStatus"/&gt;
 *         &lt;element name="SSHServerSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusSSHServerSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="SSHTrustedHostStatus" type="{http://www.datapower.com/schemas/management}StatusSSHTrustedHostStatus"/&gt;
 *         &lt;element name="SSLProxyServiceSummary" type="{http://www.datapower.com/schemas/management}StatusSSLProxyServiceSummary"/&gt;
 *         &lt;element name="StandbyStatus" type="{http://www.datapower.com/schemas/management}StatusStandbyStatus"/&gt;
 *         &lt;element name="StandbyStatus2" type="{http://www.datapower.com/schemas/management}StatusStandbyStatus2"/&gt;
 *         &lt;element name="StatelessTCPSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusStatelessTCPSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="StylesheetCachingSummary" type="{http://www.datapower.com/schemas/management}StatusStylesheetCachingSummary"/&gt;
 *         &lt;element name="StylesheetExecutions" type="{http://www.datapower.com/schemas/management}StatusStylesheetExecutions"/&gt;
 *         &lt;element name="StylesheetExecutionsSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusStylesheetExecutionsSimpleIndex"/&gt;
 *         &lt;element name="StylesheetMeanExecutionTime" type="{http://www.datapower.com/schemas/management}StatusStylesheetMeanExecutionTime"/&gt;
 *         &lt;element name="StylesheetMeanExecutionTimeSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusStylesheetMeanExecutionTimeSimpleIndex"/&gt;
 *         &lt;element name="StylesheetProfiles" type="{http://www.datapower.com/schemas/management}StatusStylesheetProfiles"/&gt;
 *         &lt;element name="StylesheetProfilesSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusStylesheetProfilesSimpleIndex"/&gt;
 *         &lt;element name="StylesheetStatus" type="{http://www.datapower.com/schemas/management}StatusStylesheetStatus"/&gt;
 *         &lt;element name="StylesheetStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusStylesheetStatusSimpleIndex"/&gt;
 *         &lt;element name="SystemMemoryStatus" type="{http://www.datapower.com/schemas/management}StatusSystemMemoryStatus"/&gt;
 *         &lt;element name="SystemUsage" type="{http://www.datapower.com/schemas/management}StatusSystemUsage"/&gt;
 *         &lt;element name="SystemUsage2Table" type="{http://www.datapower.com/schemas/management}StatusSystemUsage2Table"/&gt;
 *         &lt;element name="SystemUsageTable" type="{http://www.datapower.com/schemas/management}StatusSystemUsageTable"/&gt;
 *         &lt;element name="TCPProxyServiceSummary" type="{http://www.datapower.com/schemas/management}StatusTCPProxyServiceSummary"/&gt;
 *         &lt;element name="TCPSummary" type="{http://www.datapower.com/schemas/management}StatusTCPSummary"/&gt;
 *         &lt;element name="TCPTable" type="{http://www.datapower.com/schemas/management}StatusTCPTable"/&gt;
 *         &lt;element name="TemperatureSensors" type="{http://www.datapower.com/schemas/management}StatusTemperatureSensors"/&gt;
 *         &lt;element name="TibcoEMSSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusTibcoEMSSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="TibcoEMSStatus" type="{http://www.datapower.com/schemas/management}StatusTibcoEMSStatus"/&gt;
 *         &lt;element name="TransmitKbpsThroughput" type="{http://www.datapower.com/schemas/management}StatusTransmitKbpsThroughput"/&gt;
 *         &lt;element name="TransmitPacketThroughput" type="{http://www.datapower.com/schemas/management}StatusTransmitPacketThroughput"/&gt;
 *         &lt;element name="UDDISubscriptionKeyStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusUDDISubscriptionKeyStatusSimpleIndex"/&gt;
 *         &lt;element name="UDDISubscriptionServiceStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusUDDISubscriptionServiceStatusSimpleIndex"/&gt;
 *         &lt;element name="UDDISubscriptionStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusUDDISubscriptionStatusSimpleIndex"/&gt;
 *         &lt;element name="Version" type="{http://www.datapower.com/schemas/management}StatusVersion"/&gt;
 *         &lt;element name="VirtualPlatform" type="{http://www.datapower.com/schemas/management}StatusVirtualPlatform"/&gt;
 *         &lt;element name="VirtualPlatform2" type="{http://www.datapower.com/schemas/management}StatusVirtualPlatform2"/&gt;
 *         &lt;element name="VlanInterfaceStatus" type="{http://www.datapower.com/schemas/management}StatusVlanInterfaceStatus"/&gt;
 *         &lt;element name="VlanInterfaceStatus2" type="{http://www.datapower.com/schemas/management}StatusVlanInterfaceStatus2"/&gt;
 *         &lt;element name="VoltageSensors" type="{http://www.datapower.com/schemas/management}StatusVoltageSensors"/&gt;
 *         &lt;element name="WebAppFwAccepted" type="{http://www.datapower.com/schemas/management}StatusWebAppFwAccepted"/&gt;
 *         &lt;element name="WebAppFwRejected" type="{http://www.datapower.com/schemas/management}StatusWebAppFwRejected"/&gt;
 *         &lt;element name="WebAppFWSummary" type="{http://www.datapower.com/schemas/management}StatusWebAppFWSummary"/&gt;
 *         &lt;element name="WebSphereJMSSourceProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusWebSphereJMSSourceProtocolHandlerSummary"/&gt;
 *         &lt;element name="WebSphereJMSStatus" type="{http://www.datapower.com/schemas/management}StatusWebSphereJMSStatus"/&gt;
 *         &lt;element name="WebTokenServiceSummary" type="{http://www.datapower.com/schemas/management}StatusWebTokenServiceSummary"/&gt;
 *         &lt;element name="WSGatewaySummary" type="{http://www.datapower.com/schemas/management}StatusWSGatewaySummary"/&gt;
 *         &lt;element name="WSMAgentSpoolers" type="{http://www.datapower.com/schemas/management}StatusWSMAgentSpoolers"/&gt;
 *         &lt;element name="WSMAgentStatus" type="{http://www.datapower.com/schemas/management}StatusWSMAgentStatus"/&gt;
 *         &lt;element name="WSOperationMetrics" type="{http://www.datapower.com/schemas/management}StatusWSOperationMetrics"/&gt;
 *         &lt;element name="WSOperationMetricsSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusWSOperationMetricsSimpleIndex"/&gt;
 *         &lt;element name="WSOperationsStatus" type="{http://www.datapower.com/schemas/management}StatusWSOperationsStatus"/&gt;
 *         &lt;element name="WSOperationsStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusWSOperationsStatusSimpleIndex"/&gt;
 *         &lt;element name="WSRRSavdSrchSubsPolicyAttachmentsStatus" type="{http://www.datapower.com/schemas/management}StatusWSRRSavdSrchSubsPolicyAttachmentsStatus"/&gt;
 *         &lt;element name="WSRRSavedSearchSubscriptionServiceStatus" type="{http://www.datapower.com/schemas/management}StatusWSRRSavedSearchSubscriptionServiceStatus"/&gt;
 *         &lt;element name="WSRRSavedSearchSubscriptionStatus" type="{http://www.datapower.com/schemas/management}StatusWSRRSavedSearchSubscriptionStatus"/&gt;
 *         &lt;element name="WSRRSubscriptionPolicyAttachmentsStatus" type="{http://www.datapower.com/schemas/management}StatusWSRRSubscriptionPolicyAttachmentsStatus"/&gt;
 *         &lt;element name="WSRRSubscriptionServiceStatus" type="{http://www.datapower.com/schemas/management}StatusWSRRSubscriptionServiceStatus"/&gt;
 *         &lt;element name="WSRRSubscriptionStatus" type="{http://www.datapower.com/schemas/management}StatusWSRRSubscriptionStatus"/&gt;
 *         &lt;element name="WSWSDLStatus" type="{http://www.datapower.com/schemas/management}StatusWSWSDLStatus"/&gt;
 *         &lt;element name="WSWSDLStatusSimpleIndex" type="{http://www.datapower.com/schemas/management}StatusWSWSDLStatusSimpleIndex"/&gt;
 *         &lt;element name="WXSGridStatus" type="{http://www.datapower.com/schemas/management}StatusWXSGridStatus"/&gt;
 *         &lt;element name="XC10GridStatus" type="{http://www.datapower.com/schemas/management}StatusXC10GridStatus"/&gt;
 *         &lt;element name="XMLFirewallServiceSummary" type="{http://www.datapower.com/schemas/management}StatusXMLFirewallServiceSummary"/&gt;
 *         &lt;element name="XMLNamesStatus" type="{http://www.datapower.com/schemas/management}StatusXMLNamesStatus"/&gt;
 *         &lt;element name="XSLCoprocServiceSummary" type="{http://www.datapower.com/schemas/management}StatusXSLCoprocServiceSummary"/&gt;
 *         &lt;element name="XSLProxyServiceSummary" type="{http://www.datapower.com/schemas/management}StatusXSLProxyServiceSummary"/&gt;
 *         &lt;element name="XTCProtocolHandlerSummary" type="{http://www.datapower.com/schemas/management}StatusXTCProtocolHandlerSummary"/&gt;
 *         &lt;element name="ZHybridTCSstatus" type="{http://www.datapower.com/schemas/management}StatusZHybridTCSstatus"/&gt;
 *         &lt;element name="ZosNSSstatus" type="{http://www.datapower.com/schemas/management}StatusZosNSSstatus"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnyStatusElement", propOrder = {
    "statusObjects"
})
public class AnyStatusElement {

    @XmlElements({
        @XmlElement(name = "ActiveUsers", type = StatusActiveUsers.class),
        @XmlElement(name = "ARPStatus", type = StatusARPStatus.class),
        @XmlElement(name = "AS1PollerSourceProtocolHandlerSummary", type = StatusAS1PollerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "AS2SourceProtocolHandlerSummary", type = StatusAS2SourceProtocolHandlerSummary.class),
        @XmlElement(name = "AS3SourceProtocolHandlerSummary", type = StatusAS3SourceProtocolHandlerSummary.class),
        @XmlElement(name = "AuthCookieCacheStatus", type = StatusAuthCookieCacheStatus.class),
        @XmlElement(name = "B2BGatewaySummary", type = StatusB2BGatewaySummary.class),
        @XmlElement(name = "B2BHighAvailabilityStatus", type = StatusB2BHighAvailabilityStatus.class),
        @XmlElement(name = "B2BMessageArchiveStatus", type = StatusB2BMessageArchiveStatus.class),
        @XmlElement(name = "B2BMPCStatus", type = StatusB2BMPCStatus.class),
        @XmlElement(name = "B2BTransactionLog", type = StatusB2BTransactionLog.class),
        @XmlElement(name = "B2BTransactionLog2", type = StatusB2BTransactionLog2 .class),
        @XmlElement(name = "Battery", type = StatusBattery.class),
        @XmlElement(name = "ChangeGroupRetryQueue", type = StatusChangeGroupRetryQueue.class),
        @XmlElement(name = "ChangeGroups", type = StatusChangeGroups.class),
        @XmlElement(name = "CloudConnectorServiceSummary", type = StatusCloudConnectorServiceSummary.class),
        @XmlElement(name = "CloudGatewayServiceSummary", type = StatusCloudGatewayServiceSummary.class),
        @XmlElement(name = "ConnectionsAccepted", type = StatusConnectionsAccepted.class),
        @XmlElement(name = "CPUUsage", type = StatusCPUUsage.class),
        @XmlElement(name = "CryptoEngineStatus", type = StatusCryptoEngineStatus.class),
        @XmlElement(name = "CryptoEngineStatus2", type = StatusCryptoEngineStatus2 .class),
        @XmlElement(name = "CryptoHwDisableStatus", type = StatusCryptoHwDisableStatus.class),
        @XmlElement(name = "CryptoModeStatus", type = StatusCryptoModeStatus.class),
        @XmlElement(name = "CurrentSensors", type = StatusCurrentSensors.class),
        @XmlElement(name = "DateTimeStatus", type = StatusDateTimeStatus.class),
        @XmlElement(name = "DateTimeStatus2", type = StatusDateTimeStatus2 .class),
        @XmlElement(name = "DebugActionStatus", type = StatusDebugActionStatus.class),
        @XmlElement(name = "DNSCacheHostStatus", type = StatusDNSCacheHostStatus.class),
        @XmlElement(name = "DNSCacheHostStatus2", type = StatusDNSCacheHostStatus2 .class),
        @XmlElement(name = "DNSCacheHostStatus3", type = StatusDNSCacheHostStatus3 .class),
        @XmlElement(name = "DNSCacheHostStatus4", type = StatusDNSCacheHostStatus4 .class),
        @XmlElement(name = "DNSNameServerStatus", type = StatusDNSNameServerStatus.class),
        @XmlElement(name = "DNSNameServerStatus2", type = StatusDNSNameServerStatus2 .class),
        @XmlElement(name = "DNSSearchDomainStatus", type = StatusDNSSearchDomainStatus.class),
        @XmlElement(name = "DNSStaticHostStatus", type = StatusDNSStaticHostStatus.class),
        @XmlElement(name = "DocumentCachingSummary", type = StatusDocumentCachingSummary.class),
        @XmlElement(name = "DocumentCachingSummaryGlobal", type = StatusDocumentCachingSummaryGlobal.class),
        @XmlElement(name = "DocumentStatus", type = StatusDocumentStatus.class),
        @XmlElement(name = "DocumentStatusSimpleIndex", type = StatusDocumentStatusSimpleIndex.class),
        @XmlElement(name = "DomainCheckpointStatus", type = StatusDomainCheckpointStatus.class),
        @XmlElement(name = "DomainsMemoryStatus", type = StatusDomainsMemoryStatus.class),
        @XmlElement(name = "DomainsMemoryStatus2", type = StatusDomainsMemoryStatus2 .class),
        @XmlElement(name = "DomainStatus", type = StatusDomainStatus.class),
        @XmlElement(name = "DomainSummary", type = StatusDomainSummary.class),
        @XmlElement(name = "DynamicQueueManager", type = StatusDynamicQueueManager.class),
        @XmlElement(name = "DynamicTibcoEMSStatus", type = StatusDynamicTibcoEMSStatus.class),
        @XmlElement(name = "EBMS2SourceProtocolHandlerSummary", type = StatusEBMS2SourceProtocolHandlerSummary.class),
        @XmlElement(name = "EBMS3SourceProtocolHandlerSummary", type = StatusEBMS3SourceProtocolHandlerSummary.class),
        @XmlElement(name = "EnvironmentalFanSensors", type = StatusEnvironmentalFanSensors.class),
        @XmlElement(name = "EnvironmentalSensors", type = StatusEnvironmentalSensors.class),
        @XmlElement(name = "EthernetCountersStatus", type = StatusEthernetCountersStatus.class),
        @XmlElement(name = "EthernetInterfaceStatus", type = StatusEthernetInterfaceStatus.class),
        @XmlElement(name = "EthernetMAUStatus", type = StatusEthernetMAUStatus.class),
        @XmlElement(name = "EthernetMIIRegisterStatus", type = StatusEthernetMIIRegisterStatus.class),
        @XmlElement(name = "FailureNotificationStatus", type = StatusFailureNotificationStatus.class),
        @XmlElement(name = "FailureNotificationStatus2", type = StatusFailureNotificationStatus2 .class),
        @XmlElement(name = "FilePollerStatus", type = StatusFilePollerStatus.class),
        @XmlElement(name = "FilesystemStatus", type = StatusFilesystemStatus.class),
        @XmlElement(name = "FirmwareStatus", type = StatusFirmwareStatus.class),
        @XmlElement(name = "FirmwareVersion", type = StatusFirmwareVersion.class),
        @XmlElement(name = "FirmwareVersion2", type = StatusFirmwareVersion2 .class),
        @XmlElement(name = "FTPFilePollerSourceProtocolHandlerSummary", type = StatusFTPFilePollerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "FTPServerSourceProtocolHandlerSummary", type = StatusFTPServerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "GatewayTransactions", type = StatusGatewayTransactions.class),
        @XmlElement(name = "HSMKeyStatus", type = StatusHSMKeyStatus.class),
        @XmlElement(name = "HTTPConnections", type = StatusHTTPConnections.class),
        @XmlElement(name = "HTTPConnectionsCreated", type = StatusHTTPConnectionsCreated.class),
        @XmlElement(name = "HTTPConnectionsDestroyed", type = StatusHTTPConnectionsDestroyed.class),
        @XmlElement(name = "HTTPConnectionsOffered", type = StatusHTTPConnectionsOffered.class),
        @XmlElement(name = "HTTPConnectionsRequested", type = StatusHTTPConnectionsRequested.class),
        @XmlElement(name = "HTTPConnectionsReturned", type = StatusHTTPConnectionsReturned.class),
        @XmlElement(name = "HTTPConnectionsReused", type = StatusHTTPConnectionsReused.class),
        @XmlElement(name = "HTTPMeanTransactionTime", type = StatusHTTPMeanTransactionTime.class),
        @XmlElement(name = "HTTPMeanTransactionTime2", type = StatusHTTPMeanTransactionTime2 .class),
        @XmlElement(name = "HTTPServiceSummary", type = StatusHTTPServiceSummary.class),
        @XmlElement(name = "HTTPSourceProtocolHandlerSummary", type = StatusHTTPSourceProtocolHandlerSummary.class),
        @XmlElement(name = "HTTPSSourceProtocolHandlerSummary", type = StatusHTTPSSourceProtocolHandlerSummary.class),
        @XmlElement(name = "HTTPTransactions", type = StatusHTTPTransactions.class),
        @XmlElement(name = "HTTPTransactions2", type = StatusHTTPTransactions2 .class),
        @XmlElement(name = "Hypervisor", type = StatusHypervisor.class),
        @XmlElement(name = "Hypervisor2", type = StatusHypervisor2 .class),
        @XmlElement(name = "IGMPStatus", type = StatusIGMPStatus.class),
        @XmlElement(name = "IMSConnectSourceProtocolHandlerSummary", type = StatusIMSConnectSourceProtocolHandlerSummary.class),
        @XmlElement(name = "IMSConnectstatus", type = StatusIMSConnectstatus.class),
        @XmlElement(name = "IPAddressStatus", type = StatusIPAddressStatus.class),
        @XmlElement(name = "IPMISelEvents", type = StatusIPMISelEvents.class),
        @XmlElement(name = "IPMulticastStatus", type = StatusIPMulticastStatus.class),
        @XmlElement(name = "IScsiHBAStatus", type = StatusIScsiHBAStatus.class),
        @XmlElement(name = "IScsiInitiatorStatus", type = StatusIScsiInitiatorStatus.class),
        @XmlElement(name = "IScsiTargetStatus", type = StatusIScsiTargetStatus.class),
        @XmlElement(name = "IScsiVolumeStatus", type = StatusIScsiVolumeStatus.class),
        @XmlElement(name = "KerberosTickets", type = StatusKerberosTickets.class),
        @XmlElement(name = "KerberosTickets2", type = StatusKerberosTickets2 .class),
        @XmlElement(name = "LDAPPoolEntries", type = StatusLDAPPoolEntries.class),
        @XmlElement(name = "LDAPPoolSummary", type = StatusLDAPPoolSummary.class),
        @XmlElement(name = "LibraryVersion", type = StatusLibraryVersion.class),
        @XmlElement(name = "LicenseStatus", type = StatusLicenseStatus.class),
        @XmlElement(name = "LinkAggregationMemberStatus", type = StatusLinkAggregationMemberStatus.class),
        @XmlElement(name = "LinkAggregationStatus", type = StatusLinkAggregationStatus.class),
        @XmlElement(name = "LinkStatus", type = StatusLinkStatus.class),
        @XmlElement(name = "LoadBalancerStatus", type = StatusLoadBalancerStatus.class),
        @XmlElement(name = "LoadBalancerStatus2", type = StatusLoadBalancerStatus2 .class),
        @XmlElement(name = "LogTargetStatus", type = StatusLogTargetStatus.class),
        @XmlElement(name = "LunaLatency", type = StatusLunaLatency.class),
        @XmlElement(name = "MemoryStatus", type = StatusMemoryStatus.class),
        @XmlElement(name = "MessageCountFilters", type = StatusMessageCountFilters.class),
        @XmlElement(name = "MessageCounts", type = StatusMessageCounts.class),
        @XmlElement(name = "MessageDurationFilters", type = StatusMessageDurationFilters.class),
        @XmlElement(name = "MessageDurations", type = StatusMessageDurations.class),
        @XmlElement(name = "MessageSources", type = StatusMessageSources.class),
        @XmlElement(name = "MQConnStatus", type = StatusMQConnStatus.class),
        @XmlElement(name = "MQFTESourceProtocolHandlerSummary", type = StatusMQFTESourceProtocolHandlerSummary.class),
        @XmlElement(name = "MQQMstatus", type = StatusMQQMstatus.class),
        @XmlElement(name = "MQSourceProtocolHandlerSummary", type = StatusMQSourceProtocolHandlerSummary.class),
        @XmlElement(name = "MQStatus", type = StatusMQStatus.class),
        @XmlElement(name = "MultiProtocolGatewaySummary", type = StatusMultiProtocolGatewaySummary.class),
        @XmlElement(name = "NDCacheStatus", type = StatusNDCacheStatus.class),
        @XmlElement(name = "NDCacheStatus2", type = StatusNDCacheStatus2 .class),
        @XmlElement(name = "NetworkInterfaceStatus", type = StatusNetworkInterfaceStatus.class),
        @XmlElement(name = "NetworkReceiveDataThroughput", type = StatusNetworkReceiveDataThroughput.class),
        @XmlElement(name = "NetworkReceivePacketThroughput", type = StatusNetworkReceivePacketThroughput.class),
        @XmlElement(name = "NetworkTransmitDataThroughput", type = StatusNetworkTransmitDataThroughput.class),
        @XmlElement(name = "NetworkTransmitPacketThroughput", type = StatusNetworkTransmitPacketThroughput.class),
        @XmlElement(name = "NFSFilePollerSourceProtocolHandlerSummary", type = StatusNFSFilePollerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "NFSMountStatus", type = StatusNFSMountStatus.class),
        @XmlElement(name = "NTPRefreshStatus", type = StatusNTPRefreshStatus.class),
        @XmlElement(name = "OAuthCachesStatus", type = StatusOAuthCachesStatus.class),
        @XmlElement(name = "ObjectStatus", type = StatusObjectStatus.class),
        @XmlElement(name = "ODRConnectorGroupStatus", type = StatusODRConnectorGroupStatus.class),
        @XmlElement(name = "ODRConnectorGroupStatus2", type = StatusODRConnectorGroupStatus2 .class),
        @XmlElement(name = "ODRLoadBalancerStatus", type = StatusODRLoadBalancerStatus.class),
        @XmlElement(name = "OtherSensors", type = StatusOtherSensors.class),
        @XmlElement(name = "PCIBus", type = StatusPCIBus.class),
        @XmlElement(name = "PolicyDomainStatus", type = StatusPolicyDomainStatus.class),
        @XmlElement(name = "POPPollerSourceProtocolHandlerSummary", type = StatusPOPPollerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "PortStatus", type = StatusPortStatus.class),
        @XmlElement(name = "PowerSensors", type = StatusPowerSensors.class),
        @XmlElement(name = "QueueManagersStatus", type = StatusQueueManagersStatus.class),
        @XmlElement(name = "QuotaEnforcementStatus", type = StatusQuotaEnforcementStatus.class),
        @XmlElement(name = "RaidArrayStatus", type = StatusRaidArrayStatus.class),
        @XmlElement(name = "RaidBatteryBackUpStatus", type = StatusRaidBatteryBackUpStatus.class),
        @XmlElement(name = "RaidBatteryModuleStatus", type = StatusRaidBatteryModuleStatus.class),
        @XmlElement(name = "RaidLogicalDriveStatus", type = StatusRaidLogicalDriveStatus.class),
        @XmlElement(name = "RaidPartitionStatus", type = StatusRaidPartitionStatus.class),
        @XmlElement(name = "RaidPhysDiskStatus", type = StatusRaidPhysDiskStatus.class),
        @XmlElement(name = "RaidPhysDiskStatus2", type = StatusRaidPhysDiskStatus2 .class),
        @XmlElement(name = "RaidPhysicalDriveStatus", type = StatusRaidPhysicalDriveStatus.class),
        @XmlElement(name = "RaidSsdStatus", type = StatusRaidSsdStatus.class),
        @XmlElement(name = "RaidVolumeStatus", type = StatusRaidVolumeStatus.class),
        @XmlElement(name = "RaidVolumeStatus2", type = StatusRaidVolumeStatus2 .class),
        @XmlElement(name = "RateLimitConcurrentStatus", type = StatusRateLimitConcurrentStatus.class),
        @XmlElement(name = "RateLimitCountStatus", type = StatusRateLimitCountStatus.class),
        @XmlElement(name = "RateLimitRateStatus", type = StatusRateLimitRateStatus.class),
        @XmlElement(name = "RateLimitTokenBucketStatus", type = StatusRateLimitTokenBucketStatus.class),
        @XmlElement(name = "ReceiveKbpsThroughput", type = StatusReceiveKbpsThroughput.class),
        @XmlElement(name = "ReceivePacketThroughput", type = StatusReceivePacketThroughput.class),
        @XmlElement(name = "RoutingStatus", type = StatusRoutingStatus.class),
        @XmlElement(name = "RoutingStatus2", type = StatusRoutingStatus2 .class),
        @XmlElement(name = "RoutingStatus3", type = StatusRoutingStatus3 .class),
        @XmlElement(name = "SecureCloudConnectorConnectionsStatus", type = StatusSecureCloudConnectorConnectionsStatus.class),
        @XmlElement(name = "SelfBalancedStatus", type = StatusSelfBalancedStatus.class),
        @XmlElement(name = "SelfBalancedStatus2", type = StatusSelfBalancedStatus2 .class),
        @XmlElement(name = "SelfBalancedTable", type = StatusSelfBalancedTable.class),
        @XmlElement(name = "ServicesMemoryStatus", type = StatusServicesMemoryStatus.class),
        @XmlElement(name = "ServicesMemoryStatus2", type = StatusServicesMemoryStatus2 .class),
        @XmlElement(name = "ServicesStatus", type = StatusServicesStatus.class),
        @XmlElement(name = "ServicesStatusPlus", type = StatusServicesStatusPlus.class),
        @XmlElement(name = "ServiceVersionStatus", type = StatusServiceVersionStatus.class),
        @XmlElement(name = "SFTPFilePollerSourceProtocolHandlerSummary", type = StatusSFTPFilePollerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "SGClientConnectionStatus", type = StatusSGClientConnectionStatus.class),
        @XmlElement(name = "SGClientStatus", type = StatusSGClientStatus.class),
        @XmlElement(name = "SLMPeeringStatus", type = StatusSLMPeeringStatus.class),
        @XmlElement(name = "SLMSummaryStatus", type = StatusSLMSummaryStatus.class),
        @XmlElement(name = "SNMPStatus", type = StatusSNMPStatus.class),
        @XmlElement(name = "SQLConnectionPoolStatus", type = StatusSQLConnectionPoolStatus.class),
        @XmlElement(name = "SQLRuntimeStatus", type = StatusSQLRuntimeStatus.class),
        @XmlElement(name = "SQLStatus", type = StatusSQLStatus.class),
        @XmlElement(name = "SSHKnownHostFileStatus", type = StatusSSHKnownHostFileStatus.class),
        @XmlElement(name = "SSHKnownHostFileStatus2", type = StatusSSHKnownHostFileStatus2 .class),
        @XmlElement(name = "SSHKnownHostStatus", type = StatusSSHKnownHostStatus.class),
        @XmlElement(name = "SSHServerSourceProtocolHandlerSummary", type = StatusSSHServerSourceProtocolHandlerSummary.class),
        @XmlElement(name = "SSHTrustedHostStatus", type = StatusSSHTrustedHostStatus.class),
        @XmlElement(name = "SSLProxyServiceSummary", type = StatusSSLProxyServiceSummary.class),
        @XmlElement(name = "StandbyStatus", type = StatusStandbyStatus.class),
        @XmlElement(name = "StandbyStatus2", type = StatusStandbyStatus2 .class),
        @XmlElement(name = "StatelessTCPSourceProtocolHandlerSummary", type = StatusStatelessTCPSourceProtocolHandlerSummary.class),
        @XmlElement(name = "StylesheetCachingSummary", type = StatusStylesheetCachingSummary.class),
        @XmlElement(name = "StylesheetExecutions", type = StatusStylesheetExecutions.class),
        @XmlElement(name = "StylesheetExecutionsSimpleIndex", type = StatusStylesheetExecutionsSimpleIndex.class),
        @XmlElement(name = "StylesheetMeanExecutionTime", type = StatusStylesheetMeanExecutionTime.class),
        @XmlElement(name = "StylesheetMeanExecutionTimeSimpleIndex", type = StatusStylesheetMeanExecutionTimeSimpleIndex.class),
        @XmlElement(name = "StylesheetProfiles", type = StatusStylesheetProfiles.class),
        @XmlElement(name = "StylesheetProfilesSimpleIndex", type = StatusStylesheetProfilesSimpleIndex.class),
        @XmlElement(name = "StylesheetStatus", type = StatusStylesheetStatus.class),
        @XmlElement(name = "StylesheetStatusSimpleIndex", type = StatusStylesheetStatusSimpleIndex.class),
        @XmlElement(name = "SystemMemoryStatus", type = StatusSystemMemoryStatus.class),
        @XmlElement(name = "SystemUsage", type = StatusSystemUsage.class),
        @XmlElement(name = "SystemUsage2Table", type = StatusSystemUsage2Table.class),
        @XmlElement(name = "SystemUsageTable", type = StatusSystemUsageTable.class),
        @XmlElement(name = "TCPProxyServiceSummary", type = StatusTCPProxyServiceSummary.class),
        @XmlElement(name = "TCPSummary", type = StatusTCPSummary.class),
        @XmlElement(name = "TCPTable", type = StatusTCPTable.class),
        @XmlElement(name = "TemperatureSensors", type = StatusTemperatureSensors.class),
        @XmlElement(name = "TibcoEMSSourceProtocolHandlerSummary", type = StatusTibcoEMSSourceProtocolHandlerSummary.class),
        @XmlElement(name = "TibcoEMSStatus", type = StatusTibcoEMSStatus.class),
        @XmlElement(name = "TransmitKbpsThroughput", type = StatusTransmitKbpsThroughput.class),
        @XmlElement(name = "TransmitPacketThroughput", type = StatusTransmitPacketThroughput.class),
        @XmlElement(name = "UDDISubscriptionKeyStatusSimpleIndex", type = StatusUDDISubscriptionKeyStatusSimpleIndex.class),
        @XmlElement(name = "UDDISubscriptionServiceStatusSimpleIndex", type = StatusUDDISubscriptionServiceStatusSimpleIndex.class),
        @XmlElement(name = "UDDISubscriptionStatusSimpleIndex", type = StatusUDDISubscriptionStatusSimpleIndex.class),
        @XmlElement(name = "Version", type = StatusVersion.class),
        @XmlElement(name = "VirtualPlatform", type = StatusVirtualPlatform.class),
        @XmlElement(name = "VirtualPlatform2", type = StatusVirtualPlatform2 .class),
        @XmlElement(name = "VlanInterfaceStatus", type = StatusVlanInterfaceStatus.class),
        @XmlElement(name = "VlanInterfaceStatus2", type = StatusVlanInterfaceStatus2 .class),
        @XmlElement(name = "VoltageSensors", type = StatusVoltageSensors.class),
        @XmlElement(name = "WebAppFwAccepted", type = StatusWebAppFwAccepted.class),
        @XmlElement(name = "WebAppFwRejected", type = StatusWebAppFwRejected.class),
        @XmlElement(name = "WebAppFWSummary", type = StatusWebAppFWSummary.class),
        @XmlElement(name = "WebSphereJMSSourceProtocolHandlerSummary", type = StatusWebSphereJMSSourceProtocolHandlerSummary.class),
        @XmlElement(name = "WebSphereJMSStatus", type = StatusWebSphereJMSStatus.class),
        @XmlElement(name = "WebTokenServiceSummary", type = StatusWebTokenServiceSummary.class),
        @XmlElement(name = "WSGatewaySummary", type = StatusWSGatewaySummary.class),
        @XmlElement(name = "WSMAgentSpoolers", type = StatusWSMAgentSpoolers.class),
        @XmlElement(name = "WSMAgentStatus", type = StatusWSMAgentStatus.class),
        @XmlElement(name = "WSOperationMetrics", type = StatusWSOperationMetrics.class),
        @XmlElement(name = "WSOperationMetricsSimpleIndex", type = StatusWSOperationMetricsSimpleIndex.class),
        @XmlElement(name = "WSOperationsStatus", type = StatusWSOperationsStatus.class),
        @XmlElement(name = "WSOperationsStatusSimpleIndex", type = StatusWSOperationsStatusSimpleIndex.class),
        @XmlElement(name = "WSRRSavdSrchSubsPolicyAttachmentsStatus", type = StatusWSRRSavdSrchSubsPolicyAttachmentsStatus.class),
        @XmlElement(name = "WSRRSavedSearchSubscriptionServiceStatus", type = StatusWSRRSavedSearchSubscriptionServiceStatus.class),
        @XmlElement(name = "WSRRSavedSearchSubscriptionStatus", type = StatusWSRRSavedSearchSubscriptionStatus.class),
        @XmlElement(name = "WSRRSubscriptionPolicyAttachmentsStatus", type = StatusWSRRSubscriptionPolicyAttachmentsStatus.class),
        @XmlElement(name = "WSRRSubscriptionServiceStatus", type = StatusWSRRSubscriptionServiceStatus.class),
        @XmlElement(name = "WSRRSubscriptionStatus", type = StatusWSRRSubscriptionStatus.class),
        @XmlElement(name = "WSWSDLStatus", type = StatusWSWSDLStatus.class),
        @XmlElement(name = "WSWSDLStatusSimpleIndex", type = StatusWSWSDLStatusSimpleIndex.class),
        @XmlElement(name = "WXSGridStatus", type = StatusWXSGridStatus.class),
        @XmlElement(name = "XC10GridStatus", type = StatusXC10GridStatus.class),
        @XmlElement(name = "XMLFirewallServiceSummary", type = StatusXMLFirewallServiceSummary.class),
        @XmlElement(name = "XMLNamesStatus", type = StatusXMLNamesStatus.class),
        @XmlElement(name = "XSLCoprocServiceSummary", type = StatusXSLCoprocServiceSummary.class),
        @XmlElement(name = "XSLProxyServiceSummary", type = StatusXSLProxyServiceSummary.class),
        @XmlElement(name = "XTCProtocolHandlerSummary", type = StatusXTCProtocolHandlerSummary.class),
        @XmlElement(name = "ZHybridTCSstatus", type = StatusZHybridTCSstatus.class),
        @XmlElement(name = "ZosNSSstatus", type = StatusZosNSSstatus.class)
    })
    protected List<Object> statusObjects;

    /**
     * Gets the value of the statusObjects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statusObjects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatusObjects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatusActiveUsers }
     * {@link StatusARPStatus }
     * {@link StatusAS1PollerSourceProtocolHandlerSummary }
     * {@link StatusAS2SourceProtocolHandlerSummary }
     * {@link StatusAS3SourceProtocolHandlerSummary }
     * {@link StatusAuthCookieCacheStatus }
     * {@link StatusB2BGatewaySummary }
     * {@link StatusB2BHighAvailabilityStatus }
     * {@link StatusB2BMessageArchiveStatus }
     * {@link StatusB2BMPCStatus }
     * {@link StatusB2BTransactionLog }
     * {@link StatusB2BTransactionLog2 }
     * {@link StatusBattery }
     * {@link StatusChangeGroupRetryQueue }
     * {@link StatusChangeGroups }
     * {@link StatusCloudConnectorServiceSummary }
     * {@link StatusCloudGatewayServiceSummary }
     * {@link StatusConnectionsAccepted }
     * {@link StatusCPUUsage }
     * {@link StatusCryptoEngineStatus }
     * {@link StatusCryptoEngineStatus2 }
     * {@link StatusCryptoHwDisableStatus }
     * {@link StatusCryptoModeStatus }
     * {@link StatusCurrentSensors }
     * {@link StatusDateTimeStatus }
     * {@link StatusDateTimeStatus2 }
     * {@link StatusDebugActionStatus }
     * {@link StatusDNSCacheHostStatus }
     * {@link StatusDNSCacheHostStatus2 }
     * {@link StatusDNSCacheHostStatus3 }
     * {@link StatusDNSCacheHostStatus4 }
     * {@link StatusDNSNameServerStatus }
     * {@link StatusDNSNameServerStatus2 }
     * {@link StatusDNSSearchDomainStatus }
     * {@link StatusDNSStaticHostStatus }
     * {@link StatusDocumentCachingSummary }
     * {@link StatusDocumentCachingSummaryGlobal }
     * {@link StatusDocumentStatus }
     * {@link StatusDocumentStatusSimpleIndex }
     * {@link StatusDomainCheckpointStatus }
     * {@link StatusDomainsMemoryStatus }
     * {@link StatusDomainsMemoryStatus2 }
     * {@link StatusDomainStatus }
     * {@link StatusDomainSummary }
     * {@link StatusDynamicQueueManager }
     * {@link StatusDynamicTibcoEMSStatus }
     * {@link StatusEBMS2SourceProtocolHandlerSummary }
     * {@link StatusEBMS3SourceProtocolHandlerSummary }
     * {@link StatusEnvironmentalFanSensors }
     * {@link StatusEnvironmentalSensors }
     * {@link StatusEthernetCountersStatus }
     * {@link StatusEthernetInterfaceStatus }
     * {@link StatusEthernetMAUStatus }
     * {@link StatusEthernetMIIRegisterStatus }
     * {@link StatusFailureNotificationStatus }
     * {@link StatusFailureNotificationStatus2 }
     * {@link StatusFilePollerStatus }
     * {@link StatusFilesystemStatus }
     * {@link StatusFirmwareStatus }
     * {@link StatusFirmwareVersion }
     * {@link StatusFirmwareVersion2 }
     * {@link StatusFTPFilePollerSourceProtocolHandlerSummary }
     * {@link StatusFTPServerSourceProtocolHandlerSummary }
     * {@link StatusGatewayTransactions }
     * {@link StatusHSMKeyStatus }
     * {@link StatusHTTPConnections }
     * {@link StatusHTTPConnectionsCreated }
     * {@link StatusHTTPConnectionsDestroyed }
     * {@link StatusHTTPConnectionsOffered }
     * {@link StatusHTTPConnectionsRequested }
     * {@link StatusHTTPConnectionsReturned }
     * {@link StatusHTTPConnectionsReused }
     * {@link StatusHTTPMeanTransactionTime }
     * {@link StatusHTTPMeanTransactionTime2 }
     * {@link StatusHTTPServiceSummary }
     * {@link StatusHTTPSourceProtocolHandlerSummary }
     * {@link StatusHTTPSSourceProtocolHandlerSummary }
     * {@link StatusHTTPTransactions }
     * {@link StatusHTTPTransactions2 }
     * {@link StatusHypervisor }
     * {@link StatusHypervisor2 }
     * {@link StatusIGMPStatus }
     * {@link StatusIMSConnectSourceProtocolHandlerSummary }
     * {@link StatusIMSConnectstatus }
     * {@link StatusIPAddressStatus }
     * {@link StatusIPMISelEvents }
     * {@link StatusIPMulticastStatus }
     * {@link StatusIScsiHBAStatus }
     * {@link StatusIScsiInitiatorStatus }
     * {@link StatusIScsiTargetStatus }
     * {@link StatusIScsiVolumeStatus }
     * {@link StatusKerberosTickets }
     * {@link StatusKerberosTickets2 }
     * {@link StatusLDAPPoolEntries }
     * {@link StatusLDAPPoolSummary }
     * {@link StatusLibraryVersion }
     * {@link StatusLicenseStatus }
     * {@link StatusLinkAggregationMemberStatus }
     * {@link StatusLinkAggregationStatus }
     * {@link StatusLinkStatus }
     * {@link StatusLoadBalancerStatus }
     * {@link StatusLoadBalancerStatus2 }
     * {@link StatusLogTargetStatus }
     * {@link StatusLunaLatency }
     * {@link StatusMemoryStatus }
     * {@link StatusMessageCountFilters }
     * {@link StatusMessageCounts }
     * {@link StatusMessageDurationFilters }
     * {@link StatusMessageDurations }
     * {@link StatusMessageSources }
     * {@link StatusMQConnStatus }
     * {@link StatusMQFTESourceProtocolHandlerSummary }
     * {@link StatusMQQMstatus }
     * {@link StatusMQSourceProtocolHandlerSummary }
     * {@link StatusMQStatus }
     * {@link StatusMultiProtocolGatewaySummary }
     * {@link StatusNDCacheStatus }
     * {@link StatusNDCacheStatus2 }
     * {@link StatusNetworkInterfaceStatus }
     * {@link StatusNetworkReceiveDataThroughput }
     * {@link StatusNetworkReceivePacketThroughput }
     * {@link StatusNetworkTransmitDataThroughput }
     * {@link StatusNetworkTransmitPacketThroughput }
     * {@link StatusNFSFilePollerSourceProtocolHandlerSummary }
     * {@link StatusNFSMountStatus }
     * {@link StatusNTPRefreshStatus }
     * {@link StatusOAuthCachesStatus }
     * {@link StatusObjectStatus }
     * {@link StatusODRConnectorGroupStatus }
     * {@link StatusODRConnectorGroupStatus2 }
     * {@link StatusODRLoadBalancerStatus }
     * {@link StatusOtherSensors }
     * {@link StatusPCIBus }
     * {@link StatusPolicyDomainStatus }
     * {@link StatusPOPPollerSourceProtocolHandlerSummary }
     * {@link StatusPortStatus }
     * {@link StatusPowerSensors }
     * {@link StatusQueueManagersStatus }
     * {@link StatusQuotaEnforcementStatus }
     * {@link StatusRaidArrayStatus }
     * {@link StatusRaidBatteryBackUpStatus }
     * {@link StatusRaidBatteryModuleStatus }
     * {@link StatusRaidLogicalDriveStatus }
     * {@link StatusRaidPartitionStatus }
     * {@link StatusRaidPhysDiskStatus }
     * {@link StatusRaidPhysDiskStatus2 }
     * {@link StatusRaidPhysicalDriveStatus }
     * {@link StatusRaidSsdStatus }
     * {@link StatusRaidVolumeStatus }
     * {@link StatusRaidVolumeStatus2 }
     * {@link StatusRateLimitConcurrentStatus }
     * {@link StatusRateLimitCountStatus }
     * {@link StatusRateLimitRateStatus }
     * {@link StatusRateLimitTokenBucketStatus }
     * {@link StatusReceiveKbpsThroughput }
     * {@link StatusReceivePacketThroughput }
     * {@link StatusRoutingStatus }
     * {@link StatusRoutingStatus2 }
     * {@link StatusRoutingStatus3 }
     * {@link StatusSecureCloudConnectorConnectionsStatus }
     * {@link StatusSelfBalancedStatus }
     * {@link StatusSelfBalancedStatus2 }
     * {@link StatusSelfBalancedTable }
     * {@link StatusServicesMemoryStatus }
     * {@link StatusServicesMemoryStatus2 }
     * {@link StatusServicesStatus }
     * {@link StatusServicesStatusPlus }
     * {@link StatusServiceVersionStatus }
     * {@link StatusSFTPFilePollerSourceProtocolHandlerSummary }
     * {@link StatusSGClientConnectionStatus }
     * {@link StatusSGClientStatus }
     * {@link StatusSLMPeeringStatus }
     * {@link StatusSLMSummaryStatus }
     * {@link StatusSNMPStatus }
     * {@link StatusSQLConnectionPoolStatus }
     * {@link StatusSQLRuntimeStatus }
     * {@link StatusSQLStatus }
     * {@link StatusSSHKnownHostFileStatus }
     * {@link StatusSSHKnownHostFileStatus2 }
     * {@link StatusSSHKnownHostStatus }
     * {@link StatusSSHServerSourceProtocolHandlerSummary }
     * {@link StatusSSHTrustedHostStatus }
     * {@link StatusSSLProxyServiceSummary }
     * {@link StatusStandbyStatus }
     * {@link StatusStandbyStatus2 }
     * {@link StatusStatelessTCPSourceProtocolHandlerSummary }
     * {@link StatusStylesheetCachingSummary }
     * {@link StatusStylesheetExecutions }
     * {@link StatusStylesheetExecutionsSimpleIndex }
     * {@link StatusStylesheetMeanExecutionTime }
     * {@link StatusStylesheetMeanExecutionTimeSimpleIndex }
     * {@link StatusStylesheetProfiles }
     * {@link StatusStylesheetProfilesSimpleIndex }
     * {@link StatusStylesheetStatus }
     * {@link StatusStylesheetStatusSimpleIndex }
     * {@link StatusSystemMemoryStatus }
     * {@link StatusSystemUsage }
     * {@link StatusSystemUsage2Table }
     * {@link StatusSystemUsageTable }
     * {@link StatusTCPProxyServiceSummary }
     * {@link StatusTCPSummary }
     * {@link StatusTCPTable }
     * {@link StatusTemperatureSensors }
     * {@link StatusTibcoEMSSourceProtocolHandlerSummary }
     * {@link StatusTibcoEMSStatus }
     * {@link StatusTransmitKbpsThroughput }
     * {@link StatusTransmitPacketThroughput }
     * {@link StatusUDDISubscriptionKeyStatusSimpleIndex }
     * {@link StatusUDDISubscriptionServiceStatusSimpleIndex }
     * {@link StatusUDDISubscriptionStatusSimpleIndex }
     * {@link StatusVersion }
     * {@link StatusVirtualPlatform }
     * {@link StatusVirtualPlatform2 }
     * {@link StatusVlanInterfaceStatus }
     * {@link StatusVlanInterfaceStatus2 }
     * {@link StatusVoltageSensors }
     * {@link StatusWebAppFwAccepted }
     * {@link StatusWebAppFwRejected }
     * {@link StatusWebAppFWSummary }
     * {@link StatusWebSphereJMSSourceProtocolHandlerSummary }
     * {@link StatusWebSphereJMSStatus }
     * {@link StatusWebTokenServiceSummary }
     * {@link StatusWSGatewaySummary }
     * {@link StatusWSMAgentSpoolers }
     * {@link StatusWSMAgentStatus }
     * {@link StatusWSOperationMetrics }
     * {@link StatusWSOperationMetricsSimpleIndex }
     * {@link StatusWSOperationsStatus }
     * {@link StatusWSOperationsStatusSimpleIndex }
     * {@link StatusWSRRSavdSrchSubsPolicyAttachmentsStatus }
     * {@link StatusWSRRSavedSearchSubscriptionServiceStatus }
     * {@link StatusWSRRSavedSearchSubscriptionStatus }
     * {@link StatusWSRRSubscriptionPolicyAttachmentsStatus }
     * {@link StatusWSRRSubscriptionServiceStatus }
     * {@link StatusWSRRSubscriptionStatus }
     * {@link StatusWSWSDLStatus }
     * {@link StatusWSWSDLStatusSimpleIndex }
     * {@link StatusWXSGridStatus }
     * {@link StatusXC10GridStatus }
     * {@link StatusXMLFirewallServiceSummary }
     * {@link StatusXMLNamesStatus }
     * {@link StatusXSLCoprocServiceSummary }
     * {@link StatusXSLProxyServiceSummary }
     * {@link StatusXTCProtocolHandlerSummary }
     * {@link StatusZHybridTCSstatus }
     * {@link StatusZosNSSstatus }
     * 
     * 
     */
    public List<Object> getStatusObjects() {
        if (statusObjects == null) {
            statusObjects = new ArrayList<Object>();
        }
        return this.statusObjects;
    }

}
