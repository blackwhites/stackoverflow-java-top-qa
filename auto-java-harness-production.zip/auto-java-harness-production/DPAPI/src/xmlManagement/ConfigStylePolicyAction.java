
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigStylePolicyAction complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigStylePolicyAction"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Type"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmStyleActionType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Input" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Transform" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DFDLSettingsReference" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="InputLanguage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXformNGBinaryInputLanguage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DFDLInputRootName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InputDescriptor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OutputDescriptor" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TransformLanguage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXformNGTransformLanguage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OutputLanguage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXformNGBinaryOutputLanguage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TxMap" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="GatewayScriptLocation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ActionDebug" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TxTopLevelMap" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TxMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTxMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TxAuditLog" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Output" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NamedInOutLocationType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmNamedInOutLocationType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NamedInputs" type="{http://www.datapower.com/schemas/management}dmNamedInOut" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="NamedOutputs" type="{http://www.datapower.com/schemas/management}dmNamedInOut" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Destination" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SchemaURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JSONSchemaURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WsdlURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Policy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AAA" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DynamicSchema" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DynamicStylesheet" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="InputConversion" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="XPath" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXPathExpr {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Variable" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Value" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLCred" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLClientCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AttachmentURI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StylesheetParameters" type="{http://www.datapower.com/schemas/management}dmStylesheetParameter" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ErrorMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmStyleErrorMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ErrorInput" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ErrorOutput" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Rule" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OutputType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmActionOutputType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLogLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogType" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Transactional" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CheckpointEvent" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCheckpointEvent {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SLMPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SQLDataSource" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SQLText" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SOAPValidation" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSOAPValidation {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SQLSourceType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSQLSourceType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JOSESerializationType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmJOSESerialization {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JWEEncAlgorithm" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmJWEEncAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JWSSignatureObject" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="JWEHeaderObject" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="JOSEVerifyType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmJOSEVerifyType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JOSEDecryptType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmJOSEDecryptType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SignatureIdentifier" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RecipientIdentifier" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SingleCertificate" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SingleKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SingleSSKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="JWEDirectKeyObject" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="JWSVerifyStripSignature" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Asynchronous" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Condition" type="{http://www.datapower.com/schemas/management}dmCondition" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ResultsMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmResultsMultiWayMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetryCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetryInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeIntervalMillis {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MultipleOutputs" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IteratorType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIteratorType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IteratorExpression" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXPathExpr {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IteratorCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LoopAction" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AsyncAction" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Timeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeIntervalMillis {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLPortQName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLOperationName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLMessageDirectionOrName" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSDLAttachmentPart" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MethodRewriteType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPMethodRESTType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MethodType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPMethodRESTType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MethodType2" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPMethodRESTType2 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PolicyKey" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigStylePolicyAction", propOrder = {
    "userSummary",
    "type",
    "input",
    "transform",
    "dfdlSettingsReference",
    "inputLanguage",
    "dfdlInputRootName",
    "inputDescriptor",
    "outputDescriptor",
    "transformLanguage",
    "outputLanguage",
    "txMap",
    "gatewayScriptLocation",
    "actionDebug",
    "txTopLevelMap",
    "txMode",
    "txAuditLog",
    "output",
    "namedInOutLocationType",
    "namedInputs",
    "namedOutputs",
    "destination",
    "schemaURL",
    "jsonSchemaURL",
    "wsdlURL",
    "policy",
    "aaa",
    "dynamicSchema",
    "dynamicStylesheet",
    "inputConversion",
    "xPath",
    "variable",
    "value",
    "sslCred",
    "sslClientConfigType",
    "sslClientCred",
    "attachmentURI",
    "stylesheetParameters",
    "errorMode",
    "errorInput",
    "errorOutput",
    "rule",
    "outputType",
    "logLevel",
    "logType",
    "transactional",
    "checkpointEvent",
    "slmPolicy",
    "sqlDataSource",
    "sqlText",
    "soapValidation",
    "sqlSourceType",
    "joseSerializationType",
    "jweEncAlgorithm",
    "jwsSignatureObject",
    "jweHeaderObject",
    "joseVerifyType",
    "joseDecryptType",
    "signatureIdentifier",
    "recipientIdentifier",
    "singleCertificate",
    "singleKey",
    "singleSSKey",
    "jweDirectKeyObject",
    "jwsVerifyStripSignature",
    "asynchronous",
    "condition",
    "resultsMode",
    "retryCount",
    "retryInterval",
    "multipleOutputs",
    "iteratorType",
    "iteratorExpression",
    "iteratorCount",
    "loopAction",
    "asyncAction",
    "timeout",
    "wsdlPortQName",
    "wsdlOperationName",
    "wsdlMessageDirectionOrName",
    "wsdlAttachmentPart",
    "methodRewriteType",
    "methodType",
    "methodType2",
    "policyKey"
})
public class ConfigStylePolicyAction
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Input")
    protected String input;
    @XmlElement(name = "Transform")
    protected String transform;
    @XmlElement(name = "DFDLSettingsReference")
    protected DmReference dfdlSettingsReference;
    @XmlElement(name = "InputLanguage")
    protected String inputLanguage;
    @XmlElement(name = "DFDLInputRootName")
    protected String dfdlInputRootName;
    @XmlElement(name = "InputDescriptor")
    protected String inputDescriptor;
    @XmlElement(name = "OutputDescriptor")
    protected String outputDescriptor;
    @XmlElement(name = "TransformLanguage")
    protected String transformLanguage;
    @XmlElement(name = "OutputLanguage")
    protected String outputLanguage;
    @XmlElement(name = "TxMap")
    protected String txMap;
    @XmlElement(name = "GatewayScriptLocation")
    protected String gatewayScriptLocation;
    @XmlElement(name = "ActionDebug")
    protected String actionDebug;
    @XmlElement(name = "TxTopLevelMap")
    protected String txTopLevelMap;
    @XmlElement(name = "TxMode")
    protected String txMode;
    @XmlElement(name = "TxAuditLog")
    protected String txAuditLog;
    @XmlElement(name = "Output")
    protected String output;
    @XmlElement(name = "NamedInOutLocationType")
    protected String namedInOutLocationType;
    @XmlElement(name = "NamedInputs")
    protected List<DmNamedInOut> namedInputs;
    @XmlElement(name = "NamedOutputs")
    protected List<DmNamedInOut> namedOutputs;
    @XmlElement(name = "Destination")
    protected String destination;
    @XmlElement(name = "SchemaURL")
    protected String schemaURL;
    @XmlElement(name = "JSONSchemaURL")
    protected String jsonSchemaURL;
    @XmlElement(name = "WsdlURL")
    protected String wsdlURL;
    @XmlElement(name = "Policy")
    protected DmReference policy;
    @XmlElement(name = "AAA")
    protected DmReference aaa;
    @XmlElement(name = "DynamicSchema")
    protected DmReference dynamicSchema;
    @XmlElement(name = "DynamicStylesheet")
    protected DmReference dynamicStylesheet;
    @XmlElement(name = "InputConversion")
    protected DmReference inputConversion;
    @XmlElement(name = "XPath")
    protected String xPath;
    @XmlElement(name = "Variable")
    protected String variable;
    @XmlElement(name = "Value")
    protected String value;
    @XmlElement(name = "SSLCred")
    protected String sslCred;
    @XmlElement(name = "SSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType sslClientConfigType;
    @XmlElement(name = "SSLClientCred")
    protected DmReference sslClientCred;
    @XmlElement(name = "AttachmentURI")
    protected String attachmentURI;
    @XmlElement(name = "StylesheetParameters")
    protected List<DmStylesheetParameter> stylesheetParameters;
    @XmlElement(name = "ErrorMode")
    protected String errorMode;
    @XmlElement(name = "ErrorInput")
    protected String errorInput;
    @XmlElement(name = "ErrorOutput")
    protected String errorOutput;
    @XmlElement(name = "Rule")
    protected String rule;
    @XmlElement(name = "OutputType")
    protected String outputType;
    @XmlElement(name = "LogLevel")
    protected String logLevel;
    @XmlElement(name = "LogType")
    protected DmReference logType;
    @XmlElement(name = "Transactional")
    protected String transactional;
    @XmlElement(name = "CheckpointEvent")
    protected String checkpointEvent;
    @XmlElement(name = "SLMPolicy")
    protected String slmPolicy;
    @XmlElement(name = "SQLDataSource")
    protected DmReference sqlDataSource;
    @XmlElement(name = "SQLText")
    protected String sqlText;
    @XmlElement(name = "SOAPValidation")
    protected String soapValidation;
    @XmlElement(name = "SQLSourceType")
    protected String sqlSourceType;
    @XmlElement(name = "JOSESerializationType")
    protected String joseSerializationType;
    @XmlElement(name = "JWEEncAlgorithm")
    protected String jweEncAlgorithm;
    @XmlElement(name = "JWSSignatureObject")
    protected DmReference jwsSignatureObject;
    @XmlElement(name = "JWEHeaderObject")
    protected DmReference jweHeaderObject;
    @XmlElement(name = "JOSEVerifyType")
    protected String joseVerifyType;
    @XmlElement(name = "JOSEDecryptType")
    protected String joseDecryptType;
    @XmlElement(name = "SignatureIdentifier")
    protected List<DmReference> signatureIdentifier;
    @XmlElement(name = "RecipientIdentifier")
    protected List<DmReference> recipientIdentifier;
    @XmlElement(name = "SingleCertificate")
    protected DmReference singleCertificate;
    @XmlElement(name = "SingleKey")
    protected DmReference singleKey;
    @XmlElement(name = "SingleSSKey")
    protected DmReference singleSSKey;
    @XmlElement(name = "JWEDirectKeyObject")
    protected DmReference jweDirectKeyObject;
    @XmlElement(name = "JWSVerifyStripSignature")
    protected String jwsVerifyStripSignature;
    @XmlElement(name = "Asynchronous")
    protected String asynchronous;
    @XmlElement(name = "Condition")
    protected List<DmCondition> condition;
    @XmlElement(name = "ResultsMode")
    protected String resultsMode;
    @XmlElement(name = "RetryCount")
    protected String retryCount;
    @XmlElement(name = "RetryInterval")
    protected String retryInterval;
    @XmlElement(name = "MultipleOutputs")
    protected String multipleOutputs;
    @XmlElement(name = "IteratorType")
    protected String iteratorType;
    @XmlElement(name = "IteratorExpression")
    protected String iteratorExpression;
    @XmlElement(name = "IteratorCount")
    protected String iteratorCount;
    @XmlElement(name = "LoopAction")
    protected String loopAction;
    @XmlElement(name = "AsyncAction")
    protected List<String> asyncAction;
    @XmlElement(name = "Timeout")
    protected String timeout;
    @XmlElement(name = "WSDLPortQName")
    protected String wsdlPortQName;
    @XmlElement(name = "WSDLOperationName")
    protected String wsdlOperationName;
    @XmlElement(name = "WSDLMessageDirectionOrName")
    protected String wsdlMessageDirectionOrName;
    @XmlElement(name = "WSDLAttachmentPart")
    protected String wsdlAttachmentPart;
    @XmlElement(name = "MethodRewriteType")
    protected String methodRewriteType;
    @XmlElement(name = "MethodType")
    protected String methodType;
    @XmlElement(name = "MethodType2")
    protected String methodType2;
    @XmlElement(name = "PolicyKey")
    protected String policyKey;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the input property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInput() {
        return input;
    }

    /**
     * Sets the value of the input property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInput(String value) {
        this.input = value;
    }

    /**
     * Gets the value of the transform property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransform() {
        return transform;
    }

    /**
     * Sets the value of the transform property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransform(String value) {
        this.transform = value;
    }

    /**
     * Gets the value of the dfdlSettingsReference property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDFDLSettingsReference() {
        return dfdlSettingsReference;
    }

    /**
     * Sets the value of the dfdlSettingsReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDFDLSettingsReference(DmReference value) {
        this.dfdlSettingsReference = value;
    }

    /**
     * Gets the value of the inputLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputLanguage() {
        return inputLanguage;
    }

    /**
     * Sets the value of the inputLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputLanguage(String value) {
        this.inputLanguage = value;
    }

    /**
     * Gets the value of the dfdlInputRootName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDFDLInputRootName() {
        return dfdlInputRootName;
    }

    /**
     * Sets the value of the dfdlInputRootName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDFDLInputRootName(String value) {
        this.dfdlInputRootName = value;
    }

    /**
     * Gets the value of the inputDescriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputDescriptor() {
        return inputDescriptor;
    }

    /**
     * Sets the value of the inputDescriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputDescriptor(String value) {
        this.inputDescriptor = value;
    }

    /**
     * Gets the value of the outputDescriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutputDescriptor() {
        return outputDescriptor;
    }

    /**
     * Sets the value of the outputDescriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutputDescriptor(String value) {
        this.outputDescriptor = value;
    }

    /**
     * Gets the value of the transformLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransformLanguage() {
        return transformLanguage;
    }

    /**
     * Sets the value of the transformLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransformLanguage(String value) {
        this.transformLanguage = value;
    }

    /**
     * Gets the value of the outputLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutputLanguage() {
        return outputLanguage;
    }

    /**
     * Sets the value of the outputLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutputLanguage(String value) {
        this.outputLanguage = value;
    }

    /**
     * Gets the value of the txMap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxMap() {
        return txMap;
    }

    /**
     * Sets the value of the txMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxMap(String value) {
        this.txMap = value;
    }

    /**
     * Gets the value of the gatewayScriptLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayScriptLocation() {
        return gatewayScriptLocation;
    }

    /**
     * Sets the value of the gatewayScriptLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayScriptLocation(String value) {
        this.gatewayScriptLocation = value;
    }

    /**
     * Gets the value of the actionDebug property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionDebug() {
        return actionDebug;
    }

    /**
     * Sets the value of the actionDebug property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionDebug(String value) {
        this.actionDebug = value;
    }

    /**
     * Gets the value of the txTopLevelMap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxTopLevelMap() {
        return txTopLevelMap;
    }

    /**
     * Sets the value of the txTopLevelMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxTopLevelMap(String value) {
        this.txTopLevelMap = value;
    }

    /**
     * Gets the value of the txMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxMode() {
        return txMode;
    }

    /**
     * Sets the value of the txMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxMode(String value) {
        this.txMode = value;
    }

    /**
     * Gets the value of the txAuditLog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxAuditLog() {
        return txAuditLog;
    }

    /**
     * Sets the value of the txAuditLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxAuditLog(String value) {
        this.txAuditLog = value;
    }

    /**
     * Gets the value of the output property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutput() {
        return output;
    }

    /**
     * Sets the value of the output property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutput(String value) {
        this.output = value;
    }

    /**
     * Gets the value of the namedInOutLocationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamedInOutLocationType() {
        return namedInOutLocationType;
    }

    /**
     * Sets the value of the namedInOutLocationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamedInOutLocationType(String value) {
        this.namedInOutLocationType = value;
    }

    /**
     * Gets the value of the namedInputs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namedInputs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamedInputs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmNamedInOut }
     * 
     * 
     */
    public List<DmNamedInOut> getNamedInputs() {
        if (namedInputs == null) {
            namedInputs = new ArrayList<DmNamedInOut>();
        }
        return this.namedInputs;
    }

    /**
     * Gets the value of the namedOutputs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namedOutputs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamedOutputs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmNamedInOut }
     * 
     * 
     */
    public List<DmNamedInOut> getNamedOutputs() {
        if (namedOutputs == null) {
            namedOutputs = new ArrayList<DmNamedInOut>();
        }
        return this.namedOutputs;
    }

    /**
     * Gets the value of the destination property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the value of the destination property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestination(String value) {
        this.destination = value;
    }

    /**
     * Gets the value of the schemaURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSchemaURL() {
        return schemaURL;
    }

    /**
     * Sets the value of the schemaURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSchemaURL(String value) {
        this.schemaURL = value;
    }

    /**
     * Gets the value of the jsonSchemaURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJSONSchemaURL() {
        return jsonSchemaURL;
    }

    /**
     * Sets the value of the jsonSchemaURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJSONSchemaURL(String value) {
        this.jsonSchemaURL = value;
    }

    /**
     * Gets the value of the wsdlURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWsdlURL() {
        return wsdlURL;
    }

    /**
     * Sets the value of the wsdlURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWsdlURL(String value) {
        this.wsdlURL = value;
    }

    /**
     * Gets the value of the policy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getPolicy() {
        return policy;
    }

    /**
     * Sets the value of the policy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setPolicy(DmReference value) {
        this.policy = value;
    }

    /**
     * Gets the value of the aaa property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAAA() {
        return aaa;
    }

    /**
     * Sets the value of the aaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAAA(DmReference value) {
        this.aaa = value;
    }

    /**
     * Gets the value of the dynamicSchema property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDynamicSchema() {
        return dynamicSchema;
    }

    /**
     * Sets the value of the dynamicSchema property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDynamicSchema(DmReference value) {
        this.dynamicSchema = value;
    }

    /**
     * Gets the value of the dynamicStylesheet property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getDynamicStylesheet() {
        return dynamicStylesheet;
    }

    /**
     * Sets the value of the dynamicStylesheet property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setDynamicStylesheet(DmReference value) {
        this.dynamicStylesheet = value;
    }

    /**
     * Gets the value of the inputConversion property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getInputConversion() {
        return inputConversion;
    }

    /**
     * Sets the value of the inputConversion property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setInputConversion(DmReference value) {
        this.inputConversion = value;
    }

    /**
     * Gets the value of the xPath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXPath() {
        return xPath;
    }

    /**
     * Sets the value of the xPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXPath(String value) {
        this.xPath = value;
    }

    /**
     * Gets the value of the variable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVariable() {
        return variable;
    }

    /**
     * Sets the value of the variable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVariable(String value) {
        this.variable = value;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the value of the sslCred property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLCred() {
        return sslCred;
    }

    /**
     * Sets the value of the sslCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLCred(String value) {
        this.sslCred = value;
    }

    /**
     * Gets the value of the sslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getSSLClientConfigType() {
        return sslClientConfigType;
    }

    /**
     * Sets the value of the sslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setSSLClientConfigType(DmSSLClientConfigType value) {
        this.sslClientConfigType = value;
    }

    /**
     * Gets the value of the sslClientCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClientCred() {
        return sslClientCred;
    }

    /**
     * Sets the value of the sslClientCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClientCred(DmReference value) {
        this.sslClientCred = value;
    }

    /**
     * Gets the value of the attachmentURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachmentURI() {
        return attachmentURI;
    }

    /**
     * Sets the value of the attachmentURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachmentURI(String value) {
        this.attachmentURI = value;
    }

    /**
     * Gets the value of the stylesheetParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stylesheetParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStylesheetParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmStylesheetParameter }
     * 
     * 
     */
    public List<DmStylesheetParameter> getStylesheetParameters() {
        if (stylesheetParameters == null) {
            stylesheetParameters = new ArrayList<DmStylesheetParameter>();
        }
        return this.stylesheetParameters;
    }

    /**
     * Gets the value of the errorMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMode() {
        return errorMode;
    }

    /**
     * Sets the value of the errorMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMode(String value) {
        this.errorMode = value;
    }

    /**
     * Gets the value of the errorInput property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorInput() {
        return errorInput;
    }

    /**
     * Sets the value of the errorInput property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorInput(String value) {
        this.errorInput = value;
    }

    /**
     * Gets the value of the errorOutput property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorOutput() {
        return errorOutput;
    }

    /**
     * Sets the value of the errorOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorOutput(String value) {
        this.errorOutput = value;
    }

    /**
     * Gets the value of the rule property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRule() {
        return rule;
    }

    /**
     * Sets the value of the rule property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRule(String value) {
        this.rule = value;
    }

    /**
     * Gets the value of the outputType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutputType() {
        return outputType;
    }

    /**
     * Sets the value of the outputType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutputType(String value) {
        this.outputType = value;
    }

    /**
     * Gets the value of the logLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogLevel() {
        return logLevel;
    }

    /**
     * Sets the value of the logLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogLevel(String value) {
        this.logLevel = value;
    }

    /**
     * Gets the value of the logType property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getLogType() {
        return logType;
    }

    /**
     * Sets the value of the logType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setLogType(DmReference value) {
        this.logType = value;
    }

    /**
     * Gets the value of the transactional property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactional() {
        return transactional;
    }

    /**
     * Sets the value of the transactional property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactional(String value) {
        this.transactional = value;
    }

    /**
     * Gets the value of the checkpointEvent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckpointEvent() {
        return checkpointEvent;
    }

    /**
     * Sets the value of the checkpointEvent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckpointEvent(String value) {
        this.checkpointEvent = value;
    }

    /**
     * Gets the value of the slmPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSLMPolicy() {
        return slmPolicy;
    }

    /**
     * Sets the value of the slmPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSLMPolicy(String value) {
        this.slmPolicy = value;
    }

    /**
     * Gets the value of the sqlDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSQLDataSource() {
        return sqlDataSource;
    }

    /**
     * Sets the value of the sqlDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSQLDataSource(DmReference value) {
        this.sqlDataSource = value;
    }

    /**
     * Gets the value of the sqlText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSQLText() {
        return sqlText;
    }

    /**
     * Sets the value of the sqlText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSQLText(String value) {
        this.sqlText = value;
    }

    /**
     * Gets the value of the soapValidation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOAPValidation() {
        return soapValidation;
    }

    /**
     * Sets the value of the soapValidation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOAPValidation(String value) {
        this.soapValidation = value;
    }

    /**
     * Gets the value of the sqlSourceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSQLSourceType() {
        return sqlSourceType;
    }

    /**
     * Sets the value of the sqlSourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSQLSourceType(String value) {
        this.sqlSourceType = value;
    }

    /**
     * Gets the value of the joseSerializationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOSESerializationType() {
        return joseSerializationType;
    }

    /**
     * Sets the value of the joseSerializationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOSESerializationType(String value) {
        this.joseSerializationType = value;
    }

    /**
     * Gets the value of the jweEncAlgorithm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJWEEncAlgorithm() {
        return jweEncAlgorithm;
    }

    /**
     * Sets the value of the jweEncAlgorithm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJWEEncAlgorithm(String value) {
        this.jweEncAlgorithm = value;
    }

    /**
     * Gets the value of the jwsSignatureObject property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getJWSSignatureObject() {
        return jwsSignatureObject;
    }

    /**
     * Sets the value of the jwsSignatureObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setJWSSignatureObject(DmReference value) {
        this.jwsSignatureObject = value;
    }

    /**
     * Gets the value of the jweHeaderObject property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getJWEHeaderObject() {
        return jweHeaderObject;
    }

    /**
     * Sets the value of the jweHeaderObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setJWEHeaderObject(DmReference value) {
        this.jweHeaderObject = value;
    }

    /**
     * Gets the value of the joseVerifyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOSEVerifyType() {
        return joseVerifyType;
    }

    /**
     * Sets the value of the joseVerifyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOSEVerifyType(String value) {
        this.joseVerifyType = value;
    }

    /**
     * Gets the value of the joseDecryptType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOSEDecryptType() {
        return joseDecryptType;
    }

    /**
     * Sets the value of the joseDecryptType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOSEDecryptType(String value) {
        this.joseDecryptType = value;
    }

    /**
     * Gets the value of the signatureIdentifier property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the signatureIdentifier property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSignatureIdentifier().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getSignatureIdentifier() {
        if (signatureIdentifier == null) {
            signatureIdentifier = new ArrayList<DmReference>();
        }
        return this.signatureIdentifier;
    }

    /**
     * Gets the value of the recipientIdentifier property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the recipientIdentifier property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecipientIdentifier().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getRecipientIdentifier() {
        if (recipientIdentifier == null) {
            recipientIdentifier = new ArrayList<DmReference>();
        }
        return this.recipientIdentifier;
    }

    /**
     * Gets the value of the singleCertificate property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSingleCertificate() {
        return singleCertificate;
    }

    /**
     * Sets the value of the singleCertificate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSingleCertificate(DmReference value) {
        this.singleCertificate = value;
    }

    /**
     * Gets the value of the singleKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSingleKey() {
        return singleKey;
    }

    /**
     * Sets the value of the singleKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSingleKey(DmReference value) {
        this.singleKey = value;
    }

    /**
     * Gets the value of the singleSSKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSingleSSKey() {
        return singleSSKey;
    }

    /**
     * Sets the value of the singleSSKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSingleSSKey(DmReference value) {
        this.singleSSKey = value;
    }

    /**
     * Gets the value of the jweDirectKeyObject property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getJWEDirectKeyObject() {
        return jweDirectKeyObject;
    }

    /**
     * Sets the value of the jweDirectKeyObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setJWEDirectKeyObject(DmReference value) {
        this.jweDirectKeyObject = value;
    }

    /**
     * Gets the value of the jwsVerifyStripSignature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJWSVerifyStripSignature() {
        return jwsVerifyStripSignature;
    }

    /**
     * Sets the value of the jwsVerifyStripSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJWSVerifyStripSignature(String value) {
        this.jwsVerifyStripSignature = value;
    }

    /**
     * Gets the value of the asynchronous property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsynchronous() {
        return asynchronous;
    }

    /**
     * Sets the value of the asynchronous property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsynchronous(String value) {
        this.asynchronous = value;
    }

    /**
     * Gets the value of the condition property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the condition property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCondition().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmCondition }
     * 
     * 
     */
    public List<DmCondition> getCondition() {
        if (condition == null) {
            condition = new ArrayList<DmCondition>();
        }
        return this.condition;
    }

    /**
     * Gets the value of the resultsMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResultsMode() {
        return resultsMode;
    }

    /**
     * Sets the value of the resultsMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResultsMode(String value) {
        this.resultsMode = value;
    }

    /**
     * Gets the value of the retryCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryCount() {
        return retryCount;
    }

    /**
     * Sets the value of the retryCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryCount(String value) {
        this.retryCount = value;
    }

    /**
     * Gets the value of the retryInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryInterval() {
        return retryInterval;
    }

    /**
     * Sets the value of the retryInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryInterval(String value) {
        this.retryInterval = value;
    }

    /**
     * Gets the value of the multipleOutputs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMultipleOutputs() {
        return multipleOutputs;
    }

    /**
     * Sets the value of the multipleOutputs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMultipleOutputs(String value) {
        this.multipleOutputs = value;
    }

    /**
     * Gets the value of the iteratorType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIteratorType() {
        return iteratorType;
    }

    /**
     * Sets the value of the iteratorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIteratorType(String value) {
        this.iteratorType = value;
    }

    /**
     * Gets the value of the iteratorExpression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIteratorExpression() {
        return iteratorExpression;
    }

    /**
     * Sets the value of the iteratorExpression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIteratorExpression(String value) {
        this.iteratorExpression = value;
    }

    /**
     * Gets the value of the iteratorCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIteratorCount() {
        return iteratorCount;
    }

    /**
     * Sets the value of the iteratorCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIteratorCount(String value) {
        this.iteratorCount = value;
    }

    /**
     * Gets the value of the loopAction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoopAction() {
        return loopAction;
    }

    /**
     * Sets the value of the loopAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoopAction(String value) {
        this.loopAction = value;
    }

    /**
     * Gets the value of the asyncAction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the asyncAction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAsyncAction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAsyncAction() {
        if (asyncAction == null) {
            asyncAction = new ArrayList<String>();
        }
        return this.asyncAction;
    }

    /**
     * Gets the value of the timeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeout() {
        return timeout;
    }

    /**
     * Sets the value of the timeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeout(String value) {
        this.timeout = value;
    }

    /**
     * Gets the value of the wsdlPortQName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLPortQName() {
        return wsdlPortQName;
    }

    /**
     * Sets the value of the wsdlPortQName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLPortQName(String value) {
        this.wsdlPortQName = value;
    }

    /**
     * Gets the value of the wsdlOperationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLOperationName() {
        return wsdlOperationName;
    }

    /**
     * Sets the value of the wsdlOperationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLOperationName(String value) {
        this.wsdlOperationName = value;
    }

    /**
     * Gets the value of the wsdlMessageDirectionOrName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLMessageDirectionOrName() {
        return wsdlMessageDirectionOrName;
    }

    /**
     * Sets the value of the wsdlMessageDirectionOrName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLMessageDirectionOrName(String value) {
        this.wsdlMessageDirectionOrName = value;
    }

    /**
     * Gets the value of the wsdlAttachmentPart property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSDLAttachmentPart() {
        return wsdlAttachmentPart;
    }

    /**
     * Sets the value of the wsdlAttachmentPart property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSDLAttachmentPart(String value) {
        this.wsdlAttachmentPart = value;
    }

    /**
     * Gets the value of the methodRewriteType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMethodRewriteType() {
        return methodRewriteType;
    }

    /**
     * Sets the value of the methodRewriteType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMethodRewriteType(String value) {
        this.methodRewriteType = value;
    }

    /**
     * Gets the value of the methodType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMethodType() {
        return methodType;
    }

    /**
     * Sets the value of the methodType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMethodType(String value) {
        this.methodType = value;
    }

    /**
     * Gets the value of the methodType2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMethodType2() {
        return methodType2;
    }

    /**
     * Sets the value of the methodType2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMethodType2(String value) {
        this.methodType2 = value;
    }

    /**
     * Gets the value of the policyKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyKey() {
        return policyKey;
    }

    /**
     * Sets the value of the policyKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyKey(String value) {
        this.policyKey = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
