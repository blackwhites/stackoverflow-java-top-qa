
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigAccessControl complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigAccessControl"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigAccessControl")
@XmlSeeAlso({
    ConfigAAAPolicy.class,
    ConfigDomain.class,
    ConfigLDAPSearchParameters.class,
    ConfigProcessingMetadata.class,
    ConfigRADIUSSettings.class,
    ConfigRBMSettings.class,
    ConfigSAMLAttributes.class,
    ConfigSOAPHeaderDisposition.class,
    ConfigTAM.class,
    ConfigTFIMEndpoint.class,
    ConfigXACMLPDP.class
})
public class ConfigAccessControl
    extends ConfigConfigBase
{


}
