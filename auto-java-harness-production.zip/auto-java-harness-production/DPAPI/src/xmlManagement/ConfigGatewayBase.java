
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigGatewayBase complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigGatewayBase"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSchedulerPriority {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontProtocol" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="URLRewritePolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="FWCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="HeaderInjection" type="{http://www.datapower.com/schemas/management}dmHeaderInjection" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HeaderSuppression" type="{http://www.datapower.com/schemas/management}dmHeaderSuppression" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="StylesheetParameters" type="{http://www.datapower.com/schemas/management}dmStylesheetParameter" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DefaultParamNamespace" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="QueryParamNamespace" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackendUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PropagateURI" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ServiceMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CountMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DurationMonitors" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MonitorProcessingPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmMonitorProcessingPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestAttachments" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseAttachments" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAttachmentMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RequestAttachmentsFlowControl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseAttachmentsFlowControl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RootPartNotFirstAction" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmRootPartNotFirstAction {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontAttachmentFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmGatewayAttachmentFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackAttachmentFormat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmGatewayAttachmentFormat {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MIMEFrontHeaders" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MIMEBackHeaders" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StreamOutputToBack" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmQuarantineMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StreamOutputToFront" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmQuarantineMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxMessageSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="GatewayParserLimits" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsElementDepth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsAttributeCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsMaxNodeSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsForbidExternalReferences" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsExternalReferences" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmExternalRefHandling {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsMaxPrefixes" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsMaxNamespaces" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsMaxLocalNames" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsAttachmentByteCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ParserLimitsAttachmentPackageByteCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmDebugMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugHistory" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DebugTrigger" type="{http://www.datapower.com/schemas/management}dmMSDebugTriggerType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FlowControl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SOAPSchemaURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FrontPersistentTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackPersistentTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IncludeResponseTypeEncoding" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackHTTPVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHTTPVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PersistentConnections" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LoopDetection" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoHostRewriting" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DoChunkedUpload" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProcessHTTPErrors" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPClientIPLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="HTTPLogCorIDLabel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LoadBalancerHashHeader" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InOrderMode" type="{http://www.datapower.com/schemas/management}dmGatewayInOrderMode" minOccurs="0"/&gt;
 *         &lt;element name="WSAMode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSAModeType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSARequireAAA" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSARewriteReplyTo" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSARewriteFaultTo" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSARewriteTo" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSAStrip" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSADefaultReplyTo" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSADefaultFaultTo" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSAForce" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSAGenStyle" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWSAOriginatedRequestType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSAHTTPAsyncResponseCode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSABackProtocol" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSATimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMEnabled" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSequenceExpiration" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMAAAPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSRMDestinationAcceptCreateSequence" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMDestinationMaximumSequences" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMDestinationInOrder" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMDestinationMaximumInOrderQueueLength" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMDestinationAcceptOffers" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMFrontForce" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMBackForce" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMBackCreateSequence" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMFrontCreateSequence" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceMakeOffer" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMUsesSequenceSSL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMFrontAcksTo" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSRMBackAcksTo" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="WSRMSourceMaximumSequences" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceRetransmissionInterval" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceExponentialBackoff" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceMaximumRetransmissions" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceMaximumQueueLength" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceRequestAckCount" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="WSRMSourceInactivityClose" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ForcePolicyExec" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RewriteErrors" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DelayErrors" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DelayErrorsDuration" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigGatewayBase", propOrder = {
    "userSummary",
    "priority",
    "frontProtocol",
    "xmlManager",
    "urlRewritePolicy",
    "sslClientConfigType",
    "sslProxy",
    "sslClient",
    "fwCred",
    "headerInjection",
    "headerSuppression",
    "stylesheetParameters",
    "defaultParamNamespace",
    "queryParamNamespace",
    "backendUrl",
    "propagateURI",
    "serviceMonitors",
    "countMonitors",
    "durationMonitors",
    "monitorProcessingPolicy",
    "requestAttachments",
    "responseAttachments",
    "requestAttachmentsFlowControl",
    "responseAttachmentsFlowControl",
    "rootPartNotFirstAction",
    "frontAttachmentFormat",
    "backAttachmentFormat",
    "mimeFrontHeaders",
    "mimeBackHeaders",
    "streamOutputToBack",
    "streamOutputToFront",
    "maxMessageSize",
    "gatewayParserLimits",
    "parserLimitsElementDepth",
    "parserLimitsAttributeCount",
    "parserLimitsMaxNodeSize",
    "parserLimitsForbidExternalReferences",
    "parserLimitsExternalReferences",
    "parserLimitsMaxPrefixes",
    "parserLimitsMaxNamespaces",
    "parserLimitsMaxLocalNames",
    "parserLimitsAttachmentByteCount",
    "parserLimitsAttachmentPackageByteCount",
    "debugMode",
    "debugHistory",
    "debugTrigger",
    "flowControl",
    "soapSchemaURL",
    "frontTimeout",
    "backTimeout",
    "frontPersistentTimeout",
    "backPersistentTimeout",
    "includeResponseTypeEncoding",
    "backHTTPVersion",
    "persistentConnections",
    "loopDetection",
    "doHostRewriting",
    "doChunkedUpload",
    "processHTTPErrors",
    "httpClientIPLabel",
    "httpLogCorIDLabel",
    "loadBalancerHashHeader",
    "inOrderMode",
    "wsaMode",
    "wsaRequireAAA",
    "wsaRewriteReplyTo",
    "wsaRewriteFaultTo",
    "wsaRewriteTo",
    "wsaStrip",
    "wsaDefaultReplyTo",
    "wsaDefaultFaultTo",
    "wsaForce",
    "wsaGenStyle",
    "wsahttpAsyncResponseCode",
    "wsaBackProtocol",
    "wsaTimeout",
    "wsrmEnabled",
    "wsrmSequenceExpiration",
    "wsrmaaaPolicy",
    "wsrmDestinationAcceptCreateSequence",
    "wsrmDestinationMaximumSequences",
    "wsrmDestinationInOrder",
    "wsrmDestinationMaximumInOrderQueueLength",
    "wsrmDestinationAcceptOffers",
    "wsrmFrontForce",
    "wsrmBackForce",
    "wsrmBackCreateSequence",
    "wsrmFrontCreateSequence",
    "wsrmSourceMakeOffer",
    "wsrmUsesSequenceSSL",
    "wsrmFrontAcksTo",
    "wsrmBackAcksTo",
    "wsrmSourceMaximumSequences",
    "wsrmSourceRetransmissionInterval",
    "wsrmSourceExponentialBackoff",
    "wsrmSourceMaximumRetransmissions",
    "wsrmSourceMaximumQueueLength",
    "wsrmSourceRequestAckCount",
    "wsrmSourceInactivityClose",
    "forcePolicyExec",
    "rewriteErrors",
    "delayErrors",
    "delayErrorsDuration"
})
@XmlSeeAlso({
    ConfigMultiProtocolGateway.class,
    ConfigWSGateway.class
})
public class ConfigGatewayBase
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "FrontProtocol")
    protected List<DmReference> frontProtocol;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "URLRewritePolicy")
    protected DmReference urlRewritePolicy;
    @XmlElement(name = "SSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType sslClientConfigType;
    @XmlElement(name = "SSLProxy")
    protected DmReference sslProxy;
    @XmlElement(name = "SSLClient")
    protected DmReference sslClient;
    @XmlElement(name = "FWCred")
    protected DmReference fwCred;
    @XmlElement(name = "HeaderInjection")
    protected List<DmHeaderInjection> headerInjection;
    @XmlElement(name = "HeaderSuppression")
    protected List<DmHeaderSuppression> headerSuppression;
    @XmlElement(name = "StylesheetParameters")
    protected List<DmStylesheetParameter> stylesheetParameters;
    @XmlElement(name = "DefaultParamNamespace")
    protected String defaultParamNamespace;
    @XmlElement(name = "QueryParamNamespace")
    protected String queryParamNamespace;
    @XmlElement(name = "BackendUrl")
    protected String backendUrl;
    @XmlElement(name = "PropagateURI")
    protected String propagateURI;
    @XmlElement(name = "ServiceMonitors")
    protected List<DmReference> serviceMonitors;
    @XmlElement(name = "CountMonitors")
    protected List<DmReference> countMonitors;
    @XmlElement(name = "DurationMonitors")
    protected List<DmReference> durationMonitors;
    @XmlElement(name = "MonitorProcessingPolicy")
    protected String monitorProcessingPolicy;
    @XmlElement(name = "RequestAttachments")
    protected String requestAttachments;
    @XmlElement(name = "ResponseAttachments")
    protected String responseAttachments;
    @XmlElement(name = "RequestAttachmentsFlowControl")
    protected String requestAttachmentsFlowControl;
    @XmlElement(name = "ResponseAttachmentsFlowControl")
    protected String responseAttachmentsFlowControl;
    @XmlElement(name = "RootPartNotFirstAction")
    protected String rootPartNotFirstAction;
    @XmlElement(name = "FrontAttachmentFormat")
    protected String frontAttachmentFormat;
    @XmlElement(name = "BackAttachmentFormat")
    protected String backAttachmentFormat;
    @XmlElement(name = "MIMEFrontHeaders")
    protected String mimeFrontHeaders;
    @XmlElement(name = "MIMEBackHeaders")
    protected String mimeBackHeaders;
    @XmlElement(name = "StreamOutputToBack")
    protected String streamOutputToBack;
    @XmlElement(name = "StreamOutputToFront")
    protected String streamOutputToFront;
    @XmlElement(name = "MaxMessageSize")
    protected String maxMessageSize;
    @XmlElement(name = "GatewayParserLimits")
    protected String gatewayParserLimits;
    @XmlElement(name = "ParserLimitsElementDepth")
    protected String parserLimitsElementDepth;
    @XmlElement(name = "ParserLimitsAttributeCount")
    protected String parserLimitsAttributeCount;
    @XmlElement(name = "ParserLimitsMaxNodeSize")
    protected String parserLimitsMaxNodeSize;
    @XmlElement(name = "ParserLimitsForbidExternalReferences")
    protected String parserLimitsForbidExternalReferences;
    @XmlElement(name = "ParserLimitsExternalReferences")
    protected String parserLimitsExternalReferences;
    @XmlElement(name = "ParserLimitsMaxPrefixes")
    protected String parserLimitsMaxPrefixes;
    @XmlElement(name = "ParserLimitsMaxNamespaces")
    protected String parserLimitsMaxNamespaces;
    @XmlElement(name = "ParserLimitsMaxLocalNames")
    protected String parserLimitsMaxLocalNames;
    @XmlElement(name = "ParserLimitsAttachmentByteCount")
    protected String parserLimitsAttachmentByteCount;
    @XmlElement(name = "ParserLimitsAttachmentPackageByteCount")
    protected String parserLimitsAttachmentPackageByteCount;
    @XmlElement(name = "DebugMode")
    protected String debugMode;
    @XmlElement(name = "DebugHistory")
    protected String debugHistory;
    @XmlElement(name = "DebugTrigger")
    protected List<DmMSDebugTriggerType> debugTrigger;
    @XmlElement(name = "FlowControl")
    protected String flowControl;
    @XmlElement(name = "SOAPSchemaURL")
    protected String soapSchemaURL;
    @XmlElement(name = "FrontTimeout")
    protected String frontTimeout;
    @XmlElement(name = "BackTimeout")
    protected String backTimeout;
    @XmlElement(name = "FrontPersistentTimeout")
    protected String frontPersistentTimeout;
    @XmlElement(name = "BackPersistentTimeout")
    protected String backPersistentTimeout;
    @XmlElement(name = "IncludeResponseTypeEncoding")
    protected String includeResponseTypeEncoding;
    @XmlElement(name = "BackHTTPVersion")
    protected String backHTTPVersion;
    @XmlElement(name = "PersistentConnections")
    protected String persistentConnections;
    @XmlElement(name = "LoopDetection")
    protected String loopDetection;
    @XmlElement(name = "DoHostRewriting")
    protected String doHostRewriting;
    @XmlElement(name = "DoChunkedUpload")
    protected String doChunkedUpload;
    @XmlElement(name = "ProcessHTTPErrors")
    protected String processHTTPErrors;
    @XmlElement(name = "HTTPClientIPLabel")
    protected String httpClientIPLabel;
    @XmlElement(name = "HTTPLogCorIDLabel")
    protected String httpLogCorIDLabel;
    @XmlElement(name = "LoadBalancerHashHeader")
    protected String loadBalancerHashHeader;
    @XmlElement(name = "InOrderMode")
    protected DmGatewayInOrderMode inOrderMode;
    @XmlElement(name = "WSAMode")
    protected String wsaMode;
    @XmlElement(name = "WSARequireAAA")
    protected String wsaRequireAAA;
    @XmlElement(name = "WSARewriteReplyTo")
    protected DmReference wsaRewriteReplyTo;
    @XmlElement(name = "WSARewriteFaultTo")
    protected DmReference wsaRewriteFaultTo;
    @XmlElement(name = "WSARewriteTo")
    protected DmReference wsaRewriteTo;
    @XmlElement(name = "WSAStrip")
    protected String wsaStrip;
    @XmlElement(name = "WSADefaultReplyTo")
    protected String wsaDefaultReplyTo;
    @XmlElement(name = "WSADefaultFaultTo")
    protected String wsaDefaultFaultTo;
    @XmlElement(name = "WSAForce")
    protected String wsaForce;
    @XmlElement(name = "WSAGenStyle")
    protected String wsaGenStyle;
    @XmlElement(name = "WSAHTTPAsyncResponseCode")
    protected String wsahttpAsyncResponseCode;
    @XmlElement(name = "WSABackProtocol")
    protected DmReference wsaBackProtocol;
    @XmlElement(name = "WSATimeout")
    protected String wsaTimeout;
    @XmlElement(name = "WSRMEnabled")
    protected String wsrmEnabled;
    @XmlElement(name = "WSRMSequenceExpiration")
    protected String wsrmSequenceExpiration;
    @XmlElement(name = "WSRMAAAPolicy")
    protected DmReference wsrmaaaPolicy;
    @XmlElement(name = "WSRMDestinationAcceptCreateSequence")
    protected String wsrmDestinationAcceptCreateSequence;
    @XmlElement(name = "WSRMDestinationMaximumSequences")
    protected String wsrmDestinationMaximumSequences;
    @XmlElement(name = "WSRMDestinationInOrder")
    protected String wsrmDestinationInOrder;
    @XmlElement(name = "WSRMDestinationMaximumInOrderQueueLength")
    protected String wsrmDestinationMaximumInOrderQueueLength;
    @XmlElement(name = "WSRMDestinationAcceptOffers")
    protected String wsrmDestinationAcceptOffers;
    @XmlElement(name = "WSRMFrontForce")
    protected String wsrmFrontForce;
    @XmlElement(name = "WSRMBackForce")
    protected String wsrmBackForce;
    @XmlElement(name = "WSRMBackCreateSequence")
    protected String wsrmBackCreateSequence;
    @XmlElement(name = "WSRMFrontCreateSequence")
    protected String wsrmFrontCreateSequence;
    @XmlElement(name = "WSRMSourceMakeOffer")
    protected String wsrmSourceMakeOffer;
    @XmlElement(name = "WSRMUsesSequenceSSL")
    protected String wsrmUsesSequenceSSL;
    @XmlElement(name = "WSRMFrontAcksTo")
    protected DmReference wsrmFrontAcksTo;
    @XmlElement(name = "WSRMBackAcksTo")
    protected DmReference wsrmBackAcksTo;
    @XmlElement(name = "WSRMSourceMaximumSequences")
    protected String wsrmSourceMaximumSequences;
    @XmlElement(name = "WSRMSourceRetransmissionInterval")
    protected String wsrmSourceRetransmissionInterval;
    @XmlElement(name = "WSRMSourceExponentialBackoff")
    protected String wsrmSourceExponentialBackoff;
    @XmlElement(name = "WSRMSourceMaximumRetransmissions")
    protected String wsrmSourceMaximumRetransmissions;
    @XmlElement(name = "WSRMSourceMaximumQueueLength")
    protected String wsrmSourceMaximumQueueLength;
    @XmlElement(name = "WSRMSourceRequestAckCount")
    protected String wsrmSourceRequestAckCount;
    @XmlElement(name = "WSRMSourceInactivityClose")
    protected String wsrmSourceInactivityClose;
    @XmlElement(name = "ForcePolicyExec")
    protected String forcePolicyExec;
    @XmlElement(name = "RewriteErrors")
    protected String rewriteErrors;
    @XmlElement(name = "DelayErrors")
    protected String delayErrors;
    @XmlElement(name = "DelayErrorsDuration")
    protected String delayErrorsDuration;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the frontProtocol property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frontProtocol property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrontProtocol().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getFrontProtocol() {
        if (frontProtocol == null) {
            frontProtocol = new ArrayList<DmReference>();
        }
        return this.frontProtocol;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the urlRewritePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getURLRewritePolicy() {
        return urlRewritePolicy;
    }

    /**
     * Sets the value of the urlRewritePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setURLRewritePolicy(DmReference value) {
        this.urlRewritePolicy = value;
    }

    /**
     * Gets the value of the sslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getSSLClientConfigType() {
        return sslClientConfigType;
    }

    /**
     * Sets the value of the sslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setSSLClientConfigType(DmSSLClientConfigType value) {
        this.sslClientConfigType = value;
    }

    /**
     * Gets the value of the sslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxy() {
        return sslProxy;
    }

    /**
     * Sets the value of the sslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxy(DmReference value) {
        this.sslProxy = value;
    }

    /**
     * Gets the value of the sslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClient() {
        return sslClient;
    }

    /**
     * Sets the value of the sslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClient(DmReference value) {
        this.sslClient = value;
    }

    /**
     * Gets the value of the fwCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getFWCred() {
        return fwCred;
    }

    /**
     * Sets the value of the fwCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setFWCred(DmReference value) {
        this.fwCred = value;
    }

    /**
     * Gets the value of the headerInjection property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerInjection property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderInjection().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmHeaderInjection }
     * 
     * 
     */
    public List<DmHeaderInjection> getHeaderInjection() {
        if (headerInjection == null) {
            headerInjection = new ArrayList<DmHeaderInjection>();
        }
        return this.headerInjection;
    }

    /**
     * Gets the value of the headerSuppression property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerSuppression property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderSuppression().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmHeaderSuppression }
     * 
     * 
     */
    public List<DmHeaderSuppression> getHeaderSuppression() {
        if (headerSuppression == null) {
            headerSuppression = new ArrayList<DmHeaderSuppression>();
        }
        return this.headerSuppression;
    }

    /**
     * Gets the value of the stylesheetParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stylesheetParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStylesheetParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmStylesheetParameter }
     * 
     * 
     */
    public List<DmStylesheetParameter> getStylesheetParameters() {
        if (stylesheetParameters == null) {
            stylesheetParameters = new ArrayList<DmStylesheetParameter>();
        }
        return this.stylesheetParameters;
    }

    /**
     * Gets the value of the defaultParamNamespace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultParamNamespace() {
        return defaultParamNamespace;
    }

    /**
     * Sets the value of the defaultParamNamespace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultParamNamespace(String value) {
        this.defaultParamNamespace = value;
    }

    /**
     * Gets the value of the queryParamNamespace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueryParamNamespace() {
        return queryParamNamespace;
    }

    /**
     * Sets the value of the queryParamNamespace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueryParamNamespace(String value) {
        this.queryParamNamespace = value;
    }

    /**
     * Gets the value of the backendUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackendUrl() {
        return backendUrl;
    }

    /**
     * Sets the value of the backendUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackendUrl(String value) {
        this.backendUrl = value;
    }

    /**
     * Gets the value of the propagateURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPropagateURI() {
        return propagateURI;
    }

    /**
     * Sets the value of the propagateURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPropagateURI(String value) {
        this.propagateURI = value;
    }

    /**
     * Gets the value of the serviceMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the serviceMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getServiceMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getServiceMonitors() {
        if (serviceMonitors == null) {
            serviceMonitors = new ArrayList<DmReference>();
        }
        return this.serviceMonitors;
    }

    /**
     * Gets the value of the countMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the countMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCountMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getCountMonitors() {
        if (countMonitors == null) {
            countMonitors = new ArrayList<DmReference>();
        }
        return this.countMonitors;
    }

    /**
     * Gets the value of the durationMonitors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the durationMonitors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDurationMonitors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getDurationMonitors() {
        if (durationMonitors == null) {
            durationMonitors = new ArrayList<DmReference>();
        }
        return this.durationMonitors;
    }

    /**
     * Gets the value of the monitorProcessingPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonitorProcessingPolicy() {
        return monitorProcessingPolicy;
    }

    /**
     * Sets the value of the monitorProcessingPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonitorProcessingPolicy(String value) {
        this.monitorProcessingPolicy = value;
    }

    /**
     * Gets the value of the requestAttachments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestAttachments() {
        return requestAttachments;
    }

    /**
     * Sets the value of the requestAttachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestAttachments(String value) {
        this.requestAttachments = value;
    }

    /**
     * Gets the value of the responseAttachments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseAttachments() {
        return responseAttachments;
    }

    /**
     * Sets the value of the responseAttachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseAttachments(String value) {
        this.responseAttachments = value;
    }

    /**
     * Gets the value of the requestAttachmentsFlowControl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestAttachmentsFlowControl() {
        return requestAttachmentsFlowControl;
    }

    /**
     * Sets the value of the requestAttachmentsFlowControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestAttachmentsFlowControl(String value) {
        this.requestAttachmentsFlowControl = value;
    }

    /**
     * Gets the value of the responseAttachmentsFlowControl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseAttachmentsFlowControl() {
        return responseAttachmentsFlowControl;
    }

    /**
     * Sets the value of the responseAttachmentsFlowControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseAttachmentsFlowControl(String value) {
        this.responseAttachmentsFlowControl = value;
    }

    /**
     * Gets the value of the rootPartNotFirstAction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRootPartNotFirstAction() {
        return rootPartNotFirstAction;
    }

    /**
     * Sets the value of the rootPartNotFirstAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRootPartNotFirstAction(String value) {
        this.rootPartNotFirstAction = value;
    }

    /**
     * Gets the value of the frontAttachmentFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontAttachmentFormat() {
        return frontAttachmentFormat;
    }

    /**
     * Sets the value of the frontAttachmentFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontAttachmentFormat(String value) {
        this.frontAttachmentFormat = value;
    }

    /**
     * Gets the value of the backAttachmentFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackAttachmentFormat() {
        return backAttachmentFormat;
    }

    /**
     * Sets the value of the backAttachmentFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackAttachmentFormat(String value) {
        this.backAttachmentFormat = value;
    }

    /**
     * Gets the value of the mimeFrontHeaders property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIMEFrontHeaders() {
        return mimeFrontHeaders;
    }

    /**
     * Sets the value of the mimeFrontHeaders property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIMEFrontHeaders(String value) {
        this.mimeFrontHeaders = value;
    }

    /**
     * Gets the value of the mimeBackHeaders property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIMEBackHeaders() {
        return mimeBackHeaders;
    }

    /**
     * Sets the value of the mimeBackHeaders property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIMEBackHeaders(String value) {
        this.mimeBackHeaders = value;
    }

    /**
     * Gets the value of the streamOutputToBack property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreamOutputToBack() {
        return streamOutputToBack;
    }

    /**
     * Sets the value of the streamOutputToBack property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreamOutputToBack(String value) {
        this.streamOutputToBack = value;
    }

    /**
     * Gets the value of the streamOutputToFront property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreamOutputToFront() {
        return streamOutputToFront;
    }

    /**
     * Sets the value of the streamOutputToFront property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreamOutputToFront(String value) {
        this.streamOutputToFront = value;
    }

    /**
     * Gets the value of the maxMessageSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxMessageSize() {
        return maxMessageSize;
    }

    /**
     * Sets the value of the maxMessageSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxMessageSize(String value) {
        this.maxMessageSize = value;
    }

    /**
     * Gets the value of the gatewayParserLimits property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayParserLimits() {
        return gatewayParserLimits;
    }

    /**
     * Sets the value of the gatewayParserLimits property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayParserLimits(String value) {
        this.gatewayParserLimits = value;
    }

    /**
     * Gets the value of the parserLimitsElementDepth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsElementDepth() {
        return parserLimitsElementDepth;
    }

    /**
     * Sets the value of the parserLimitsElementDepth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsElementDepth(String value) {
        this.parserLimitsElementDepth = value;
    }

    /**
     * Gets the value of the parserLimitsAttributeCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsAttributeCount() {
        return parserLimitsAttributeCount;
    }

    /**
     * Sets the value of the parserLimitsAttributeCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsAttributeCount(String value) {
        this.parserLimitsAttributeCount = value;
    }

    /**
     * Gets the value of the parserLimitsMaxNodeSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsMaxNodeSize() {
        return parserLimitsMaxNodeSize;
    }

    /**
     * Sets the value of the parserLimitsMaxNodeSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsMaxNodeSize(String value) {
        this.parserLimitsMaxNodeSize = value;
    }

    /**
     * Gets the value of the parserLimitsForbidExternalReferences property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsForbidExternalReferences() {
        return parserLimitsForbidExternalReferences;
    }

    /**
     * Sets the value of the parserLimitsForbidExternalReferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsForbidExternalReferences(String value) {
        this.parserLimitsForbidExternalReferences = value;
    }

    /**
     * Gets the value of the parserLimitsExternalReferences property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsExternalReferences() {
        return parserLimitsExternalReferences;
    }

    /**
     * Sets the value of the parserLimitsExternalReferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsExternalReferences(String value) {
        this.parserLimitsExternalReferences = value;
    }

    /**
     * Gets the value of the parserLimitsMaxPrefixes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsMaxPrefixes() {
        return parserLimitsMaxPrefixes;
    }

    /**
     * Sets the value of the parserLimitsMaxPrefixes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsMaxPrefixes(String value) {
        this.parserLimitsMaxPrefixes = value;
    }

    /**
     * Gets the value of the parserLimitsMaxNamespaces property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsMaxNamespaces() {
        return parserLimitsMaxNamespaces;
    }

    /**
     * Sets the value of the parserLimitsMaxNamespaces property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsMaxNamespaces(String value) {
        this.parserLimitsMaxNamespaces = value;
    }

    /**
     * Gets the value of the parserLimitsMaxLocalNames property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsMaxLocalNames() {
        return parserLimitsMaxLocalNames;
    }

    /**
     * Sets the value of the parserLimitsMaxLocalNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsMaxLocalNames(String value) {
        this.parserLimitsMaxLocalNames = value;
    }

    /**
     * Gets the value of the parserLimitsAttachmentByteCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsAttachmentByteCount() {
        return parserLimitsAttachmentByteCount;
    }

    /**
     * Sets the value of the parserLimitsAttachmentByteCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsAttachmentByteCount(String value) {
        this.parserLimitsAttachmentByteCount = value;
    }

    /**
     * Gets the value of the parserLimitsAttachmentPackageByteCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParserLimitsAttachmentPackageByteCount() {
        return parserLimitsAttachmentPackageByteCount;
    }

    /**
     * Sets the value of the parserLimitsAttachmentPackageByteCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParserLimitsAttachmentPackageByteCount(String value) {
        this.parserLimitsAttachmentPackageByteCount = value;
    }

    /**
     * Gets the value of the debugMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugMode() {
        return debugMode;
    }

    /**
     * Sets the value of the debugMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugMode(String value) {
        this.debugMode = value;
    }

    /**
     * Gets the value of the debugHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebugHistory() {
        return debugHistory;
    }

    /**
     * Sets the value of the debugHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebugHistory(String value) {
        this.debugHistory = value;
    }

    /**
     * Gets the value of the debugTrigger property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the debugTrigger property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDebugTrigger().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmMSDebugTriggerType }
     * 
     * 
     */
    public List<DmMSDebugTriggerType> getDebugTrigger() {
        if (debugTrigger == null) {
            debugTrigger = new ArrayList<DmMSDebugTriggerType>();
        }
        return this.debugTrigger;
    }

    /**
     * Gets the value of the flowControl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlowControl() {
        return flowControl;
    }

    /**
     * Sets the value of the flowControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlowControl(String value) {
        this.flowControl = value;
    }

    /**
     * Gets the value of the soapSchemaURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOAPSchemaURL() {
        return soapSchemaURL;
    }

    /**
     * Sets the value of the soapSchemaURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOAPSchemaURL(String value) {
        this.soapSchemaURL = value;
    }

    /**
     * Gets the value of the frontTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontTimeout() {
        return frontTimeout;
    }

    /**
     * Sets the value of the frontTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontTimeout(String value) {
        this.frontTimeout = value;
    }

    /**
     * Gets the value of the backTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackTimeout() {
        return backTimeout;
    }

    /**
     * Sets the value of the backTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackTimeout(String value) {
        this.backTimeout = value;
    }

    /**
     * Gets the value of the frontPersistentTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontPersistentTimeout() {
        return frontPersistentTimeout;
    }

    /**
     * Sets the value of the frontPersistentTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontPersistentTimeout(String value) {
        this.frontPersistentTimeout = value;
    }

    /**
     * Gets the value of the backPersistentTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackPersistentTimeout() {
        return backPersistentTimeout;
    }

    /**
     * Sets the value of the backPersistentTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackPersistentTimeout(String value) {
        this.backPersistentTimeout = value;
    }

    /**
     * Gets the value of the includeResponseTypeEncoding property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncludeResponseTypeEncoding() {
        return includeResponseTypeEncoding;
    }

    /**
     * Sets the value of the includeResponseTypeEncoding property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncludeResponseTypeEncoding(String value) {
        this.includeResponseTypeEncoding = value;
    }

    /**
     * Gets the value of the backHTTPVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackHTTPVersion() {
        return backHTTPVersion;
    }

    /**
     * Sets the value of the backHTTPVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackHTTPVersion(String value) {
        this.backHTTPVersion = value;
    }

    /**
     * Gets the value of the persistentConnections property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersistentConnections() {
        return persistentConnections;
    }

    /**
     * Sets the value of the persistentConnections property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersistentConnections(String value) {
        this.persistentConnections = value;
    }

    /**
     * Gets the value of the loopDetection property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoopDetection() {
        return loopDetection;
    }

    /**
     * Sets the value of the loopDetection property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoopDetection(String value) {
        this.loopDetection = value;
    }

    /**
     * Gets the value of the doHostRewriting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoHostRewriting() {
        return doHostRewriting;
    }

    /**
     * Sets the value of the doHostRewriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoHostRewriting(String value) {
        this.doHostRewriting = value;
    }

    /**
     * Gets the value of the doChunkedUpload property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoChunkedUpload() {
        return doChunkedUpload;
    }

    /**
     * Sets the value of the doChunkedUpload property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoChunkedUpload(String value) {
        this.doChunkedUpload = value;
    }

    /**
     * Gets the value of the processHTTPErrors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessHTTPErrors() {
        return processHTTPErrors;
    }

    /**
     * Sets the value of the processHTTPErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessHTTPErrors(String value) {
        this.processHTTPErrors = value;
    }

    /**
     * Gets the value of the httpClientIPLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPClientIPLabel() {
        return httpClientIPLabel;
    }

    /**
     * Sets the value of the httpClientIPLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPClientIPLabel(String value) {
        this.httpClientIPLabel = value;
    }

    /**
     * Gets the value of the httpLogCorIDLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHTTPLogCorIDLabel() {
        return httpLogCorIDLabel;
    }

    /**
     * Sets the value of the httpLogCorIDLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHTTPLogCorIDLabel(String value) {
        this.httpLogCorIDLabel = value;
    }

    /**
     * Gets the value of the loadBalancerHashHeader property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoadBalancerHashHeader() {
        return loadBalancerHashHeader;
    }

    /**
     * Sets the value of the loadBalancerHashHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoadBalancerHashHeader(String value) {
        this.loadBalancerHashHeader = value;
    }

    /**
     * Gets the value of the inOrderMode property.
     * 
     * @return
     *     possible object is
     *     {@link DmGatewayInOrderMode }
     *     
     */
    public DmGatewayInOrderMode getInOrderMode() {
        return inOrderMode;
    }

    /**
     * Sets the value of the inOrderMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmGatewayInOrderMode }
     *     
     */
    public void setInOrderMode(DmGatewayInOrderMode value) {
        this.inOrderMode = value;
    }

    /**
     * Gets the value of the wsaMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSAMode() {
        return wsaMode;
    }

    /**
     * Sets the value of the wsaMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSAMode(String value) {
        this.wsaMode = value;
    }

    /**
     * Gets the value of the wsaRequireAAA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSARequireAAA() {
        return wsaRequireAAA;
    }

    /**
     * Sets the value of the wsaRequireAAA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSARequireAAA(String value) {
        this.wsaRequireAAA = value;
    }

    /**
     * Gets the value of the wsaRewriteReplyTo property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSARewriteReplyTo() {
        return wsaRewriteReplyTo;
    }

    /**
     * Sets the value of the wsaRewriteReplyTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSARewriteReplyTo(DmReference value) {
        this.wsaRewriteReplyTo = value;
    }

    /**
     * Gets the value of the wsaRewriteFaultTo property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSARewriteFaultTo() {
        return wsaRewriteFaultTo;
    }

    /**
     * Sets the value of the wsaRewriteFaultTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSARewriteFaultTo(DmReference value) {
        this.wsaRewriteFaultTo = value;
    }

    /**
     * Gets the value of the wsaRewriteTo property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSARewriteTo() {
        return wsaRewriteTo;
    }

    /**
     * Sets the value of the wsaRewriteTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSARewriteTo(DmReference value) {
        this.wsaRewriteTo = value;
    }

    /**
     * Gets the value of the wsaStrip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSAStrip() {
        return wsaStrip;
    }

    /**
     * Sets the value of the wsaStrip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSAStrip(String value) {
        this.wsaStrip = value;
    }

    /**
     * Gets the value of the wsaDefaultReplyTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSADefaultReplyTo() {
        return wsaDefaultReplyTo;
    }

    /**
     * Sets the value of the wsaDefaultReplyTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSADefaultReplyTo(String value) {
        this.wsaDefaultReplyTo = value;
    }

    /**
     * Gets the value of the wsaDefaultFaultTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSADefaultFaultTo() {
        return wsaDefaultFaultTo;
    }

    /**
     * Sets the value of the wsaDefaultFaultTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSADefaultFaultTo(String value) {
        this.wsaDefaultFaultTo = value;
    }

    /**
     * Gets the value of the wsaForce property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSAForce() {
        return wsaForce;
    }

    /**
     * Sets the value of the wsaForce property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSAForce(String value) {
        this.wsaForce = value;
    }

    /**
     * Gets the value of the wsaGenStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSAGenStyle() {
        return wsaGenStyle;
    }

    /**
     * Sets the value of the wsaGenStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSAGenStyle(String value) {
        this.wsaGenStyle = value;
    }

    /**
     * Gets the value of the wsahttpAsyncResponseCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSAHTTPAsyncResponseCode() {
        return wsahttpAsyncResponseCode;
    }

    /**
     * Sets the value of the wsahttpAsyncResponseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSAHTTPAsyncResponseCode(String value) {
        this.wsahttpAsyncResponseCode = value;
    }

    /**
     * Gets the value of the wsaBackProtocol property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSABackProtocol() {
        return wsaBackProtocol;
    }

    /**
     * Sets the value of the wsaBackProtocol property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSABackProtocol(DmReference value) {
        this.wsaBackProtocol = value;
    }

    /**
     * Gets the value of the wsaTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSATimeout() {
        return wsaTimeout;
    }

    /**
     * Sets the value of the wsaTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSATimeout(String value) {
        this.wsaTimeout = value;
    }

    /**
     * Gets the value of the wsrmEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMEnabled() {
        return wsrmEnabled;
    }

    /**
     * Sets the value of the wsrmEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMEnabled(String value) {
        this.wsrmEnabled = value;
    }

    /**
     * Gets the value of the wsrmSequenceExpiration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSequenceExpiration() {
        return wsrmSequenceExpiration;
    }

    /**
     * Sets the value of the wsrmSequenceExpiration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSequenceExpiration(String value) {
        this.wsrmSequenceExpiration = value;
    }

    /**
     * Gets the value of the wsrmaaaPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSRMAAAPolicy() {
        return wsrmaaaPolicy;
    }

    /**
     * Sets the value of the wsrmaaaPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSRMAAAPolicy(DmReference value) {
        this.wsrmaaaPolicy = value;
    }

    /**
     * Gets the value of the wsrmDestinationAcceptCreateSequence property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMDestinationAcceptCreateSequence() {
        return wsrmDestinationAcceptCreateSequence;
    }

    /**
     * Sets the value of the wsrmDestinationAcceptCreateSequence property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMDestinationAcceptCreateSequence(String value) {
        this.wsrmDestinationAcceptCreateSequence = value;
    }

    /**
     * Gets the value of the wsrmDestinationMaximumSequences property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMDestinationMaximumSequences() {
        return wsrmDestinationMaximumSequences;
    }

    /**
     * Sets the value of the wsrmDestinationMaximumSequences property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMDestinationMaximumSequences(String value) {
        this.wsrmDestinationMaximumSequences = value;
    }

    /**
     * Gets the value of the wsrmDestinationInOrder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMDestinationInOrder() {
        return wsrmDestinationInOrder;
    }

    /**
     * Sets the value of the wsrmDestinationInOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMDestinationInOrder(String value) {
        this.wsrmDestinationInOrder = value;
    }

    /**
     * Gets the value of the wsrmDestinationMaximumInOrderQueueLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMDestinationMaximumInOrderQueueLength() {
        return wsrmDestinationMaximumInOrderQueueLength;
    }

    /**
     * Sets the value of the wsrmDestinationMaximumInOrderQueueLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMDestinationMaximumInOrderQueueLength(String value) {
        this.wsrmDestinationMaximumInOrderQueueLength = value;
    }

    /**
     * Gets the value of the wsrmDestinationAcceptOffers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMDestinationAcceptOffers() {
        return wsrmDestinationAcceptOffers;
    }

    /**
     * Sets the value of the wsrmDestinationAcceptOffers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMDestinationAcceptOffers(String value) {
        this.wsrmDestinationAcceptOffers = value;
    }

    /**
     * Gets the value of the wsrmFrontForce property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMFrontForce() {
        return wsrmFrontForce;
    }

    /**
     * Sets the value of the wsrmFrontForce property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMFrontForce(String value) {
        this.wsrmFrontForce = value;
    }

    /**
     * Gets the value of the wsrmBackForce property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMBackForce() {
        return wsrmBackForce;
    }

    /**
     * Sets the value of the wsrmBackForce property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMBackForce(String value) {
        this.wsrmBackForce = value;
    }

    /**
     * Gets the value of the wsrmBackCreateSequence property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMBackCreateSequence() {
        return wsrmBackCreateSequence;
    }

    /**
     * Sets the value of the wsrmBackCreateSequence property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMBackCreateSequence(String value) {
        this.wsrmBackCreateSequence = value;
    }

    /**
     * Gets the value of the wsrmFrontCreateSequence property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMFrontCreateSequence() {
        return wsrmFrontCreateSequence;
    }

    /**
     * Sets the value of the wsrmFrontCreateSequence property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMFrontCreateSequence(String value) {
        this.wsrmFrontCreateSequence = value;
    }

    /**
     * Gets the value of the wsrmSourceMakeOffer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceMakeOffer() {
        return wsrmSourceMakeOffer;
    }

    /**
     * Sets the value of the wsrmSourceMakeOffer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceMakeOffer(String value) {
        this.wsrmSourceMakeOffer = value;
    }

    /**
     * Gets the value of the wsrmUsesSequenceSSL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMUsesSequenceSSL() {
        return wsrmUsesSequenceSSL;
    }

    /**
     * Sets the value of the wsrmUsesSequenceSSL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMUsesSequenceSSL(String value) {
        this.wsrmUsesSequenceSSL = value;
    }

    /**
     * Gets the value of the wsrmFrontAcksTo property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSRMFrontAcksTo() {
        return wsrmFrontAcksTo;
    }

    /**
     * Sets the value of the wsrmFrontAcksTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSRMFrontAcksTo(DmReference value) {
        this.wsrmFrontAcksTo = value;
    }

    /**
     * Gets the value of the wsrmBackAcksTo property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getWSRMBackAcksTo() {
        return wsrmBackAcksTo;
    }

    /**
     * Sets the value of the wsrmBackAcksTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setWSRMBackAcksTo(DmReference value) {
        this.wsrmBackAcksTo = value;
    }

    /**
     * Gets the value of the wsrmSourceMaximumSequences property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceMaximumSequences() {
        return wsrmSourceMaximumSequences;
    }

    /**
     * Sets the value of the wsrmSourceMaximumSequences property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceMaximumSequences(String value) {
        this.wsrmSourceMaximumSequences = value;
    }

    /**
     * Gets the value of the wsrmSourceRetransmissionInterval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceRetransmissionInterval() {
        return wsrmSourceRetransmissionInterval;
    }

    /**
     * Sets the value of the wsrmSourceRetransmissionInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceRetransmissionInterval(String value) {
        this.wsrmSourceRetransmissionInterval = value;
    }

    /**
     * Gets the value of the wsrmSourceExponentialBackoff property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceExponentialBackoff() {
        return wsrmSourceExponentialBackoff;
    }

    /**
     * Sets the value of the wsrmSourceExponentialBackoff property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceExponentialBackoff(String value) {
        this.wsrmSourceExponentialBackoff = value;
    }

    /**
     * Gets the value of the wsrmSourceMaximumRetransmissions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceMaximumRetransmissions() {
        return wsrmSourceMaximumRetransmissions;
    }

    /**
     * Sets the value of the wsrmSourceMaximumRetransmissions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceMaximumRetransmissions(String value) {
        this.wsrmSourceMaximumRetransmissions = value;
    }

    /**
     * Gets the value of the wsrmSourceMaximumQueueLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceMaximumQueueLength() {
        return wsrmSourceMaximumQueueLength;
    }

    /**
     * Sets the value of the wsrmSourceMaximumQueueLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceMaximumQueueLength(String value) {
        this.wsrmSourceMaximumQueueLength = value;
    }

    /**
     * Gets the value of the wsrmSourceRequestAckCount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceRequestAckCount() {
        return wsrmSourceRequestAckCount;
    }

    /**
     * Sets the value of the wsrmSourceRequestAckCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceRequestAckCount(String value) {
        this.wsrmSourceRequestAckCount = value;
    }

    /**
     * Gets the value of the wsrmSourceInactivityClose property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRMSourceInactivityClose() {
        return wsrmSourceInactivityClose;
    }

    /**
     * Sets the value of the wsrmSourceInactivityClose property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRMSourceInactivityClose(String value) {
        this.wsrmSourceInactivityClose = value;
    }

    /**
     * Gets the value of the forcePolicyExec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForcePolicyExec() {
        return forcePolicyExec;
    }

    /**
     * Sets the value of the forcePolicyExec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForcePolicyExec(String value) {
        this.forcePolicyExec = value;
    }

    /**
     * Gets the value of the rewriteErrors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRewriteErrors() {
        return rewriteErrors;
    }

    /**
     * Sets the value of the rewriteErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRewriteErrors(String value) {
        this.rewriteErrors = value;
    }

    /**
     * Gets the value of the delayErrors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayErrors() {
        return delayErrors;
    }

    /**
     * Sets the value of the delayErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayErrors(String value) {
        this.delayErrors = value;
    }

    /**
     * Gets the value of the delayErrorsDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayErrorsDuration() {
        return delayErrorsDuration;
    }

    /**
     * Sets the value of the delayErrorsDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayErrorsDuration(String value) {
        this.delayErrorsDuration = value;
    }

}
