
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSSLClientProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSSLClientProfile"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigCrypto"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Protocols" type="{http://www.datapower.com/schemas/management}dmSSLProtoVersionsBitmap" minOccurs="0"/&gt;
 *         &lt;element name="Ciphers" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSSLCipherSuite {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Idcred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ValidateServerCert" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Valcred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="Caching" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CacheTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CacheSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLClientFeatures" type="{http://www.datapower.com/schemas/management}dmSSLClientFeatures" minOccurs="0"/&gt;
 *         &lt;element name="EllipticCurves" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTLSEllipticCurves {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseCustomSNIHostname" type="{http://www.datapower.com/schemas/management}dmUseCustomSNIHostname" minOccurs="0"/&gt;
 *         &lt;element name="CustomSNIHostname" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSSLClientProfile", propOrder = {
    "userSummary",
    "protocols",
    "ciphers",
    "idcred",
    "validateServerCert",
    "valcred",
    "caching",
    "cacheTimeout",
    "cacheSize",
    "sslClientFeatures",
    "ellipticCurves",
    "useCustomSNIHostname",
    "customSNIHostname"
})
public class ConfigSSLClientProfile
    extends ConfigCrypto
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Protocols")
    protected DmSSLProtoVersionsBitmap protocols;
    @XmlElement(name = "Ciphers")
    protected List<String> ciphers;
    @XmlElement(name = "Idcred")
    protected DmReference idcred;
    @XmlElement(name = "ValidateServerCert")
    protected String validateServerCert;
    @XmlElement(name = "Valcred")
    protected DmReference valcred;
    @XmlElement(name = "Caching")
    protected String caching;
    @XmlElement(name = "CacheTimeout")
    protected String cacheTimeout;
    @XmlElement(name = "CacheSize")
    protected String cacheSize;
    @XmlElement(name = "SSLClientFeatures")
    protected DmSSLClientFeatures sslClientFeatures;
    @XmlElement(name = "EllipticCurves")
    protected List<String> ellipticCurves;
    @XmlElement(name = "UseCustomSNIHostname")
    @XmlSchemaType(name = "string")
    protected DmUseCustomSNIHostname useCustomSNIHostname;
    @XmlElement(name = "CustomSNIHostname")
    protected String customSNIHostname;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the protocols property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLProtoVersionsBitmap }
     *     
     */
    public DmSSLProtoVersionsBitmap getProtocols() {
        return protocols;
    }

    /**
     * Sets the value of the protocols property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLProtoVersionsBitmap }
     *     
     */
    public void setProtocols(DmSSLProtoVersionsBitmap value) {
        this.protocols = value;
    }

    /**
     * Gets the value of the ciphers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ciphers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCiphers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCiphers() {
        if (ciphers == null) {
            ciphers = new ArrayList<String>();
        }
        return this.ciphers;
    }

    /**
     * Gets the value of the idcred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getIdcred() {
        return idcred;
    }

    /**
     * Sets the value of the idcred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setIdcred(DmReference value) {
        this.idcred = value;
    }

    /**
     * Gets the value of the validateServerCert property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidateServerCert() {
        return validateServerCert;
    }

    /**
     * Sets the value of the validateServerCert property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidateServerCert(String value) {
        this.validateServerCert = value;
    }

    /**
     * Gets the value of the valcred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getValcred() {
        return valcred;
    }

    /**
     * Sets the value of the valcred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setValcred(DmReference value) {
        this.valcred = value;
    }

    /**
     * Gets the value of the caching property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaching() {
        return caching;
    }

    /**
     * Sets the value of the caching property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaching(String value) {
        this.caching = value;
    }

    /**
     * Gets the value of the cacheTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheTimeout() {
        return cacheTimeout;
    }

    /**
     * Sets the value of the cacheTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheTimeout(String value) {
        this.cacheTimeout = value;
    }

    /**
     * Gets the value of the cacheSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheSize() {
        return cacheSize;
    }

    /**
     * Sets the value of the cacheSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheSize(String value) {
        this.cacheSize = value;
    }

    /**
     * Gets the value of the sslClientFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientFeatures }
     *     
     */
    public DmSSLClientFeatures getSSLClientFeatures() {
        return sslClientFeatures;
    }

    /**
     * Sets the value of the sslClientFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientFeatures }
     *     
     */
    public void setSSLClientFeatures(DmSSLClientFeatures value) {
        this.sslClientFeatures = value;
    }

    /**
     * Gets the value of the ellipticCurves property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ellipticCurves property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEllipticCurves().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEllipticCurves() {
        if (ellipticCurves == null) {
            ellipticCurves = new ArrayList<String>();
        }
        return this.ellipticCurves;
    }

    /**
     * Gets the value of the useCustomSNIHostname property.
     * 
     * @return
     *     possible object is
     *     {@link DmUseCustomSNIHostname }
     *     
     */
    public DmUseCustomSNIHostname getUseCustomSNIHostname() {
        return useCustomSNIHostname;
    }

    /**
     * Sets the value of the useCustomSNIHostname property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmUseCustomSNIHostname }
     *     
     */
    public void setUseCustomSNIHostname(DmUseCustomSNIHostname value) {
        this.useCustomSNIHostname = value;
    }

    /**
     * Gets the value of the customSNIHostname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomSNIHostname() {
        return customSNIHostname;
    }

    /**
     * Sets the value of the customSNIHostname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomSNIHostname(String value) {
        this.customSNIHostname = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
