
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigOAuthSupportedClient complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigOAuthSupportedClient"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigCrypto"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Customized" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CustomizedProcessUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OAuthRole" type="{http://www.datapower.com/schemas/management}dmOAuthRole" minOccurs="0"/&gt;
 *         &lt;element name="AZGrant" type="{http://www.datapower.com/schemas/management}dmOAuthAZGrantType" minOccurs="0"/&gt;
 *         &lt;element name="ClientType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmOAuthClientType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CheckClientCredential" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseValidationUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientAuthenMethod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmOAuthClientAuthenMethod {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientValCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="GenerateClientSecret" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClientSecret" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Caching" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmOAuthCache {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ValidationURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ValidationURLSSLProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ValidationFeatures" type="{http://www.datapower.com/schemas/management}dmValidationFeatures" minOccurs="0"/&gt;
 *         &lt;element name="RedirectURI" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CustomScopeCheck" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Scope" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ScopeUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DefaultScope" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TokenSecret" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="LocalAZPageUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DPStateLifeTime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AUCodeLifeTime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AccessTokenLifeTime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RefreshTokenAllowed" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RefreshTokenLifeTime" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CustomResourceOwner" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResourceOwnerUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AdditionalOAuthProcessUrl" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RSSetHeader" type="{http://www.datapower.com/schemas/management}dmOAuthRSSetHeader" minOccurs="0"/&gt;
 *         &lt;element name="ValidationURLSSLClientType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="ValidationURLSSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="JWTGrantValidator" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ClientJWTValidator" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="OIDCIDTokenGenerator" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="OAuthFeatures" type="{http://www.datapower.com/schemas/management}dmOAuthFeatures" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigOAuthSupportedClient", propOrder = {
    "userSummary",
    "customized",
    "customizedProcessUrl",
    "oAuthRole",
    "azGrant",
    "clientType",
    "checkClientCredential",
    "useValidationUrl",
    "clientAuthenMethod",
    "clientValCred",
    "generateClientSecret",
    "clientSecret",
    "caching",
    "validationURL",
    "validationURLSSLProfile",
    "validationFeatures",
    "redirectURI",
    "customScopeCheck",
    "scope",
    "scopeUrl",
    "defaultScope",
    "tokenSecret",
    "localAZPageUrl",
    "dpStateLifeTime",
    "auCodeLifeTime",
    "accessTokenLifeTime",
    "refreshTokenAllowed",
    "refreshTokenLifeTime",
    "customResourceOwner",
    "resourceOwnerUrl",
    "additionalOAuthProcessUrl",
    "rsSetHeader",
    "validationURLSSLClientType",
    "validationURLSSLClient",
    "jwtGrantValidator",
    "clientJWTValidator",
    "oidcidTokenGenerator",
    "oAuthFeatures"
})
public class ConfigOAuthSupportedClient
    extends ConfigCrypto
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Customized")
    protected String customized;
    @XmlElement(name = "CustomizedProcessUrl")
    protected String customizedProcessUrl;
    @XmlElement(name = "OAuthRole")
    protected DmOAuthRole oAuthRole;
    @XmlElement(name = "AZGrant")
    protected DmOAuthAZGrantType azGrant;
    @XmlElement(name = "ClientType")
    protected String clientType;
    @XmlElement(name = "CheckClientCredential")
    protected String checkClientCredential;
    @XmlElement(name = "UseValidationUrl")
    protected String useValidationUrl;
    @XmlElement(name = "ClientAuthenMethod")
    protected String clientAuthenMethod;
    @XmlElement(name = "ClientValCred")
    protected DmReference clientValCred;
    @XmlElement(name = "GenerateClientSecret")
    protected String generateClientSecret;
    @XmlElement(name = "ClientSecret")
    protected String clientSecret;
    @XmlElement(name = "Caching")
    protected String caching;
    @XmlElement(name = "ValidationURL")
    protected String validationURL;
    @XmlElement(name = "ValidationURLSSLProfile")
    protected DmReference validationURLSSLProfile;
    @XmlElement(name = "ValidationFeatures")
    protected DmValidationFeatures validationFeatures;
    @XmlElement(name = "RedirectURI")
    protected List<String> redirectURI;
    @XmlElement(name = "CustomScopeCheck")
    protected String customScopeCheck;
    @XmlElement(name = "Scope")
    protected String scope;
    @XmlElement(name = "ScopeUrl")
    protected String scopeUrl;
    @XmlElement(name = "DefaultScope")
    protected String defaultScope;
    @XmlElement(name = "TokenSecret")
    protected DmReference tokenSecret;
    @XmlElement(name = "LocalAZPageUrl")
    protected String localAZPageUrl;
    @XmlElement(name = "DPStateLifeTime")
    protected String dpStateLifeTime;
    @XmlElement(name = "AUCodeLifeTime")
    protected String auCodeLifeTime;
    @XmlElement(name = "AccessTokenLifeTime")
    protected String accessTokenLifeTime;
    @XmlElement(name = "RefreshTokenAllowed")
    protected String refreshTokenAllowed;
    @XmlElement(name = "RefreshTokenLifeTime")
    protected String refreshTokenLifeTime;
    @XmlElement(name = "CustomResourceOwner")
    protected String customResourceOwner;
    @XmlElement(name = "ResourceOwnerUrl")
    protected String resourceOwnerUrl;
    @XmlElement(name = "AdditionalOAuthProcessUrl")
    protected String additionalOAuthProcessUrl;
    @XmlElement(name = "RSSetHeader")
    protected DmOAuthRSSetHeader rsSetHeader;
    @XmlElement(name = "ValidationURLSSLClientType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType validationURLSSLClientType;
    @XmlElement(name = "ValidationURLSSLClient")
    protected DmReference validationURLSSLClient;
    @XmlElement(name = "JWTGrantValidator")
    protected DmReference jwtGrantValidator;
    @XmlElement(name = "ClientJWTValidator")
    protected DmReference clientJWTValidator;
    @XmlElement(name = "OIDCIDTokenGenerator")
    protected DmReference oidcidTokenGenerator;
    @XmlElement(name = "OAuthFeatures")
    protected DmOAuthFeatures oAuthFeatures;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the customized property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomized() {
        return customized;
    }

    /**
     * Sets the value of the customized property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomized(String value) {
        this.customized = value;
    }

    /**
     * Gets the value of the customizedProcessUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomizedProcessUrl() {
        return customizedProcessUrl;
    }

    /**
     * Sets the value of the customizedProcessUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomizedProcessUrl(String value) {
        this.customizedProcessUrl = value;
    }

    /**
     * Gets the value of the oAuthRole property.
     * 
     * @return
     *     possible object is
     *     {@link DmOAuthRole }
     *     
     */
    public DmOAuthRole getOAuthRole() {
        return oAuthRole;
    }

    /**
     * Sets the value of the oAuthRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmOAuthRole }
     *     
     */
    public void setOAuthRole(DmOAuthRole value) {
        this.oAuthRole = value;
    }

    /**
     * Gets the value of the azGrant property.
     * 
     * @return
     *     possible object is
     *     {@link DmOAuthAZGrantType }
     *     
     */
    public DmOAuthAZGrantType getAZGrant() {
        return azGrant;
    }

    /**
     * Sets the value of the azGrant property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmOAuthAZGrantType }
     *     
     */
    public void setAZGrant(DmOAuthAZGrantType value) {
        this.azGrant = value;
    }

    /**
     * Gets the value of the clientType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientType() {
        return clientType;
    }

    /**
     * Sets the value of the clientType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientType(String value) {
        this.clientType = value;
    }

    /**
     * Gets the value of the checkClientCredential property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckClientCredential() {
        return checkClientCredential;
    }

    /**
     * Sets the value of the checkClientCredential property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckClientCredential(String value) {
        this.checkClientCredential = value;
    }

    /**
     * Gets the value of the useValidationUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseValidationUrl() {
        return useValidationUrl;
    }

    /**
     * Sets the value of the useValidationUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseValidationUrl(String value) {
        this.useValidationUrl = value;
    }

    /**
     * Gets the value of the clientAuthenMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientAuthenMethod() {
        return clientAuthenMethod;
    }

    /**
     * Sets the value of the clientAuthenMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientAuthenMethod(String value) {
        this.clientAuthenMethod = value;
    }

    /**
     * Gets the value of the clientValCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getClientValCred() {
        return clientValCred;
    }

    /**
     * Sets the value of the clientValCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setClientValCred(DmReference value) {
        this.clientValCred = value;
    }

    /**
     * Gets the value of the generateClientSecret property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGenerateClientSecret() {
        return generateClientSecret;
    }

    /**
     * Sets the value of the generateClientSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGenerateClientSecret(String value) {
        this.generateClientSecret = value;
    }

    /**
     * Gets the value of the clientSecret property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientSecret() {
        return clientSecret;
    }

    /**
     * Sets the value of the clientSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientSecret(String value) {
        this.clientSecret = value;
    }

    /**
     * Gets the value of the caching property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaching() {
        return caching;
    }

    /**
     * Sets the value of the caching property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaching(String value) {
        this.caching = value;
    }

    /**
     * Gets the value of the validationURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationURL() {
        return validationURL;
    }

    /**
     * Sets the value of the validationURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationURL(String value) {
        this.validationURL = value;
    }

    /**
     * Gets the value of the validationURLSSLProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getValidationURLSSLProfile() {
        return validationURLSSLProfile;
    }

    /**
     * Sets the value of the validationURLSSLProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setValidationURLSSLProfile(DmReference value) {
        this.validationURLSSLProfile = value;
    }

    /**
     * Gets the value of the validationFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link DmValidationFeatures }
     *     
     */
    public DmValidationFeatures getValidationFeatures() {
        return validationFeatures;
    }

    /**
     * Sets the value of the validationFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmValidationFeatures }
     *     
     */
    public void setValidationFeatures(DmValidationFeatures value) {
        this.validationFeatures = value;
    }

    /**
     * Gets the value of the redirectURI property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the redirectURI property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRedirectURI().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRedirectURI() {
        if (redirectURI == null) {
            redirectURI = new ArrayList<String>();
        }
        return this.redirectURI;
    }

    /**
     * Gets the value of the customScopeCheck property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomScopeCheck() {
        return customScopeCheck;
    }

    /**
     * Sets the value of the customScopeCheck property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomScopeCheck(String value) {
        this.customScopeCheck = value;
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    /**
     * Gets the value of the scopeUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScopeUrl() {
        return scopeUrl;
    }

    /**
     * Sets the value of the scopeUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScopeUrl(String value) {
        this.scopeUrl = value;
    }

    /**
     * Gets the value of the defaultScope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultScope() {
        return defaultScope;
    }

    /**
     * Sets the value of the defaultScope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultScope(String value) {
        this.defaultScope = value;
    }

    /**
     * Gets the value of the tokenSecret property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getTokenSecret() {
        return tokenSecret;
    }

    /**
     * Sets the value of the tokenSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setTokenSecret(DmReference value) {
        this.tokenSecret = value;
    }

    /**
     * Gets the value of the localAZPageUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAZPageUrl() {
        return localAZPageUrl;
    }

    /**
     * Sets the value of the localAZPageUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAZPageUrl(String value) {
        this.localAZPageUrl = value;
    }

    /**
     * Gets the value of the dpStateLifeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDPStateLifeTime() {
        return dpStateLifeTime;
    }

    /**
     * Sets the value of the dpStateLifeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDPStateLifeTime(String value) {
        this.dpStateLifeTime = value;
    }

    /**
     * Gets the value of the auCodeLifeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUCodeLifeTime() {
        return auCodeLifeTime;
    }

    /**
     * Sets the value of the auCodeLifeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUCodeLifeTime(String value) {
        this.auCodeLifeTime = value;
    }

    /**
     * Gets the value of the accessTokenLifeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessTokenLifeTime() {
        return accessTokenLifeTime;
    }

    /**
     * Sets the value of the accessTokenLifeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessTokenLifeTime(String value) {
        this.accessTokenLifeTime = value;
    }

    /**
     * Gets the value of the refreshTokenAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefreshTokenAllowed() {
        return refreshTokenAllowed;
    }

    /**
     * Sets the value of the refreshTokenAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefreshTokenAllowed(String value) {
        this.refreshTokenAllowed = value;
    }

    /**
     * Gets the value of the refreshTokenLifeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefreshTokenLifeTime() {
        return refreshTokenLifeTime;
    }

    /**
     * Sets the value of the refreshTokenLifeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefreshTokenLifeTime(String value) {
        this.refreshTokenLifeTime = value;
    }

    /**
     * Gets the value of the customResourceOwner property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomResourceOwner() {
        return customResourceOwner;
    }

    /**
     * Sets the value of the customResourceOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomResourceOwner(String value) {
        this.customResourceOwner = value;
    }

    /**
     * Gets the value of the resourceOwnerUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResourceOwnerUrl() {
        return resourceOwnerUrl;
    }

    /**
     * Sets the value of the resourceOwnerUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResourceOwnerUrl(String value) {
        this.resourceOwnerUrl = value;
    }

    /**
     * Gets the value of the additionalOAuthProcessUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalOAuthProcessUrl() {
        return additionalOAuthProcessUrl;
    }

    /**
     * Sets the value of the additionalOAuthProcessUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalOAuthProcessUrl(String value) {
        this.additionalOAuthProcessUrl = value;
    }

    /**
     * Gets the value of the rsSetHeader property.
     * 
     * @return
     *     possible object is
     *     {@link DmOAuthRSSetHeader }
     *     
     */
    public DmOAuthRSSetHeader getRSSetHeader() {
        return rsSetHeader;
    }

    /**
     * Sets the value of the rsSetHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmOAuthRSSetHeader }
     *     
     */
    public void setRSSetHeader(DmOAuthRSSetHeader value) {
        this.rsSetHeader = value;
    }

    /**
     * Gets the value of the validationURLSSLClientType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getValidationURLSSLClientType() {
        return validationURLSSLClientType;
    }

    /**
     * Sets the value of the validationURLSSLClientType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setValidationURLSSLClientType(DmSSLClientConfigType value) {
        this.validationURLSSLClientType = value;
    }

    /**
     * Gets the value of the validationURLSSLClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getValidationURLSSLClient() {
        return validationURLSSLClient;
    }

    /**
     * Sets the value of the validationURLSSLClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setValidationURLSSLClient(DmReference value) {
        this.validationURLSSLClient = value;
    }

    /**
     * Gets the value of the jwtGrantValidator property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getJWTGrantValidator() {
        return jwtGrantValidator;
    }

    /**
     * Sets the value of the jwtGrantValidator property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setJWTGrantValidator(DmReference value) {
        this.jwtGrantValidator = value;
    }

    /**
     * Gets the value of the clientJWTValidator property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getClientJWTValidator() {
        return clientJWTValidator;
    }

    /**
     * Sets the value of the clientJWTValidator property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setClientJWTValidator(DmReference value) {
        this.clientJWTValidator = value;
    }

    /**
     * Gets the value of the oidcidTokenGenerator property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getOIDCIDTokenGenerator() {
        return oidcidTokenGenerator;
    }

    /**
     * Sets the value of the oidcidTokenGenerator property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setOIDCIDTokenGenerator(DmReference value) {
        this.oidcidTokenGenerator = value;
    }

    /**
     * Gets the value of the oAuthFeatures property.
     * 
     * @return
     *     possible object is
     *     {@link DmOAuthFeatures }
     *     
     */
    public DmOAuthFeatures getOAuthFeatures() {
        return oAuthFeatures;
    }

    /**
     * Sets the value of the oAuthFeatures property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmOAuthFeatures }
     *     
     */
    public void setOAuthFeatures(DmOAuthFeatures value) {
        this.oAuthFeatures = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
