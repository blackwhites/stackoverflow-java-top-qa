
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionB2BArchiveNow complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionB2BArchiveNow"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ArchiveIncomplete"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ArchiveAllGateways" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="B2BGatewayName" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ArchiveUnexpiredEBMS" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionB2BArchiveNow", propOrder = {
    "archiveIncomplete",
    "archiveAllGateways",
    "b2BGatewayName",
    "archiveUnexpiredEBMS"
})
public class ActionB2BArchiveNow {

    @XmlElement(name = "ArchiveIncomplete", required = true)
    protected String archiveIncomplete;
    @XmlElement(name = "ArchiveAllGateways")
    protected String archiveAllGateways;
    @XmlElement(name = "B2BGatewayName")
    protected DmReference b2BGatewayName;
    @XmlElement(name = "ArchiveUnexpiredEBMS")
    protected String archiveUnexpiredEBMS;

    /**
     * Gets the value of the archiveIncomplete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveIncomplete() {
        return archiveIncomplete;
    }

    /**
     * Sets the value of the archiveIncomplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveIncomplete(String value) {
        this.archiveIncomplete = value;
    }

    /**
     * Gets the value of the archiveAllGateways property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveAllGateways() {
        return archiveAllGateways;
    }

    /**
     * Sets the value of the archiveAllGateways property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveAllGateways(String value) {
        this.archiveAllGateways = value;
    }

    /**
     * Gets the value of the b2BGatewayName property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getB2BGatewayName() {
        return b2BGatewayName;
    }

    /**
     * Sets the value of the b2BGatewayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setB2BGatewayName(DmReference value) {
        this.b2BGatewayName = value;
    }

    /**
     * Gets the value of the archiveUnexpiredEBMS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArchiveUnexpiredEBMS() {
        return archiveUnexpiredEBMS;
    }

    /**
     * Sets the value of the archiveUnexpiredEBMS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArchiveUnexpiredEBMS(String value) {
        this.archiveUnexpiredEBMS = value;
    }

}
