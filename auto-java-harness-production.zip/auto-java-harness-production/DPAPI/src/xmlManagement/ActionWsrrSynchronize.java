
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionWsrrSynchronize complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionWsrrSynchronize"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="WSRRSubscription"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionWsrrSynchronize", propOrder = {
    "wsrrSubscription"
})
public class ActionWsrrSynchronize {

    @XmlElement(name = "WSRRSubscription", required = true)
    protected String wsrrSubscription;

    /**
     * Gets the value of the wsrrSubscription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWSRRSubscription() {
        return wsrrSubscription;
    }

    /**
     * Sets the value of the wsrrSubscription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWSRRSubscription(String value) {
        this.wsrrSubscription = value;
    }

}
