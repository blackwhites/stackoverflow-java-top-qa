
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnyModifyElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AnyModifyElement"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded"&gt;
 *         &lt;element name="AAAPolicy" type="{http://www.datapower.com/schemas/management}ModifyAAAPolicy"/&gt;
 *         &lt;element name="Domain" type="{http://www.datapower.com/schemas/management}ModifyDomain"/&gt;
 *         &lt;element name="LDAPSearchParameters" type="{http://www.datapower.com/schemas/management}ModifyLDAPSearchParameters"/&gt;
 *         &lt;element name="ProcessingMetadata" type="{http://www.datapower.com/schemas/management}ModifyProcessingMetadata"/&gt;
 *         &lt;element name="RADIUSSettings" type="{http://www.datapower.com/schemas/management}ModifyRADIUSSettings"/&gt;
 *         &lt;element name="RBMSettings" type="{http://www.datapower.com/schemas/management}ModifyRBMSettings"/&gt;
 *         &lt;element name="SAMLAttributes" type="{http://www.datapower.com/schemas/management}ModifySAMLAttributes"/&gt;
 *         &lt;element name="SOAPHeaderDisposition" type="{http://www.datapower.com/schemas/management}ModifySOAPHeaderDisposition"/&gt;
 *         &lt;element name="TAM" type="{http://www.datapower.com/schemas/management}ModifyTAM"/&gt;
 *         &lt;element name="TFIMEndpoint" type="{http://www.datapower.com/schemas/management}ModifyTFIMEndpoint"/&gt;
 *         &lt;element name="XACMLPDP" type="{http://www.datapower.com/schemas/management}ModifyXACMLPDP"/&gt;
 *         &lt;element name="AccessControlList" type="{http://www.datapower.com/schemas/management}ModifyAccessControlList"/&gt;
 *         &lt;element name="AppSecurityPolicy" type="{http://www.datapower.com/schemas/management}ModifyAppSecurityPolicy"/&gt;
 *         &lt;element name="AuditLog" type="{http://www.datapower.com/schemas/management}ModifyAuditLog"/&gt;
 *         &lt;element name="B2BCPA" type="{http://www.datapower.com/schemas/management}ModifyB2BCPA"/&gt;
 *         &lt;element name="B2BCPACollaboration" type="{http://www.datapower.com/schemas/management}ModifyB2BCPACollaboration"/&gt;
 *         &lt;element name="B2BCPAReceiverSetting" type="{http://www.datapower.com/schemas/management}ModifyB2BCPAReceiverSetting"/&gt;
 *         &lt;element name="B2BCPASenderSetting" type="{http://www.datapower.com/schemas/management}ModifyB2BCPASenderSetting"/&gt;
 *         &lt;element name="B2BGateway" type="{http://www.datapower.com/schemas/management}ModifyB2BGateway"/&gt;
 *         &lt;element name="B2BPersistence" type="{http://www.datapower.com/schemas/management}ModifyB2BPersistence"/&gt;
 *         &lt;element name="B2BProfile" type="{http://www.datapower.com/schemas/management}ModifyB2BProfile"/&gt;
 *         &lt;element name="B2BProfileGroup" type="{http://www.datapower.com/schemas/management}ModifyB2BProfileGroup"/&gt;
 *         &lt;element name="B2BXPathRoutingPolicy" type="{http://www.datapower.com/schemas/management}ModifyB2BXPathRoutingPolicy"/&gt;
 *         &lt;element name="WXSGrid" type="{http://www.datapower.com/schemas/management}ModifyWXSGrid"/&gt;
 *         &lt;element name="XC10Grid" type="{http://www.datapower.com/schemas/management}ModifyXC10Grid"/&gt;
 *         &lt;element name="CloudConnectorService" type="{http://www.datapower.com/schemas/management}ModifyCloudConnectorService"/&gt;
 *         &lt;element name="CloudGatewayService" type="{http://www.datapower.com/schemas/management}ModifyCloudGatewayService"/&gt;
 *         &lt;element name="CompactFlash" type="{http://www.datapower.com/schemas/management}ModifyCompactFlash"/&gt;
 *         &lt;element name="CompileOptionsPolicy" type="{http://www.datapower.com/schemas/management}ModifyCompileOptionsPolicy"/&gt;
 *         &lt;element name="ConfigDeploymentPolicy" type="{http://www.datapower.com/schemas/management}ModifyConfigDeploymentPolicy"/&gt;
 *         &lt;element name="ConformancePolicy" type="{http://www.datapower.com/schemas/management}ModifyConformancePolicy"/&gt;
 *         &lt;element name="AAAJWTGenerator" type="{http://www.datapower.com/schemas/management}ModifyAAAJWTGenerator"/&gt;
 *         &lt;element name="AAAJWTValidator" type="{http://www.datapower.com/schemas/management}ModifyAAAJWTValidator"/&gt;
 *         &lt;element name="CertMonitor" type="{http://www.datapower.com/schemas/management}ModifyCertMonitor"/&gt;
 *         &lt;element name="CookieAttributePolicy" type="{http://www.datapower.com/schemas/management}ModifyCookieAttributePolicy"/&gt;
 *         &lt;element name="CRLFetch" type="{http://www.datapower.com/schemas/management}ModifyCRLFetch"/&gt;
 *         &lt;element name="CryptoCertificate" type="{http://www.datapower.com/schemas/management}ModifyCryptoCertificate"/&gt;
 *         &lt;element name="CryptoFWCred" type="{http://www.datapower.com/schemas/management}ModifyCryptoFWCred"/&gt;
 *         &lt;element name="CryptoIdentCred" type="{http://www.datapower.com/schemas/management}ModifyCryptoIdentCred"/&gt;
 *         &lt;element name="CryptoKerberosKDC" type="{http://www.datapower.com/schemas/management}ModifyCryptoKerberosKDC"/&gt;
 *         &lt;element name="CryptoKerberosKeytab" type="{http://www.datapower.com/schemas/management}ModifyCryptoKerberosKeytab"/&gt;
 *         &lt;element name="CryptoKey" type="{http://www.datapower.com/schemas/management}ModifyCryptoKey"/&gt;
 *         &lt;element name="CryptoProfile" type="{http://www.datapower.com/schemas/management}ModifyCryptoProfile"/&gt;
 *         &lt;element name="CryptoSSKey" type="{http://www.datapower.com/schemas/management}ModifyCryptoSSKey"/&gt;
 *         &lt;element name="CryptoValCred" type="{http://www.datapower.com/schemas/management}ModifyCryptoValCred"/&gt;
 *         &lt;element name="JOSERecipientIdentifier" type="{http://www.datapower.com/schemas/management}ModifyJOSERecipientIdentifier"/&gt;
 *         &lt;element name="JOSESignatureIdentifier" type="{http://www.datapower.com/schemas/management}ModifyJOSESignatureIdentifier"/&gt;
 *         &lt;element name="JWEHeader" type="{http://www.datapower.com/schemas/management}ModifyJWEHeader"/&gt;
 *         &lt;element name="JWERecipient" type="{http://www.datapower.com/schemas/management}ModifyJWERecipient"/&gt;
 *         &lt;element name="JWSSignature" type="{http://www.datapower.com/schemas/management}ModifyJWSSignature"/&gt;
 *         &lt;element name="OAuthSupportedClient" type="{http://www.datapower.com/schemas/management}ModifyOAuthSupportedClient"/&gt;
 *         &lt;element name="OAuthSupportedClientGroup" type="{http://www.datapower.com/schemas/management}ModifyOAuthSupportedClientGroup"/&gt;
 *         &lt;element name="SocialLoginPolicy" type="{http://www.datapower.com/schemas/management}ModifySocialLoginPolicy"/&gt;
 *         &lt;element name="SSHClientProfile" type="{http://www.datapower.com/schemas/management}ModifySSHClientProfile"/&gt;
 *         &lt;element name="SSHDomainClientProfile" type="{http://www.datapower.com/schemas/management}ModifySSHDomainClientProfile"/&gt;
 *         &lt;element name="SSHServerProfile" type="{http://www.datapower.com/schemas/management}ModifySSHServerProfile"/&gt;
 *         &lt;element name="SSLClientProfile" type="{http://www.datapower.com/schemas/management}ModifySSLClientProfile"/&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}ModifySSLProxyProfile"/&gt;
 *         &lt;element name="SSLServerProfile" type="{http://www.datapower.com/schemas/management}ModifySSLServerProfile"/&gt;
 *         &lt;element name="SSLSNIMapping" type="{http://www.datapower.com/schemas/management}ModifySSLSNIMapping"/&gt;
 *         &lt;element name="SSLSNIServerProfile" type="{http://www.datapower.com/schemas/management}ModifySSLSNIServerProfile"/&gt;
 *         &lt;element name="DeploymentPolicyParametersBinding" type="{http://www.datapower.com/schemas/management}ModifyDeploymentPolicyParametersBinding"/&gt;
 *         &lt;element name="ErrorReportSettings" type="{http://www.datapower.com/schemas/management}ModifyErrorReportSettings"/&gt;
 *         &lt;element name="SystemSettings" type="{http://www.datapower.com/schemas/management}ModifySystemSettings"/&gt;
 *         &lt;element name="TimeSettings" type="{http://www.datapower.com/schemas/management}ModifyTimeSettings"/&gt;
 *         &lt;element name="DFDLSettings" type="{http://www.datapower.com/schemas/management}ModifyDFDLSettings"/&gt;
 *         &lt;element name="DomainAvailability" type="{http://www.datapower.com/schemas/management}ModifyDomainAvailability"/&gt;
 *         &lt;element name="DomainSettings" type="{http://www.datapower.com/schemas/management}ModifyDomainSettings"/&gt;
 *         &lt;element name="SchemaExceptionMap" type="{http://www.datapower.com/schemas/management}ModifySchemaExceptionMap"/&gt;
 *         &lt;element name="DocumentCryptoMap" type="{http://www.datapower.com/schemas/management}ModifyDocumentCryptoMap"/&gt;
 *         &lt;element name="XPathRoutingMap" type="{http://www.datapower.com/schemas/management}ModifyXPathRoutingMap"/&gt;
 *         &lt;element name="LogTarget" type="{http://www.datapower.com/schemas/management}ModifyLogTarget"/&gt;
 *         &lt;element name="FormsLoginPolicy" type="{http://www.datapower.com/schemas/management}ModifyFormsLoginPolicy"/&gt;
 *         &lt;element name="FTPQuoteCommands" type="{http://www.datapower.com/schemas/management}ModifyFTPQuoteCommands"/&gt;
 *         &lt;element name="MultiProtocolGateway" type="{http://www.datapower.com/schemas/management}ModifyMultiProtocolGateway"/&gt;
 *         &lt;element name="WSGateway" type="{http://www.datapower.com/schemas/management}ModifyWSGateway"/&gt;
 *         &lt;element name="GeneratedPolicy" type="{http://www.datapower.com/schemas/management}ModifyGeneratedPolicy"/&gt;
 *         &lt;element name="HTTPInputConversionMap" type="{http://www.datapower.com/schemas/management}ModifyHTTPInputConversionMap"/&gt;
 *         &lt;element name="HTTPUserAgent" type="{http://www.datapower.com/schemas/management}ModifyHTTPUserAgent"/&gt;
 *         &lt;element name="ILMTAgent" type="{http://www.datapower.com/schemas/management}ModifyILMTAgent"/&gt;
 *         &lt;element name="ImportPackage" type="{http://www.datapower.com/schemas/management}ModifyImportPackage"/&gt;
 *         &lt;element name="IMSConnect" type="{http://www.datapower.com/schemas/management}ModifyIMSConnect"/&gt;
 *         &lt;element name="IncludeConfig" type="{http://www.datapower.com/schemas/management}ModifyIncludeConfig"/&gt;
 *         &lt;element name="InteropService" type="{http://www.datapower.com/schemas/management}ModifyInteropService"/&gt;
 *         &lt;element name="EthernetInterface" type="{http://www.datapower.com/schemas/management}ModifyEthernetInterface"/&gt;
 *         &lt;element name="LinkAggregation" type="{http://www.datapower.com/schemas/management}ModifyLinkAggregation"/&gt;
 *         &lt;element name="VLANInterface" type="{http://www.datapower.com/schemas/management}ModifyVLANInterface"/&gt;
 *         &lt;element name="IPMILanChannel" type="{http://www.datapower.com/schemas/management}ModifyIPMILanChannel"/&gt;
 *         &lt;element name="IPMIUser" type="{http://www.datapower.com/schemas/management}ModifyIPMIUser"/&gt;
 *         &lt;element name="IPMulticast" type="{http://www.datapower.com/schemas/management}ModifyIPMulticast"/&gt;
 *         &lt;element name="ISAMReverseProxy" type="{http://www.datapower.com/schemas/management}ModifyISAMReverseProxy"/&gt;
 *         &lt;element name="ISAMReverseProxyJunction" type="{http://www.datapower.com/schemas/management}ModifyISAMReverseProxyJunction"/&gt;
 *         &lt;element name="ISAMRuntime" type="{http://www.datapower.com/schemas/management}ModifyISAMRuntime"/&gt;
 *         &lt;element name="IScsiChapConfig" type="{http://www.datapower.com/schemas/management}ModifyIScsiChapConfig"/&gt;
 *         &lt;element name="IScsiHBAConfig" type="{http://www.datapower.com/schemas/management}ModifyIScsiHBAConfig"/&gt;
 *         &lt;element name="IScsiInitiatorConfig" type="{http://www.datapower.com/schemas/management}ModifyIScsiInitiatorConfig"/&gt;
 *         &lt;element name="IScsiTargetConfig" type="{http://www.datapower.com/schemas/management}ModifyIScsiTargetConfig"/&gt;
 *         &lt;element name="IScsiVolumeConfig" type="{http://www.datapower.com/schemas/management}ModifyIScsiVolumeConfig"/&gt;
 *         &lt;element name="TibcoEMSServer" type="{http://www.datapower.com/schemas/management}ModifyTibcoEMSServer"/&gt;
 *         &lt;element name="WebSphereJMSServer" type="{http://www.datapower.com/schemas/management}ModifyWebSphereJMSServer"/&gt;
 *         &lt;element name="JSONSettings" type="{http://www.datapower.com/schemas/management}ModifyJSONSettings"/&gt;
 *         &lt;element name="Language" type="{http://www.datapower.com/schemas/management}ModifyLanguage"/&gt;
 *         &lt;element name="LDAPConnectionPool" type="{http://www.datapower.com/schemas/management}ModifyLDAPConnectionPool"/&gt;
 *         &lt;element name="LoadBalancerGroup" type="{http://www.datapower.com/schemas/management}ModifyLoadBalancerGroup"/&gt;
 *         &lt;element name="LogLabel" type="{http://www.datapower.com/schemas/management}ModifyLogLabel"/&gt;
 *         &lt;element name="Luna" type="{http://www.datapower.com/schemas/management}ModifyLuna"/&gt;
 *         &lt;element name="LunaPartition" type="{http://www.datapower.com/schemas/management}ModifyLunaPartition"/&gt;
 *         &lt;element name="Matching" type="{http://www.datapower.com/schemas/management}ModifyMatching"/&gt;
 *         &lt;element name="MCFCustomRule" type="{http://www.datapower.com/schemas/management}ModifyMCFCustomRule"/&gt;
 *         &lt;element name="MCFHttpHeader" type="{http://www.datapower.com/schemas/management}ModifyMCFHttpHeader"/&gt;
 *         &lt;element name="MCFHttpMethod" type="{http://www.datapower.com/schemas/management}ModifyMCFHttpMethod"/&gt;
 *         &lt;element name="MCFHttpURL" type="{http://www.datapower.com/schemas/management}ModifyMCFHttpURL"/&gt;
 *         &lt;element name="MCFXPath" type="{http://www.datapower.com/schemas/management}ModifyMCFXPath"/&gt;
 *         &lt;element name="MessageContentFilters" type="{http://www.datapower.com/schemas/management}ModifyMessageContentFilters"/&gt;
 *         &lt;element name="FilterAction" type="{http://www.datapower.com/schemas/management}ModifyFilterAction"/&gt;
 *         &lt;element name="MessageMatching" type="{http://www.datapower.com/schemas/management}ModifyMessageMatching"/&gt;
 *         &lt;element name="CountMonitor" type="{http://www.datapower.com/schemas/management}ModifyCountMonitor"/&gt;
 *         &lt;element name="DurationMonitor" type="{http://www.datapower.com/schemas/management}ModifyDurationMonitor"/&gt;
 *         &lt;element name="MessageType" type="{http://www.datapower.com/schemas/management}ModifyMessageType"/&gt;
 *         &lt;element name="MPGWErrorAction" type="{http://www.datapower.com/schemas/management}ModifyMPGWErrorAction"/&gt;
 *         &lt;element name="MPGWErrorHandlingPolicy" type="{http://www.datapower.com/schemas/management}ModifyMPGWErrorHandlingPolicy"/&gt;
 *         &lt;element name="MQAUI" type="{http://www.datapower.com/schemas/management}ModifyMQAUI"/&gt;
 *         &lt;element name="MQGW" type="{http://www.datapower.com/schemas/management}ModifyMQGW"/&gt;
 *         &lt;element name="MQhost" type="{http://www.datapower.com/schemas/management}ModifyMQhost"/&gt;
 *         &lt;element name="MQproxy" type="{http://www.datapower.com/schemas/management}ModifyMQproxy"/&gt;
 *         &lt;element name="MQQM" type="{http://www.datapower.com/schemas/management}ModifyMQQM"/&gt;
 *         &lt;element name="MQQMGroup" type="{http://www.datapower.com/schemas/management}ModifyMQQMGroup"/&gt;
 *         &lt;element name="MTOMPolicy" type="{http://www.datapower.com/schemas/management}ModifyMTOMPolicy"/&gt;
 *         &lt;element name="NameValueProfile" type="{http://www.datapower.com/schemas/management}ModifyNameValueProfile"/&gt;
 *         &lt;element name="DNSNameService" type="{http://www.datapower.com/schemas/management}ModifyDNSNameService"/&gt;
 *         &lt;element name="HostAlias" type="{http://www.datapower.com/schemas/management}ModifyHostAlias"/&gt;
 *         &lt;element name="NetworkSettings" type="{http://www.datapower.com/schemas/management}ModifyNetworkSettings"/&gt;
 *         &lt;element name="NTPService" type="{http://www.datapower.com/schemas/management}ModifyNTPService"/&gt;
 *         &lt;element name="NFSClientSettings" type="{http://www.datapower.com/schemas/management}ModifyNFSClientSettings"/&gt;
 *         &lt;element name="NFSDynamicMounts" type="{http://www.datapower.com/schemas/management}ModifyNFSDynamicMounts"/&gt;
 *         &lt;element name="NFSStaticMount" type="{http://www.datapower.com/schemas/management}ModifyNFSStaticMount"/&gt;
 *         &lt;element name="ODR" type="{http://www.datapower.com/schemas/management}ModifyODR"/&gt;
 *         &lt;element name="ODRConnectorGroup" type="{http://www.datapower.com/schemas/management}ModifyODRConnectorGroup"/&gt;
 *         &lt;element name="PasswordAlias" type="{http://www.datapower.com/schemas/management}ModifyPasswordAlias"/&gt;
 *         &lt;element name="Pattern" type="{http://www.datapower.com/schemas/management}ModifyPattern"/&gt;
 *         &lt;element name="PeerGroup" type="{http://www.datapower.com/schemas/management}ModifyPeerGroup"/&gt;
 *         &lt;element name="PolicyAttachments" type="{http://www.datapower.com/schemas/management}ModifyPolicyAttachments"/&gt;
 *         &lt;element name="PolicyParameters" type="{http://www.datapower.com/schemas/management}ModifyPolicyParameters"/&gt;
 *         &lt;element name="QuotaEnforcementServer" type="{http://www.datapower.com/schemas/management}ModifyQuotaEnforcementServer"/&gt;
 *         &lt;element name="RaidVolume" type="{http://www.datapower.com/schemas/management}ModifyRaidVolume"/&gt;
 *         &lt;element name="SQLRuntimeSettings" type="{http://www.datapower.com/schemas/management}ModifySQLRuntimeSettings"/&gt;
 *         &lt;element name="SecureBackupMode" type="{http://www.datapower.com/schemas/management}ModifySecureBackupMode"/&gt;
 *         &lt;element name="SecureCloudConnector" type="{http://www.datapower.com/schemas/management}ModifySecureCloudConnector"/&gt;
 *         &lt;element name="SecureGatewayClient" type="{http://www.datapower.com/schemas/management}ModifySecureGatewayClient"/&gt;
 *         &lt;element name="MgmtInterface" type="{http://www.datapower.com/schemas/management}ModifyMgmtInterface"/&gt;
 *         &lt;element name="RestMgmtInterface" type="{http://www.datapower.com/schemas/management}ModifyRestMgmtInterface"/&gt;
 *         &lt;element name="SSHService" type="{http://www.datapower.com/schemas/management}ModifySSHService"/&gt;
 *         &lt;element name="TelnetService" type="{http://www.datapower.com/schemas/management}ModifyTelnetService"/&gt;
 *         &lt;element name="WebB2BViewer" type="{http://www.datapower.com/schemas/management}ModifyWebB2BViewer"/&gt;
 *         &lt;element name="WebGUI" type="{http://www.datapower.com/schemas/management}ModifyWebGUI"/&gt;
 *         &lt;element name="XMLFirewallService" type="{http://www.datapower.com/schemas/management}ModifyXMLFirewallService"/&gt;
 *         &lt;element name="XSLProxyService" type="{http://www.datapower.com/schemas/management}ModifyXSLProxyService"/&gt;
 *         &lt;element name="HTTPService" type="{http://www.datapower.com/schemas/management}ModifyHTTPService"/&gt;
 *         &lt;element name="SSLProxyService" type="{http://www.datapower.com/schemas/management}ModifySSLProxyService"/&gt;
 *         &lt;element name="TCPProxyService" type="{http://www.datapower.com/schemas/management}ModifyTCPProxyService"/&gt;
 *         &lt;element name="XSLCoprocService" type="{http://www.datapower.com/schemas/management}ModifyXSLCoprocService"/&gt;
 *         &lt;element name="ShellAlias" type="{http://www.datapower.com/schemas/management}ModifyShellAlias"/&gt;
 *         &lt;element name="SimpleCountMonitor" type="{http://www.datapower.com/schemas/management}ModifySimpleCountMonitor"/&gt;
 *         &lt;element name="SLMAction" type="{http://www.datapower.com/schemas/management}ModifySLMAction"/&gt;
 *         &lt;element name="SLMCredClass" type="{http://www.datapower.com/schemas/management}ModifySLMCredClass"/&gt;
 *         &lt;element name="SLMPolicy" type="{http://www.datapower.com/schemas/management}ModifySLMPolicy"/&gt;
 *         &lt;element name="SLMRsrcClass" type="{http://www.datapower.com/schemas/management}ModifySLMRsrcClass"/&gt;
 *         &lt;element name="SLMSchedule" type="{http://www.datapower.com/schemas/management}ModifySLMSchedule"/&gt;
 *         &lt;element name="SMTPServerConnection" type="{http://www.datapower.com/schemas/management}ModifySMTPServerConnection"/&gt;
 *         &lt;element name="SNMPSettings" type="{http://www.datapower.com/schemas/management}ModifySNMPSettings"/&gt;
 *         &lt;element name="AS2ProxySourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyAS2ProxySourceProtocolHandler"/&gt;
 *         &lt;element name="AS2SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyAS2SourceProtocolHandler"/&gt;
 *         &lt;element name="AS3SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyAS3SourceProtocolHandler"/&gt;
 *         &lt;element name="EBMS2SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyEBMS2SourceProtocolHandler"/&gt;
 *         &lt;element name="EBMS3SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyEBMS3SourceProtocolHandler"/&gt;
 *         &lt;element name="FTPFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyFTPFilePollerSourceProtocolHandler"/&gt;
 *         &lt;element name="NFSFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyNFSFilePollerSourceProtocolHandler"/&gt;
 *         &lt;element name="SFTPFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifySFTPFilePollerSourceProtocolHandler"/&gt;
 *         &lt;element name="FTPServerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyFTPServerSourceProtocolHandler"/&gt;
 *         &lt;element name="HTTPSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyHTTPSourceProtocolHandler"/&gt;
 *         &lt;element name="HTTPSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyHTTPSSourceProtocolHandler"/&gt;
 *         &lt;element name="IMSCalloutSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyIMSCalloutSourceProtocolHandler"/&gt;
 *         &lt;element name="IMSConnectSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyIMSConnectSourceProtocolHandler"/&gt;
 *         &lt;element name="TibcoEMSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyTibcoEMSSourceProtocolHandler"/&gt;
 *         &lt;element name="WebSphereJMSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyWebSphereJMSSourceProtocolHandler"/&gt;
 *         &lt;element name="MQFTESourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyMQFTESourceProtocolHandler"/&gt;
 *         &lt;element name="MQSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyMQSourceProtocolHandler"/&gt;
 *         &lt;element name="AS1PollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyAS1PollerSourceProtocolHandler"/&gt;
 *         &lt;element name="POPPollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyPOPPollerSourceProtocolHandler"/&gt;
 *         &lt;element name="SSHServerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifySSHServerSourceProtocolHandler"/&gt;
 *         &lt;element name="StatelessTCPSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyStatelessTCPSourceProtocolHandler"/&gt;
 *         &lt;element name="XTCProtocolHandler" type="{http://www.datapower.com/schemas/management}ModifyXTCProtocolHandler"/&gt;
 *         &lt;element name="SQLDataSource" type="{http://www.datapower.com/schemas/management}ModifySQLDataSource"/&gt;
 *         &lt;element name="StandaloneStandbyControl" type="{http://www.datapower.com/schemas/management}ModifyStandaloneStandbyControl"/&gt;
 *         &lt;element name="StandaloneStandbyControlInterface" type="{http://www.datapower.com/schemas/management}ModifyStandaloneStandbyControlInterface"/&gt;
 *         &lt;element name="Statistics" type="{http://www.datapower.com/schemas/management}ModifyStatistics"/&gt;
 *         &lt;element name="StylePolicy" type="{http://www.datapower.com/schemas/management}ModifyStylePolicy"/&gt;
 *         &lt;element name="StylePolicyAction" type="{http://www.datapower.com/schemas/management}ModifyStylePolicyAction"/&gt;
 *         &lt;element name="StylePolicyRule" type="{http://www.datapower.com/schemas/management}ModifyStylePolicyRule"/&gt;
 *         &lt;element name="WSStylePolicyRule" type="{http://www.datapower.com/schemas/management}ModifyWSStylePolicyRule"/&gt;
 *         &lt;element name="Throttler" type="{http://www.datapower.com/schemas/management}ModifyThrottler"/&gt;
 *         &lt;element name="UDDIRegistry" type="{http://www.datapower.com/schemas/management}ModifyUDDIRegistry"/&gt;
 *         &lt;element name="URLMap" type="{http://www.datapower.com/schemas/management}ModifyURLMap"/&gt;
 *         &lt;element name="URLRefreshPolicy" type="{http://www.datapower.com/schemas/management}ModifyURLRefreshPolicy"/&gt;
 *         &lt;element name="URLRewritePolicy" type="{http://www.datapower.com/schemas/management}ModifyURLRewritePolicy"/&gt;
 *         &lt;element name="User" type="{http://www.datapower.com/schemas/management}ModifyUser"/&gt;
 *         &lt;element name="UserGroup" type="{http://www.datapower.com/schemas/management}ModifyUserGroup"/&gt;
 *         &lt;element name="WCCService" type="{http://www.datapower.com/schemas/management}ModifyWCCService"/&gt;
 *         &lt;element name="WebAppErrorHandlingPolicy" type="{http://www.datapower.com/schemas/management}ModifyWebAppErrorHandlingPolicy"/&gt;
 *         &lt;element name="WebAppFW" type="{http://www.datapower.com/schemas/management}ModifyWebAppFW"/&gt;
 *         &lt;element name="WebAppRequest" type="{http://www.datapower.com/schemas/management}ModifyWebAppRequest"/&gt;
 *         &lt;element name="WebAppResponse" type="{http://www.datapower.com/schemas/management}ModifyWebAppResponse"/&gt;
 *         &lt;element name="WebAppSessionPolicy" type="{http://www.datapower.com/schemas/management}ModifyWebAppSessionPolicy"/&gt;
 *         &lt;element name="WebServiceMonitor" type="{http://www.datapower.com/schemas/management}ModifyWebServiceMonitor"/&gt;
 *         &lt;element name="WebServicesAgent" type="{http://www.datapower.com/schemas/management}ModifyWebServicesAgent"/&gt;
 *         &lt;element name="UDDISubscription" type="{http://www.datapower.com/schemas/management}ModifyUDDISubscription"/&gt;
 *         &lt;element name="WSRRSavedSearchSubscription" type="{http://www.datapower.com/schemas/management}ModifyWSRRSavedSearchSubscription"/&gt;
 *         &lt;element name="WSRRSubscription" type="{http://www.datapower.com/schemas/management}ModifyWSRRSubscription"/&gt;
 *         &lt;element name="WebTokenService" type="{http://www.datapower.com/schemas/management}ModifyWebTokenService"/&gt;
 *         &lt;element name="WSEndpointRewritePolicy" type="{http://www.datapower.com/schemas/management}ModifyWSEndpointRewritePolicy"/&gt;
 *         &lt;element name="WSRRServer" type="{http://www.datapower.com/schemas/management}ModifyWSRRServer"/&gt;
 *         &lt;element name="WSStylePolicy" type="{http://www.datapower.com/schemas/management}ModifyWSStylePolicy"/&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}ModifyXMLManager"/&gt;
 *         &lt;element name="xmltrace" type="{http://www.datapower.com/schemas/management}Modifyxmltrace"/&gt;
 *         &lt;element name="ZHybridTargetControlService" type="{http://www.datapower.com/schemas/management}ModifyZHybridTargetControlService"/&gt;
 *         &lt;element name="ZosNSSClient" type="{http://www.datapower.com/schemas/management}ModifyZosNSSClient"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnyModifyElement", propOrder = {
    "configObjects"
})
public class AnyModifyElement {

    @XmlElements({
        @XmlElement(name = "AAAPolicy", type = ModifyAAAPolicy.class),
        @XmlElement(name = "Domain", type = ModifyDomain.class),
        @XmlElement(name = "LDAPSearchParameters", type = ModifyLDAPSearchParameters.class),
        @XmlElement(name = "ProcessingMetadata", type = ModifyProcessingMetadata.class),
        @XmlElement(name = "RADIUSSettings", type = ModifyRADIUSSettings.class),
        @XmlElement(name = "RBMSettings", type = ModifyRBMSettings.class),
        @XmlElement(name = "SAMLAttributes", type = ModifySAMLAttributes.class),
        @XmlElement(name = "SOAPHeaderDisposition", type = ModifySOAPHeaderDisposition.class),
        @XmlElement(name = "TAM", type = ModifyTAM.class),
        @XmlElement(name = "TFIMEndpoint", type = ModifyTFIMEndpoint.class),
        @XmlElement(name = "XACMLPDP", type = ModifyXACMLPDP.class),
        @XmlElement(name = "AccessControlList", type = ModifyAccessControlList.class),
        @XmlElement(name = "AppSecurityPolicy", type = ModifyAppSecurityPolicy.class),
        @XmlElement(name = "AuditLog", type = ModifyAuditLog.class),
        @XmlElement(name = "B2BCPA", type = ModifyB2BCPA.class),
        @XmlElement(name = "B2BCPACollaboration", type = ModifyB2BCPACollaboration.class),
        @XmlElement(name = "B2BCPAReceiverSetting", type = ModifyB2BCPAReceiverSetting.class),
        @XmlElement(name = "B2BCPASenderSetting", type = ModifyB2BCPASenderSetting.class),
        @XmlElement(name = "B2BGateway", type = ModifyB2BGateway.class),
        @XmlElement(name = "B2BPersistence", type = ModifyB2BPersistence.class),
        @XmlElement(name = "B2BProfile", type = ModifyB2BProfile.class),
        @XmlElement(name = "B2BProfileGroup", type = ModifyB2BProfileGroup.class),
        @XmlElement(name = "B2BXPathRoutingPolicy", type = ModifyB2BXPathRoutingPolicy.class),
        @XmlElement(name = "WXSGrid", type = ModifyWXSGrid.class),
        @XmlElement(name = "XC10Grid", type = ModifyXC10Grid.class),
        @XmlElement(name = "CloudConnectorService", type = ModifyCloudConnectorService.class),
        @XmlElement(name = "CloudGatewayService", type = ModifyCloudGatewayService.class),
        @XmlElement(name = "CompactFlash", type = ModifyCompactFlash.class),
        @XmlElement(name = "CompileOptionsPolicy", type = ModifyCompileOptionsPolicy.class),
        @XmlElement(name = "ConfigDeploymentPolicy", type = ModifyConfigDeploymentPolicy.class),
        @XmlElement(name = "ConformancePolicy", type = ModifyConformancePolicy.class),
        @XmlElement(name = "AAAJWTGenerator", type = ModifyAAAJWTGenerator.class),
        @XmlElement(name = "AAAJWTValidator", type = ModifyAAAJWTValidator.class),
        @XmlElement(name = "CertMonitor", type = ModifyCertMonitor.class),
        @XmlElement(name = "CookieAttributePolicy", type = ModifyCookieAttributePolicy.class),
        @XmlElement(name = "CRLFetch", type = ModifyCRLFetch.class),
        @XmlElement(name = "CryptoCertificate", type = ModifyCryptoCertificate.class),
        @XmlElement(name = "CryptoFWCred", type = ModifyCryptoFWCred.class),
        @XmlElement(name = "CryptoIdentCred", type = ModifyCryptoIdentCred.class),
        @XmlElement(name = "CryptoKerberosKDC", type = ModifyCryptoKerberosKDC.class),
        @XmlElement(name = "CryptoKerberosKeytab", type = ModifyCryptoKerberosKeytab.class),
        @XmlElement(name = "CryptoKey", type = ModifyCryptoKey.class),
        @XmlElement(name = "CryptoProfile", type = ModifyCryptoProfile.class),
        @XmlElement(name = "CryptoSSKey", type = ModifyCryptoSSKey.class),
        @XmlElement(name = "CryptoValCred", type = ModifyCryptoValCred.class),
        @XmlElement(name = "JOSERecipientIdentifier", type = ModifyJOSERecipientIdentifier.class),
        @XmlElement(name = "JOSESignatureIdentifier", type = ModifyJOSESignatureIdentifier.class),
        @XmlElement(name = "JWEHeader", type = ModifyJWEHeader.class),
        @XmlElement(name = "JWERecipient", type = ModifyJWERecipient.class),
        @XmlElement(name = "JWSSignature", type = ModifyJWSSignature.class),
        @XmlElement(name = "OAuthSupportedClient", type = ModifyOAuthSupportedClient.class),
        @XmlElement(name = "OAuthSupportedClientGroup", type = ModifyOAuthSupportedClientGroup.class),
        @XmlElement(name = "SocialLoginPolicy", type = ModifySocialLoginPolicy.class),
        @XmlElement(name = "SSHClientProfile", type = ModifySSHClientProfile.class),
        @XmlElement(name = "SSHDomainClientProfile", type = ModifySSHDomainClientProfile.class),
        @XmlElement(name = "SSHServerProfile", type = ModifySSHServerProfile.class),
        @XmlElement(name = "SSLClientProfile", type = ModifySSLClientProfile.class),
        @XmlElement(name = "SSLProxyProfile", type = ModifySSLProxyProfile.class),
        @XmlElement(name = "SSLServerProfile", type = ModifySSLServerProfile.class),
        @XmlElement(name = "SSLSNIMapping", type = ModifySSLSNIMapping.class),
        @XmlElement(name = "SSLSNIServerProfile", type = ModifySSLSNIServerProfile.class),
        @XmlElement(name = "DeploymentPolicyParametersBinding", type = ModifyDeploymentPolicyParametersBinding.class),
        @XmlElement(name = "ErrorReportSettings", type = ModifyErrorReportSettings.class),
        @XmlElement(name = "SystemSettings", type = ModifySystemSettings.class),
        @XmlElement(name = "TimeSettings", type = ModifyTimeSettings.class),
        @XmlElement(name = "DFDLSettings", type = ModifyDFDLSettings.class),
        @XmlElement(name = "DomainAvailability", type = ModifyDomainAvailability.class),
        @XmlElement(name = "DomainSettings", type = ModifyDomainSettings.class),
        @XmlElement(name = "SchemaExceptionMap", type = ModifySchemaExceptionMap.class),
        @XmlElement(name = "DocumentCryptoMap", type = ModifyDocumentCryptoMap.class),
        @XmlElement(name = "XPathRoutingMap", type = ModifyXPathRoutingMap.class),
        @XmlElement(name = "LogTarget", type = ModifyLogTarget.class),
        @XmlElement(name = "FormsLoginPolicy", type = ModifyFormsLoginPolicy.class),
        @XmlElement(name = "FTPQuoteCommands", type = ModifyFTPQuoteCommands.class),
        @XmlElement(name = "MultiProtocolGateway", type = ModifyMultiProtocolGateway.class),
        @XmlElement(name = "WSGateway", type = ModifyWSGateway.class),
        @XmlElement(name = "GeneratedPolicy", type = ModifyGeneratedPolicy.class),
        @XmlElement(name = "HTTPInputConversionMap", type = ModifyHTTPInputConversionMap.class),
        @XmlElement(name = "HTTPUserAgent", type = ModifyHTTPUserAgent.class),
        @XmlElement(name = "ILMTAgent", type = ModifyILMTAgent.class),
        @XmlElement(name = "ImportPackage", type = ModifyImportPackage.class),
        @XmlElement(name = "IMSConnect", type = ModifyIMSConnect.class),
        @XmlElement(name = "IncludeConfig", type = ModifyIncludeConfig.class),
        @XmlElement(name = "InteropService", type = ModifyInteropService.class),
        @XmlElement(name = "EthernetInterface", type = ModifyEthernetInterface.class),
        @XmlElement(name = "LinkAggregation", type = ModifyLinkAggregation.class),
        @XmlElement(name = "VLANInterface", type = ModifyVLANInterface.class),
        @XmlElement(name = "IPMILanChannel", type = ModifyIPMILanChannel.class),
        @XmlElement(name = "IPMIUser", type = ModifyIPMIUser.class),
        @XmlElement(name = "IPMulticast", type = ModifyIPMulticast.class),
        @XmlElement(name = "ISAMReverseProxy", type = ModifyISAMReverseProxy.class),
        @XmlElement(name = "ISAMReverseProxyJunction", type = ModifyISAMReverseProxyJunction.class),
        @XmlElement(name = "ISAMRuntime", type = ModifyISAMRuntime.class),
        @XmlElement(name = "IScsiChapConfig", type = ModifyIScsiChapConfig.class),
        @XmlElement(name = "IScsiHBAConfig", type = ModifyIScsiHBAConfig.class),
        @XmlElement(name = "IScsiInitiatorConfig", type = ModifyIScsiInitiatorConfig.class),
        @XmlElement(name = "IScsiTargetConfig", type = ModifyIScsiTargetConfig.class),
        @XmlElement(name = "IScsiVolumeConfig", type = ModifyIScsiVolumeConfig.class),
        @XmlElement(name = "TibcoEMSServer", type = ModifyTibcoEMSServer.class),
        @XmlElement(name = "WebSphereJMSServer", type = ModifyWebSphereJMSServer.class),
        @XmlElement(name = "JSONSettings", type = ModifyJSONSettings.class),
        @XmlElement(name = "Language", type = ModifyLanguage.class),
        @XmlElement(name = "LDAPConnectionPool", type = ModifyLDAPConnectionPool.class),
        @XmlElement(name = "LoadBalancerGroup", type = ModifyLoadBalancerGroup.class),
        @XmlElement(name = "LogLabel", type = ModifyLogLabel.class),
        @XmlElement(name = "Luna", type = ModifyLuna.class),
        @XmlElement(name = "LunaPartition", type = ModifyLunaPartition.class),
        @XmlElement(name = "Matching", type = ModifyMatching.class),
        @XmlElement(name = "MCFCustomRule", type = ModifyMCFCustomRule.class),
        @XmlElement(name = "MCFHttpHeader", type = ModifyMCFHttpHeader.class),
        @XmlElement(name = "MCFHttpMethod", type = ModifyMCFHttpMethod.class),
        @XmlElement(name = "MCFHttpURL", type = ModifyMCFHttpURL.class),
        @XmlElement(name = "MCFXPath", type = ModifyMCFXPath.class),
        @XmlElement(name = "MessageContentFilters", type = ModifyMessageContentFilters.class),
        @XmlElement(name = "FilterAction", type = ModifyFilterAction.class),
        @XmlElement(name = "MessageMatching", type = ModifyMessageMatching.class),
        @XmlElement(name = "CountMonitor", type = ModifyCountMonitor.class),
        @XmlElement(name = "DurationMonitor", type = ModifyDurationMonitor.class),
        @XmlElement(name = "MessageType", type = ModifyMessageType.class),
        @XmlElement(name = "MPGWErrorAction", type = ModifyMPGWErrorAction.class),
        @XmlElement(name = "MPGWErrorHandlingPolicy", type = ModifyMPGWErrorHandlingPolicy.class),
        @XmlElement(name = "MQAUI", type = ModifyMQAUI.class),
        @XmlElement(name = "MQGW", type = ModifyMQGW.class),
        @XmlElement(name = "MQhost", type = ModifyMQhost.class),
        @XmlElement(name = "MQproxy", type = ModifyMQproxy.class),
        @XmlElement(name = "MQQM", type = ModifyMQQM.class),
        @XmlElement(name = "MQQMGroup", type = ModifyMQQMGroup.class),
        @XmlElement(name = "MTOMPolicy", type = ModifyMTOMPolicy.class),
        @XmlElement(name = "NameValueProfile", type = ModifyNameValueProfile.class),
        @XmlElement(name = "DNSNameService", type = ModifyDNSNameService.class),
        @XmlElement(name = "HostAlias", type = ModifyHostAlias.class),
        @XmlElement(name = "NetworkSettings", type = ModifyNetworkSettings.class),
        @XmlElement(name = "NTPService", type = ModifyNTPService.class),
        @XmlElement(name = "NFSClientSettings", type = ModifyNFSClientSettings.class),
        @XmlElement(name = "NFSDynamicMounts", type = ModifyNFSDynamicMounts.class),
        @XmlElement(name = "NFSStaticMount", type = ModifyNFSStaticMount.class),
        @XmlElement(name = "ODR", type = ModifyODR.class),
        @XmlElement(name = "ODRConnectorGroup", type = ModifyODRConnectorGroup.class),
        @XmlElement(name = "PasswordAlias", type = ModifyPasswordAlias.class),
        @XmlElement(name = "Pattern", type = ModifyPattern.class),
        @XmlElement(name = "PeerGroup", type = ModifyPeerGroup.class),
        @XmlElement(name = "PolicyAttachments", type = ModifyPolicyAttachments.class),
        @XmlElement(name = "PolicyParameters", type = ModifyPolicyParameters.class),
        @XmlElement(name = "QuotaEnforcementServer", type = ModifyQuotaEnforcementServer.class),
        @XmlElement(name = "RaidVolume", type = ModifyRaidVolume.class),
        @XmlElement(name = "SQLRuntimeSettings", type = ModifySQLRuntimeSettings.class),
        @XmlElement(name = "SecureBackupMode", type = ModifySecureBackupMode.class),
        @XmlElement(name = "SecureCloudConnector", type = ModifySecureCloudConnector.class),
        @XmlElement(name = "SecureGatewayClient", type = ModifySecureGatewayClient.class),
        @XmlElement(name = "MgmtInterface", type = ModifyMgmtInterface.class),
        @XmlElement(name = "RestMgmtInterface", type = ModifyRestMgmtInterface.class),
        @XmlElement(name = "SSHService", type = ModifySSHService.class),
        @XmlElement(name = "TelnetService", type = ModifyTelnetService.class),
        @XmlElement(name = "WebB2BViewer", type = ModifyWebB2BViewer.class),
        @XmlElement(name = "WebGUI", type = ModifyWebGUI.class),
        @XmlElement(name = "XMLFirewallService", type = ModifyXMLFirewallService.class),
        @XmlElement(name = "XSLProxyService", type = ModifyXSLProxyService.class),
        @XmlElement(name = "HTTPService", type = ModifyHTTPService.class),
        @XmlElement(name = "SSLProxyService", type = ModifySSLProxyService.class),
        @XmlElement(name = "TCPProxyService", type = ModifyTCPProxyService.class),
        @XmlElement(name = "XSLCoprocService", type = ModifyXSLCoprocService.class),
        @XmlElement(name = "ShellAlias", type = ModifyShellAlias.class),
        @XmlElement(name = "SimpleCountMonitor", type = ModifySimpleCountMonitor.class),
        @XmlElement(name = "SLMAction", type = ModifySLMAction.class),
        @XmlElement(name = "SLMCredClass", type = ModifySLMCredClass.class),
        @XmlElement(name = "SLMPolicy", type = ModifySLMPolicy.class),
        @XmlElement(name = "SLMRsrcClass", type = ModifySLMRsrcClass.class),
        @XmlElement(name = "SLMSchedule", type = ModifySLMSchedule.class),
        @XmlElement(name = "SMTPServerConnection", type = ModifySMTPServerConnection.class),
        @XmlElement(name = "SNMPSettings", type = ModifySNMPSettings.class),
        @XmlElement(name = "AS2ProxySourceProtocolHandler", type = ModifyAS2ProxySourceProtocolHandler.class),
        @XmlElement(name = "AS2SourceProtocolHandler", type = ModifyAS2SourceProtocolHandler.class),
        @XmlElement(name = "AS3SourceProtocolHandler", type = ModifyAS3SourceProtocolHandler.class),
        @XmlElement(name = "EBMS2SourceProtocolHandler", type = ModifyEBMS2SourceProtocolHandler.class),
        @XmlElement(name = "EBMS3SourceProtocolHandler", type = ModifyEBMS3SourceProtocolHandler.class),
        @XmlElement(name = "FTPFilePollerSourceProtocolHandler", type = ModifyFTPFilePollerSourceProtocolHandler.class),
        @XmlElement(name = "NFSFilePollerSourceProtocolHandler", type = ModifyNFSFilePollerSourceProtocolHandler.class),
        @XmlElement(name = "SFTPFilePollerSourceProtocolHandler", type = ModifySFTPFilePollerSourceProtocolHandler.class),
        @XmlElement(name = "FTPServerSourceProtocolHandler", type = ModifyFTPServerSourceProtocolHandler.class),
        @XmlElement(name = "HTTPSourceProtocolHandler", type = ModifyHTTPSourceProtocolHandler.class),
        @XmlElement(name = "HTTPSSourceProtocolHandler", type = ModifyHTTPSSourceProtocolHandler.class),
        @XmlElement(name = "IMSCalloutSourceProtocolHandler", type = ModifyIMSCalloutSourceProtocolHandler.class),
        @XmlElement(name = "IMSConnectSourceProtocolHandler", type = ModifyIMSConnectSourceProtocolHandler.class),
        @XmlElement(name = "TibcoEMSSourceProtocolHandler", type = ModifyTibcoEMSSourceProtocolHandler.class),
        @XmlElement(name = "WebSphereJMSSourceProtocolHandler", type = ModifyWebSphereJMSSourceProtocolHandler.class),
        @XmlElement(name = "MQFTESourceProtocolHandler", type = ModifyMQFTESourceProtocolHandler.class),
        @XmlElement(name = "MQSourceProtocolHandler", type = ModifyMQSourceProtocolHandler.class),
        @XmlElement(name = "AS1PollerSourceProtocolHandler", type = ModifyAS1PollerSourceProtocolHandler.class),
        @XmlElement(name = "POPPollerSourceProtocolHandler", type = ModifyPOPPollerSourceProtocolHandler.class),
        @XmlElement(name = "SSHServerSourceProtocolHandler", type = ModifySSHServerSourceProtocolHandler.class),
        @XmlElement(name = "StatelessTCPSourceProtocolHandler", type = ModifyStatelessTCPSourceProtocolHandler.class),
        @XmlElement(name = "XTCProtocolHandler", type = ModifyXTCProtocolHandler.class),
        @XmlElement(name = "SQLDataSource", type = ModifySQLDataSource.class),
        @XmlElement(name = "StandaloneStandbyControl", type = ModifyStandaloneStandbyControl.class),
        @XmlElement(name = "StandaloneStandbyControlInterface", type = ModifyStandaloneStandbyControlInterface.class),
        @XmlElement(name = "Statistics", type = ModifyStatistics.class),
        @XmlElement(name = "StylePolicy", type = ModifyStylePolicy.class),
        @XmlElement(name = "StylePolicyAction", type = ModifyStylePolicyAction.class),
        @XmlElement(name = "StylePolicyRule", type = ModifyStylePolicyRule.class),
        @XmlElement(name = "WSStylePolicyRule", type = ModifyWSStylePolicyRule.class),
        @XmlElement(name = "Throttler", type = ModifyThrottler.class),
        @XmlElement(name = "UDDIRegistry", type = ModifyUDDIRegistry.class),
        @XmlElement(name = "URLMap", type = ModifyURLMap.class),
        @XmlElement(name = "URLRefreshPolicy", type = ModifyURLRefreshPolicy.class),
        @XmlElement(name = "URLRewritePolicy", type = ModifyURLRewritePolicy.class),
        @XmlElement(name = "User", type = ModifyUser.class),
        @XmlElement(name = "UserGroup", type = ModifyUserGroup.class),
        @XmlElement(name = "WCCService", type = ModifyWCCService.class),
        @XmlElement(name = "WebAppErrorHandlingPolicy", type = ModifyWebAppErrorHandlingPolicy.class),
        @XmlElement(name = "WebAppFW", type = ModifyWebAppFW.class),
        @XmlElement(name = "WebAppRequest", type = ModifyWebAppRequest.class),
        @XmlElement(name = "WebAppResponse", type = ModifyWebAppResponse.class),
        @XmlElement(name = "WebAppSessionPolicy", type = ModifyWebAppSessionPolicy.class),
        @XmlElement(name = "WebServiceMonitor", type = ModifyWebServiceMonitor.class),
        @XmlElement(name = "WebServicesAgent", type = ModifyWebServicesAgent.class),
        @XmlElement(name = "UDDISubscription", type = ModifyUDDISubscription.class),
        @XmlElement(name = "WSRRSavedSearchSubscription", type = ModifyWSRRSavedSearchSubscription.class),
        @XmlElement(name = "WSRRSubscription", type = ModifyWSRRSubscription.class),
        @XmlElement(name = "WebTokenService", type = ModifyWebTokenService.class),
        @XmlElement(name = "WSEndpointRewritePolicy", type = ModifyWSEndpointRewritePolicy.class),
        @XmlElement(name = "WSRRServer", type = ModifyWSRRServer.class),
        @XmlElement(name = "WSStylePolicy", type = ModifyWSStylePolicy.class),
        @XmlElement(name = "XMLManager", type = ModifyXMLManager.class),
        @XmlElement(name = "xmltrace", type = Modifyxmltrace.class),
        @XmlElement(name = "ZHybridTargetControlService", type = ModifyZHybridTargetControlService.class),
        @XmlElement(name = "ZosNSSClient", type = ModifyZosNSSClient.class)
    })
    protected List<ModifyConfigBase> configObjects;

    /**
     * Gets the value of the configObjects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the configObjects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConfigObjects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModifyAAAPolicy }
     * {@link ModifyDomain }
     * {@link ModifyLDAPSearchParameters }
     * {@link ModifyProcessingMetadata }
     * {@link ModifyRADIUSSettings }
     * {@link ModifyRBMSettings }
     * {@link ModifySAMLAttributes }
     * {@link ModifySOAPHeaderDisposition }
     * {@link ModifyTAM }
     * {@link ModifyTFIMEndpoint }
     * {@link ModifyXACMLPDP }
     * {@link ModifyAccessControlList }
     * {@link ModifyAppSecurityPolicy }
     * {@link ModifyAuditLog }
     * {@link ModifyB2BCPA }
     * {@link ModifyB2BCPACollaboration }
     * {@link ModifyB2BCPAReceiverSetting }
     * {@link ModifyB2BCPASenderSetting }
     * {@link ModifyB2BGateway }
     * {@link ModifyB2BPersistence }
     * {@link ModifyB2BProfile }
     * {@link ModifyB2BProfileGroup }
     * {@link ModifyB2BXPathRoutingPolicy }
     * {@link ModifyWXSGrid }
     * {@link ModifyXC10Grid }
     * {@link ModifyCloudConnectorService }
     * {@link ModifyCloudGatewayService }
     * {@link ModifyCompactFlash }
     * {@link ModifyCompileOptionsPolicy }
     * {@link ModifyConfigDeploymentPolicy }
     * {@link ModifyConformancePolicy }
     * {@link ModifyAAAJWTGenerator }
     * {@link ModifyAAAJWTValidator }
     * {@link ModifyCertMonitor }
     * {@link ModifyCookieAttributePolicy }
     * {@link ModifyCRLFetch }
     * {@link ModifyCryptoCertificate }
     * {@link ModifyCryptoFWCred }
     * {@link ModifyCryptoIdentCred }
     * {@link ModifyCryptoKerberosKDC }
     * {@link ModifyCryptoKerberosKeytab }
     * {@link ModifyCryptoKey }
     * {@link ModifyCryptoProfile }
     * {@link ModifyCryptoSSKey }
     * {@link ModifyCryptoValCred }
     * {@link ModifyJOSERecipientIdentifier }
     * {@link ModifyJOSESignatureIdentifier }
     * {@link ModifyJWEHeader }
     * {@link ModifyJWERecipient }
     * {@link ModifyJWSSignature }
     * {@link ModifyOAuthSupportedClient }
     * {@link ModifyOAuthSupportedClientGroup }
     * {@link ModifySocialLoginPolicy }
     * {@link ModifySSHClientProfile }
     * {@link ModifySSHDomainClientProfile }
     * {@link ModifySSHServerProfile }
     * {@link ModifySSLClientProfile }
     * {@link ModifySSLProxyProfile }
     * {@link ModifySSLServerProfile }
     * {@link ModifySSLSNIMapping }
     * {@link ModifySSLSNIServerProfile }
     * {@link ModifyDeploymentPolicyParametersBinding }
     * {@link ModifyErrorReportSettings }
     * {@link ModifySystemSettings }
     * {@link ModifyTimeSettings }
     * {@link ModifyDFDLSettings }
     * {@link ModifyDomainAvailability }
     * {@link ModifyDomainSettings }
     * {@link ModifySchemaExceptionMap }
     * {@link ModifyDocumentCryptoMap }
     * {@link ModifyXPathRoutingMap }
     * {@link ModifyLogTarget }
     * {@link ModifyFormsLoginPolicy }
     * {@link ModifyFTPQuoteCommands }
     * {@link ModifyMultiProtocolGateway }
     * {@link ModifyWSGateway }
     * {@link ModifyGeneratedPolicy }
     * {@link ModifyHTTPInputConversionMap }
     * {@link ModifyHTTPUserAgent }
     * {@link ModifyILMTAgent }
     * {@link ModifyImportPackage }
     * {@link ModifyIMSConnect }
     * {@link ModifyIncludeConfig }
     * {@link ModifyInteropService }
     * {@link ModifyEthernetInterface }
     * {@link ModifyLinkAggregation }
     * {@link ModifyVLANInterface }
     * {@link ModifyIPMILanChannel }
     * {@link ModifyIPMIUser }
     * {@link ModifyIPMulticast }
     * {@link ModifyISAMReverseProxy }
     * {@link ModifyISAMReverseProxyJunction }
     * {@link ModifyISAMRuntime }
     * {@link ModifyIScsiChapConfig }
     * {@link ModifyIScsiHBAConfig }
     * {@link ModifyIScsiInitiatorConfig }
     * {@link ModifyIScsiTargetConfig }
     * {@link ModifyIScsiVolumeConfig }
     * {@link ModifyTibcoEMSServer }
     * {@link ModifyWebSphereJMSServer }
     * {@link ModifyJSONSettings }
     * {@link ModifyLanguage }
     * {@link ModifyLDAPConnectionPool }
     * {@link ModifyLoadBalancerGroup }
     * {@link ModifyLogLabel }
     * {@link ModifyLuna }
     * {@link ModifyLunaPartition }
     * {@link ModifyMatching }
     * {@link ModifyMCFCustomRule }
     * {@link ModifyMCFHttpHeader }
     * {@link ModifyMCFHttpMethod }
     * {@link ModifyMCFHttpURL }
     * {@link ModifyMCFXPath }
     * {@link ModifyMessageContentFilters }
     * {@link ModifyFilterAction }
     * {@link ModifyMessageMatching }
     * {@link ModifyCountMonitor }
     * {@link ModifyDurationMonitor }
     * {@link ModifyMessageType }
     * {@link ModifyMPGWErrorAction }
     * {@link ModifyMPGWErrorHandlingPolicy }
     * {@link ModifyMQAUI }
     * {@link ModifyMQGW }
     * {@link ModifyMQhost }
     * {@link ModifyMQproxy }
     * {@link ModifyMQQM }
     * {@link ModifyMQQMGroup }
     * {@link ModifyMTOMPolicy }
     * {@link ModifyNameValueProfile }
     * {@link ModifyDNSNameService }
     * {@link ModifyHostAlias }
     * {@link ModifyNetworkSettings }
     * {@link ModifyNTPService }
     * {@link ModifyNFSClientSettings }
     * {@link ModifyNFSDynamicMounts }
     * {@link ModifyNFSStaticMount }
     * {@link ModifyODR }
     * {@link ModifyODRConnectorGroup }
     * {@link ModifyPasswordAlias }
     * {@link ModifyPattern }
     * {@link ModifyPeerGroup }
     * {@link ModifyPolicyAttachments }
     * {@link ModifyPolicyParameters }
     * {@link ModifyQuotaEnforcementServer }
     * {@link ModifyRaidVolume }
     * {@link ModifySQLRuntimeSettings }
     * {@link ModifySecureBackupMode }
     * {@link ModifySecureCloudConnector }
     * {@link ModifySecureGatewayClient }
     * {@link ModifyMgmtInterface }
     * {@link ModifyRestMgmtInterface }
     * {@link ModifySSHService }
     * {@link ModifyTelnetService }
     * {@link ModifyWebB2BViewer }
     * {@link ModifyWebGUI }
     * {@link ModifyXMLFirewallService }
     * {@link ModifyXSLProxyService }
     * {@link ModifyHTTPService }
     * {@link ModifySSLProxyService }
     * {@link ModifyTCPProxyService }
     * {@link ModifyXSLCoprocService }
     * {@link ModifyShellAlias }
     * {@link ModifySimpleCountMonitor }
     * {@link ModifySLMAction }
     * {@link ModifySLMCredClass }
     * {@link ModifySLMPolicy }
     * {@link ModifySLMRsrcClass }
     * {@link ModifySLMSchedule }
     * {@link ModifySMTPServerConnection }
     * {@link ModifySNMPSettings }
     * {@link ModifyAS2ProxySourceProtocolHandler }
     * {@link ModifyAS2SourceProtocolHandler }
     * {@link ModifyAS3SourceProtocolHandler }
     * {@link ModifyEBMS2SourceProtocolHandler }
     * {@link ModifyEBMS3SourceProtocolHandler }
     * {@link ModifyFTPFilePollerSourceProtocolHandler }
     * {@link ModifyNFSFilePollerSourceProtocolHandler }
     * {@link ModifySFTPFilePollerSourceProtocolHandler }
     * {@link ModifyFTPServerSourceProtocolHandler }
     * {@link ModifyHTTPSourceProtocolHandler }
     * {@link ModifyHTTPSSourceProtocolHandler }
     * {@link ModifyIMSCalloutSourceProtocolHandler }
     * {@link ModifyIMSConnectSourceProtocolHandler }
     * {@link ModifyTibcoEMSSourceProtocolHandler }
     * {@link ModifyWebSphereJMSSourceProtocolHandler }
     * {@link ModifyMQFTESourceProtocolHandler }
     * {@link ModifyMQSourceProtocolHandler }
     * {@link ModifyAS1PollerSourceProtocolHandler }
     * {@link ModifyPOPPollerSourceProtocolHandler }
     * {@link ModifySSHServerSourceProtocolHandler }
     * {@link ModifyStatelessTCPSourceProtocolHandler }
     * {@link ModifyXTCProtocolHandler }
     * {@link ModifySQLDataSource }
     * {@link ModifyStandaloneStandbyControl }
     * {@link ModifyStandaloneStandbyControlInterface }
     * {@link ModifyStatistics }
     * {@link ModifyStylePolicy }
     * {@link ModifyStylePolicyAction }
     * {@link ModifyStylePolicyRule }
     * {@link ModifyWSStylePolicyRule }
     * {@link ModifyThrottler }
     * {@link ModifyUDDIRegistry }
     * {@link ModifyURLMap }
     * {@link ModifyURLRefreshPolicy }
     * {@link ModifyURLRewritePolicy }
     * {@link ModifyUser }
     * {@link ModifyUserGroup }
     * {@link ModifyWCCService }
     * {@link ModifyWebAppErrorHandlingPolicy }
     * {@link ModifyWebAppFW }
     * {@link ModifyWebAppRequest }
     * {@link ModifyWebAppResponse }
     * {@link ModifyWebAppSessionPolicy }
     * {@link ModifyWebServiceMonitor }
     * {@link ModifyWebServicesAgent }
     * {@link ModifyUDDISubscription }
     * {@link ModifyWSRRSavedSearchSubscription }
     * {@link ModifyWSRRSubscription }
     * {@link ModifyWebTokenService }
     * {@link ModifyWSEndpointRewritePolicy }
     * {@link ModifyWSRRServer }
     * {@link ModifyWSStylePolicy }
     * {@link ModifyXMLManager }
     * {@link Modifyxmltrace }
     * {@link ModifyZHybridTargetControlService }
     * {@link ModifyZosNSSClient }
     * 
     * 
     */
    public List<ModifyConfigBase> getConfigObjects() {
        if (configObjects == null) {
            configObjects = new ArrayList<ModifyConfigBase>();
        }
        return this.configObjects;
    }

}
