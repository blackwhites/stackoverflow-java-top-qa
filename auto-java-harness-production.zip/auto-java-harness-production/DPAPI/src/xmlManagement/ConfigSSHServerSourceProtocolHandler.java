
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSSHServerSourceProtocolHandler complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSSHServerSourceProtocolHandler"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigSourceProtocolHandler"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLocalIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ACL" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="HostPrivateKeys" type="{http://www.datapower.com/schemas/management}dmReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SSHUserAuthentication" type="{http://www.datapower.com/schemas/management}dmSSHUserAuthenticationMethods"/&gt;
 *         &lt;element name="AllowBackendListings" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowBackendDelete" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowBackendStat" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowBackendMkdir" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowBackendRmdir" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AllowBackendRename" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AAAPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="FilesystemType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSFTPFilesystemType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DefaultDirectory"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IdleTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PersistentFilesystemTimeout" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="VirtualDirectories" type="{http://www.datapower.com/schemas/management}dmSFTPServerVirtualDirectory" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSSHServerSourceProtocolHandler", propOrder = {
    "userSummary",
    "localAddress",
    "localPort",
    "acl",
    "hostPrivateKeys",
    "sshUserAuthentication",
    "allowBackendListings",
    "allowBackendDelete",
    "allowBackendStat",
    "allowBackendMkdir",
    "allowBackendRmdir",
    "allowBackendRename",
    "aaaPolicy",
    "filesystemType",
    "defaultDirectory",
    "idleTimeout",
    "persistentFilesystemTimeout",
    "virtualDirectories"
})
public class ConfigSSHServerSourceProtocolHandler
    extends ConfigSourceProtocolHandler
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "LocalAddress")
    protected String localAddress;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "ACL")
    protected DmReference acl;
    @XmlElement(name = "HostPrivateKeys")
    protected List<DmReference> hostPrivateKeys;
    @XmlElement(name = "SSHUserAuthentication")
    protected DmSSHUserAuthenticationMethods sshUserAuthentication;
    @XmlElement(name = "AllowBackendListings")
    protected String allowBackendListings;
    @XmlElement(name = "AllowBackendDelete")
    protected String allowBackendDelete;
    @XmlElement(name = "AllowBackendStat")
    protected String allowBackendStat;
    @XmlElement(name = "AllowBackendMkdir")
    protected String allowBackendMkdir;
    @XmlElement(name = "AllowBackendRmdir")
    protected String allowBackendRmdir;
    @XmlElement(name = "AllowBackendRename")
    protected String allowBackendRename;
    @XmlElement(name = "AAAPolicy")
    protected DmReference aaaPolicy;
    @XmlElement(name = "FilesystemType")
    protected String filesystemType;
    @XmlElement(name = "DefaultDirectory")
    protected String defaultDirectory;
    @XmlElement(name = "IdleTimeout")
    protected String idleTimeout;
    @XmlElement(name = "PersistentFilesystemTimeout")
    protected String persistentFilesystemTimeout;
    @XmlElement(name = "VirtualDirectories")
    protected List<DmSFTPServerVirtualDirectory> virtualDirectories;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the localAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAddress() {
        return localAddress;
    }

    /**
     * Sets the value of the localAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAddress(String value) {
        this.localAddress = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getACL() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setACL(DmReference value) {
        this.acl = value;
    }

    /**
     * Gets the value of the hostPrivateKeys property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hostPrivateKeys property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHostPrivateKeys().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmReference }
     * 
     * 
     */
    public List<DmReference> getHostPrivateKeys() {
        if (hostPrivateKeys == null) {
            hostPrivateKeys = new ArrayList<DmReference>();
        }
        return this.hostPrivateKeys;
    }

    /**
     * Gets the value of the sshUserAuthentication property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSHUserAuthenticationMethods }
     *     
     */
    public DmSSHUserAuthenticationMethods getSSHUserAuthentication() {
        return sshUserAuthentication;
    }

    /**
     * Sets the value of the sshUserAuthentication property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSHUserAuthenticationMethods }
     *     
     */
    public void setSSHUserAuthentication(DmSSHUserAuthenticationMethods value) {
        this.sshUserAuthentication = value;
    }

    /**
     * Gets the value of the allowBackendListings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowBackendListings() {
        return allowBackendListings;
    }

    /**
     * Sets the value of the allowBackendListings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowBackendListings(String value) {
        this.allowBackendListings = value;
    }

    /**
     * Gets the value of the allowBackendDelete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowBackendDelete() {
        return allowBackendDelete;
    }

    /**
     * Sets the value of the allowBackendDelete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowBackendDelete(String value) {
        this.allowBackendDelete = value;
    }

    /**
     * Gets the value of the allowBackendStat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowBackendStat() {
        return allowBackendStat;
    }

    /**
     * Sets the value of the allowBackendStat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowBackendStat(String value) {
        this.allowBackendStat = value;
    }

    /**
     * Gets the value of the allowBackendMkdir property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowBackendMkdir() {
        return allowBackendMkdir;
    }

    /**
     * Sets the value of the allowBackendMkdir property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowBackendMkdir(String value) {
        this.allowBackendMkdir = value;
    }

    /**
     * Gets the value of the allowBackendRmdir property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowBackendRmdir() {
        return allowBackendRmdir;
    }

    /**
     * Sets the value of the allowBackendRmdir property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowBackendRmdir(String value) {
        this.allowBackendRmdir = value;
    }

    /**
     * Gets the value of the allowBackendRename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowBackendRename() {
        return allowBackendRename;
    }

    /**
     * Sets the value of the allowBackendRename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowBackendRename(String value) {
        this.allowBackendRename = value;
    }

    /**
     * Gets the value of the aaaPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAAAPolicy() {
        return aaaPolicy;
    }

    /**
     * Sets the value of the aaaPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAAAPolicy(DmReference value) {
        this.aaaPolicy = value;
    }

    /**
     * Gets the value of the filesystemType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilesystemType() {
        return filesystemType;
    }

    /**
     * Sets the value of the filesystemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilesystemType(String value) {
        this.filesystemType = value;
    }

    /**
     * Gets the value of the defaultDirectory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultDirectory() {
        return defaultDirectory;
    }

    /**
     * Sets the value of the defaultDirectory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultDirectory(String value) {
        this.defaultDirectory = value;
    }

    /**
     * Gets the value of the idleTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdleTimeout() {
        return idleTimeout;
    }

    /**
     * Sets the value of the idleTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdleTimeout(String value) {
        this.idleTimeout = value;
    }

    /**
     * Gets the value of the persistentFilesystemTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersistentFilesystemTimeout() {
        return persistentFilesystemTimeout;
    }

    /**
     * Sets the value of the persistentFilesystemTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersistentFilesystemTimeout(String value) {
        this.persistentFilesystemTimeout = value;
    }

    /**
     * Gets the value of the virtualDirectories property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the virtualDirectories property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVirtualDirectories().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmSFTPServerVirtualDirectory }
     * 
     * 
     */
    public List<DmSFTPServerVirtualDirectory> getVirtualDirectories() {
        if (virtualDirectories == null) {
            virtualDirectories = new ArrayList<DmSFTPServerVirtualDirectory>();
        }
        return this.virtualDirectories;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
