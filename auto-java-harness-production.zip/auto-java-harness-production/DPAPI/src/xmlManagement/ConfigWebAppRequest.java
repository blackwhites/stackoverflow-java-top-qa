
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigWebAppRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigWebAppRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PolicyType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSatisfactionPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmARDType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AAA" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SSKey" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="RateLimiter" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ACL" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="OKMethods" type="{http://www.datapower.com/schemas/management}dmHTTPRequestMethods" minOccurs="0"/&gt;
 *         &lt;element name="OKVersions" type="{http://www.datapower.com/schemas/management}dmHTTPVersionMask" minOccurs="0"/&gt;
 *         &lt;element name="MinBodySize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxBodySize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWebAppXMLPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLRule" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="NonXMLPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmWebAppNonXMLPolicy {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NonXMLRule" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ErrorPolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SessionManagementProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="HeaderGNVC" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="UrlEncodedGNVC" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="QueryStringPolicy" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmARDType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="QueryStringGNVC" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="SQLInjection" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxURISize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="URIFilterUnicode" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="URIFilterDotDot" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="URIFilterExe" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="URIFilterFragment" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURIFragmentFixupType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ContentTypes" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MultipartFormData" type="{http://www.datapower.com/schemas/management}dmMultipartFormDataProfile" minOccurs="0"/&gt;
 *         &lt;element name="CookieProfile" type="{http://www.datapower.com/schemas/management}dmCookieProfile" minOccurs="0"/&gt;
 *         &lt;element name="ProcessAllCookie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CookieNameVector" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SQLInjectionPatternsFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmFSFile {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigWebAppRequest", propOrder = {
    "userSummary",
    "policyType",
    "sslPolicy",
    "aaa",
    "ssKey",
    "rateLimiter",
    "acl",
    "okMethods",
    "okVersions",
    "minBodySize",
    "maxBodySize",
    "xmlPolicy",
    "xmlRule",
    "nonXMLPolicy",
    "nonXMLRule",
    "errorPolicy",
    "sessionManagementProfile",
    "headerGNVC",
    "urlEncodedGNVC",
    "queryStringPolicy",
    "queryStringGNVC",
    "sqlInjection",
    "maxURISize",
    "uriFilterUnicode",
    "uriFilterDotDot",
    "uriFilterExe",
    "uriFilterFragment",
    "contentTypes",
    "multipartFormData",
    "cookieProfile",
    "processAllCookie",
    "cookieNameVector",
    "sqlInjectionPatternsFile"
})
public class ConfigWebAppRequest
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "PolicyType")
    protected String policyType;
    @XmlElement(name = "SSLPolicy")
    protected String sslPolicy;
    @XmlElement(name = "AAA")
    protected DmReference aaa;
    @XmlElement(name = "SSKey")
    protected DmReference ssKey;
    @XmlElement(name = "RateLimiter")
    protected DmReference rateLimiter;
    @XmlElement(name = "ACL")
    protected DmReference acl;
    @XmlElement(name = "OKMethods")
    protected DmHTTPRequestMethods okMethods;
    @XmlElement(name = "OKVersions")
    protected DmHTTPVersionMask okVersions;
    @XmlElement(name = "MinBodySize")
    protected String minBodySize;
    @XmlElement(name = "MaxBodySize")
    protected String maxBodySize;
    @XmlElement(name = "XMLPolicy")
    protected String xmlPolicy;
    @XmlElement(name = "XMLRule")
    protected DmReference xmlRule;
    @XmlElement(name = "NonXMLPolicy")
    protected String nonXMLPolicy;
    @XmlElement(name = "NonXMLRule")
    protected DmReference nonXMLRule;
    @XmlElement(name = "ErrorPolicy")
    protected DmReference errorPolicy;
    @XmlElement(name = "SessionManagementProfile")
    protected DmReference sessionManagementProfile;
    @XmlElement(name = "HeaderGNVC")
    protected DmReference headerGNVC;
    @XmlElement(name = "UrlEncodedGNVC")
    protected DmReference urlEncodedGNVC;
    @XmlElement(name = "QueryStringPolicy")
    protected String queryStringPolicy;
    @XmlElement(name = "QueryStringGNVC")
    protected DmReference queryStringGNVC;
    @XmlElement(name = "SQLInjection")
    protected String sqlInjection;
    @XmlElement(name = "MaxURISize")
    protected String maxURISize;
    @XmlElement(name = "URIFilterUnicode")
    protected String uriFilterUnicode;
    @XmlElement(name = "URIFilterDotDot")
    protected String uriFilterDotDot;
    @XmlElement(name = "URIFilterExe")
    protected String uriFilterExe;
    @XmlElement(name = "URIFilterFragment")
    protected String uriFilterFragment;
    @XmlElement(name = "ContentTypes")
    protected List<String> contentTypes;
    @XmlElement(name = "MultipartFormData")
    protected DmMultipartFormDataProfile multipartFormData;
    @XmlElement(name = "CookieProfile")
    protected DmCookieProfile cookieProfile;
    @XmlElement(name = "ProcessAllCookie")
    protected String processAllCookie;
    @XmlElement(name = "CookieNameVector")
    protected List<String> cookieNameVector;
    @XmlElement(name = "SQLInjectionPatternsFile")
    protected String sqlInjectionPatternsFile;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the policyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyType() {
        return policyType;
    }

    /**
     * Sets the value of the policyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyType(String value) {
        this.policyType = value;
    }

    /**
     * Gets the value of the sslPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLPolicy() {
        return sslPolicy;
    }

    /**
     * Sets the value of the sslPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLPolicy(String value) {
        this.sslPolicy = value;
    }

    /**
     * Gets the value of the aaa property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getAAA() {
        return aaa;
    }

    /**
     * Sets the value of the aaa property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setAAA(DmReference value) {
        this.aaa = value;
    }

    /**
     * Gets the value of the ssKey property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSKey() {
        return ssKey;
    }

    /**
     * Sets the value of the ssKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSKey(DmReference value) {
        this.ssKey = value;
    }

    /**
     * Gets the value of the rateLimiter property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getRateLimiter() {
        return rateLimiter;
    }

    /**
     * Sets the value of the rateLimiter property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setRateLimiter(DmReference value) {
        this.rateLimiter = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getACL() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setACL(DmReference value) {
        this.acl = value;
    }

    /**
     * Gets the value of the okMethods property.
     * 
     * @return
     *     possible object is
     *     {@link DmHTTPRequestMethods }
     *     
     */
    public DmHTTPRequestMethods getOKMethods() {
        return okMethods;
    }

    /**
     * Sets the value of the okMethods property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmHTTPRequestMethods }
     *     
     */
    public void setOKMethods(DmHTTPRequestMethods value) {
        this.okMethods = value;
    }

    /**
     * Gets the value of the okVersions property.
     * 
     * @return
     *     possible object is
     *     {@link DmHTTPVersionMask }
     *     
     */
    public DmHTTPVersionMask getOKVersions() {
        return okVersions;
    }

    /**
     * Sets the value of the okVersions property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmHTTPVersionMask }
     *     
     */
    public void setOKVersions(DmHTTPVersionMask value) {
        this.okVersions = value;
    }

    /**
     * Gets the value of the minBodySize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinBodySize() {
        return minBodySize;
    }

    /**
     * Sets the value of the minBodySize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinBodySize(String value) {
        this.minBodySize = value;
    }

    /**
     * Gets the value of the maxBodySize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxBodySize() {
        return maxBodySize;
    }

    /**
     * Sets the value of the maxBodySize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxBodySize(String value) {
        this.maxBodySize = value;
    }

    /**
     * Gets the value of the xmlPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXMLPolicy() {
        return xmlPolicy;
    }

    /**
     * Sets the value of the xmlPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXMLPolicy(String value) {
        this.xmlPolicy = value;
    }

    /**
     * Gets the value of the xmlRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLRule() {
        return xmlRule;
    }

    /**
     * Sets the value of the xmlRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLRule(DmReference value) {
        this.xmlRule = value;
    }

    /**
     * Gets the value of the nonXMLPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonXMLPolicy() {
        return nonXMLPolicy;
    }

    /**
     * Sets the value of the nonXMLPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonXMLPolicy(String value) {
        this.nonXMLPolicy = value;
    }

    /**
     * Gets the value of the nonXMLRule property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getNonXMLRule() {
        return nonXMLRule;
    }

    /**
     * Sets the value of the nonXMLRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setNonXMLRule(DmReference value) {
        this.nonXMLRule = value;
    }

    /**
     * Gets the value of the errorPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getErrorPolicy() {
        return errorPolicy;
    }

    /**
     * Sets the value of the errorPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setErrorPolicy(DmReference value) {
        this.errorPolicy = value;
    }

    /**
     * Gets the value of the sessionManagementProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSessionManagementProfile() {
        return sessionManagementProfile;
    }

    /**
     * Sets the value of the sessionManagementProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSessionManagementProfile(DmReference value) {
        this.sessionManagementProfile = value;
    }

    /**
     * Gets the value of the headerGNVC property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getHeaderGNVC() {
        return headerGNVC;
    }

    /**
     * Sets the value of the headerGNVC property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setHeaderGNVC(DmReference value) {
        this.headerGNVC = value;
    }

    /**
     * Gets the value of the urlEncodedGNVC property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getUrlEncodedGNVC() {
        return urlEncodedGNVC;
    }

    /**
     * Sets the value of the urlEncodedGNVC property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setUrlEncodedGNVC(DmReference value) {
        this.urlEncodedGNVC = value;
    }

    /**
     * Gets the value of the queryStringPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueryStringPolicy() {
        return queryStringPolicy;
    }

    /**
     * Sets the value of the queryStringPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueryStringPolicy(String value) {
        this.queryStringPolicy = value;
    }

    /**
     * Gets the value of the queryStringGNVC property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getQueryStringGNVC() {
        return queryStringGNVC;
    }

    /**
     * Sets the value of the queryStringGNVC property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setQueryStringGNVC(DmReference value) {
        this.queryStringGNVC = value;
    }

    /**
     * Gets the value of the sqlInjection property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSQLInjection() {
        return sqlInjection;
    }

    /**
     * Sets the value of the sqlInjection property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSQLInjection(String value) {
        this.sqlInjection = value;
    }

    /**
     * Gets the value of the maxURISize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxURISize() {
        return maxURISize;
    }

    /**
     * Sets the value of the maxURISize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxURISize(String value) {
        this.maxURISize = value;
    }

    /**
     * Gets the value of the uriFilterUnicode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURIFilterUnicode() {
        return uriFilterUnicode;
    }

    /**
     * Sets the value of the uriFilterUnicode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURIFilterUnicode(String value) {
        this.uriFilterUnicode = value;
    }

    /**
     * Gets the value of the uriFilterDotDot property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURIFilterDotDot() {
        return uriFilterDotDot;
    }

    /**
     * Sets the value of the uriFilterDotDot property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURIFilterDotDot(String value) {
        this.uriFilterDotDot = value;
    }

    /**
     * Gets the value of the uriFilterExe property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURIFilterExe() {
        return uriFilterExe;
    }

    /**
     * Sets the value of the uriFilterExe property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURIFilterExe(String value) {
        this.uriFilterExe = value;
    }

    /**
     * Gets the value of the uriFilterFragment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getURIFilterFragment() {
        return uriFilterFragment;
    }

    /**
     * Sets the value of the uriFilterFragment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setURIFilterFragment(String value) {
        this.uriFilterFragment = value;
    }

    /**
     * Gets the value of the contentTypes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contentTypes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContentTypes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getContentTypes() {
        if (contentTypes == null) {
            contentTypes = new ArrayList<String>();
        }
        return this.contentTypes;
    }

    /**
     * Gets the value of the multipartFormData property.
     * 
     * @return
     *     possible object is
     *     {@link DmMultipartFormDataProfile }
     *     
     */
    public DmMultipartFormDataProfile getMultipartFormData() {
        return multipartFormData;
    }

    /**
     * Sets the value of the multipartFormData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmMultipartFormDataProfile }
     *     
     */
    public void setMultipartFormData(DmMultipartFormDataProfile value) {
        this.multipartFormData = value;
    }

    /**
     * Gets the value of the cookieProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmCookieProfile }
     *     
     */
    public DmCookieProfile getCookieProfile() {
        return cookieProfile;
    }

    /**
     * Sets the value of the cookieProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmCookieProfile }
     *     
     */
    public void setCookieProfile(DmCookieProfile value) {
        this.cookieProfile = value;
    }

    /**
     * Gets the value of the processAllCookie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessAllCookie() {
        return processAllCookie;
    }

    /**
     * Sets the value of the processAllCookie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessAllCookie(String value) {
        this.processAllCookie = value;
    }

    /**
     * Gets the value of the cookieNameVector property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cookieNameVector property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCookieNameVector().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCookieNameVector() {
        if (cookieNameVector == null) {
            cookieNameVector = new ArrayList<String>();
        }
        return this.cookieNameVector;
    }

    /**
     * Gets the value of the sqlInjectionPatternsFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSQLInjectionPatternsFile() {
        return sqlInjectionPatternsFile;
    }

    /**
     * Sets the value of the sqlInjectionPatternsFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSQLInjectionPatternsFile(String value) {
        this.sqlInjectionPatternsFile = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
