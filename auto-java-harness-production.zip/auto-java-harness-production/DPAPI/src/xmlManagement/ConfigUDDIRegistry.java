
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigUDDIRegistry complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigUDDIRegistry"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IPAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Port"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="UseSSL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUDDIUseSSL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLPort" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="InquiryURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PublishURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SubscriptionURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SecurityURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Version" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUDDIVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigUDDIRegistry", propOrder = {
    "userSummary",
    "ipAddress",
    "port",
    "useSSL",
    "sslPort",
    "sslProxyProfile",
    "inquiryURL",
    "publishURL",
    "subscriptionURL",
    "securityURL",
    "version",
    "sslClientConfigType",
    "sslClient"
})
public class ConfigUDDIRegistry
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "Port")
    protected String port;
    @XmlElement(name = "UseSSL")
    protected String useSSL;
    @XmlElement(name = "SSLPort")
    protected String sslPort;
    @XmlElement(name = "SSLProxyProfile")
    protected DmReference sslProxyProfile;
    @XmlElement(name = "InquiryURL")
    protected String inquiryURL;
    @XmlElement(name = "PublishURL")
    protected String publishURL;
    @XmlElement(name = "SubscriptionURL")
    protected String subscriptionURL;
    @XmlElement(name = "SecurityURL")
    protected String securityURL;
    @XmlElement(name = "Version")
    protected String version;
    @XmlElement(name = "SSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType sslClientConfigType;
    @XmlElement(name = "SSLClient")
    protected DmReference sslClient;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the port property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPort() {
        return port;
    }

    /**
     * Sets the value of the port property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPort(String value) {
        this.port = value;
    }

    /**
     * Gets the value of the useSSL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseSSL() {
        return useSSL;
    }

    /**
     * Sets the value of the useSSL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseSSL(String value) {
        this.useSSL = value;
    }

    /**
     * Gets the value of the sslPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSLPort() {
        return sslPort;
    }

    /**
     * Sets the value of the sslPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSLPort(String value) {
        this.sslPort = value;
    }

    /**
     * Gets the value of the sslProxyProfile property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxyProfile() {
        return sslProxyProfile;
    }

    /**
     * Sets the value of the sslProxyProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxyProfile(DmReference value) {
        this.sslProxyProfile = value;
    }

    /**
     * Gets the value of the inquiryURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInquiryURL() {
        return inquiryURL;
    }

    /**
     * Sets the value of the inquiryURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInquiryURL(String value) {
        this.inquiryURL = value;
    }

    /**
     * Gets the value of the publishURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublishURL() {
        return publishURL;
    }

    /**
     * Sets the value of the publishURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublishURL(String value) {
        this.publishURL = value;
    }

    /**
     * Gets the value of the subscriptionURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptionURL() {
        return subscriptionURL;
    }

    /**
     * Sets the value of the subscriptionURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptionURL(String value) {
        this.subscriptionURL = value;
    }

    /**
     * Gets the value of the securityURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecurityURL() {
        return securityURL;
    }

    /**
     * Sets the value of the securityURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecurityURL(String value) {
        this.securityURL = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Gets the value of the sslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getSSLClientConfigType() {
        return sslClientConfigType;
    }

    /**
     * Sets the value of the sslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setSSLClientConfigType(DmSSLClientConfigType value) {
        this.sslClientConfigType = value;
    }

    /**
     * Gets the value of the sslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClient() {
        return sslClient;
    }

    /**
     * Sets the value of the sslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClient(DmReference value) {
        this.sslClient = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
