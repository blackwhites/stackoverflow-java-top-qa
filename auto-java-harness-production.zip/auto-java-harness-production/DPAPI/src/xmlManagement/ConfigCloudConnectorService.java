
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigCloudConnectorService complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigCloudConnectorService"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmLocalIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Priority" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSchedulerPriority {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LocalPort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ServiceName"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemotePort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLProxy" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="FrontTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BackTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ConnTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmTimeInterval {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ConnLimit"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigCloudConnectorService", propOrder = {
    "userSummary",
    "localAddress",
    "priority",
    "localPort",
    "serviceName",
    "remoteAddress",
    "remotePort",
    "sslProxy",
    "frontTimeout",
    "backTimeout",
    "connTimeout",
    "connLimit"
})
public class ConfigCloudConnectorService
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "LocalAddress")
    protected String localAddress;
    @XmlElement(name = "Priority")
    protected String priority;
    @XmlElement(name = "LocalPort")
    protected String localPort;
    @XmlElement(name = "ServiceName")
    protected String serviceName;
    @XmlElement(name = "RemoteAddress")
    protected String remoteAddress;
    @XmlElement(name = "RemotePort")
    protected String remotePort;
    @XmlElement(name = "SSLProxy")
    protected DmReference sslProxy;
    @XmlElement(name = "FrontTimeout")
    protected String frontTimeout;
    @XmlElement(name = "BackTimeout")
    protected String backTimeout;
    @XmlElement(name = "ConnTimeout")
    protected String connTimeout;
    @XmlElement(name = "ConnLimit")
    protected String connLimit;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the localAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalAddress() {
        return localAddress;
    }

    /**
     * Sets the value of the localAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalAddress(String value) {
        this.localAddress = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the localPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalPort() {
        return localPort;
    }

    /**
     * Sets the value of the localPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalPort(String value) {
        this.localPort = value;
    }

    /**
     * Gets the value of the serviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the value of the serviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceName(String value) {
        this.serviceName = value;
    }

    /**
     * Gets the value of the remoteAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteAddress() {
        return remoteAddress;
    }

    /**
     * Sets the value of the remoteAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteAddress(String value) {
        this.remoteAddress = value;
    }

    /**
     * Gets the value of the remotePort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemotePort() {
        return remotePort;
    }

    /**
     * Sets the value of the remotePort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemotePort(String value) {
        this.remotePort = value;
    }

    /**
     * Gets the value of the sslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxy() {
        return sslProxy;
    }

    /**
     * Sets the value of the sslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxy(DmReference value) {
        this.sslProxy = value;
    }

    /**
     * Gets the value of the frontTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrontTimeout() {
        return frontTimeout;
    }

    /**
     * Sets the value of the frontTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrontTimeout(String value) {
        this.frontTimeout = value;
    }

    /**
     * Gets the value of the backTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackTimeout() {
        return backTimeout;
    }

    /**
     * Sets the value of the backTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackTimeout(String value) {
        this.backTimeout = value;
    }

    /**
     * Gets the value of the connTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConnTimeout() {
        return connTimeout;
    }

    /**
     * Sets the value of the connTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConnTimeout(String value) {
        this.connTimeout = value;
    }

    /**
     * Gets the value of the connLimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConnLimit() {
        return connLimit;
    }

    /**
     * Sets the value of the connLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConnLimit(String value) {
        this.connLimit = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
