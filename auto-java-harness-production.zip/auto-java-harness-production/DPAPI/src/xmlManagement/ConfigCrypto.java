
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigCrypto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigCrypto"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigCrypto")
@XmlSeeAlso({
    ConfigAAAJWTGenerator.class,
    ConfigAAAJWTValidator.class,
    ConfigCertMonitor.class,
    ConfigCookieAttributePolicy.class,
    ConfigCRLFetch.class,
    ConfigCryptoCertificate.class,
    ConfigCryptoFWCred.class,
    ConfigCryptoIdentCred.class,
    ConfigCryptoKerberosKDC.class,
    ConfigCryptoKerberosKeytab.class,
    ConfigCryptoKey.class,
    ConfigCryptoProfile.class,
    ConfigCryptoSSKey.class,
    ConfigCryptoValCred.class,
    ConfigJOSERecipientIdentifier.class,
    ConfigJOSESignatureIdentifier.class,
    ConfigJWEHeader.class,
    ConfigJWERecipient.class,
    ConfigJWSSignature.class,
    ConfigOAuthSupportedClient.class,
    ConfigOAuthSupportedClientGroup.class,
    ConfigSocialLoginPolicy.class,
    ConfigSSHClientProfile.class,
    ConfigSSHDomainClientProfile.class,
    ConfigSSHServerProfile.class,
    ConfigSSLClientProfile.class,
    ConfigSSLProxyProfile.class,
    ConfigSSLServerProfile.class,
    ConfigSSLSNIMapping.class,
    ConfigSSLSNIServerProfile.class
})
public class ConfigCrypto
    extends ConfigConfigBase
{


}
