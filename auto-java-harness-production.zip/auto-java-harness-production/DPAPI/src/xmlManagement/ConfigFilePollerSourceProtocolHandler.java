
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigFilePollerSourceProtocolHandler complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigFilePollerSourceProtocolHandler"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigSourceProtocolHandler"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TargetDirectory"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DelayBetweenPolls"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InputFileMatchPattern"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProcessingRenamePattern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DeleteOnSuccess" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuccessRenamePattern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DeleteOnError" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ErrorRenamePattern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="GenerateResultFile" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResultNamePattern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProcessingSeizeTimeout"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProcessingSeizePattern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPCRE {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="MaxTransfersPerPoll" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigFilePollerSourceProtocolHandler", propOrder = {
    "userSummary",
    "targetDirectory",
    "delayBetweenPolls",
    "inputFileMatchPattern",
    "processingRenamePattern",
    "deleteOnSuccess",
    "successRenamePattern",
    "deleteOnError",
    "errorRenamePattern",
    "generateResultFile",
    "resultNamePattern",
    "processingSeizeTimeout",
    "processingSeizePattern",
    "xmlManager",
    "maxTransfersPerPoll"
})
@XmlSeeAlso({
    ConfigFTPFilePollerSourceProtocolHandler.class,
    ConfigNFSFilePollerSourceProtocolHandler.class,
    ConfigSFTPFilePollerSourceProtocolHandler.class
})
public class ConfigFilePollerSourceProtocolHandler
    extends ConfigSourceProtocolHandler
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "TargetDirectory")
    protected String targetDirectory;
    @XmlElement(name = "DelayBetweenPolls")
    protected String delayBetweenPolls;
    @XmlElement(name = "InputFileMatchPattern")
    protected String inputFileMatchPattern;
    @XmlElement(name = "ProcessingRenamePattern")
    protected String processingRenamePattern;
    @XmlElement(name = "DeleteOnSuccess")
    protected String deleteOnSuccess;
    @XmlElement(name = "SuccessRenamePattern")
    protected String successRenamePattern;
    @XmlElement(name = "DeleteOnError")
    protected String deleteOnError;
    @XmlElement(name = "ErrorRenamePattern")
    protected String errorRenamePattern;
    @XmlElement(name = "GenerateResultFile")
    protected String generateResultFile;
    @XmlElement(name = "ResultNamePattern")
    protected String resultNamePattern;
    @XmlElement(name = "ProcessingSeizeTimeout")
    protected String processingSeizeTimeout;
    @XmlElement(name = "ProcessingSeizePattern")
    protected String processingSeizePattern;
    @XmlElement(name = "XMLManager")
    protected DmReference xmlManager;
    @XmlElement(name = "MaxTransfersPerPoll")
    protected String maxTransfersPerPoll;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the targetDirectory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetDirectory() {
        return targetDirectory;
    }

    /**
     * Sets the value of the targetDirectory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetDirectory(String value) {
        this.targetDirectory = value;
    }

    /**
     * Gets the value of the delayBetweenPolls property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayBetweenPolls() {
        return delayBetweenPolls;
    }

    /**
     * Sets the value of the delayBetweenPolls property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayBetweenPolls(String value) {
        this.delayBetweenPolls = value;
    }

    /**
     * Gets the value of the inputFileMatchPattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputFileMatchPattern() {
        return inputFileMatchPattern;
    }

    /**
     * Sets the value of the inputFileMatchPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputFileMatchPattern(String value) {
        this.inputFileMatchPattern = value;
    }

    /**
     * Gets the value of the processingRenamePattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingRenamePattern() {
        return processingRenamePattern;
    }

    /**
     * Sets the value of the processingRenamePattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingRenamePattern(String value) {
        this.processingRenamePattern = value;
    }

    /**
     * Gets the value of the deleteOnSuccess property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeleteOnSuccess() {
        return deleteOnSuccess;
    }

    /**
     * Sets the value of the deleteOnSuccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeleteOnSuccess(String value) {
        this.deleteOnSuccess = value;
    }

    /**
     * Gets the value of the successRenamePattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuccessRenamePattern() {
        return successRenamePattern;
    }

    /**
     * Sets the value of the successRenamePattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuccessRenamePattern(String value) {
        this.successRenamePattern = value;
    }

    /**
     * Gets the value of the deleteOnError property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeleteOnError() {
        return deleteOnError;
    }

    /**
     * Sets the value of the deleteOnError property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeleteOnError(String value) {
        this.deleteOnError = value;
    }

    /**
     * Gets the value of the errorRenamePattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorRenamePattern() {
        return errorRenamePattern;
    }

    /**
     * Sets the value of the errorRenamePattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorRenamePattern(String value) {
        this.errorRenamePattern = value;
    }

    /**
     * Gets the value of the generateResultFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGenerateResultFile() {
        return generateResultFile;
    }

    /**
     * Sets the value of the generateResultFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGenerateResultFile(String value) {
        this.generateResultFile = value;
    }

    /**
     * Gets the value of the resultNamePattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResultNamePattern() {
        return resultNamePattern;
    }

    /**
     * Sets the value of the resultNamePattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResultNamePattern(String value) {
        this.resultNamePattern = value;
    }

    /**
     * Gets the value of the processingSeizeTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingSeizeTimeout() {
        return processingSeizeTimeout;
    }

    /**
     * Sets the value of the processingSeizeTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingSeizeTimeout(String value) {
        this.processingSeizeTimeout = value;
    }

    /**
     * Gets the value of the processingSeizePattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingSeizePattern() {
        return processingSeizePattern;
    }

    /**
     * Sets the value of the processingSeizePattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingSeizePattern(String value) {
        this.processingSeizePattern = value;
    }

    /**
     * Gets the value of the xmlManager property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getXMLManager() {
        return xmlManager;
    }

    /**
     * Sets the value of the xmlManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setXMLManager(DmReference value) {
        this.xmlManager = value;
    }

    /**
     * Gets the value of the maxTransfersPerPoll property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxTransfersPerPoll() {
        return maxTransfersPerPoll;
    }

    /**
     * Sets the value of the maxTransfersPerPoll property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxTransfersPerPoll(String value) {
        this.maxTransfersPerPoll = value;
    }

}
