
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigPolicyAttachments complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigPolicyAttachments"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EnforcementMode"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPolicyEnforcementMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PolicyReferences"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IgnoredPolicyAttachmentPoints" type="{http://www.datapower.com/schemas/management}dmPolicyAttachmentPoint" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExternalPolicy" type="{http://www.datapower.com/schemas/management}dmExternalAttachedPolicy" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SLAEnforcementMode"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSLAPolicyEnforcementMode {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigPolicyAttachments", propOrder = {
    "userSummary",
    "enforcementMode",
    "policyReferences",
    "ignoredPolicyAttachmentPoints",
    "externalPolicy",
    "slaEnforcementMode"
})
public class ConfigPolicyAttachments
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "EnforcementMode")
    protected String enforcementMode;
    @XmlElement(name = "PolicyReferences")
    protected String policyReferences;
    @XmlElement(name = "IgnoredPolicyAttachmentPoints")
    protected List<DmPolicyAttachmentPoint> ignoredPolicyAttachmentPoints;
    @XmlElement(name = "ExternalPolicy")
    protected List<DmExternalAttachedPolicy> externalPolicy;
    @XmlElement(name = "SLAEnforcementMode")
    protected String slaEnforcementMode;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the enforcementMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnforcementMode() {
        return enforcementMode;
    }

    /**
     * Sets the value of the enforcementMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnforcementMode(String value) {
        this.enforcementMode = value;
    }

    /**
     * Gets the value of the policyReferences property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyReferences() {
        return policyReferences;
    }

    /**
     * Sets the value of the policyReferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyReferences(String value) {
        this.policyReferences = value;
    }

    /**
     * Gets the value of the ignoredPolicyAttachmentPoints property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ignoredPolicyAttachmentPoints property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIgnoredPolicyAttachmentPoints().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmPolicyAttachmentPoint }
     * 
     * 
     */
    public List<DmPolicyAttachmentPoint> getIgnoredPolicyAttachmentPoints() {
        if (ignoredPolicyAttachmentPoints == null) {
            ignoredPolicyAttachmentPoints = new ArrayList<DmPolicyAttachmentPoint>();
        }
        return this.ignoredPolicyAttachmentPoints;
    }

    /**
     * Gets the value of the externalPolicy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the externalPolicy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExternalPolicy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmExternalAttachedPolicy }
     * 
     * 
     */
    public List<DmExternalAttachedPolicy> getExternalPolicy() {
        if (externalPolicy == null) {
            externalPolicy = new ArrayList<DmExternalAttachedPolicy>();
        }
        return this.externalPolicy;
    }

    /**
     * Gets the value of the slaEnforcementMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSLAEnforcementMode() {
        return slaEnforcementMode;
    }

    /**
     * Sets the value of the slaEnforcementMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSLAEnforcementMode(String value) {
        this.slaEnforcementMode = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
