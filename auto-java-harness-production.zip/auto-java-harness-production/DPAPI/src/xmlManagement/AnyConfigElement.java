
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnyConfigElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AnyConfigElement"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded"&gt;
 *         &lt;element name="AAAPolicy" type="{http://www.datapower.com/schemas/management}ConfigAAAPolicy"/&gt;
 *         &lt;element name="Domain" type="{http://www.datapower.com/schemas/management}ConfigDomain"/&gt;
 *         &lt;element name="LDAPSearchParameters" type="{http://www.datapower.com/schemas/management}ConfigLDAPSearchParameters"/&gt;
 *         &lt;element name="ProcessingMetadata" type="{http://www.datapower.com/schemas/management}ConfigProcessingMetadata"/&gt;
 *         &lt;element name="RADIUSSettings" type="{http://www.datapower.com/schemas/management}ConfigRADIUSSettings"/&gt;
 *         &lt;element name="RBMSettings" type="{http://www.datapower.com/schemas/management}ConfigRBMSettings"/&gt;
 *         &lt;element name="SAMLAttributes" type="{http://www.datapower.com/schemas/management}ConfigSAMLAttributes"/&gt;
 *         &lt;element name="SOAPHeaderDisposition" type="{http://www.datapower.com/schemas/management}ConfigSOAPHeaderDisposition"/&gt;
 *         &lt;element name="TAM" type="{http://www.datapower.com/schemas/management}ConfigTAM"/&gt;
 *         &lt;element name="TFIMEndpoint" type="{http://www.datapower.com/schemas/management}ConfigTFIMEndpoint"/&gt;
 *         &lt;element name="XACMLPDP" type="{http://www.datapower.com/schemas/management}ConfigXACMLPDP"/&gt;
 *         &lt;element name="AccessControlList" type="{http://www.datapower.com/schemas/management}ConfigAccessControlList"/&gt;
 *         &lt;element name="AppSecurityPolicy" type="{http://www.datapower.com/schemas/management}ConfigAppSecurityPolicy"/&gt;
 *         &lt;element name="AuditLog" type="{http://www.datapower.com/schemas/management}ConfigAuditLog"/&gt;
 *         &lt;element name="B2BCPA" type="{http://www.datapower.com/schemas/management}ConfigB2BCPA"/&gt;
 *         &lt;element name="B2BCPACollaboration" type="{http://www.datapower.com/schemas/management}ConfigB2BCPACollaboration"/&gt;
 *         &lt;element name="B2BCPAReceiverSetting" type="{http://www.datapower.com/schemas/management}ConfigB2BCPAReceiverSetting"/&gt;
 *         &lt;element name="B2BCPASenderSetting" type="{http://www.datapower.com/schemas/management}ConfigB2BCPASenderSetting"/&gt;
 *         &lt;element name="B2BGateway" type="{http://www.datapower.com/schemas/management}ConfigB2BGateway"/&gt;
 *         &lt;element name="B2BPersistence" type="{http://www.datapower.com/schemas/management}ConfigB2BPersistence"/&gt;
 *         &lt;element name="B2BProfile" type="{http://www.datapower.com/schemas/management}ConfigB2BProfile"/&gt;
 *         &lt;element name="B2BProfileGroup" type="{http://www.datapower.com/schemas/management}ConfigB2BProfileGroup"/&gt;
 *         &lt;element name="B2BXPathRoutingPolicy" type="{http://www.datapower.com/schemas/management}ConfigB2BXPathRoutingPolicy"/&gt;
 *         &lt;element name="WXSGrid" type="{http://www.datapower.com/schemas/management}ConfigWXSGrid"/&gt;
 *         &lt;element name="XC10Grid" type="{http://www.datapower.com/schemas/management}ConfigXC10Grid"/&gt;
 *         &lt;element name="CloudConnectorService" type="{http://www.datapower.com/schemas/management}ConfigCloudConnectorService"/&gt;
 *         &lt;element name="CloudGatewayService" type="{http://www.datapower.com/schemas/management}ConfigCloudGatewayService"/&gt;
 *         &lt;element name="CompactFlash" type="{http://www.datapower.com/schemas/management}ConfigCompactFlash"/&gt;
 *         &lt;element name="CompileOptionsPolicy" type="{http://www.datapower.com/schemas/management}ConfigCompileOptionsPolicy"/&gt;
 *         &lt;element name="ConfigDeploymentPolicy" type="{http://www.datapower.com/schemas/management}ConfigConfigDeploymentPolicy"/&gt;
 *         &lt;element name="ConformancePolicy" type="{http://www.datapower.com/schemas/management}ConfigConformancePolicy"/&gt;
 *         &lt;element name="AAAJWTGenerator" type="{http://www.datapower.com/schemas/management}ConfigAAAJWTGenerator"/&gt;
 *         &lt;element name="AAAJWTValidator" type="{http://www.datapower.com/schemas/management}ConfigAAAJWTValidator"/&gt;
 *         &lt;element name="CertMonitor" type="{http://www.datapower.com/schemas/management}ConfigCertMonitor"/&gt;
 *         &lt;element name="CookieAttributePolicy" type="{http://www.datapower.com/schemas/management}ConfigCookieAttributePolicy"/&gt;
 *         &lt;element name="CRLFetch" type="{http://www.datapower.com/schemas/management}ConfigCRLFetch"/&gt;
 *         &lt;element name="CryptoCertificate" type="{http://www.datapower.com/schemas/management}ConfigCryptoCertificate"/&gt;
 *         &lt;element name="CryptoFWCred" type="{http://www.datapower.com/schemas/management}ConfigCryptoFWCred"/&gt;
 *         &lt;element name="CryptoIdentCred" type="{http://www.datapower.com/schemas/management}ConfigCryptoIdentCred"/&gt;
 *         &lt;element name="CryptoKerberosKDC" type="{http://www.datapower.com/schemas/management}ConfigCryptoKerberosKDC"/&gt;
 *         &lt;element name="CryptoKerberosKeytab" type="{http://www.datapower.com/schemas/management}ConfigCryptoKerberosKeytab"/&gt;
 *         &lt;element name="CryptoKey" type="{http://www.datapower.com/schemas/management}ConfigCryptoKey"/&gt;
 *         &lt;element name="CryptoProfile" type="{http://www.datapower.com/schemas/management}ConfigCryptoProfile"/&gt;
 *         &lt;element name="CryptoSSKey" type="{http://www.datapower.com/schemas/management}ConfigCryptoSSKey"/&gt;
 *         &lt;element name="CryptoValCred" type="{http://www.datapower.com/schemas/management}ConfigCryptoValCred"/&gt;
 *         &lt;element name="JOSERecipientIdentifier" type="{http://www.datapower.com/schemas/management}ConfigJOSERecipientIdentifier"/&gt;
 *         &lt;element name="JOSESignatureIdentifier" type="{http://www.datapower.com/schemas/management}ConfigJOSESignatureIdentifier"/&gt;
 *         &lt;element name="JWEHeader" type="{http://www.datapower.com/schemas/management}ConfigJWEHeader"/&gt;
 *         &lt;element name="JWERecipient" type="{http://www.datapower.com/schemas/management}ConfigJWERecipient"/&gt;
 *         &lt;element name="JWSSignature" type="{http://www.datapower.com/schemas/management}ConfigJWSSignature"/&gt;
 *         &lt;element name="OAuthSupportedClient" type="{http://www.datapower.com/schemas/management}ConfigOAuthSupportedClient"/&gt;
 *         &lt;element name="OAuthSupportedClientGroup" type="{http://www.datapower.com/schemas/management}ConfigOAuthSupportedClientGroup"/&gt;
 *         &lt;element name="SocialLoginPolicy" type="{http://www.datapower.com/schemas/management}ConfigSocialLoginPolicy"/&gt;
 *         &lt;element name="SSHClientProfile" type="{http://www.datapower.com/schemas/management}ConfigSSHClientProfile"/&gt;
 *         &lt;element name="SSHDomainClientProfile" type="{http://www.datapower.com/schemas/management}ConfigSSHDomainClientProfile"/&gt;
 *         &lt;element name="SSHServerProfile" type="{http://www.datapower.com/schemas/management}ConfigSSHServerProfile"/&gt;
 *         &lt;element name="SSLClientProfile" type="{http://www.datapower.com/schemas/management}ConfigSSLClientProfile"/&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}ConfigSSLProxyProfile"/&gt;
 *         &lt;element name="SSLServerProfile" type="{http://www.datapower.com/schemas/management}ConfigSSLServerProfile"/&gt;
 *         &lt;element name="SSLSNIMapping" type="{http://www.datapower.com/schemas/management}ConfigSSLSNIMapping"/&gt;
 *         &lt;element name="SSLSNIServerProfile" type="{http://www.datapower.com/schemas/management}ConfigSSLSNIServerProfile"/&gt;
 *         &lt;element name="DeploymentPolicyParametersBinding" type="{http://www.datapower.com/schemas/management}ConfigDeploymentPolicyParametersBinding"/&gt;
 *         &lt;element name="ErrorReportSettings" type="{http://www.datapower.com/schemas/management}ConfigErrorReportSettings"/&gt;
 *         &lt;element name="SystemSettings" type="{http://www.datapower.com/schemas/management}ConfigSystemSettings"/&gt;
 *         &lt;element name="TimeSettings" type="{http://www.datapower.com/schemas/management}ConfigTimeSettings"/&gt;
 *         &lt;element name="DFDLSettings" type="{http://www.datapower.com/schemas/management}ConfigDFDLSettings"/&gt;
 *         &lt;element name="DomainAvailability" type="{http://www.datapower.com/schemas/management}ConfigDomainAvailability"/&gt;
 *         &lt;element name="DomainSettings" type="{http://www.datapower.com/schemas/management}ConfigDomainSettings"/&gt;
 *         &lt;element name="SchemaExceptionMap" type="{http://www.datapower.com/schemas/management}ConfigSchemaExceptionMap"/&gt;
 *         &lt;element name="DocumentCryptoMap" type="{http://www.datapower.com/schemas/management}ConfigDocumentCryptoMap"/&gt;
 *         &lt;element name="XPathRoutingMap" type="{http://www.datapower.com/schemas/management}ConfigXPathRoutingMap"/&gt;
 *         &lt;element name="LogTarget" type="{http://www.datapower.com/schemas/management}ConfigLogTarget"/&gt;
 *         &lt;element name="FormsLoginPolicy" type="{http://www.datapower.com/schemas/management}ConfigFormsLoginPolicy"/&gt;
 *         &lt;element name="FTPQuoteCommands" type="{http://www.datapower.com/schemas/management}ConfigFTPQuoteCommands"/&gt;
 *         &lt;element name="MultiProtocolGateway" type="{http://www.datapower.com/schemas/management}ConfigMultiProtocolGateway"/&gt;
 *         &lt;element name="WSGateway" type="{http://www.datapower.com/schemas/management}ConfigWSGateway"/&gt;
 *         &lt;element name="GeneratedPolicy" type="{http://www.datapower.com/schemas/management}ConfigGeneratedPolicy"/&gt;
 *         &lt;element name="HTTPInputConversionMap" type="{http://www.datapower.com/schemas/management}ConfigHTTPInputConversionMap"/&gt;
 *         &lt;element name="HTTPUserAgent" type="{http://www.datapower.com/schemas/management}ConfigHTTPUserAgent"/&gt;
 *         &lt;element name="ILMTAgent" type="{http://www.datapower.com/schemas/management}ConfigILMTAgent"/&gt;
 *         &lt;element name="ImportPackage" type="{http://www.datapower.com/schemas/management}ConfigImportPackage"/&gt;
 *         &lt;element name="IMSConnect" type="{http://www.datapower.com/schemas/management}ConfigIMSConnect"/&gt;
 *         &lt;element name="IncludeConfig" type="{http://www.datapower.com/schemas/management}ConfigIncludeConfig"/&gt;
 *         &lt;element name="InteropService" type="{http://www.datapower.com/schemas/management}ConfigInteropService"/&gt;
 *         &lt;element name="EthernetInterface" type="{http://www.datapower.com/schemas/management}ConfigEthernetInterface"/&gt;
 *         &lt;element name="LinkAggregation" type="{http://www.datapower.com/schemas/management}ConfigLinkAggregation"/&gt;
 *         &lt;element name="VLANInterface" type="{http://www.datapower.com/schemas/management}ConfigVLANInterface"/&gt;
 *         &lt;element name="IPMILanChannel" type="{http://www.datapower.com/schemas/management}ConfigIPMILanChannel"/&gt;
 *         &lt;element name="IPMIUser" type="{http://www.datapower.com/schemas/management}ConfigIPMIUser"/&gt;
 *         &lt;element name="IPMulticast" type="{http://www.datapower.com/schemas/management}ConfigIPMulticast"/&gt;
 *         &lt;element name="ISAMReverseProxy" type="{http://www.datapower.com/schemas/management}ConfigISAMReverseProxy"/&gt;
 *         &lt;element name="ISAMReverseProxyJunction" type="{http://www.datapower.com/schemas/management}ConfigISAMReverseProxyJunction"/&gt;
 *         &lt;element name="ISAMRuntime" type="{http://www.datapower.com/schemas/management}ConfigISAMRuntime"/&gt;
 *         &lt;element name="IScsiChapConfig" type="{http://www.datapower.com/schemas/management}ConfigIScsiChapConfig"/&gt;
 *         &lt;element name="IScsiHBAConfig" type="{http://www.datapower.com/schemas/management}ConfigIScsiHBAConfig"/&gt;
 *         &lt;element name="IScsiInitiatorConfig" type="{http://www.datapower.com/schemas/management}ConfigIScsiInitiatorConfig"/&gt;
 *         &lt;element name="IScsiTargetConfig" type="{http://www.datapower.com/schemas/management}ConfigIScsiTargetConfig"/&gt;
 *         &lt;element name="IScsiVolumeConfig" type="{http://www.datapower.com/schemas/management}ConfigIScsiVolumeConfig"/&gt;
 *         &lt;element name="TibcoEMSServer" type="{http://www.datapower.com/schemas/management}ConfigTibcoEMSServer"/&gt;
 *         &lt;element name="WebSphereJMSServer" type="{http://www.datapower.com/schemas/management}ConfigWebSphereJMSServer"/&gt;
 *         &lt;element name="JSONSettings" type="{http://www.datapower.com/schemas/management}ConfigJSONSettings"/&gt;
 *         &lt;element name="Language" type="{http://www.datapower.com/schemas/management}ConfigLanguage"/&gt;
 *         &lt;element name="LDAPConnectionPool" type="{http://www.datapower.com/schemas/management}ConfigLDAPConnectionPool"/&gt;
 *         &lt;element name="LoadBalancerGroup" type="{http://www.datapower.com/schemas/management}ConfigLoadBalancerGroup"/&gt;
 *         &lt;element name="LogLabel" type="{http://www.datapower.com/schemas/management}ConfigLogLabel"/&gt;
 *         &lt;element name="Luna" type="{http://www.datapower.com/schemas/management}ConfigLuna"/&gt;
 *         &lt;element name="LunaPartition" type="{http://www.datapower.com/schemas/management}ConfigLunaPartition"/&gt;
 *         &lt;element name="Matching" type="{http://www.datapower.com/schemas/management}ConfigMatching"/&gt;
 *         &lt;element name="MCFCustomRule" type="{http://www.datapower.com/schemas/management}ConfigMCFCustomRule"/&gt;
 *         &lt;element name="MCFHttpHeader" type="{http://www.datapower.com/schemas/management}ConfigMCFHttpHeader"/&gt;
 *         &lt;element name="MCFHttpMethod" type="{http://www.datapower.com/schemas/management}ConfigMCFHttpMethod"/&gt;
 *         &lt;element name="MCFHttpURL" type="{http://www.datapower.com/schemas/management}ConfigMCFHttpURL"/&gt;
 *         &lt;element name="MCFXPath" type="{http://www.datapower.com/schemas/management}ConfigMCFXPath"/&gt;
 *         &lt;element name="MessageContentFilters" type="{http://www.datapower.com/schemas/management}ConfigMessageContentFilters"/&gt;
 *         &lt;element name="FilterAction" type="{http://www.datapower.com/schemas/management}ConfigFilterAction"/&gt;
 *         &lt;element name="MessageMatching" type="{http://www.datapower.com/schemas/management}ConfigMessageMatching"/&gt;
 *         &lt;element name="CountMonitor" type="{http://www.datapower.com/schemas/management}ConfigCountMonitor"/&gt;
 *         &lt;element name="DurationMonitor" type="{http://www.datapower.com/schemas/management}ConfigDurationMonitor"/&gt;
 *         &lt;element name="MessageType" type="{http://www.datapower.com/schemas/management}ConfigMessageType"/&gt;
 *         &lt;element name="MPGWErrorAction" type="{http://www.datapower.com/schemas/management}ConfigMPGWErrorAction"/&gt;
 *         &lt;element name="MPGWErrorHandlingPolicy" type="{http://www.datapower.com/schemas/management}ConfigMPGWErrorHandlingPolicy"/&gt;
 *         &lt;element name="MQAUI" type="{http://www.datapower.com/schemas/management}ConfigMQAUI"/&gt;
 *         &lt;element name="MQGW" type="{http://www.datapower.com/schemas/management}ConfigMQGW"/&gt;
 *         &lt;element name="MQhost" type="{http://www.datapower.com/schemas/management}ConfigMQhost"/&gt;
 *         &lt;element name="MQproxy" type="{http://www.datapower.com/schemas/management}ConfigMQproxy"/&gt;
 *         &lt;element name="MQQM" type="{http://www.datapower.com/schemas/management}ConfigMQQM"/&gt;
 *         &lt;element name="MQQMGroup" type="{http://www.datapower.com/schemas/management}ConfigMQQMGroup"/&gt;
 *         &lt;element name="MTOMPolicy" type="{http://www.datapower.com/schemas/management}ConfigMTOMPolicy"/&gt;
 *         &lt;element name="NameValueProfile" type="{http://www.datapower.com/schemas/management}ConfigNameValueProfile"/&gt;
 *         &lt;element name="DNSNameService" type="{http://www.datapower.com/schemas/management}ConfigDNSNameService"/&gt;
 *         &lt;element name="HostAlias" type="{http://www.datapower.com/schemas/management}ConfigHostAlias"/&gt;
 *         &lt;element name="NetworkSettings" type="{http://www.datapower.com/schemas/management}ConfigNetworkSettings"/&gt;
 *         &lt;element name="NTPService" type="{http://www.datapower.com/schemas/management}ConfigNTPService"/&gt;
 *         &lt;element name="NFSClientSettings" type="{http://www.datapower.com/schemas/management}ConfigNFSClientSettings"/&gt;
 *         &lt;element name="NFSDynamicMounts" type="{http://www.datapower.com/schemas/management}ConfigNFSDynamicMounts"/&gt;
 *         &lt;element name="NFSStaticMount" type="{http://www.datapower.com/schemas/management}ConfigNFSStaticMount"/&gt;
 *         &lt;element name="ODR" type="{http://www.datapower.com/schemas/management}ConfigODR"/&gt;
 *         &lt;element name="ODRConnectorGroup" type="{http://www.datapower.com/schemas/management}ConfigODRConnectorGroup"/&gt;
 *         &lt;element name="PasswordAlias" type="{http://www.datapower.com/schemas/management}ConfigPasswordAlias"/&gt;
 *         &lt;element name="Pattern" type="{http://www.datapower.com/schemas/management}ConfigPattern"/&gt;
 *         &lt;element name="PeerGroup" type="{http://www.datapower.com/schemas/management}ConfigPeerGroup"/&gt;
 *         &lt;element name="PolicyAttachments" type="{http://www.datapower.com/schemas/management}ConfigPolicyAttachments"/&gt;
 *         &lt;element name="PolicyParameters" type="{http://www.datapower.com/schemas/management}ConfigPolicyParameters"/&gt;
 *         &lt;element name="QuotaEnforcementServer" type="{http://www.datapower.com/schemas/management}ConfigQuotaEnforcementServer"/&gt;
 *         &lt;element name="RaidVolume" type="{http://www.datapower.com/schemas/management}ConfigRaidVolume"/&gt;
 *         &lt;element name="SQLRuntimeSettings" type="{http://www.datapower.com/schemas/management}ConfigSQLRuntimeSettings"/&gt;
 *         &lt;element name="SecureBackupMode" type="{http://www.datapower.com/schemas/management}ConfigSecureBackupMode"/&gt;
 *         &lt;element name="SecureCloudConnector" type="{http://www.datapower.com/schemas/management}ConfigSecureCloudConnector"/&gt;
 *         &lt;element name="SecureGatewayClient" type="{http://www.datapower.com/schemas/management}ConfigSecureGatewayClient"/&gt;
 *         &lt;element name="MgmtInterface" type="{http://www.datapower.com/schemas/management}ConfigMgmtInterface"/&gt;
 *         &lt;element name="RestMgmtInterface" type="{http://www.datapower.com/schemas/management}ConfigRestMgmtInterface"/&gt;
 *         &lt;element name="SSHService" type="{http://www.datapower.com/schemas/management}ConfigSSHService"/&gt;
 *         &lt;element name="TelnetService" type="{http://www.datapower.com/schemas/management}ConfigTelnetService"/&gt;
 *         &lt;element name="WebB2BViewer" type="{http://www.datapower.com/schemas/management}ConfigWebB2BViewer"/&gt;
 *         &lt;element name="WebGUI" type="{http://www.datapower.com/schemas/management}ConfigWebGUI"/&gt;
 *         &lt;element name="XMLFirewallService" type="{http://www.datapower.com/schemas/management}ConfigXMLFirewallService"/&gt;
 *         &lt;element name="XSLProxyService" type="{http://www.datapower.com/schemas/management}ConfigXSLProxyService"/&gt;
 *         &lt;element name="HTTPService" type="{http://www.datapower.com/schemas/management}ConfigHTTPService"/&gt;
 *         &lt;element name="SSLProxyService" type="{http://www.datapower.com/schemas/management}ConfigSSLProxyService"/&gt;
 *         &lt;element name="TCPProxyService" type="{http://www.datapower.com/schemas/management}ConfigTCPProxyService"/&gt;
 *         &lt;element name="XSLCoprocService" type="{http://www.datapower.com/schemas/management}ConfigXSLCoprocService"/&gt;
 *         &lt;element name="ShellAlias" type="{http://www.datapower.com/schemas/management}ConfigShellAlias"/&gt;
 *         &lt;element name="SimpleCountMonitor" type="{http://www.datapower.com/schemas/management}ConfigSimpleCountMonitor"/&gt;
 *         &lt;element name="SLMAction" type="{http://www.datapower.com/schemas/management}ConfigSLMAction"/&gt;
 *         &lt;element name="SLMCredClass" type="{http://www.datapower.com/schemas/management}ConfigSLMCredClass"/&gt;
 *         &lt;element name="SLMPolicy" type="{http://www.datapower.com/schemas/management}ConfigSLMPolicy"/&gt;
 *         &lt;element name="SLMRsrcClass" type="{http://www.datapower.com/schemas/management}ConfigSLMRsrcClass"/&gt;
 *         &lt;element name="SLMSchedule" type="{http://www.datapower.com/schemas/management}ConfigSLMSchedule"/&gt;
 *         &lt;element name="SMTPServerConnection" type="{http://www.datapower.com/schemas/management}ConfigSMTPServerConnection"/&gt;
 *         &lt;element name="SNMPSettings" type="{http://www.datapower.com/schemas/management}ConfigSNMPSettings"/&gt;
 *         &lt;element name="AS2ProxySourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigAS2ProxySourceProtocolHandler"/&gt;
 *         &lt;element name="AS2SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigAS2SourceProtocolHandler"/&gt;
 *         &lt;element name="AS3SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigAS3SourceProtocolHandler"/&gt;
 *         &lt;element name="EBMS2SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigEBMS2SourceProtocolHandler"/&gt;
 *         &lt;element name="EBMS3SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigEBMS3SourceProtocolHandler"/&gt;
 *         &lt;element name="FTPFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigFTPFilePollerSourceProtocolHandler"/&gt;
 *         &lt;element name="NFSFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigNFSFilePollerSourceProtocolHandler"/&gt;
 *         &lt;element name="SFTPFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigSFTPFilePollerSourceProtocolHandler"/&gt;
 *         &lt;element name="FTPServerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigFTPServerSourceProtocolHandler"/&gt;
 *         &lt;element name="HTTPSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigHTTPSourceProtocolHandler"/&gt;
 *         &lt;element name="HTTPSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigHTTPSSourceProtocolHandler"/&gt;
 *         &lt;element name="IMSCalloutSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigIMSCalloutSourceProtocolHandler"/&gt;
 *         &lt;element name="IMSConnectSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigIMSConnectSourceProtocolHandler"/&gt;
 *         &lt;element name="TibcoEMSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigTibcoEMSSourceProtocolHandler"/&gt;
 *         &lt;element name="WebSphereJMSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigWebSphereJMSSourceProtocolHandler"/&gt;
 *         &lt;element name="MQFTESourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigMQFTESourceProtocolHandler"/&gt;
 *         &lt;element name="MQSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigMQSourceProtocolHandler"/&gt;
 *         &lt;element name="AS1PollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigAS1PollerSourceProtocolHandler"/&gt;
 *         &lt;element name="POPPollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigPOPPollerSourceProtocolHandler"/&gt;
 *         &lt;element name="SSHServerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigSSHServerSourceProtocolHandler"/&gt;
 *         &lt;element name="StatelessTCPSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigStatelessTCPSourceProtocolHandler"/&gt;
 *         &lt;element name="XTCProtocolHandler" type="{http://www.datapower.com/schemas/management}ConfigXTCProtocolHandler"/&gt;
 *         &lt;element name="SQLDataSource" type="{http://www.datapower.com/schemas/management}ConfigSQLDataSource"/&gt;
 *         &lt;element name="StandaloneStandbyControl" type="{http://www.datapower.com/schemas/management}ConfigStandaloneStandbyControl"/&gt;
 *         &lt;element name="StandaloneStandbyControlInterface" type="{http://www.datapower.com/schemas/management}ConfigStandaloneStandbyControlInterface"/&gt;
 *         &lt;element name="Statistics" type="{http://www.datapower.com/schemas/management}ConfigStatistics"/&gt;
 *         &lt;element name="StylePolicy" type="{http://www.datapower.com/schemas/management}ConfigStylePolicy"/&gt;
 *         &lt;element name="StylePolicyAction" type="{http://www.datapower.com/schemas/management}ConfigStylePolicyAction"/&gt;
 *         &lt;element name="StylePolicyRule" type="{http://www.datapower.com/schemas/management}ConfigStylePolicyRule"/&gt;
 *         &lt;element name="WSStylePolicyRule" type="{http://www.datapower.com/schemas/management}ConfigWSStylePolicyRule"/&gt;
 *         &lt;element name="Throttler" type="{http://www.datapower.com/schemas/management}ConfigThrottler"/&gt;
 *         &lt;element name="UDDIRegistry" type="{http://www.datapower.com/schemas/management}ConfigUDDIRegistry"/&gt;
 *         &lt;element name="URLMap" type="{http://www.datapower.com/schemas/management}ConfigURLMap"/&gt;
 *         &lt;element name="URLRefreshPolicy" type="{http://www.datapower.com/schemas/management}ConfigURLRefreshPolicy"/&gt;
 *         &lt;element name="URLRewritePolicy" type="{http://www.datapower.com/schemas/management}ConfigURLRewritePolicy"/&gt;
 *         &lt;element name="User" type="{http://www.datapower.com/schemas/management}ConfigUser"/&gt;
 *         &lt;element name="UserGroup" type="{http://www.datapower.com/schemas/management}ConfigUserGroup"/&gt;
 *         &lt;element name="WCCService" type="{http://www.datapower.com/schemas/management}ConfigWCCService"/&gt;
 *         &lt;element name="WebAppErrorHandlingPolicy" type="{http://www.datapower.com/schemas/management}ConfigWebAppErrorHandlingPolicy"/&gt;
 *         &lt;element name="WebAppFW" type="{http://www.datapower.com/schemas/management}ConfigWebAppFW"/&gt;
 *         &lt;element name="WebAppRequest" type="{http://www.datapower.com/schemas/management}ConfigWebAppRequest"/&gt;
 *         &lt;element name="WebAppResponse" type="{http://www.datapower.com/schemas/management}ConfigWebAppResponse"/&gt;
 *         &lt;element name="WebAppSessionPolicy" type="{http://www.datapower.com/schemas/management}ConfigWebAppSessionPolicy"/&gt;
 *         &lt;element name="WebServiceMonitor" type="{http://www.datapower.com/schemas/management}ConfigWebServiceMonitor"/&gt;
 *         &lt;element name="WebServicesAgent" type="{http://www.datapower.com/schemas/management}ConfigWebServicesAgent"/&gt;
 *         &lt;element name="UDDISubscription" type="{http://www.datapower.com/schemas/management}ConfigUDDISubscription"/&gt;
 *         &lt;element name="WSRRSavedSearchSubscription" type="{http://www.datapower.com/schemas/management}ConfigWSRRSavedSearchSubscription"/&gt;
 *         &lt;element name="WSRRSubscription" type="{http://www.datapower.com/schemas/management}ConfigWSRRSubscription"/&gt;
 *         &lt;element name="WebTokenService" type="{http://www.datapower.com/schemas/management}ConfigWebTokenService"/&gt;
 *         &lt;element name="WSEndpointRewritePolicy" type="{http://www.datapower.com/schemas/management}ConfigWSEndpointRewritePolicy"/&gt;
 *         &lt;element name="WSRRServer" type="{http://www.datapower.com/schemas/management}ConfigWSRRServer"/&gt;
 *         &lt;element name="WSStylePolicy" type="{http://www.datapower.com/schemas/management}ConfigWSStylePolicy"/&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}ConfigXMLManager"/&gt;
 *         &lt;element name="xmltrace" type="{http://www.datapower.com/schemas/management}Configxmltrace"/&gt;
 *         &lt;element name="ZHybridTargetControlService" type="{http://www.datapower.com/schemas/management}ConfigZHybridTargetControlService"/&gt;
 *         &lt;element name="ZosNSSClient" type="{http://www.datapower.com/schemas/management}ConfigZosNSSClient"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnyConfigElement", propOrder = {
    "configObjects"
})
public class AnyConfigElement {

    @XmlElements({
        @XmlElement(name = "AAAPolicy", type = ConfigAAAPolicy.class),
        @XmlElement(name = "Domain", type = ConfigDomain.class),
        @XmlElement(name = "LDAPSearchParameters", type = ConfigLDAPSearchParameters.class),
        @XmlElement(name = "ProcessingMetadata", type = ConfigProcessingMetadata.class),
        @XmlElement(name = "RADIUSSettings", type = ConfigRADIUSSettings.class),
        @XmlElement(name = "RBMSettings", type = ConfigRBMSettings.class),
        @XmlElement(name = "SAMLAttributes", type = ConfigSAMLAttributes.class),
        @XmlElement(name = "SOAPHeaderDisposition", type = ConfigSOAPHeaderDisposition.class),
        @XmlElement(name = "TAM", type = ConfigTAM.class),
        @XmlElement(name = "TFIMEndpoint", type = ConfigTFIMEndpoint.class),
        @XmlElement(name = "XACMLPDP", type = ConfigXACMLPDP.class),
        @XmlElement(name = "AccessControlList", type = ConfigAccessControlList.class),
        @XmlElement(name = "AppSecurityPolicy", type = ConfigAppSecurityPolicy.class),
        @XmlElement(name = "AuditLog", type = ConfigAuditLog.class),
        @XmlElement(name = "B2BCPA", type = ConfigB2BCPA.class),
        @XmlElement(name = "B2BCPACollaboration", type = ConfigB2BCPACollaboration.class),
        @XmlElement(name = "B2BCPAReceiverSetting", type = ConfigB2BCPAReceiverSetting.class),
        @XmlElement(name = "B2BCPASenderSetting", type = ConfigB2BCPASenderSetting.class),
        @XmlElement(name = "B2BGateway", type = ConfigB2BGateway.class),
        @XmlElement(name = "B2BPersistence", type = ConfigB2BPersistence.class),
        @XmlElement(name = "B2BProfile", type = ConfigB2BProfile.class),
        @XmlElement(name = "B2BProfileGroup", type = ConfigB2BProfileGroup.class),
        @XmlElement(name = "B2BXPathRoutingPolicy", type = ConfigB2BXPathRoutingPolicy.class),
        @XmlElement(name = "WXSGrid", type = ConfigWXSGrid.class),
        @XmlElement(name = "XC10Grid", type = ConfigXC10Grid.class),
        @XmlElement(name = "CloudConnectorService", type = ConfigCloudConnectorService.class),
        @XmlElement(name = "CloudGatewayService", type = ConfigCloudGatewayService.class),
        @XmlElement(name = "CompactFlash", type = ConfigCompactFlash.class),
        @XmlElement(name = "CompileOptionsPolicy", type = ConfigCompileOptionsPolicy.class),
        @XmlElement(name = "ConfigDeploymentPolicy", type = ConfigConfigDeploymentPolicy.class),
        @XmlElement(name = "ConformancePolicy", type = ConfigConformancePolicy.class),
        @XmlElement(name = "AAAJWTGenerator", type = ConfigAAAJWTGenerator.class),
        @XmlElement(name = "AAAJWTValidator", type = ConfigAAAJWTValidator.class),
        @XmlElement(name = "CertMonitor", type = ConfigCertMonitor.class),
        @XmlElement(name = "CookieAttributePolicy", type = ConfigCookieAttributePolicy.class),
        @XmlElement(name = "CRLFetch", type = ConfigCRLFetch.class),
        @XmlElement(name = "CryptoCertificate", type = ConfigCryptoCertificate.class),
        @XmlElement(name = "CryptoFWCred", type = ConfigCryptoFWCred.class),
        @XmlElement(name = "CryptoIdentCred", type = ConfigCryptoIdentCred.class),
        @XmlElement(name = "CryptoKerberosKDC", type = ConfigCryptoKerberosKDC.class),
        @XmlElement(name = "CryptoKerberosKeytab", type = ConfigCryptoKerberosKeytab.class),
        @XmlElement(name = "CryptoKey", type = ConfigCryptoKey.class),
        @XmlElement(name = "CryptoProfile", type = ConfigCryptoProfile.class),
        @XmlElement(name = "CryptoSSKey", type = ConfigCryptoSSKey.class),
        @XmlElement(name = "CryptoValCred", type = ConfigCryptoValCred.class),
        @XmlElement(name = "JOSERecipientIdentifier", type = ConfigJOSERecipientIdentifier.class),
        @XmlElement(name = "JOSESignatureIdentifier", type = ConfigJOSESignatureIdentifier.class),
        @XmlElement(name = "JWEHeader", type = ConfigJWEHeader.class),
        @XmlElement(name = "JWERecipient", type = ConfigJWERecipient.class),
        @XmlElement(name = "JWSSignature", type = ConfigJWSSignature.class),
        @XmlElement(name = "OAuthSupportedClient", type = ConfigOAuthSupportedClient.class),
        @XmlElement(name = "OAuthSupportedClientGroup", type = ConfigOAuthSupportedClientGroup.class),
        @XmlElement(name = "SocialLoginPolicy", type = ConfigSocialLoginPolicy.class),
        @XmlElement(name = "SSHClientProfile", type = ConfigSSHClientProfile.class),
        @XmlElement(name = "SSHDomainClientProfile", type = ConfigSSHDomainClientProfile.class),
        @XmlElement(name = "SSHServerProfile", type = ConfigSSHServerProfile.class),
        @XmlElement(name = "SSLClientProfile", type = ConfigSSLClientProfile.class),
        @XmlElement(name = "SSLProxyProfile", type = ConfigSSLProxyProfile.class),
        @XmlElement(name = "SSLServerProfile", type = ConfigSSLServerProfile.class),
        @XmlElement(name = "SSLSNIMapping", type = ConfigSSLSNIMapping.class),
        @XmlElement(name = "SSLSNIServerProfile", type = ConfigSSLSNIServerProfile.class),
        @XmlElement(name = "DeploymentPolicyParametersBinding", type = ConfigDeploymentPolicyParametersBinding.class),
        @XmlElement(name = "ErrorReportSettings", type = ConfigErrorReportSettings.class),
        @XmlElement(name = "SystemSettings", type = ConfigSystemSettings.class),
        @XmlElement(name = "TimeSettings", type = ConfigTimeSettings.class),
        @XmlElement(name = "DFDLSettings", type = ConfigDFDLSettings.class),
        @XmlElement(name = "DomainAvailability", type = ConfigDomainAvailability.class),
        @XmlElement(name = "DomainSettings", type = ConfigDomainSettings.class),
        @XmlElement(name = "SchemaExceptionMap", type = ConfigSchemaExceptionMap.class),
        @XmlElement(name = "DocumentCryptoMap", type = ConfigDocumentCryptoMap.class),
        @XmlElement(name = "XPathRoutingMap", type = ConfigXPathRoutingMap.class),
        @XmlElement(name = "LogTarget", type = ConfigLogTarget.class),
        @XmlElement(name = "FormsLoginPolicy", type = ConfigFormsLoginPolicy.class),
        @XmlElement(name = "FTPQuoteCommands", type = ConfigFTPQuoteCommands.class),
        @XmlElement(name = "MultiProtocolGateway", type = ConfigMultiProtocolGateway.class),
        @XmlElement(name = "WSGateway", type = ConfigWSGateway.class),
        @XmlElement(name = "GeneratedPolicy", type = ConfigGeneratedPolicy.class),
        @XmlElement(name = "HTTPInputConversionMap", type = ConfigHTTPInputConversionMap.class),
        @XmlElement(name = "HTTPUserAgent", type = ConfigHTTPUserAgent.class),
        @XmlElement(name = "ILMTAgent", type = ConfigILMTAgent.class),
        @XmlElement(name = "ImportPackage", type = ConfigImportPackage.class),
        @XmlElement(name = "IMSConnect", type = ConfigIMSConnect.class),
        @XmlElement(name = "IncludeConfig", type = ConfigIncludeConfig.class),
        @XmlElement(name = "InteropService", type = ConfigInteropService.class),
        @XmlElement(name = "EthernetInterface", type = ConfigEthernetInterface.class),
        @XmlElement(name = "LinkAggregation", type = ConfigLinkAggregation.class),
        @XmlElement(name = "VLANInterface", type = ConfigVLANInterface.class),
        @XmlElement(name = "IPMILanChannel", type = ConfigIPMILanChannel.class),
        @XmlElement(name = "IPMIUser", type = ConfigIPMIUser.class),
        @XmlElement(name = "IPMulticast", type = ConfigIPMulticast.class),
        @XmlElement(name = "ISAMReverseProxy", type = ConfigISAMReverseProxy.class),
        @XmlElement(name = "ISAMReverseProxyJunction", type = ConfigISAMReverseProxyJunction.class),
        @XmlElement(name = "ISAMRuntime", type = ConfigISAMRuntime.class),
        @XmlElement(name = "IScsiChapConfig", type = ConfigIScsiChapConfig.class),
        @XmlElement(name = "IScsiHBAConfig", type = ConfigIScsiHBAConfig.class),
        @XmlElement(name = "IScsiInitiatorConfig", type = ConfigIScsiInitiatorConfig.class),
        @XmlElement(name = "IScsiTargetConfig", type = ConfigIScsiTargetConfig.class),
        @XmlElement(name = "IScsiVolumeConfig", type = ConfigIScsiVolumeConfig.class),
        @XmlElement(name = "TibcoEMSServer", type = ConfigTibcoEMSServer.class),
        @XmlElement(name = "WebSphereJMSServer", type = ConfigWebSphereJMSServer.class),
        @XmlElement(name = "JSONSettings", type = ConfigJSONSettings.class),
        @XmlElement(name = "Language", type = ConfigLanguage.class),
        @XmlElement(name = "LDAPConnectionPool", type = ConfigLDAPConnectionPool.class),
        @XmlElement(name = "LoadBalancerGroup", type = ConfigLoadBalancerGroup.class),
        @XmlElement(name = "LogLabel", type = ConfigLogLabel.class),
        @XmlElement(name = "Luna", type = ConfigLuna.class),
        @XmlElement(name = "LunaPartition", type = ConfigLunaPartition.class),
        @XmlElement(name = "Matching", type = ConfigMatching.class),
        @XmlElement(name = "MCFCustomRule", type = ConfigMCFCustomRule.class),
        @XmlElement(name = "MCFHttpHeader", type = ConfigMCFHttpHeader.class),
        @XmlElement(name = "MCFHttpMethod", type = ConfigMCFHttpMethod.class),
        @XmlElement(name = "MCFHttpURL", type = ConfigMCFHttpURL.class),
        @XmlElement(name = "MCFXPath", type = ConfigMCFXPath.class),
        @XmlElement(name = "MessageContentFilters", type = ConfigMessageContentFilters.class),
        @XmlElement(name = "FilterAction", type = ConfigFilterAction.class),
        @XmlElement(name = "MessageMatching", type = ConfigMessageMatching.class),
        @XmlElement(name = "CountMonitor", type = ConfigCountMonitor.class),
        @XmlElement(name = "DurationMonitor", type = ConfigDurationMonitor.class),
        @XmlElement(name = "MessageType", type = ConfigMessageType.class),
        @XmlElement(name = "MPGWErrorAction", type = ConfigMPGWErrorAction.class),
        @XmlElement(name = "MPGWErrorHandlingPolicy", type = ConfigMPGWErrorHandlingPolicy.class),
        @XmlElement(name = "MQAUI", type = ConfigMQAUI.class),
        @XmlElement(name = "MQGW", type = ConfigMQGW.class),
        @XmlElement(name = "MQhost", type = ConfigMQhost.class),
        @XmlElement(name = "MQproxy", type = ConfigMQproxy.class),
        @XmlElement(name = "MQQM", type = ConfigMQQM.class),
        @XmlElement(name = "MQQMGroup", type = ConfigMQQMGroup.class),
        @XmlElement(name = "MTOMPolicy", type = ConfigMTOMPolicy.class),
        @XmlElement(name = "NameValueProfile", type = ConfigNameValueProfile.class),
        @XmlElement(name = "DNSNameService", type = ConfigDNSNameService.class),
        @XmlElement(name = "HostAlias", type = ConfigHostAlias.class),
        @XmlElement(name = "NetworkSettings", type = ConfigNetworkSettings.class),
        @XmlElement(name = "NTPService", type = ConfigNTPService.class),
        @XmlElement(name = "NFSClientSettings", type = ConfigNFSClientSettings.class),
        @XmlElement(name = "NFSDynamicMounts", type = ConfigNFSDynamicMounts.class),
        @XmlElement(name = "NFSStaticMount", type = ConfigNFSStaticMount.class),
        @XmlElement(name = "ODR", type = ConfigODR.class),
        @XmlElement(name = "ODRConnectorGroup", type = ConfigODRConnectorGroup.class),
        @XmlElement(name = "PasswordAlias", type = ConfigPasswordAlias.class),
        @XmlElement(name = "Pattern", type = ConfigPattern.class),
        @XmlElement(name = "PeerGroup", type = ConfigPeerGroup.class),
        @XmlElement(name = "PolicyAttachments", type = ConfigPolicyAttachments.class),
        @XmlElement(name = "PolicyParameters", type = ConfigPolicyParameters.class),
        @XmlElement(name = "QuotaEnforcementServer", type = ConfigQuotaEnforcementServer.class),
        @XmlElement(name = "RaidVolume", type = ConfigRaidVolume.class),
        @XmlElement(name = "SQLRuntimeSettings", type = ConfigSQLRuntimeSettings.class),
        @XmlElement(name = "SecureBackupMode", type = ConfigSecureBackupMode.class),
        @XmlElement(name = "SecureCloudConnector", type = ConfigSecureCloudConnector.class),
        @XmlElement(name = "SecureGatewayClient", type = ConfigSecureGatewayClient.class),
        @XmlElement(name = "MgmtInterface", type = ConfigMgmtInterface.class),
        @XmlElement(name = "RestMgmtInterface", type = ConfigRestMgmtInterface.class),
        @XmlElement(name = "SSHService", type = ConfigSSHService.class),
        @XmlElement(name = "TelnetService", type = ConfigTelnetService.class),
        @XmlElement(name = "WebB2BViewer", type = ConfigWebB2BViewer.class),
        @XmlElement(name = "WebGUI", type = ConfigWebGUI.class),
        @XmlElement(name = "XMLFirewallService", type = ConfigXMLFirewallService.class),
        @XmlElement(name = "XSLProxyService", type = ConfigXSLProxyService.class),
        @XmlElement(name = "HTTPService", type = ConfigHTTPService.class),
        @XmlElement(name = "SSLProxyService", type = ConfigSSLProxyService.class),
        @XmlElement(name = "TCPProxyService", type = ConfigTCPProxyService.class),
        @XmlElement(name = "XSLCoprocService", type = ConfigXSLCoprocService.class),
        @XmlElement(name = "ShellAlias", type = ConfigShellAlias.class),
        @XmlElement(name = "SimpleCountMonitor", type = ConfigSimpleCountMonitor.class),
        @XmlElement(name = "SLMAction", type = ConfigSLMAction.class),
        @XmlElement(name = "SLMCredClass", type = ConfigSLMCredClass.class),
        @XmlElement(name = "SLMPolicy", type = ConfigSLMPolicy.class),
        @XmlElement(name = "SLMRsrcClass", type = ConfigSLMRsrcClass.class),
        @XmlElement(name = "SLMSchedule", type = ConfigSLMSchedule.class),
        @XmlElement(name = "SMTPServerConnection", type = ConfigSMTPServerConnection.class),
        @XmlElement(name = "SNMPSettings", type = ConfigSNMPSettings.class),
        @XmlElement(name = "AS2ProxySourceProtocolHandler", type = ConfigAS2ProxySourceProtocolHandler.class),
        @XmlElement(name = "AS2SourceProtocolHandler", type = ConfigAS2SourceProtocolHandler.class),
        @XmlElement(name = "AS3SourceProtocolHandler", type = ConfigAS3SourceProtocolHandler.class),
        @XmlElement(name = "EBMS2SourceProtocolHandler", type = ConfigEBMS2SourceProtocolHandler.class),
        @XmlElement(name = "EBMS3SourceProtocolHandler", type = ConfigEBMS3SourceProtocolHandler.class),
        @XmlElement(name = "FTPFilePollerSourceProtocolHandler", type = ConfigFTPFilePollerSourceProtocolHandler.class),
        @XmlElement(name = "NFSFilePollerSourceProtocolHandler", type = ConfigNFSFilePollerSourceProtocolHandler.class),
        @XmlElement(name = "SFTPFilePollerSourceProtocolHandler", type = ConfigSFTPFilePollerSourceProtocolHandler.class),
        @XmlElement(name = "FTPServerSourceProtocolHandler", type = ConfigFTPServerSourceProtocolHandler.class),
        @XmlElement(name = "HTTPSourceProtocolHandler", type = ConfigHTTPSourceProtocolHandler.class),
        @XmlElement(name = "HTTPSSourceProtocolHandler", type = ConfigHTTPSSourceProtocolHandler.class),
        @XmlElement(name = "IMSCalloutSourceProtocolHandler", type = ConfigIMSCalloutSourceProtocolHandler.class),
        @XmlElement(name = "IMSConnectSourceProtocolHandler", type = ConfigIMSConnectSourceProtocolHandler.class),
        @XmlElement(name = "TibcoEMSSourceProtocolHandler", type = ConfigTibcoEMSSourceProtocolHandler.class),
        @XmlElement(name = "WebSphereJMSSourceProtocolHandler", type = ConfigWebSphereJMSSourceProtocolHandler.class),
        @XmlElement(name = "MQFTESourceProtocolHandler", type = ConfigMQFTESourceProtocolHandler.class),
        @XmlElement(name = "MQSourceProtocolHandler", type = ConfigMQSourceProtocolHandler.class),
        @XmlElement(name = "AS1PollerSourceProtocolHandler", type = ConfigAS1PollerSourceProtocolHandler.class),
        @XmlElement(name = "POPPollerSourceProtocolHandler", type = ConfigPOPPollerSourceProtocolHandler.class),
        @XmlElement(name = "SSHServerSourceProtocolHandler", type = ConfigSSHServerSourceProtocolHandler.class),
        @XmlElement(name = "StatelessTCPSourceProtocolHandler", type = ConfigStatelessTCPSourceProtocolHandler.class),
        @XmlElement(name = "XTCProtocolHandler", type = ConfigXTCProtocolHandler.class),
        @XmlElement(name = "SQLDataSource", type = ConfigSQLDataSource.class),
        @XmlElement(name = "StandaloneStandbyControl", type = ConfigStandaloneStandbyControl.class),
        @XmlElement(name = "StandaloneStandbyControlInterface", type = ConfigStandaloneStandbyControlInterface.class),
        @XmlElement(name = "Statistics", type = ConfigStatistics.class),
        @XmlElement(name = "StylePolicy", type = ConfigStylePolicy.class),
        @XmlElement(name = "StylePolicyAction", type = ConfigStylePolicyAction.class),
        @XmlElement(name = "StylePolicyRule", type = ConfigStylePolicyRule.class),
        @XmlElement(name = "WSStylePolicyRule", type = ConfigWSStylePolicyRule.class),
        @XmlElement(name = "Throttler", type = ConfigThrottler.class),
        @XmlElement(name = "UDDIRegistry", type = ConfigUDDIRegistry.class),
        @XmlElement(name = "URLMap", type = ConfigURLMap.class),
        @XmlElement(name = "URLRefreshPolicy", type = ConfigURLRefreshPolicy.class),
        @XmlElement(name = "URLRewritePolicy", type = ConfigURLRewritePolicy.class),
        @XmlElement(name = "User", type = ConfigUser.class),
        @XmlElement(name = "UserGroup", type = ConfigUserGroup.class),
        @XmlElement(name = "WCCService", type = ConfigWCCService.class),
        @XmlElement(name = "WebAppErrorHandlingPolicy", type = ConfigWebAppErrorHandlingPolicy.class),
        @XmlElement(name = "WebAppFW", type = ConfigWebAppFW.class),
        @XmlElement(name = "WebAppRequest", type = ConfigWebAppRequest.class),
        @XmlElement(name = "WebAppResponse", type = ConfigWebAppResponse.class),
        @XmlElement(name = "WebAppSessionPolicy", type = ConfigWebAppSessionPolicy.class),
        @XmlElement(name = "WebServiceMonitor", type = ConfigWebServiceMonitor.class),
        @XmlElement(name = "WebServicesAgent", type = ConfigWebServicesAgent.class),
        @XmlElement(name = "UDDISubscription", type = ConfigUDDISubscription.class),
        @XmlElement(name = "WSRRSavedSearchSubscription", type = ConfigWSRRSavedSearchSubscription.class),
        @XmlElement(name = "WSRRSubscription", type = ConfigWSRRSubscription.class),
        @XmlElement(name = "WebTokenService", type = ConfigWebTokenService.class),
        @XmlElement(name = "WSEndpointRewritePolicy", type = ConfigWSEndpointRewritePolicy.class),
        @XmlElement(name = "WSRRServer", type = ConfigWSRRServer.class),
        @XmlElement(name = "WSStylePolicy", type = ConfigWSStylePolicy.class),
        @XmlElement(name = "XMLManager", type = ConfigXMLManager.class),
        @XmlElement(name = "xmltrace", type = Configxmltrace.class),
        @XmlElement(name = "ZHybridTargetControlService", type = ConfigZHybridTargetControlService.class),
        @XmlElement(name = "ZosNSSClient", type = ConfigZosNSSClient.class)
    })
    protected List<ConfigConfigBase> configObjects;

    /**
     * Gets the value of the configObjects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the configObjects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConfigObjects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConfigAAAPolicy }
     * {@link ConfigDomain }
     * {@link ConfigLDAPSearchParameters }
     * {@link ConfigProcessingMetadata }
     * {@link ConfigRADIUSSettings }
     * {@link ConfigRBMSettings }
     * {@link ConfigSAMLAttributes }
     * {@link ConfigSOAPHeaderDisposition }
     * {@link ConfigTAM }
     * {@link ConfigTFIMEndpoint }
     * {@link ConfigXACMLPDP }
     * {@link ConfigAccessControlList }
     * {@link ConfigAppSecurityPolicy }
     * {@link ConfigAuditLog }
     * {@link ConfigB2BCPA }
     * {@link ConfigB2BCPACollaboration }
     * {@link ConfigB2BCPAReceiverSetting }
     * {@link ConfigB2BCPASenderSetting }
     * {@link ConfigB2BGateway }
     * {@link ConfigB2BPersistence }
     * {@link ConfigB2BProfile }
     * {@link ConfigB2BProfileGroup }
     * {@link ConfigB2BXPathRoutingPolicy }
     * {@link ConfigWXSGrid }
     * {@link ConfigXC10Grid }
     * {@link ConfigCloudConnectorService }
     * {@link ConfigCloudGatewayService }
     * {@link ConfigCompactFlash }
     * {@link ConfigCompileOptionsPolicy }
     * {@link ConfigConfigDeploymentPolicy }
     * {@link ConfigConformancePolicy }
     * {@link ConfigAAAJWTGenerator }
     * {@link ConfigAAAJWTValidator }
     * {@link ConfigCertMonitor }
     * {@link ConfigCookieAttributePolicy }
     * {@link ConfigCRLFetch }
     * {@link ConfigCryptoCertificate }
     * {@link ConfigCryptoFWCred }
     * {@link ConfigCryptoIdentCred }
     * {@link ConfigCryptoKerberosKDC }
     * {@link ConfigCryptoKerberosKeytab }
     * {@link ConfigCryptoKey }
     * {@link ConfigCryptoProfile }
     * {@link ConfigCryptoSSKey }
     * {@link ConfigCryptoValCred }
     * {@link ConfigJOSERecipientIdentifier }
     * {@link ConfigJOSESignatureIdentifier }
     * {@link ConfigJWEHeader }
     * {@link ConfigJWERecipient }
     * {@link ConfigJWSSignature }
     * {@link ConfigOAuthSupportedClient }
     * {@link ConfigOAuthSupportedClientGroup }
     * {@link ConfigSocialLoginPolicy }
     * {@link ConfigSSHClientProfile }
     * {@link ConfigSSHDomainClientProfile }
     * {@link ConfigSSHServerProfile }
     * {@link ConfigSSLClientProfile }
     * {@link ConfigSSLProxyProfile }
     * {@link ConfigSSLServerProfile }
     * {@link ConfigSSLSNIMapping }
     * {@link ConfigSSLSNIServerProfile }
     * {@link ConfigDeploymentPolicyParametersBinding }
     * {@link ConfigErrorReportSettings }
     * {@link ConfigSystemSettings }
     * {@link ConfigTimeSettings }
     * {@link ConfigDFDLSettings }
     * {@link ConfigDomainAvailability }
     * {@link ConfigDomainSettings }
     * {@link ConfigSchemaExceptionMap }
     * {@link ConfigDocumentCryptoMap }
     * {@link ConfigXPathRoutingMap }
     * {@link ConfigLogTarget }
     * {@link ConfigFormsLoginPolicy }
     * {@link ConfigFTPQuoteCommands }
     * {@link ConfigMultiProtocolGateway }
     * {@link ConfigWSGateway }
     * {@link ConfigGeneratedPolicy }
     * {@link ConfigHTTPInputConversionMap }
     * {@link ConfigHTTPUserAgent }
     * {@link ConfigILMTAgent }
     * {@link ConfigImportPackage }
     * {@link ConfigIMSConnect }
     * {@link ConfigIncludeConfig }
     * {@link ConfigInteropService }
     * {@link ConfigEthernetInterface }
     * {@link ConfigLinkAggregation }
     * {@link ConfigVLANInterface }
     * {@link ConfigIPMILanChannel }
     * {@link ConfigIPMIUser }
     * {@link ConfigIPMulticast }
     * {@link ConfigISAMReverseProxy }
     * {@link ConfigISAMReverseProxyJunction }
     * {@link ConfigISAMRuntime }
     * {@link ConfigIScsiChapConfig }
     * {@link ConfigIScsiHBAConfig }
     * {@link ConfigIScsiInitiatorConfig }
     * {@link ConfigIScsiTargetConfig }
     * {@link ConfigIScsiVolumeConfig }
     * {@link ConfigTibcoEMSServer }
     * {@link ConfigWebSphereJMSServer }
     * {@link ConfigJSONSettings }
     * {@link ConfigLanguage }
     * {@link ConfigLDAPConnectionPool }
     * {@link ConfigLoadBalancerGroup }
     * {@link ConfigLogLabel }
     * {@link ConfigLuna }
     * {@link ConfigLunaPartition }
     * {@link ConfigMatching }
     * {@link ConfigMCFCustomRule }
     * {@link ConfigMCFHttpHeader }
     * {@link ConfigMCFHttpMethod }
     * {@link ConfigMCFHttpURL }
     * {@link ConfigMCFXPath }
     * {@link ConfigMessageContentFilters }
     * {@link ConfigFilterAction }
     * {@link ConfigMessageMatching }
     * {@link ConfigCountMonitor }
     * {@link ConfigDurationMonitor }
     * {@link ConfigMessageType }
     * {@link ConfigMPGWErrorAction }
     * {@link ConfigMPGWErrorHandlingPolicy }
     * {@link ConfigMQAUI }
     * {@link ConfigMQGW }
     * {@link ConfigMQhost }
     * {@link ConfigMQproxy }
     * {@link ConfigMQQM }
     * {@link ConfigMQQMGroup }
     * {@link ConfigMTOMPolicy }
     * {@link ConfigNameValueProfile }
     * {@link ConfigDNSNameService }
     * {@link ConfigHostAlias }
     * {@link ConfigNetworkSettings }
     * {@link ConfigNTPService }
     * {@link ConfigNFSClientSettings }
     * {@link ConfigNFSDynamicMounts }
     * {@link ConfigNFSStaticMount }
     * {@link ConfigODR }
     * {@link ConfigODRConnectorGroup }
     * {@link ConfigPasswordAlias }
     * {@link ConfigPattern }
     * {@link ConfigPeerGroup }
     * {@link ConfigPolicyAttachments }
     * {@link ConfigPolicyParameters }
     * {@link ConfigQuotaEnforcementServer }
     * {@link ConfigRaidVolume }
     * {@link ConfigSQLRuntimeSettings }
     * {@link ConfigSecureBackupMode }
     * {@link ConfigSecureCloudConnector }
     * {@link ConfigSecureGatewayClient }
     * {@link ConfigMgmtInterface }
     * {@link ConfigRestMgmtInterface }
     * {@link ConfigSSHService }
     * {@link ConfigTelnetService }
     * {@link ConfigWebB2BViewer }
     * {@link ConfigWebGUI }
     * {@link ConfigXMLFirewallService }
     * {@link ConfigXSLProxyService }
     * {@link ConfigHTTPService }
     * {@link ConfigSSLProxyService }
     * {@link ConfigTCPProxyService }
     * {@link ConfigXSLCoprocService }
     * {@link ConfigShellAlias }
     * {@link ConfigSimpleCountMonitor }
     * {@link ConfigSLMAction }
     * {@link ConfigSLMCredClass }
     * {@link ConfigSLMPolicy }
     * {@link ConfigSLMRsrcClass }
     * {@link ConfigSLMSchedule }
     * {@link ConfigSMTPServerConnection }
     * {@link ConfigSNMPSettings }
     * {@link ConfigAS2ProxySourceProtocolHandler }
     * {@link ConfigAS2SourceProtocolHandler }
     * {@link ConfigAS3SourceProtocolHandler }
     * {@link ConfigEBMS2SourceProtocolHandler }
     * {@link ConfigEBMS3SourceProtocolHandler }
     * {@link ConfigFTPFilePollerSourceProtocolHandler }
     * {@link ConfigNFSFilePollerSourceProtocolHandler }
     * {@link ConfigSFTPFilePollerSourceProtocolHandler }
     * {@link ConfigFTPServerSourceProtocolHandler }
     * {@link ConfigHTTPSourceProtocolHandler }
     * {@link ConfigHTTPSSourceProtocolHandler }
     * {@link ConfigIMSCalloutSourceProtocolHandler }
     * {@link ConfigIMSConnectSourceProtocolHandler }
     * {@link ConfigTibcoEMSSourceProtocolHandler }
     * {@link ConfigWebSphereJMSSourceProtocolHandler }
     * {@link ConfigMQFTESourceProtocolHandler }
     * {@link ConfigMQSourceProtocolHandler }
     * {@link ConfigAS1PollerSourceProtocolHandler }
     * {@link ConfigPOPPollerSourceProtocolHandler }
     * {@link ConfigSSHServerSourceProtocolHandler }
     * {@link ConfigStatelessTCPSourceProtocolHandler }
     * {@link ConfigXTCProtocolHandler }
     * {@link ConfigSQLDataSource }
     * {@link ConfigStandaloneStandbyControl }
     * {@link ConfigStandaloneStandbyControlInterface }
     * {@link ConfigStatistics }
     * {@link ConfigStylePolicy }
     * {@link ConfigStylePolicyAction }
     * {@link ConfigStylePolicyRule }
     * {@link ConfigWSStylePolicyRule }
     * {@link ConfigThrottler }
     * {@link ConfigUDDIRegistry }
     * {@link ConfigURLMap }
     * {@link ConfigURLRefreshPolicy }
     * {@link ConfigURLRewritePolicy }
     * {@link ConfigUser }
     * {@link ConfigUserGroup }
     * {@link ConfigWCCService }
     * {@link ConfigWebAppErrorHandlingPolicy }
     * {@link ConfigWebAppFW }
     * {@link ConfigWebAppRequest }
     * {@link ConfigWebAppResponse }
     * {@link ConfigWebAppSessionPolicy }
     * {@link ConfigWebServiceMonitor }
     * {@link ConfigWebServicesAgent }
     * {@link ConfigUDDISubscription }
     * {@link ConfigWSRRSavedSearchSubscription }
     * {@link ConfigWSRRSubscription }
     * {@link ConfigWebTokenService }
     * {@link ConfigWSEndpointRewritePolicy }
     * {@link ConfigWSRRServer }
     * {@link ConfigWSStylePolicy }
     * {@link ConfigXMLManager }
     * {@link Configxmltrace }
     * {@link ConfigZHybridTargetControlService }
     * {@link ConfigZosNSSClient }
     * 
     * 
     */
    public List<ConfigConfigBase> getConfigObjects() {
        if (configObjects == null) {
            configObjects = new ArrayList<ConfigConfigBase>();
        }
        return this.configObjects;
    }

}
