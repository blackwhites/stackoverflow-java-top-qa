
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigConformancePolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigConformancePolicy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Profiles" type="{http://www.datapower.com/schemas/management}dmConformanceProfiles" minOccurs="0"/&gt;
 *         &lt;element name="IgnoredRequirements" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FixupStylesheets" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AssertBP10Conformance" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ReportLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmConformanceReportLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LogTarget" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RejectLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmConformanceRejectLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RejectIncludeSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResultIsConformanceReport" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponsePropertiesEnabled" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseReportLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmConformanceReportLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseLogTarget" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseRejectLevel" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmConformanceRejectLevel {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResponseRejectIncludeSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigConformancePolicy", propOrder = {
    "userSummary",
    "profiles",
    "ignoredRequirements",
    "fixupStylesheets",
    "assertBP10Conformance",
    "reportLevel",
    "logTarget",
    "rejectLevel",
    "rejectIncludeSummary",
    "resultIsConformanceReport",
    "responsePropertiesEnabled",
    "responseReportLevel",
    "responseLogTarget",
    "responseRejectLevel",
    "responseRejectIncludeSummary"
})
public class ConfigConformancePolicy
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "Profiles")
    protected DmConformanceProfiles profiles;
    @XmlElement(name = "IgnoredRequirements")
    protected List<String> ignoredRequirements;
    @XmlElement(name = "FixupStylesheets")
    protected List<String> fixupStylesheets;
    @XmlElement(name = "AssertBP10Conformance")
    protected String assertBP10Conformance;
    @XmlElement(name = "ReportLevel")
    protected String reportLevel;
    @XmlElement(name = "LogTarget")
    protected String logTarget;
    @XmlElement(name = "RejectLevel")
    protected String rejectLevel;
    @XmlElement(name = "RejectIncludeSummary")
    protected String rejectIncludeSummary;
    @XmlElement(name = "ResultIsConformanceReport")
    protected String resultIsConformanceReport;
    @XmlElement(name = "ResponsePropertiesEnabled")
    protected String responsePropertiesEnabled;
    @XmlElement(name = "ResponseReportLevel")
    protected String responseReportLevel;
    @XmlElement(name = "ResponseLogTarget")
    protected String responseLogTarget;
    @XmlElement(name = "ResponseRejectLevel")
    protected String responseRejectLevel;
    @XmlElement(name = "ResponseRejectIncludeSummary")
    protected String responseRejectIncludeSummary;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the profiles property.
     * 
     * @return
     *     possible object is
     *     {@link DmConformanceProfiles }
     *     
     */
    public DmConformanceProfiles getProfiles() {
        return profiles;
    }

    /**
     * Sets the value of the profiles property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmConformanceProfiles }
     *     
     */
    public void setProfiles(DmConformanceProfiles value) {
        this.profiles = value;
    }

    /**
     * Gets the value of the ignoredRequirements property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ignoredRequirements property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIgnoredRequirements().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getIgnoredRequirements() {
        if (ignoredRequirements == null) {
            ignoredRequirements = new ArrayList<String>();
        }
        return this.ignoredRequirements;
    }

    /**
     * Gets the value of the fixupStylesheets property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fixupStylesheets property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFixupStylesheets().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFixupStylesheets() {
        if (fixupStylesheets == null) {
            fixupStylesheets = new ArrayList<String>();
        }
        return this.fixupStylesheets;
    }

    /**
     * Gets the value of the assertBP10Conformance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssertBP10Conformance() {
        return assertBP10Conformance;
    }

    /**
     * Sets the value of the assertBP10Conformance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssertBP10Conformance(String value) {
        this.assertBP10Conformance = value;
    }

    /**
     * Gets the value of the reportLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReportLevel() {
        return reportLevel;
    }

    /**
     * Sets the value of the reportLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReportLevel(String value) {
        this.reportLevel = value;
    }

    /**
     * Gets the value of the logTarget property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogTarget() {
        return logTarget;
    }

    /**
     * Sets the value of the logTarget property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogTarget(String value) {
        this.logTarget = value;
    }

    /**
     * Gets the value of the rejectLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectLevel() {
        return rejectLevel;
    }

    /**
     * Sets the value of the rejectLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectLevel(String value) {
        this.rejectLevel = value;
    }

    /**
     * Gets the value of the rejectIncludeSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectIncludeSummary() {
        return rejectIncludeSummary;
    }

    /**
     * Sets the value of the rejectIncludeSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectIncludeSummary(String value) {
        this.rejectIncludeSummary = value;
    }

    /**
     * Gets the value of the resultIsConformanceReport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResultIsConformanceReport() {
        return resultIsConformanceReport;
    }

    /**
     * Sets the value of the resultIsConformanceReport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResultIsConformanceReport(String value) {
        this.resultIsConformanceReport = value;
    }

    /**
     * Gets the value of the responsePropertiesEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponsePropertiesEnabled() {
        return responsePropertiesEnabled;
    }

    /**
     * Sets the value of the responsePropertiesEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponsePropertiesEnabled(String value) {
        this.responsePropertiesEnabled = value;
    }

    /**
     * Gets the value of the responseReportLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseReportLevel() {
        return responseReportLevel;
    }

    /**
     * Sets the value of the responseReportLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseReportLevel(String value) {
        this.responseReportLevel = value;
    }

    /**
     * Gets the value of the responseLogTarget property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseLogTarget() {
        return responseLogTarget;
    }

    /**
     * Sets the value of the responseLogTarget property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseLogTarget(String value) {
        this.responseLogTarget = value;
    }

    /**
     * Gets the value of the responseRejectLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseRejectLevel() {
        return responseRejectLevel;
    }

    /**
     * Sets the value of the responseRejectLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseRejectLevel(String value) {
        this.responseRejectLevel = value;
    }

    /**
     * Gets the value of the responseRejectIncludeSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseRejectIncludeSummary() {
        return responseRejectIncludeSummary;
    }

    /**
     * Sets the value of the responseRejectIncludeSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseRejectIncludeSummary(String value) {
        this.responseRejectIncludeSummary = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
