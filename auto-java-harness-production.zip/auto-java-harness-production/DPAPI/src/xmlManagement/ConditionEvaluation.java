
package xmlManagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for condition-evaluation.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="condition-evaluation"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="logical-and"/&gt;
 *     &lt;enumeration value="logical-or"/&gt;
 *     &lt;enumeration value="logical-not"/&gt;
 *     &lt;enumeration value="property-equals"/&gt;
 *     &lt;enumeration value="property-does-not-equal"/&gt;
 *     &lt;enumeration value="property-greater-than"/&gt;
 *     &lt;enumeration value="property-greater-than-or-equal"/&gt;
 *     &lt;enumeration value="property-less-than"/&gt;
 *     &lt;enumeration value="property-less-than-or-equal"/&gt;
 *     &lt;enumeration value="property-value-in-list"/&gt;
 *     &lt;enumeration value="property-value-not-in-list"/&gt;
 *     &lt;enumeration value="property-between"/&gt;
 *     &lt;enumeration value="property-contains"/&gt;
 *     &lt;enumeration value="property-ends-with"/&gt;
 *     &lt;enumeration value="property-starts-with"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "condition-evaluation")
@XmlEnum
public enum ConditionEvaluation {

    @XmlEnumValue("logical-and")
    LOGICAL_AND("logical-and"),
    @XmlEnumValue("logical-or")
    LOGICAL_OR("logical-or"),
    @XmlEnumValue("logical-not")
    LOGICAL_NOT("logical-not"),
    @XmlEnumValue("property-equals")
    PROPERTY_EQUALS("property-equals"),
    @XmlEnumValue("property-does-not-equal")
    PROPERTY_DOES_NOT_EQUAL("property-does-not-equal"),
    @XmlEnumValue("property-greater-than")
    PROPERTY_GREATER_THAN("property-greater-than"),
    @XmlEnumValue("property-greater-than-or-equal")
    PROPERTY_GREATER_THAN_OR_EQUAL("property-greater-than-or-equal"),
    @XmlEnumValue("property-less-than")
    PROPERTY_LESS_THAN("property-less-than"),
    @XmlEnumValue("property-less-than-or-equal")
    PROPERTY_LESS_THAN_OR_EQUAL("property-less-than-or-equal"),
    @XmlEnumValue("property-value-in-list")
    PROPERTY_VALUE_IN_LIST("property-value-in-list"),
    @XmlEnumValue("property-value-not-in-list")
    PROPERTY_VALUE_NOT_IN_LIST("property-value-not-in-list"),
    @XmlEnumValue("property-between")
    PROPERTY_BETWEEN("property-between"),
    @XmlEnumValue("property-contains")
    PROPERTY_CONTAINS("property-contains"),
    @XmlEnumValue("property-ends-with")
    PROPERTY_ENDS_WITH("property-ends-with"),
    @XmlEnumValue("property-starts-with")
    PROPERTY_STARTS_WITH("property-starts-with");
    private final String value;

    ConditionEvaluation(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ConditionEvaluation fromValue(String v) {
        for (ConditionEvaluation c: ConditionEvaluation.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
