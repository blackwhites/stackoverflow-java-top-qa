
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigB2BProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigB2BProfile"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ProfileType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmB2BProfileType {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BusinessIDs" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BusinessIDsDUNS" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BusinessIDsDUNSPlus4" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="CustomStylePolicy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="ResponseType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmXMLReqRespType1 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EmailAddresses" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Destinations" type="{http://www.datapower.com/schemas/management}dmB2BDestination" maxOccurs="unbounded"/&gt;
 *         &lt;element name="InboundVerifyValCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="InboundRequireSigned" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InboundRequireEncrypted" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InboundDecryptIdCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="MDNSSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="OutboundSign" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OutboundSignIdCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="OutboundSignDigestAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCMSHashAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OutboundSignMICAlgVersion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmSMIMEVersion {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Contacts" type="{http://www.datapower.com/schemas/management}dmB2BContact" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OverrideASID" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ASAllowDuplicateMessage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAllowDuplicateMessage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PreserveFilename" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSRole" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSPersistDuration" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSAckURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSErrorURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundSendReceipt" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundSendSignedReceipt" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundReceiptReplyPattern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEBMSReplyPattern {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSReceiptURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundErrorURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundVerifyValCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSDefaultSignerCert" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSAckSSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSInboundRequireSigned" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundRequireEncrypted" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSInboundDecryptIdCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSOutboundSign" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSOutboundSignIdCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSOutboundSignatureAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEBMSSignatureAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSOutboundSignatureC14NAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCryptoCanonicalizationAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSOutboundSignDigestAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCryptoHashAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSEnableCPABinding" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSProfileCPABindings" type="{http://www.datapower.com/schemas/management}dmProfileCPABinding" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EBMSCpaId" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSService" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSAction" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSStartParameter" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSAllowDuplicateMessage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAllowDuplicateMessage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MDNSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="MDNSSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSAckSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="EBMSAckSSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3OutboundSign" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3OutboundSignIdCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3OutboundSignDigestAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCryptoHashAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3OutboundSignatureAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmEBMSSignatureAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3OutboundSignatureC14NAlg" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmCryptoCanonicalizationAlgorithm {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3InboundVerifyValCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3DefaultSignerCert" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3ReceiptSSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3InboundRequireSigned" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3InboundRequireEncrypted" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3InboundDecryptIdCred" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3InboundRequireCompressed" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3ReceiptSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3ReceiptSSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSNotification" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSNotificationURL" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmURL {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMSNotificationSSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="EBMSNotificationSSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMSNotificationSSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="EBMS3AllowDuplicateMessage" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmAllowDuplicateMessage {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EBMS3DuplicateDetectionNotification" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigB2BProfile", propOrder = {
    "userSummary",
    "profileType",
    "businessIDs",
    "businessIDsDUNS",
    "businessIDsDUNSPlus4",
    "customStylePolicy",
    "responseType",
    "emailAddresses",
    "destinations",
    "inboundVerifyValCred",
    "inboundRequireSigned",
    "inboundRequireEncrypted",
    "inboundDecryptIdCred",
    "mdnsslProxy",
    "outboundSign",
    "outboundSignIdCred",
    "outboundSignDigestAlg",
    "outboundSignMICAlgVersion",
    "contacts",
    "overrideASID",
    "asAllowDuplicateMessage",
    "preserveFilename",
    "ebmsRole",
    "ebmsPersistDuration",
    "ebmsAckURL",
    "ebmsErrorURL",
    "ebmsInboundSendReceipt",
    "ebmsInboundSendSignedReceipt",
    "ebmsInboundReceiptReplyPattern",
    "ebmsReceiptURL",
    "ebmsInboundErrorURL",
    "ebmsInboundVerifyValCred",
    "ebmsDefaultSignerCert",
    "ebmsAckSSLProxy",
    "ebmsInboundRequireSigned",
    "ebmsInboundRequireEncrypted",
    "ebmsInboundDecryptIdCred",
    "ebmsOutboundSign",
    "ebmsOutboundSignIdCred",
    "ebmsOutboundSignatureAlg",
    "ebmsOutboundSignatureC14NAlg",
    "ebmsOutboundSignDigestAlg",
    "ebmsEnableCPABinding",
    "ebmsProfileCPABindings",
    "ebmsCpaId",
    "ebmsService",
    "ebmsAction",
    "ebmsStartParameter",
    "ebmsAllowDuplicateMessage",
    "mdnsslClientConfigType",
    "mdnsslClient",
    "ebmsAckSSLClientConfigType",
    "ebmsAckSSLClient",
    "ebms3OutboundSign",
    "ebms3OutboundSignIdCred",
    "ebms3OutboundSignDigestAlg",
    "ebms3OutboundSignatureAlg",
    "ebms3OutboundSignatureC14NAlg",
    "ebms3InboundVerifyValCred",
    "ebms3DefaultSignerCert",
    "ebms3ReceiptSSLProxy",
    "ebms3InboundRequireSigned",
    "ebms3InboundRequireEncrypted",
    "ebms3InboundDecryptIdCred",
    "ebms3InboundRequireCompressed",
    "ebms3ReceiptSSLClientConfigType",
    "ebms3ReceiptSSLClient",
    "ebmsNotification",
    "ebmsNotificationURL",
    "ebmsNotificationSSLClientConfigType",
    "ebmsNotificationSSLProxy",
    "ebmsNotificationSSLClient",
    "ebms3AllowDuplicateMessage",
    "ebms3DuplicateDetectionNotification"
})
public class ConfigB2BProfile
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "ProfileType")
    protected String profileType;
    @XmlElement(name = "BusinessIDs")
    protected List<String> businessIDs;
    @XmlElement(name = "BusinessIDsDUNS")
    protected List<String> businessIDsDUNS;
    @XmlElement(name = "BusinessIDsDUNSPlus4")
    protected List<String> businessIDsDUNSPlus4;
    @XmlElement(name = "CustomStylePolicy")
    protected DmReference customStylePolicy;
    @XmlElement(name = "ResponseType")
    protected String responseType;
    @XmlElement(name = "EmailAddresses")
    protected List<String> emailAddresses;
    @XmlElement(name = "Destinations")
    protected List<DmB2BDestination> destinations;
    @XmlElement(name = "InboundVerifyValCred")
    protected DmReference inboundVerifyValCred;
    @XmlElement(name = "InboundRequireSigned")
    protected String inboundRequireSigned;
    @XmlElement(name = "InboundRequireEncrypted")
    protected String inboundRequireEncrypted;
    @XmlElement(name = "InboundDecryptIdCred")
    protected DmReference inboundDecryptIdCred;
    @XmlElement(name = "MDNSSLProxy")
    protected DmReference mdnsslProxy;
    @XmlElement(name = "OutboundSign")
    protected String outboundSign;
    @XmlElement(name = "OutboundSignIdCred")
    protected DmReference outboundSignIdCred;
    @XmlElement(name = "OutboundSignDigestAlg")
    protected String outboundSignDigestAlg;
    @XmlElement(name = "OutboundSignMICAlgVersion")
    protected String outboundSignMICAlgVersion;
    @XmlElement(name = "Contacts")
    protected List<DmB2BContact> contacts;
    @XmlElement(name = "OverrideASID")
    protected String overrideASID;
    @XmlElement(name = "ASAllowDuplicateMessage")
    protected String asAllowDuplicateMessage;
    @XmlElement(name = "PreserveFilename")
    protected String preserveFilename;
    @XmlElement(name = "EBMSRole")
    protected String ebmsRole;
    @XmlElement(name = "EBMSPersistDuration")
    protected String ebmsPersistDuration;
    @XmlElement(name = "EBMSAckURL")
    protected String ebmsAckURL;
    @XmlElement(name = "EBMSErrorURL")
    protected String ebmsErrorURL;
    @XmlElement(name = "EBMSInboundSendReceipt")
    protected String ebmsInboundSendReceipt;
    @XmlElement(name = "EBMSInboundSendSignedReceipt")
    protected String ebmsInboundSendSignedReceipt;
    @XmlElement(name = "EBMSInboundReceiptReplyPattern")
    protected String ebmsInboundReceiptReplyPattern;
    @XmlElement(name = "EBMSReceiptURL")
    protected String ebmsReceiptURL;
    @XmlElement(name = "EBMSInboundErrorURL")
    protected String ebmsInboundErrorURL;
    @XmlElement(name = "EBMSInboundVerifyValCred")
    protected DmReference ebmsInboundVerifyValCred;
    @XmlElement(name = "EBMSDefaultSignerCert")
    protected DmReference ebmsDefaultSignerCert;
    @XmlElement(name = "EBMSAckSSLProxy")
    protected DmReference ebmsAckSSLProxy;
    @XmlElement(name = "EBMSInboundRequireSigned")
    protected String ebmsInboundRequireSigned;
    @XmlElement(name = "EBMSInboundRequireEncrypted")
    protected String ebmsInboundRequireEncrypted;
    @XmlElement(name = "EBMSInboundDecryptIdCred")
    protected DmReference ebmsInboundDecryptIdCred;
    @XmlElement(name = "EBMSOutboundSign")
    protected String ebmsOutboundSign;
    @XmlElement(name = "EBMSOutboundSignIdCred")
    protected DmReference ebmsOutboundSignIdCred;
    @XmlElement(name = "EBMSOutboundSignatureAlg")
    protected String ebmsOutboundSignatureAlg;
    @XmlElement(name = "EBMSOutboundSignatureC14NAlg")
    protected String ebmsOutboundSignatureC14NAlg;
    @XmlElement(name = "EBMSOutboundSignDigestAlg")
    protected String ebmsOutboundSignDigestAlg;
    @XmlElement(name = "EBMSEnableCPABinding")
    protected String ebmsEnableCPABinding;
    @XmlElement(name = "EBMSProfileCPABindings")
    protected List<DmProfileCPABinding> ebmsProfileCPABindings;
    @XmlElement(name = "EBMSCpaId")
    protected String ebmsCpaId;
    @XmlElement(name = "EBMSService")
    protected String ebmsService;
    @XmlElement(name = "EBMSAction")
    protected String ebmsAction;
    @XmlElement(name = "EBMSStartParameter")
    protected String ebmsStartParameter;
    @XmlElement(name = "EBMSAllowDuplicateMessage")
    protected String ebmsAllowDuplicateMessage;
    @XmlElement(name = "MDNSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType mdnsslClientConfigType;
    @XmlElement(name = "MDNSSLClient")
    protected DmReference mdnsslClient;
    @XmlElement(name = "EBMSAckSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType ebmsAckSSLClientConfigType;
    @XmlElement(name = "EBMSAckSSLClient")
    protected DmReference ebmsAckSSLClient;
    @XmlElement(name = "EBMS3OutboundSign")
    protected String ebms3OutboundSign;
    @XmlElement(name = "EBMS3OutboundSignIdCred")
    protected DmReference ebms3OutboundSignIdCred;
    @XmlElement(name = "EBMS3OutboundSignDigestAlg")
    protected String ebms3OutboundSignDigestAlg;
    @XmlElement(name = "EBMS3OutboundSignatureAlg")
    protected String ebms3OutboundSignatureAlg;
    @XmlElement(name = "EBMS3OutboundSignatureC14NAlg")
    protected String ebms3OutboundSignatureC14NAlg;
    @XmlElement(name = "EBMS3InboundVerifyValCred")
    protected DmReference ebms3InboundVerifyValCred;
    @XmlElement(name = "EBMS3DefaultSignerCert")
    protected DmReference ebms3DefaultSignerCert;
    @XmlElement(name = "EBMS3ReceiptSSLProxy")
    protected DmReference ebms3ReceiptSSLProxy;
    @XmlElement(name = "EBMS3InboundRequireSigned")
    protected String ebms3InboundRequireSigned;
    @XmlElement(name = "EBMS3InboundRequireEncrypted")
    protected String ebms3InboundRequireEncrypted;
    @XmlElement(name = "EBMS3InboundDecryptIdCred")
    protected DmReference ebms3InboundDecryptIdCred;
    @XmlElement(name = "EBMS3InboundRequireCompressed")
    protected String ebms3InboundRequireCompressed;
    @XmlElement(name = "EBMS3ReceiptSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType ebms3ReceiptSSLClientConfigType;
    @XmlElement(name = "EBMS3ReceiptSSLClient")
    protected DmReference ebms3ReceiptSSLClient;
    @XmlElement(name = "EBMSNotification")
    protected String ebmsNotification;
    @XmlElement(name = "EBMSNotificationURL")
    protected String ebmsNotificationURL;
    @XmlElement(name = "EBMSNotificationSSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType ebmsNotificationSSLClientConfigType;
    @XmlElement(name = "EBMSNotificationSSLProxy")
    protected DmReference ebmsNotificationSSLProxy;
    @XmlElement(name = "EBMSNotificationSSLClient")
    protected DmReference ebmsNotificationSSLClient;
    @XmlElement(name = "EBMS3AllowDuplicateMessage")
    protected String ebms3AllowDuplicateMessage;
    @XmlElement(name = "EBMS3DuplicateDetectionNotification")
    protected String ebms3DuplicateDetectionNotification;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the profileType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProfileType() {
        return profileType;
    }

    /**
     * Sets the value of the profileType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProfileType(String value) {
        this.profileType = value;
    }

    /**
     * Gets the value of the businessIDs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the businessIDs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBusinessIDs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBusinessIDs() {
        if (businessIDs == null) {
            businessIDs = new ArrayList<String>();
        }
        return this.businessIDs;
    }

    /**
     * Gets the value of the businessIDsDUNS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the businessIDsDUNS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBusinessIDsDUNS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBusinessIDsDUNS() {
        if (businessIDsDUNS == null) {
            businessIDsDUNS = new ArrayList<String>();
        }
        return this.businessIDsDUNS;
    }

    /**
     * Gets the value of the businessIDsDUNSPlus4 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the businessIDsDUNSPlus4 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBusinessIDsDUNSPlus4().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBusinessIDsDUNSPlus4() {
        if (businessIDsDUNSPlus4 == null) {
            businessIDsDUNSPlus4 = new ArrayList<String>();
        }
        return this.businessIDsDUNSPlus4;
    }

    /**
     * Gets the value of the customStylePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getCustomStylePolicy() {
        return customStylePolicy;
    }

    /**
     * Sets the value of the customStylePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setCustomStylePolicy(DmReference value) {
        this.customStylePolicy = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the emailAddresses property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emailAddresses property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmailAddresses().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEmailAddresses() {
        if (emailAddresses == null) {
            emailAddresses = new ArrayList<String>();
        }
        return this.emailAddresses;
    }

    /**
     * Gets the value of the destinations property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the destinations property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDestinations().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmB2BDestination }
     * 
     * 
     */
    public List<DmB2BDestination> getDestinations() {
        if (destinations == null) {
            destinations = new ArrayList<DmB2BDestination>();
        }
        return this.destinations;
    }

    /**
     * Gets the value of the inboundVerifyValCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getInboundVerifyValCred() {
        return inboundVerifyValCred;
    }

    /**
     * Sets the value of the inboundVerifyValCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setInboundVerifyValCred(DmReference value) {
        this.inboundVerifyValCred = value;
    }

    /**
     * Gets the value of the inboundRequireSigned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInboundRequireSigned() {
        return inboundRequireSigned;
    }

    /**
     * Sets the value of the inboundRequireSigned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInboundRequireSigned(String value) {
        this.inboundRequireSigned = value;
    }

    /**
     * Gets the value of the inboundRequireEncrypted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInboundRequireEncrypted() {
        return inboundRequireEncrypted;
    }

    /**
     * Sets the value of the inboundRequireEncrypted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInboundRequireEncrypted(String value) {
        this.inboundRequireEncrypted = value;
    }

    /**
     * Gets the value of the inboundDecryptIdCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getInboundDecryptIdCred() {
        return inboundDecryptIdCred;
    }

    /**
     * Sets the value of the inboundDecryptIdCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setInboundDecryptIdCred(DmReference value) {
        this.inboundDecryptIdCred = value;
    }

    /**
     * Gets the value of the mdnsslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMDNSSLProxy() {
        return mdnsslProxy;
    }

    /**
     * Sets the value of the mdnsslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMDNSSLProxy(DmReference value) {
        this.mdnsslProxy = value;
    }

    /**
     * Gets the value of the outboundSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutboundSign() {
        return outboundSign;
    }

    /**
     * Sets the value of the outboundSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutboundSign(String value) {
        this.outboundSign = value;
    }

    /**
     * Gets the value of the outboundSignIdCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getOutboundSignIdCred() {
        return outboundSignIdCred;
    }

    /**
     * Sets the value of the outboundSignIdCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setOutboundSignIdCred(DmReference value) {
        this.outboundSignIdCred = value;
    }

    /**
     * Gets the value of the outboundSignDigestAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutboundSignDigestAlg() {
        return outboundSignDigestAlg;
    }

    /**
     * Sets the value of the outboundSignDigestAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutboundSignDigestAlg(String value) {
        this.outboundSignDigestAlg = value;
    }

    /**
     * Gets the value of the outboundSignMICAlgVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutboundSignMICAlgVersion() {
        return outboundSignMICAlgVersion;
    }

    /**
     * Sets the value of the outboundSignMICAlgVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutboundSignMICAlgVersion(String value) {
        this.outboundSignMICAlgVersion = value;
    }

    /**
     * Gets the value of the contacts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contacts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContacts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmB2BContact }
     * 
     * 
     */
    public List<DmB2BContact> getContacts() {
        if (contacts == null) {
            contacts = new ArrayList<DmB2BContact>();
        }
        return this.contacts;
    }

    /**
     * Gets the value of the overrideASID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOverrideASID() {
        return overrideASID;
    }

    /**
     * Sets the value of the overrideASID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOverrideASID(String value) {
        this.overrideASID = value;
    }

    /**
     * Gets the value of the asAllowDuplicateMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getASAllowDuplicateMessage() {
        return asAllowDuplicateMessage;
    }

    /**
     * Sets the value of the asAllowDuplicateMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setASAllowDuplicateMessage(String value) {
        this.asAllowDuplicateMessage = value;
    }

    /**
     * Gets the value of the preserveFilename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreserveFilename() {
        return preserveFilename;
    }

    /**
     * Sets the value of the preserveFilename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreserveFilename(String value) {
        this.preserveFilename = value;
    }

    /**
     * Gets the value of the ebmsRole property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSRole() {
        return ebmsRole;
    }

    /**
     * Sets the value of the ebmsRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSRole(String value) {
        this.ebmsRole = value;
    }

    /**
     * Gets the value of the ebmsPersistDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSPersistDuration() {
        return ebmsPersistDuration;
    }

    /**
     * Sets the value of the ebmsPersistDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSPersistDuration(String value) {
        this.ebmsPersistDuration = value;
    }

    /**
     * Gets the value of the ebmsAckURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSAckURL() {
        return ebmsAckURL;
    }

    /**
     * Sets the value of the ebmsAckURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSAckURL(String value) {
        this.ebmsAckURL = value;
    }

    /**
     * Gets the value of the ebmsErrorURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSErrorURL() {
        return ebmsErrorURL;
    }

    /**
     * Sets the value of the ebmsErrorURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSErrorURL(String value) {
        this.ebmsErrorURL = value;
    }

    /**
     * Gets the value of the ebmsInboundSendReceipt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSInboundSendReceipt() {
        return ebmsInboundSendReceipt;
    }

    /**
     * Sets the value of the ebmsInboundSendReceipt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSInboundSendReceipt(String value) {
        this.ebmsInboundSendReceipt = value;
    }

    /**
     * Gets the value of the ebmsInboundSendSignedReceipt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSInboundSendSignedReceipt() {
        return ebmsInboundSendSignedReceipt;
    }

    /**
     * Sets the value of the ebmsInboundSendSignedReceipt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSInboundSendSignedReceipt(String value) {
        this.ebmsInboundSendSignedReceipt = value;
    }

    /**
     * Gets the value of the ebmsInboundReceiptReplyPattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSInboundReceiptReplyPattern() {
        return ebmsInboundReceiptReplyPattern;
    }

    /**
     * Sets the value of the ebmsInboundReceiptReplyPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSInboundReceiptReplyPattern(String value) {
        this.ebmsInboundReceiptReplyPattern = value;
    }

    /**
     * Gets the value of the ebmsReceiptURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSReceiptURL() {
        return ebmsReceiptURL;
    }

    /**
     * Sets the value of the ebmsReceiptURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSReceiptURL(String value) {
        this.ebmsReceiptURL = value;
    }

    /**
     * Gets the value of the ebmsInboundErrorURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSInboundErrorURL() {
        return ebmsInboundErrorURL;
    }

    /**
     * Sets the value of the ebmsInboundErrorURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSInboundErrorURL(String value) {
        this.ebmsInboundErrorURL = value;
    }

    /**
     * Gets the value of the ebmsInboundVerifyValCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSInboundVerifyValCred() {
        return ebmsInboundVerifyValCred;
    }

    /**
     * Sets the value of the ebmsInboundVerifyValCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSInboundVerifyValCred(DmReference value) {
        this.ebmsInboundVerifyValCred = value;
    }

    /**
     * Gets the value of the ebmsDefaultSignerCert property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSDefaultSignerCert() {
        return ebmsDefaultSignerCert;
    }

    /**
     * Sets the value of the ebmsDefaultSignerCert property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSDefaultSignerCert(DmReference value) {
        this.ebmsDefaultSignerCert = value;
    }

    /**
     * Gets the value of the ebmsAckSSLProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSAckSSLProxy() {
        return ebmsAckSSLProxy;
    }

    /**
     * Sets the value of the ebmsAckSSLProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSAckSSLProxy(DmReference value) {
        this.ebmsAckSSLProxy = value;
    }

    /**
     * Gets the value of the ebmsInboundRequireSigned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSInboundRequireSigned() {
        return ebmsInboundRequireSigned;
    }

    /**
     * Sets the value of the ebmsInboundRequireSigned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSInboundRequireSigned(String value) {
        this.ebmsInboundRequireSigned = value;
    }

    /**
     * Gets the value of the ebmsInboundRequireEncrypted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSInboundRequireEncrypted() {
        return ebmsInboundRequireEncrypted;
    }

    /**
     * Sets the value of the ebmsInboundRequireEncrypted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSInboundRequireEncrypted(String value) {
        this.ebmsInboundRequireEncrypted = value;
    }

    /**
     * Gets the value of the ebmsInboundDecryptIdCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSInboundDecryptIdCred() {
        return ebmsInboundDecryptIdCred;
    }

    /**
     * Sets the value of the ebmsInboundDecryptIdCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSInboundDecryptIdCred(DmReference value) {
        this.ebmsInboundDecryptIdCred = value;
    }

    /**
     * Gets the value of the ebmsOutboundSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSOutboundSign() {
        return ebmsOutboundSign;
    }

    /**
     * Sets the value of the ebmsOutboundSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSOutboundSign(String value) {
        this.ebmsOutboundSign = value;
    }

    /**
     * Gets the value of the ebmsOutboundSignIdCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSOutboundSignIdCred() {
        return ebmsOutboundSignIdCred;
    }

    /**
     * Sets the value of the ebmsOutboundSignIdCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSOutboundSignIdCred(DmReference value) {
        this.ebmsOutboundSignIdCred = value;
    }

    /**
     * Gets the value of the ebmsOutboundSignatureAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSOutboundSignatureAlg() {
        return ebmsOutboundSignatureAlg;
    }

    /**
     * Sets the value of the ebmsOutboundSignatureAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSOutboundSignatureAlg(String value) {
        this.ebmsOutboundSignatureAlg = value;
    }

    /**
     * Gets the value of the ebmsOutboundSignatureC14NAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSOutboundSignatureC14NAlg() {
        return ebmsOutboundSignatureC14NAlg;
    }

    /**
     * Sets the value of the ebmsOutboundSignatureC14NAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSOutboundSignatureC14NAlg(String value) {
        this.ebmsOutboundSignatureC14NAlg = value;
    }

    /**
     * Gets the value of the ebmsOutboundSignDigestAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSOutboundSignDigestAlg() {
        return ebmsOutboundSignDigestAlg;
    }

    /**
     * Sets the value of the ebmsOutboundSignDigestAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSOutboundSignDigestAlg(String value) {
        this.ebmsOutboundSignDigestAlg = value;
    }

    /**
     * Gets the value of the ebmsEnableCPABinding property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSEnableCPABinding() {
        return ebmsEnableCPABinding;
    }

    /**
     * Sets the value of the ebmsEnableCPABinding property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSEnableCPABinding(String value) {
        this.ebmsEnableCPABinding = value;
    }

    /**
     * Gets the value of the ebmsProfileCPABindings property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ebmsProfileCPABindings property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEBMSProfileCPABindings().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DmProfileCPABinding }
     * 
     * 
     */
    public List<DmProfileCPABinding> getEBMSProfileCPABindings() {
        if (ebmsProfileCPABindings == null) {
            ebmsProfileCPABindings = new ArrayList<DmProfileCPABinding>();
        }
        return this.ebmsProfileCPABindings;
    }

    /**
     * Gets the value of the ebmsCpaId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSCpaId() {
        return ebmsCpaId;
    }

    /**
     * Sets the value of the ebmsCpaId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSCpaId(String value) {
        this.ebmsCpaId = value;
    }

    /**
     * Gets the value of the ebmsService property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSService() {
        return ebmsService;
    }

    /**
     * Sets the value of the ebmsService property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSService(String value) {
        this.ebmsService = value;
    }

    /**
     * Gets the value of the ebmsAction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSAction() {
        return ebmsAction;
    }

    /**
     * Sets the value of the ebmsAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSAction(String value) {
        this.ebmsAction = value;
    }

    /**
     * Gets the value of the ebmsStartParameter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSStartParameter() {
        return ebmsStartParameter;
    }

    /**
     * Sets the value of the ebmsStartParameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSStartParameter(String value) {
        this.ebmsStartParameter = value;
    }

    /**
     * Gets the value of the ebmsAllowDuplicateMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSAllowDuplicateMessage() {
        return ebmsAllowDuplicateMessage;
    }

    /**
     * Sets the value of the ebmsAllowDuplicateMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSAllowDuplicateMessage(String value) {
        this.ebmsAllowDuplicateMessage = value;
    }

    /**
     * Gets the value of the mdnsslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getMDNSSLClientConfigType() {
        return mdnsslClientConfigType;
    }

    /**
     * Sets the value of the mdnsslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setMDNSSLClientConfigType(DmSSLClientConfigType value) {
        this.mdnsslClientConfigType = value;
    }

    /**
     * Gets the value of the mdnsslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getMDNSSLClient() {
        return mdnsslClient;
    }

    /**
     * Sets the value of the mdnsslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setMDNSSLClient(DmReference value) {
        this.mdnsslClient = value;
    }

    /**
     * Gets the value of the ebmsAckSSLClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getEBMSAckSSLClientConfigType() {
        return ebmsAckSSLClientConfigType;
    }

    /**
     * Sets the value of the ebmsAckSSLClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setEBMSAckSSLClientConfigType(DmSSLClientConfigType value) {
        this.ebmsAckSSLClientConfigType = value;
    }

    /**
     * Gets the value of the ebmsAckSSLClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSAckSSLClient() {
        return ebmsAckSSLClient;
    }

    /**
     * Sets the value of the ebmsAckSSLClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSAckSSLClient(DmReference value) {
        this.ebmsAckSSLClient = value;
    }

    /**
     * Gets the value of the ebms3OutboundSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3OutboundSign() {
        return ebms3OutboundSign;
    }

    /**
     * Sets the value of the ebms3OutboundSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3OutboundSign(String value) {
        this.ebms3OutboundSign = value;
    }

    /**
     * Gets the value of the ebms3OutboundSignIdCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMS3OutboundSignIdCred() {
        return ebms3OutboundSignIdCred;
    }

    /**
     * Sets the value of the ebms3OutboundSignIdCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMS3OutboundSignIdCred(DmReference value) {
        this.ebms3OutboundSignIdCred = value;
    }

    /**
     * Gets the value of the ebms3OutboundSignDigestAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3OutboundSignDigestAlg() {
        return ebms3OutboundSignDigestAlg;
    }

    /**
     * Sets the value of the ebms3OutboundSignDigestAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3OutboundSignDigestAlg(String value) {
        this.ebms3OutboundSignDigestAlg = value;
    }

    /**
     * Gets the value of the ebms3OutboundSignatureAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3OutboundSignatureAlg() {
        return ebms3OutboundSignatureAlg;
    }

    /**
     * Sets the value of the ebms3OutboundSignatureAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3OutboundSignatureAlg(String value) {
        this.ebms3OutboundSignatureAlg = value;
    }

    /**
     * Gets the value of the ebms3OutboundSignatureC14NAlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3OutboundSignatureC14NAlg() {
        return ebms3OutboundSignatureC14NAlg;
    }

    /**
     * Sets the value of the ebms3OutboundSignatureC14NAlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3OutboundSignatureC14NAlg(String value) {
        this.ebms3OutboundSignatureC14NAlg = value;
    }

    /**
     * Gets the value of the ebms3InboundVerifyValCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMS3InboundVerifyValCred() {
        return ebms3InboundVerifyValCred;
    }

    /**
     * Sets the value of the ebms3InboundVerifyValCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMS3InboundVerifyValCred(DmReference value) {
        this.ebms3InboundVerifyValCred = value;
    }

    /**
     * Gets the value of the ebms3DefaultSignerCert property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMS3DefaultSignerCert() {
        return ebms3DefaultSignerCert;
    }

    /**
     * Sets the value of the ebms3DefaultSignerCert property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMS3DefaultSignerCert(DmReference value) {
        this.ebms3DefaultSignerCert = value;
    }

    /**
     * Gets the value of the ebms3ReceiptSSLProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMS3ReceiptSSLProxy() {
        return ebms3ReceiptSSLProxy;
    }

    /**
     * Sets the value of the ebms3ReceiptSSLProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMS3ReceiptSSLProxy(DmReference value) {
        this.ebms3ReceiptSSLProxy = value;
    }

    /**
     * Gets the value of the ebms3InboundRequireSigned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3InboundRequireSigned() {
        return ebms3InboundRequireSigned;
    }

    /**
     * Sets the value of the ebms3InboundRequireSigned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3InboundRequireSigned(String value) {
        this.ebms3InboundRequireSigned = value;
    }

    /**
     * Gets the value of the ebms3InboundRequireEncrypted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3InboundRequireEncrypted() {
        return ebms3InboundRequireEncrypted;
    }

    /**
     * Sets the value of the ebms3InboundRequireEncrypted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3InboundRequireEncrypted(String value) {
        this.ebms3InboundRequireEncrypted = value;
    }

    /**
     * Gets the value of the ebms3InboundDecryptIdCred property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMS3InboundDecryptIdCred() {
        return ebms3InboundDecryptIdCred;
    }

    /**
     * Sets the value of the ebms3InboundDecryptIdCred property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMS3InboundDecryptIdCred(DmReference value) {
        this.ebms3InboundDecryptIdCred = value;
    }

    /**
     * Gets the value of the ebms3InboundRequireCompressed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3InboundRequireCompressed() {
        return ebms3InboundRequireCompressed;
    }

    /**
     * Sets the value of the ebms3InboundRequireCompressed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3InboundRequireCompressed(String value) {
        this.ebms3InboundRequireCompressed = value;
    }

    /**
     * Gets the value of the ebms3ReceiptSSLClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getEBMS3ReceiptSSLClientConfigType() {
        return ebms3ReceiptSSLClientConfigType;
    }

    /**
     * Sets the value of the ebms3ReceiptSSLClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setEBMS3ReceiptSSLClientConfigType(DmSSLClientConfigType value) {
        this.ebms3ReceiptSSLClientConfigType = value;
    }

    /**
     * Gets the value of the ebms3ReceiptSSLClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMS3ReceiptSSLClient() {
        return ebms3ReceiptSSLClient;
    }

    /**
     * Sets the value of the ebms3ReceiptSSLClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMS3ReceiptSSLClient(DmReference value) {
        this.ebms3ReceiptSSLClient = value;
    }

    /**
     * Gets the value of the ebmsNotification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSNotification() {
        return ebmsNotification;
    }

    /**
     * Sets the value of the ebmsNotification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSNotification(String value) {
        this.ebmsNotification = value;
    }

    /**
     * Gets the value of the ebmsNotificationURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMSNotificationURL() {
        return ebmsNotificationURL;
    }

    /**
     * Sets the value of the ebmsNotificationURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMSNotificationURL(String value) {
        this.ebmsNotificationURL = value;
    }

    /**
     * Gets the value of the ebmsNotificationSSLClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getEBMSNotificationSSLClientConfigType() {
        return ebmsNotificationSSLClientConfigType;
    }

    /**
     * Sets the value of the ebmsNotificationSSLClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setEBMSNotificationSSLClientConfigType(DmSSLClientConfigType value) {
        this.ebmsNotificationSSLClientConfigType = value;
    }

    /**
     * Gets the value of the ebmsNotificationSSLProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSNotificationSSLProxy() {
        return ebmsNotificationSSLProxy;
    }

    /**
     * Sets the value of the ebmsNotificationSSLProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSNotificationSSLProxy(DmReference value) {
        this.ebmsNotificationSSLProxy = value;
    }

    /**
     * Gets the value of the ebmsNotificationSSLClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getEBMSNotificationSSLClient() {
        return ebmsNotificationSSLClient;
    }

    /**
     * Sets the value of the ebmsNotificationSSLClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setEBMSNotificationSSLClient(DmReference value) {
        this.ebmsNotificationSSLClient = value;
    }

    /**
     * Gets the value of the ebms3AllowDuplicateMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3AllowDuplicateMessage() {
        return ebms3AllowDuplicateMessage;
    }

    /**
     * Sets the value of the ebms3AllowDuplicateMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3AllowDuplicateMessage(String value) {
        this.ebms3AllowDuplicateMessage = value;
    }

    /**
     * Gets the value of the ebms3DuplicateDetectionNotification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEBMS3DuplicateDetectionNotification() {
        return ebms3DuplicateDetectionNotification;
    }

    /**
     * Sets the value of the ebms3DuplicateDetectionNotification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEBMS3DuplicateDetectionNotification(String value) {
        this.ebms3DuplicateDetectionNotification = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
