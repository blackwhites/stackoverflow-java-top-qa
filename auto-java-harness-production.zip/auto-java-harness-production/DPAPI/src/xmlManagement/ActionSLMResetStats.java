
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActionSLMResetStats complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActionSLMResetStats"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SLMPolicy"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SLMStatementID"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SLMCredential"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SLMResource"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActionSLMResetStats", propOrder = {
    "slmPolicy",
    "slmStatementID",
    "slmCredential",
    "slmResource"
})
public class ActionSLMResetStats {

    @XmlElement(name = "SLMPolicy", required = true)
    protected String slmPolicy;
    @XmlElement(name = "SLMStatementID", required = true)
    protected String slmStatementID;
    @XmlElement(name = "SLMCredential", required = true)
    protected String slmCredential;
    @XmlElement(name = "SLMResource", required = true)
    protected String slmResource;

    /**
     * Gets the value of the slmPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSLMPolicy() {
        return slmPolicy;
    }

    /**
     * Sets the value of the slmPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSLMPolicy(String value) {
        this.slmPolicy = value;
    }

    /**
     * Gets the value of the slmStatementID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSLMStatementID() {
        return slmStatementID;
    }

    /**
     * Sets the value of the slmStatementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSLMStatementID(String value) {
        this.slmStatementID = value;
    }

    /**
     * Gets the value of the slmCredential property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSLMCredential() {
        return slmCredential;
    }

    /**
     * Sets the value of the slmCredential property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSLMCredential(String value) {
        this.slmCredential = value;
    }

    /**
     * Gets the value of the slmResource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSLMResource() {
        return slmResource;
    }

    /**
     * Sets the value of the slmResource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSLMResource(String value) {
        this.slmResource = value;
    }

}
