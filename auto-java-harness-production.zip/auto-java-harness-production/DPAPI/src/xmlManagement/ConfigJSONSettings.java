
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigJSONSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigJSONSettings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JSONMaxNestingDepth" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JSONMaxLabelLength" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JSONMaxValueLength" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt64 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JSONMaxNumberLength" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JSONDocumentSize" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt64 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigJSONSettings", propOrder = {
    "userSummary",
    "jsonMaxNestingDepth",
    "jsonMaxLabelLength",
    "jsonMaxValueLength",
    "jsonMaxNumberLength",
    "jsonDocumentSize"
})
public class ConfigJSONSettings
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "JSONMaxNestingDepth")
    protected String jsonMaxNestingDepth;
    @XmlElement(name = "JSONMaxLabelLength")
    protected String jsonMaxLabelLength;
    @XmlElement(name = "JSONMaxValueLength")
    protected String jsonMaxValueLength;
    @XmlElement(name = "JSONMaxNumberLength")
    protected String jsonMaxNumberLength;
    @XmlElement(name = "JSONDocumentSize")
    protected String jsonDocumentSize;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the jsonMaxNestingDepth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJSONMaxNestingDepth() {
        return jsonMaxNestingDepth;
    }

    /**
     * Sets the value of the jsonMaxNestingDepth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJSONMaxNestingDepth(String value) {
        this.jsonMaxNestingDepth = value;
    }

    /**
     * Gets the value of the jsonMaxLabelLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJSONMaxLabelLength() {
        return jsonMaxLabelLength;
    }

    /**
     * Sets the value of the jsonMaxLabelLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJSONMaxLabelLength(String value) {
        this.jsonMaxLabelLength = value;
    }

    /**
     * Gets the value of the jsonMaxValueLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJSONMaxValueLength() {
        return jsonMaxValueLength;
    }

    /**
     * Sets the value of the jsonMaxValueLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJSONMaxValueLength(String value) {
        this.jsonMaxValueLength = value;
    }

    /**
     * Gets the value of the jsonMaxNumberLength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJSONMaxNumberLength() {
        return jsonMaxNumberLength;
    }

    /**
     * Sets the value of the jsonMaxNumberLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJSONMaxNumberLength(String value) {
        this.jsonMaxNumberLength = value;
    }

    /**
     * Gets the value of the jsonDocumentSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJSONDocumentSize() {
        return jsonDocumentSize;
    }

    /**
     * Sets the value of the jsonDocumentSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJSONDocumentSize(String value) {
        this.jsonDocumentSize = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
