
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigSecureCloudConnector complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigSecureCloudConnector"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteAddress"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemotePort"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSHClientProfileRef" type="{http://www.datapower.com/schemas/management}dmReference"/&gt;
 *         &lt;element name="LocalTunnelIP"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteTunnelIP"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPHostAddress {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteTunnelID" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt32 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RemoteAutoConfig" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ICMPLivenessCheck" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{http://www.datapower.com/schemas/management}ConfigAttributes"/&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigSecureCloudConnector", propOrder = {
    "userSummary",
    "remoteAddress",
    "remotePort",
    "sshClientProfileRef",
    "localTunnelIP",
    "remoteTunnelIP",
    "remoteTunnelID",
    "remoteAutoConfig",
    "icmpLivenessCheck"
})
public class ConfigSecureCloudConnector
    extends ConfigConfigBase
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "RemoteAddress")
    protected String remoteAddress;
    @XmlElement(name = "RemotePort")
    protected String remotePort;
    @XmlElement(name = "SSHClientProfileRef")
    protected DmReference sshClientProfileRef;
    @XmlElement(name = "LocalTunnelIP")
    protected String localTunnelIP;
    @XmlElement(name = "RemoteTunnelIP")
    protected String remoteTunnelIP;
    @XmlElement(name = "RemoteTunnelID")
    protected String remoteTunnelID;
    @XmlElement(name = "RemoteAutoConfig")
    protected String remoteAutoConfig;
    @XmlElement(name = "ICMPLivenessCheck")
    protected String icmpLivenessCheck;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "local")
    protected Boolean local;
    @XmlAttribute(name = "intrinsic")
    protected Boolean intrinsic;
    @XmlAttribute(name = "read-only")
    protected Boolean readOnlyAttribute;
    @XmlAttribute(name = "external")
    protected Boolean external;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the remoteAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteAddress() {
        return remoteAddress;
    }

    /**
     * Sets the value of the remoteAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteAddress(String value) {
        this.remoteAddress = value;
    }

    /**
     * Gets the value of the remotePort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemotePort() {
        return remotePort;
    }

    /**
     * Sets the value of the remotePort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemotePort(String value) {
        this.remotePort = value;
    }

    /**
     * Gets the value of the sshClientProfileRef property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSHClientProfileRef() {
        return sshClientProfileRef;
    }

    /**
     * Sets the value of the sshClientProfileRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSHClientProfileRef(DmReference value) {
        this.sshClientProfileRef = value;
    }

    /**
     * Gets the value of the localTunnelIP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalTunnelIP() {
        return localTunnelIP;
    }

    /**
     * Sets the value of the localTunnelIP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalTunnelIP(String value) {
        this.localTunnelIP = value;
    }

    /**
     * Gets the value of the remoteTunnelIP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteTunnelIP() {
        return remoteTunnelIP;
    }

    /**
     * Sets the value of the remoteTunnelIP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteTunnelIP(String value) {
        this.remoteTunnelIP = value;
    }

    /**
     * Gets the value of the remoteTunnelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteTunnelID() {
        return remoteTunnelID;
    }

    /**
     * Sets the value of the remoteTunnelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteTunnelID(String value) {
        this.remoteTunnelID = value;
    }

    /**
     * Gets the value of the remoteAutoConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteAutoConfig() {
        return remoteAutoConfig;
    }

    /**
     * Sets the value of the remoteAutoConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteAutoConfig(String value) {
        this.remoteAutoConfig = value;
    }

    /**
     * Gets the value of the icmpLivenessCheck property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getICMPLivenessCheck() {
        return icmpLivenessCheck;
    }

    /**
     * Sets the value of the icmpLivenessCheck property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setICMPLivenessCheck(String value) {
        this.icmpLivenessCheck = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocal() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocal(Boolean value) {
        this.local = value;
    }

    /**
     * Gets the value of the intrinsic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntrinsic() {
        return intrinsic;
    }

    /**
     * Sets the value of the intrinsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntrinsic(Boolean value) {
        this.intrinsic = value;
    }

    /**
     * Gets the value of the readOnlyAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadOnlyAttribute() {
        return readOnlyAttribute;
    }

    /**
     * Sets the value of the readOnlyAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadOnlyAttribute(Boolean value) {
        this.readOnlyAttribute = value;
    }

    /**
     * Gets the value of the external property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternal() {
        return external;
    }

    /**
     * Sets the value of the external property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternal(Boolean value) {
        this.external = value;
    }

}
