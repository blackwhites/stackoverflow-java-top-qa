
package xmlManagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnyDeleteElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AnyDeleteElement"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded"&gt;
 *         &lt;element name="AAAPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Domain" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LDAPSearchParameters" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ProcessingMetadata" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="RADIUSSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="RBMSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SAMLAttributes" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SOAPHeaderDisposition" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TAM" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TFIMEndpoint" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XACMLPDP" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AccessControlList" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AppSecurityPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AuditLog" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BCPA" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BCPACollaboration" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BCPAReceiverSetting" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BCPASenderSetting" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BGateway" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BPersistence" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BProfileGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="B2BXPathRoutingPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WXSGrid" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XC10Grid" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CloudConnectorService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CloudGatewayService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CompactFlash" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CompileOptionsPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ConfigDeploymentPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ConformancePolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AAAJWTGenerator" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AAAJWTValidator" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CertMonitor" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CookieAttributePolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CRLFetch" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoCertificate" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoFWCred" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoIdentCred" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoKerberosKDC" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoKerberosKeytab" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoKey" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoSSKey" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CryptoValCred" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="JOSERecipientIdentifier" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="JOSESignatureIdentifier" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="JWEHeader" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="JWERecipient" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="JWSSignature" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="OAuthSupportedClient" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="OAuthSupportedClientGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SocialLoginPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSHClientProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSHDomainClientProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSHServerProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSLClientProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSLProxyProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSLServerProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSLSNIMapping" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSLSNIServerProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DeploymentPolicyParametersBinding" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ErrorReportSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SystemSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TimeSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DFDLSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DomainAvailability" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DomainSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SchemaExceptionMap" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DocumentCryptoMap" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XPathRoutingMap" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LogTarget" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="FormsLoginPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="FTPQuoteCommands" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MultiProtocolGateway" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSGateway" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="GeneratedPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="HTTPInputConversionMap" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="HTTPUserAgent" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ILMTAgent" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ImportPackage" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IMSConnect" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IncludeConfig" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="InteropService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="EthernetInterface" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LinkAggregation" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="VLANInterface" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IPMILanChannel" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IPMIUser" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IPMulticast" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ISAMReverseProxy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ISAMReverseProxyJunction" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ISAMRuntime" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IScsiChapConfig" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IScsiHBAConfig" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IScsiInitiatorConfig" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IScsiTargetConfig" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IScsiVolumeConfig" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TibcoEMSServer" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebSphereJMSServer" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="JSONSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Language" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LDAPConnectionPool" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LoadBalancerGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LogLabel" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Luna" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="LunaPartition" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Matching" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MCFCustomRule" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MCFHttpHeader" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MCFHttpMethod" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MCFHttpURL" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MCFXPath" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MessageContentFilters" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="FilterAction" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MessageMatching" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="CountMonitor" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DurationMonitor" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MessageType" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MPGWErrorAction" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MPGWErrorHandlingPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQAUI" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQGW" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQhost" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQproxy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQQM" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQQMGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MTOMPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NameValueProfile" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="DNSNameService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="HostAlias" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NetworkSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NTPService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NFSClientSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NFSDynamicMounts" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NFSStaticMount" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ODR" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ODRConnectorGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="PasswordAlias" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Pattern" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="PeerGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="PolicyAttachments" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="PolicyParameters" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="QuotaEnforcementServer" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="RaidVolume" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SQLRuntimeSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SecureBackupMode" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SecureCloudConnector" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SecureGatewayClient" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MgmtInterface" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="RestMgmtInterface" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSHService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TelnetService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebB2BViewer" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebGUI" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XMLFirewallService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XSLProxyService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="HTTPService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSLProxyService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TCPProxyService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XSLCoprocService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ShellAlias" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SimpleCountMonitor" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SLMAction" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SLMCredClass" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SLMPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SLMRsrcClass" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SLMSchedule" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SMTPServerConnection" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SNMPSettings" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AS2ProxySourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AS2SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AS3SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="EBMS2SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="EBMS3SourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="FTPFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="NFSFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SFTPFilePollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="FTPServerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="HTTPSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="HTTPSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IMSCalloutSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="IMSConnectSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="TibcoEMSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebSphereJMSSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQFTESourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="MQSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="AS1PollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="POPPollerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SSHServerSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="StatelessTCPSourceProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XTCProtocolHandler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="SQLDataSource" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="StandaloneStandbyControl" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="StandaloneStandbyControlInterface" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Statistics" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="StylePolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="StylePolicyAction" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="StylePolicyRule" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSStylePolicyRule" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="Throttler" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="UDDIRegistry" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="URLMap" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="URLRefreshPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="URLRewritePolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="User" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="UserGroup" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WCCService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebAppErrorHandlingPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebAppFW" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebAppRequest" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebAppResponse" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebAppSessionPolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebServiceMonitor" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebServicesAgent" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="UDDISubscription" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSRRSavedSearchSubscription" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSRRSubscription" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WebTokenService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSEndpointRewritePolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSRRServer" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="WSStylePolicy" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="XMLManager" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="xmltrace" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ZHybridTargetControlService" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *         &lt;element name="ZosNSSClient" type="{http://www.datapower.com/schemas/management}dmDelConfig"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnyDeleteElement", propOrder = {
    "configObjects"
})
public class AnyDeleteElement {

    @XmlElementRefs({
        @XmlElementRef(name = "TAM", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSLClientProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MessageContentFilters", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XC10Grid", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "StylePolicyRule", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "OAuthSupportedClientGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AccessControlList", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoValCred", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Matching", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoCertificate", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Luna", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DeploymentPolicyParametersBinding", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "JWSSignature", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SecureBackupMode", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MessageMatching", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "URLRefreshPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ISAMReverseProxy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSLProxyProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SOAPHeaderDisposition", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "RestMgmtInterface", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "StandaloneStandbyControl", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSStylePolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSHDomainClientProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SNMPSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "HTTPSSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "GeneratedPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "RADIUSSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ShellAlias", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CloudConnectorService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SecureCloudConnector", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "OAuthSupportedClient", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TFIMEndpoint", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQGW", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IScsiInitiatorConfig", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "EBMS3SourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "HTTPService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "JSONSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "RBMSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "StylePolicyAction", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SimpleCountMonitor", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NTPService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MCFHttpMethod", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "FilterAction", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Pattern", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SLMAction", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "POPPollerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebServiceMonitor", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "JWEHeader", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SQLRuntimeSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IScsiTargetConfig", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SocialLoginPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AAAJWTGenerator", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AS2ProxySourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSRRSavedSearchSubscription", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoKerberosKDC", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "URLMap", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LogLabel", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "VLANInterface", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DomainAvailability", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IScsiChapConfig", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ODR", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "FTPServerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "HTTPSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "StatelessTCPSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LDAPConnectionPool", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "FormsLoginPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "PolicyParameters", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoKerberosKeytab", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MCFXPath", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "JOSESignatureIdentifier", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IMSConnect", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ZHybridTargetControlService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MCFCustomRule", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebTokenService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XSLCoprocService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "FTPFilePollerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "InteropService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQhost", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQproxy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DurationMonitor", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MTOMPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSHServerProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQAUI", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DomainSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoFWCred", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ILMTAgent", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSEndpointRewritePolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSStylePolicyRule", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BCPASenderSetting", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "URLRewritePolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AS1PollerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSLServerProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TimeSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XMLManager", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ProcessingMetadata", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IScsiVolumeConfig", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NetworkSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DNSNameService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NameValueProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SQLDataSource", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SystemSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebGUI", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XTCProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SecureGatewayClient", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ConformancePolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "UDDIRegistry", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "JOSERecipientIdentifier", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MPGWErrorAction", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WXSGrid", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "PolicyAttachments", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "StylePolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Domain", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQQM", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "PasswordAlias", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Throttler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LoadBalancerGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NFSFilePollerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SLMRsrcClass", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AS2SourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TCPProxyService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "HTTPInputConversionMap", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSRRSubscription", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LunaPartition", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CertMonitor", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LinkAggregation", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AuditLog", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MCFHttpHeader", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MessageType", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NFSClientSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "QuotaEnforcementServer", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SLMCredClass", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSHService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XSLProxyService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AAAJWTValidator", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ISAMRuntime", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSGateway", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "FTPQuoteCommands", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebAppFW", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BPersistence", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TelnetService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "StandaloneStandbyControlInterface", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IMSCalloutSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "EthernetInterface", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "JWERecipient", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MgmtInterface", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XMLFirewallService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "HTTPUserAgent", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BGateway", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CookieAttributePolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebServicesAgent", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DocumentCryptoMap", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "xmltrace", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Statistics", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TibcoEMSServer", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebAppSessionPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSHClientProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IScsiHBAConfig", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NFSDynamicMounts", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ISAMReverseProxyJunction", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoIdentCred", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "HostAlias", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "UserGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "PeerGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BProfileGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SFTPFilePollerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SchemaExceptionMap", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IMSConnectSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IPMIUser", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ODRConnectorGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "RaidVolume", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ErrorReportSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebSphereJMSServer", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LogTarget", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebAppResponse", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IPMILanChannel", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AS3SourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AppSecurityPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BXPathRoutingPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CRLFetch", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MultiProtocolGateway", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebAppErrorHandlingPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BCPAReceiverSetting", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoKey", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BCPACollaboration", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SLMPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSLSNIServerProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AAAPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SAMLAttributes", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XACMLPDP", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WCCService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "XPathRoutingMap", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQFTESourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "NFSStaticMount", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebAppRequest", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IPMulticast", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "IncludeConfig", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ZosNSSClient", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BProfile", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "Language", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CompactFlash", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSHServerSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSLProxyService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CloudGatewayService", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CountMonitor", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ConfigDeploymentPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CryptoSSKey", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MQQMGroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebSphereJMSSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SLMSchedule", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "LDAPSearchParameters", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SSLSNIMapping", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WSRRServer", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MPGWErrorHandlingPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DFDLSettings", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "User", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "B2BCPA", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "MCFHttpURL", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "WebB2BViewer", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "SMTPServerConnection", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "UDDISubscription", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CompileOptionsPolicy", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "EBMS2SourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TibcoEMSSourceProtocolHandler", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ImportPackage", type = JAXBElement.class, required = false)
    })
    protected List<JAXBElement<DmDelConfig>> configObjects;

    /**
     * Gets the value of the configObjects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the configObjects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConfigObjects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * {@link JAXBElement }{@code <}{@link DmDelConfig }{@code >}
     * 
     * 
     */
    public List<JAXBElement<DmDelConfig>> getConfigObjects() {
        if (configObjects == null) {
            configObjects = new ArrayList<JAXBElement<DmDelConfig>>();
        }
        return this.configObjects;
    }

}
