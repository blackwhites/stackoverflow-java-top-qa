
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigRuntimeSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigRuntimeSettings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigConfigBase"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="EnableSharing" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Profiles" type="{http://www.datapower.com/schemas/management}dmRuntimeProfile"/&gt;
 *         &lt;element name="EnableJRTEDump" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmToggle {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigRuntimeSettings", propOrder = {
    "enableSharing",
    "profiles",
    "enableJRTEDump"
})
@XmlSeeAlso({
    ConfigSQLRuntimeSettings.class
})
public class ConfigRuntimeSettings
    extends ConfigConfigBase
{

    @XmlElement(name = "EnableSharing")
    protected String enableSharing;
    @XmlElement(name = "Profiles")
    protected DmRuntimeProfile profiles;
    @XmlElement(name = "EnableJRTEDump")
    protected String enableJRTEDump;

    /**
     * Gets the value of the enableSharing property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableSharing() {
        return enableSharing;
    }

    /**
     * Sets the value of the enableSharing property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableSharing(String value) {
        this.enableSharing = value;
    }

    /**
     * Gets the value of the profiles property.
     * 
     * @return
     *     possible object is
     *     {@link DmRuntimeProfile }
     *     
     */
    public DmRuntimeProfile getProfiles() {
        return profiles;
    }

    /**
     * Sets the value of the profiles property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmRuntimeProfile }
     *     
     */
    public void setProfiles(DmRuntimeProfile value) {
        this.profiles = value;
    }

    /**
     * Gets the value of the enableJRTEDump property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnableJRTEDump() {
        return enableJRTEDump;
    }

    /**
     * Sets the value of the enableJRTEDump property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnableJRTEDump(String value) {
        this.enableJRTEDump = value;
    }

}
