
package xmlManagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ConfigPOPPollerSourceProtocolHandlerBase complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConfigPOPPollerSourceProtocolHandlerBase"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.datapower.com/schemas/management}ConfigSourceProtocolHandler"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="UserSummary" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MailServer"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmHostname {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Port"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmIPPort {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ConnSecurity"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPOPConnSecurity {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLProxy" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="AuthMethod" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmPOPAuthMethod {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Account"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Password" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmString {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PasswordAlias" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *         &lt;element name="DelayBetweenPolls"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MaxMessagesPerPoll"&gt;
 *           &lt;simpleType&gt;
 *             &lt;union memberTypes=" {http://www.datapower.com/schemas/management}dmUInt16 {http://www.datapower.com/schemas/management}dmEmptyElement"&gt;
 *             &lt;/union&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SSLClientConfigType" type="{http://www.datapower.com/schemas/management}dmSSLClientConfigType" minOccurs="0"/&gt;
 *         &lt;element name="SSLClient" type="{http://www.datapower.com/schemas/management}dmReference" minOccurs="0"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConfigPOPPollerSourceProtocolHandlerBase", propOrder = {
    "userSummary",
    "mailServer",
    "port",
    "connSecurity",
    "sslProxy",
    "authMethod",
    "account",
    "password",
    "passwordAlias",
    "delayBetweenPolls",
    "maxMessagesPerPoll",
    "sslClientConfigType",
    "sslClient"
})
@XmlSeeAlso({
    ConfigAS1PollerSourceProtocolHandler.class,
    ConfigPOPPollerSourceProtocolHandler.class
})
public class ConfigPOPPollerSourceProtocolHandlerBase
    extends ConfigSourceProtocolHandler
{

    @XmlElement(name = "UserSummary")
    protected String userSummary;
    @XmlElement(name = "MailServer")
    protected String mailServer;
    @XmlElement(name = "Port")
    protected String port;
    @XmlElement(name = "ConnSecurity")
    protected String connSecurity;
    @XmlElement(name = "SSLProxy")
    protected DmReference sslProxy;
    @XmlElement(name = "AuthMethod")
    protected String authMethod;
    @XmlElement(name = "Account")
    protected String account;
    @XmlElement(name = "Password")
    protected String password;
    @XmlElement(name = "PasswordAlias")
    protected DmReference passwordAlias;
    @XmlElement(name = "DelayBetweenPolls")
    protected String delayBetweenPolls;
    @XmlElement(name = "MaxMessagesPerPoll")
    protected String maxMessagesPerPoll;
    @XmlElement(name = "SSLClientConfigType")
    @XmlSchemaType(name = "string")
    protected DmSSLClientConfigType sslClientConfigType;
    @XmlElement(name = "SSLClient")
    protected DmReference sslClient;

    /**
     * Gets the value of the userSummary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserSummary() {
        return userSummary;
    }

    /**
     * Sets the value of the userSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserSummary(String value) {
        this.userSummary = value;
    }

    /**
     * Gets the value of the mailServer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailServer() {
        return mailServer;
    }

    /**
     * Sets the value of the mailServer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailServer(String value) {
        this.mailServer = value;
    }

    /**
     * Gets the value of the port property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPort() {
        return port;
    }

    /**
     * Sets the value of the port property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPort(String value) {
        this.port = value;
    }

    /**
     * Gets the value of the connSecurity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConnSecurity() {
        return connSecurity;
    }

    /**
     * Sets the value of the connSecurity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConnSecurity(String value) {
        this.connSecurity = value;
    }

    /**
     * Gets the value of the sslProxy property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLProxy() {
        return sslProxy;
    }

    /**
     * Sets the value of the sslProxy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLProxy(DmReference value) {
        this.sslProxy = value;
    }

    /**
     * Gets the value of the authMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthMethod() {
        return authMethod;
    }

    /**
     * Sets the value of the authMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthMethod(String value) {
        this.authMethod = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccount(String value) {
        this.account = value;
    }

    /**
     * Gets the value of the password property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassword(String value) {
        this.password = value;
    }

    /**
     * Gets the value of the passwordAlias property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getPasswordAlias() {
        return passwordAlias;
    }

    /**
     * Sets the value of the passwordAlias property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setPasswordAlias(DmReference value) {
        this.passwordAlias = value;
    }

    /**
     * Gets the value of the delayBetweenPolls property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayBetweenPolls() {
        return delayBetweenPolls;
    }

    /**
     * Sets the value of the delayBetweenPolls property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayBetweenPolls(String value) {
        this.delayBetweenPolls = value;
    }

    /**
     * Gets the value of the maxMessagesPerPoll property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxMessagesPerPoll() {
        return maxMessagesPerPoll;
    }

    /**
     * Sets the value of the maxMessagesPerPoll property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxMessagesPerPoll(String value) {
        this.maxMessagesPerPoll = value;
    }

    /**
     * Gets the value of the sslClientConfigType property.
     * 
     * @return
     *     possible object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public DmSSLClientConfigType getSSLClientConfigType() {
        return sslClientConfigType;
    }

    /**
     * Sets the value of the sslClientConfigType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmSSLClientConfigType }
     *     
     */
    public void setSSLClientConfigType(DmSSLClientConfigType value) {
        this.sslClientConfigType = value;
    }

    /**
     * Gets the value of the sslClient property.
     * 
     * @return
     *     possible object is
     *     {@link DmReference }
     *     
     */
    public DmReference getSSLClient() {
        return sslClient;
    }

    /**
     * Sets the value of the sslClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link DmReference }
     *     
     */
    public void setSSLClient(DmReference value) {
        this.sslClient = value;
    }

}
