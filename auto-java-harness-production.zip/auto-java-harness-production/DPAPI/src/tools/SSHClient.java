package tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import variables.CLIVariables;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.HostKey;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * Creates an interactive ssh shell for users to send commands to a remote service
 * Uses a default buffer of 100K to read responses, this can make retrieving large responses, ie cat 100MB.xml,
 * very slow.  You can increase the buffer size by using the proper constructor, make sure you have enough heap 
 * space allocated in your JVM.  You can increase the buffer size by using the proper constructor to increase speed, make sure you have enough heap 
 space allocated in your JVM. 
 <br/><br/>NOTE:  There are some issues with the current version when sending certain linux commands like appending to a file >>.  The command might come back incorrectly in the response.  
 This will prevent the object from trimming properly.  A fix is being worked out.<br/><br/>
 Sample:<br/>
 <br/>When using the SSHClient to connect to a DP device use the dpClient.loginDP("{domain}"), this will handle starting the session and logging the user into the specified domain.<br/>
 You can go through the log in process yourself by using the startSession method instead.<br/><br/>
 When using the SSHClient to connect to a linux machine you only need to use the startSession method.  This will start the session and handle the log in process.<br/><br/>
 	&emsp;public boolean helloWorldDP(){  <br/>
&emsp;&emsp;		SSHClient dpClient = null;<br/>
 					&emsp;&emsp;				try{<br/>
 	&emsp;&emsp;&emsp;	dpClient = new SSHClient("dpvirt4a.dp.rtp.raleigh.ibm.com", 22, "admin", "admin1");<br/>
  	&emsp;&emsp;				}catch(Exception e){<br/>
 	&emsp;&emsp;&emsp;					e.printStackTrace();<br/>
 	&emsp;&emsp;&emsp;					return false;<br/>
 	&emsp;&emsp;				}<br/> 	
 	&emsp;&emsp;	if(!dpClient.loginDP("default"){<br/>
 	&emsp;&emsp;&emsp;		dpClient.endSession();<br/>
 	&emsp;&emsp;&emsp;		return false;<br/>
 	&emsp;&emsp;	}<br/><br/>
 	
 		
 	&emsp;&emsp;	System.out.println(dpClient.getResponse("show version"));<br/>
 	&emsp;&emsp;	dpClient.endSession();<br/>
 &emsp;	}<br/><br/><br/>
 &emsp;	public boolean helloWorldLinux(){  <br/>
 &emsp;&emsp;		SSHClient linuxClient = null;<br/>
 					&emsp;&emsp;				try{<br/>
 	&emsp;&emsp;&emsp;	linuxClient = new SSHClient("localhost", 22, "admin", "admin1");<br/>
  	&emsp;&emsp;				}catch(Exception e){<br/>
 	&emsp;&emsp;&emsp;					e.printStackTrace();<br/>
 	&emsp;&emsp;&emsp;					return false;<br/>
 	&emsp;&emsp;				}<br/>
 
 &emsp;&emsp;		if(!linuxClient.startSession(){<br/>
 	&emsp;&emsp;&emsp;		linuxClient.endSession();<br/>
 	&emsp;&emsp;&emsp;		return false;<br/>
 	&emsp;&emsp;	}<br/>
 	&emsp;&emsp;	System.out.println(linuxClient.getResponse());//Gets log in response<br/>

 	&emsp;&emsp;	System.out.println(linuxClient.getResponse("ls -latr"));<br/>
 	&emsp;&emsp;	linuxClient.endSession();<br/>
 	&emsp;}<br/>
 	        
&emsp;        DTAF Sample:<br/>
&emsp;&emsp;     You can use the SSHClient in the script blocks of your test to connect to a DP or linux SSH port.<br/>
&emsp;&emsp;				Best practice is to initialize in set up and end session in clean up to be sure everything gets closed.<br/>
&emsp;&emsp;				You can have as many as your heap space will allow.  Tested Up to 100 concurrent sessions.<br/>
&emsp;&emsp;				You must pass Java compliant strings.  IE: if you have \ in the string then you will need to make it \\.<br/> 
				<br/><br/>
&emsp;&emsp;  	import sys<br/>
&emsp;&emsp;		sys.path.append(dtafJavaHarnessJarDirectory +"/DPAPIV5.jar")<br/>
&emsp;&emsp;    sys.path.append(dtafJavaHarnessJarDirectory +"/jsch-0.1.51.jar")<br/>
&emsp;&emsp;		from tools import SSHClient<br/>
&emsp;&emsp;		from com.jcraft.jsch import PortWatcher<br/>
		&emsp;&emsp;		from com.jcraft.jsch import ChannelShell<br/>
&emsp;&emsp;				from com.jcraft.jsch import JSch<br/>
&emsp;&emsp;				from com.jcraft.jsch import JSchException<br/>
&emsp;&emsp;				from com.jcraft.jsch import Session<br/>
&emsp;&emsp;				from java import io<br/>
&emsp;&emsp;				dp = SSHClient(dtafDPTarget, 22, dtafDPAdminUser, dtafDPAdminPassword)<br/>
&emsp;&emsp;				if dp.loginDP("default"):<br/>
&emsp;&emsp;&emsp;					print dp.getResponse('show version')<br/>
&emsp;&emsp;&emsp;					print dp.getRegEx(dp.getLastResponse(), 'Version: .+\n[ ]+Build: .+\n', false)<br/>
&emsp;&emsp;&emsp;					print str(dp.responseContains('\\QWatchdog Build: XI52.6.0.2.0\\E', false))<br/>
&emsp;&emsp;				else:<br/>
&emsp;&emsp;&emsp;					print "Unable to connect :("<br/>
&emsp;&emsp;&emsp;					print dp.errorMessage<br/>
&emsp;&emsp;				dp.endSession()<br/><br/>
&emsp;&emsp;				linux = SSHClient('localhost', 22, linuxUser, linuxPW)<br/>
&emsp;&emsp;				if linux.startSession():<br/>
&emsp;&emsp;&emsp;					print linux.getResponse('ls -latr')<br/>
&emsp;&emsp;				else:<br/>
&emsp;&emsp;&emsp;					print "Unable to connect :("<br/>
&emsp;&emsp;&emsp;					print linux.errorMessage<br/>
&emsp;&emsp;				linux.endSession()<br/>
 * @author Nick Coble
 *
 */
public class SSHClient extends CLIClient {
	final static private String REGEX_END_RESPONSE = ".+[:#>$\\)][ ]{0,1}";

	protected PipedOutputStream pin = null; 
	protected PipedInputStream pout = null;
	protected InputStream in = null;
	protected OutputStream out = null;
	protected JSch jsh = null;
	protected Session session = null;
	protected ChannelShell channel = null;
	public boolean loggedIn =false;
	public boolean established = false;
	private String strictHostCheck = "no";
	long responseBytes = 0;
	long totalTimeOut = 60000;//Total time to get response, default 1 min
	int bufferSize = 100000;//Default buffer for the read from stream pipe
	
	public SSHClient(String hostName, int port, String userName, String  password) throws InvalidParameterException{
		if(hostName==null || hostName.equals("")){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid IP: " + hostName);
		}else if(userName == null){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Username: null");
		}else if(password == null){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Password: null");
		}else if(port < 0){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Port: " + port);
		}
		this.hostName = hostName;
		this.port = port;
		this.userName =userName;
		this.password = password;
		this.jsh = new JSch();

	}
	
	public SSHClient(String hostName, int port, String userName, String  password, int bufferSize) throws InvalidParameterException{
		
		if(hostName==null || hostName.equals("")){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid IP: " + hostName);
		}else if(userName == null){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Username: null");
		}else if(password == null){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Password: null");
		}else if(port < 0){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Port: " + port);
		}else if(bufferSize < 1){
			throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Buffer Size: " + bufferSize);

		}
		this.hostName = hostName;
		this.port = port;
		this.userName =userName;
		this.password = password;
		this.bufferSize=bufferSize;
		this.jsh = new JSch();

	}
	
	public SSHClient(String hostName, int port) throws InvalidParameterException{
		if(hostName==null || hostName.equals("")){throw new InvalidParameterException("Error Instantiating SSHClient, Invalid IP: " + hostName);}
		if(port < 0){throw new InvalidParameterException("Error Instantiating SSHClient, Invalid Port: " + port);}
		this.hostName = hostName;
		this.port = port;
		this.jsh = new JSch();
	}

	/**
	 * Method to establish an ssh session
	 * Handles logging into remote host of a normal linux machine.  Refer to loginDP(<domain>) method for connecting to a DP appliance.<br/>
	 * Note:  After estiblishing session the response buffer will have the initial login information in it.  You will need to us the getResponse() method to clear this off if you dont need to do any checks on it.
	 * @return boolean
	 */
	public boolean startSession(){
		
		try {
			//Check session is not already open, if so close it 
			if((this.session != null && this.session.isConnected()) || (this.channel != null && this.channel.isConnected())){this.endSession();}
			
			in =new PipedInputStream(5000);
			out = new PipedOutputStream();
			try {
				pin = new PipedOutputStream((PipedInputStream)in);
				pout = new PipedInputStream((PipedOutputStream)out,bufferSize);
			} catch (IOException e) {
				e.printStackTrace();
				this.errorMessage = e.getMessage();
				return false;
			}
			
			//Create Session
			this.session = this.jsh.getSession(this.userName,this.hostName,this.port);
			this.session.setPassword(this.password);
			this.session.setConfig("StrictHostKeyChecking", strictHostCheck);		
			this.session.connect();
			
			//Open Channel
			this.channel = (ChannelShell) this.session.openChannel("shell");
			//		TODO Escape sequences need to be implemented.
			this.channel.setPtyType("dumb");
//			this.channel.setPtySize(0, 1, 0, 0);
		    this.channel.setInputStream(in);
			this.channel.setOutputStream(out);
			this.channel.connect();


//
//System.out.println(this.session.getHostKey().getKey());
//System.out.println(this.session.getHostKey().getComment());
//System.out.println(this.session.getHostKey().getType());
//System.out.println(this.session.getHostKey().getFingerPrint(this.jsh));
//
//System.out.println(this.session.getHostKeyRepository().getKnownHostsRepositoryID());
//			
			return (this.established=true);
		} catch (JSchException e) {
			e.printStackTrace();
			this.errorMessage= e.getMessage();
			return (this.established = false);
		} 
	}
	
	/**
	 * True if you want to be prompted to accept host key, false otherwise
	 * @param check
	 */
	public void setStrictHostCheck(boolean check){
		if(check){
			this.strictHostCheck="yes";
		}else{
			this.strictHostCheck="no";
		}
	}
	
	/**
	 * Does a series of checks to see if client is connected to remote host
	 */
	public boolean isConnected(){return (this.channel!=null && this.channel.isConnected() && this.loggedIn && this.established);}
	
	/**
	 * Establishes an SSH session and logs in to the remote host
	 * Note: use the logInDP method to log into a DP appliance
	 * @return boolean
	 */
	public boolean logIn(){return (this.loggedIn=this.startSession());}
	
	/**
	 * Used instead of password auth, must include path with file name.
	 * @param keyFile: Path to and name of keyfile
	 * @return
	 */
	public boolean setKeyFile(String keyFile){
		if(keyFile == null || keyFile.equals("")){return false;}
		
		try {
			this.jsh.addIdentity(keyFile);
			return true;
		} catch (JSchException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Sets the buffer size of the pipes used, larger buffers will increase the transfer speed of larger sets of data
	 * @param size
	 */
	public void setBufferSize(int size){
		if(size<1){return;}
		this.bufferSize=size;
		try {
			pout = new PipedInputStream((PipedOutputStream)out,this.bufferSize);
		} catch (IOException e) {
			e.printStackTrace();
			this.errorMessage = e.getMessage();
			System.out.println("Error Resetting output pipe. \n"+e.getMessage());
		}
	}
		
	/**
	 * Method to close the ssh session
	 * @return boolean
	 */
	public boolean endSession(){
		if(this.channel!=null && this.channel.isConnected()){
			while(!this.channel.isClosed() && !this.channel.isEOF()){
				this.getResponse("exit");
				if(this.response.toLowerCase().contains("goodbye")){
					break;
				}
			}}
		
		if(this.session!=null){this.session.disconnect();}else{this.errorMessage="Unable to close session, object was null.";}
		if(pin != null){
			try {
				pin.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			pin=null;
		}
		
		if(pout != null){
			try {
				pout.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			pout=null;
		}
		
		if(in!=null){
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			in=null;
		}
		
		if(out!=null){
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			out=null;
		}

		if(this.channel!=null && this.session!=null){
			boolean r = this.channel.isClosed() && !this.session.isConnected();
			this.established = this.loggedIn= false;
			return r;
		}else{
			return (this.established = this.loggedIn= false);
		}
	}
	
	/**
	 * Method to get cli response from remote service.
	 * Times out according to global variable totalTimeOut
	 * @return String
	 */
	public String getResponse(){return this.getResponse((int)this.totalTimeOut);}
	
	/**
	 * Reads the response buffer until the response matches the regex or a timeout occurs.
	 * @param regEx
	 * @param timeOutMilli
	 * @return
	 */
	public String readUntil(String regEx, int timeOutMilli){
		if(timeOutMilli < 1){return null;}
		this.response = "";
		StringBuilder stringBuilder= new StringBuilder();
		long startTime = System.currentTimeMillis();
		boolean startedReading = false;
		this.responseTrimed = false;
		if(this.channel==null || this.channel.isClosed()){return "ERROR: Unable to get response, channel is closed.\n";}
		try {
			while(true){
				if((this.pout.available()>0)){
					startedReading = true;
					while(this.pout.available()>0){
						int i = pout.read();
						//Determine what to do based on value of i
						if(i<0){
							break;
						}else if((i<32 || i>126) && !(i==13 || i == 10)){//Special Character
					//		TODO Escape sequences need to be implemented.
//							System.out.println(i+ "=" + ((char)i));
							switch(i){
							
							case 8:
//								System.out.println("BACKup");
//								System.out.println(stringBuilder.toString());
//								stringBuilder = new StringBuilder(stringBuilder.toString().trim());
								stringBuilder = stringBuilder.deleteCharAt(stringBuilder.length()-1);
//								System.out.println(stringBuilder.toString());
								break;
							case 9:
								//stringBuilder.append(" ");
							case 10:
								stringBuilder.append((char)i);
								break;
							case 13:
								stringBuilder.append((char)i);
								break;
							case 27:
//								System.out.println("ecs seq");

								//Escape sequences, Esc[
								//ends with PL;Pch, Pcf, PnA, PnB, PnC, PnD, s,u,2J, K, Ps;...;Psm, =psh, code;string;...p
//								http://www.termsys.demon.co.uk/vtansi.htm
//								System.out.println("===============================");
								if((i = pout.read())=='['){
									while((i = pout.read())!='m' && i != -1 && i!='s' && i!='i' && i!='M' && i!='D'&& i!='r'&& i!='J'&& i!='K'&& i!='g' && i!='u' && i!='f' && i!='C' && i!='B' && i!='A' && i!='H' && i!='h' && i!='l'){
	//									System.out.println(i + "=" + ((char)i));
									}
									//while((i = pout.read())!=-1 && ((i<65 || i>122 || (i>90 && i <97)) && i!=';')){
								//		System.out.println(i + "=" + ((char)i));
								//	}
								}
//								System.out.println(i + "=" + ((char)i) + "\n===============================");
								
							}

						}else{
							stringBuilder.append((char)i);
						}
						
						if(this.matchesRegEx(stringBuilder.toString(), regEx, true)){
							this.response = stringBuilder.toString().replace("\r", "");
							return this.response;
						}
					}
				}else{
		
					
					if(startedReading && this.matchesRegEx(stringBuilder.toString(), regEx, true)){
						break;
					}

					
					if(this.channel.isClosed()){
						if(!stringBuilder.toString().toLowerCase().trim().endsWith("goodbye")){
							stringBuilder.append("\nERROR: Channel was closed.\n");
						}
						break;
					}else{
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
				
				if(System.currentTimeMillis() - startTime > timeOutMilli){
					stringBuilder.append("\nERROR: Timed Out("+ timeOutMilli +").\n");
					break;
				}

			
			}
		} catch (IOException e) {
			e.printStackTrace();
			this.errorMessage = e.getMessage();
			stringBuilder.append("\nERROR getting response: " + e.getMessage() + "\n");
		}
		
		this.response = stringBuilder.toString().replace("\r\n", "\n").replace("\r", "");
		this.responseBytes = this.response.getBytes().length;
		return this.response;
	}
	
	/**
	 * Gets response 
	 * Specify time out in milliseconds
	 * @param timeOut
	 * @return
	 */
	public String getResponse(int timeOutMilli){
//		return readUntil(REGEX_END_RESPONSE, timeOutMilli);
		if(timeOutMilli < 1){return null;}
		this.response = "";
		StringBuilder stringBuilder= new StringBuilder();
		long startTime = System.currentTimeMillis();
		boolean doublecheck =false;
		boolean startedReading = false;
		this.responseTrimed = false;
		if(this.channel==null || this.channel.isClosed()){return "ERROR: Unable to get response, channel is closed.\n";}
		try {
			while(true){
				if((this.pout.available()>0)){
					startedReading = true;
					doublecheck =false;
					while(this.pout.available()>0){
						int i = pout.read();
						
						//Determine what to do based on value of i
						if(i<0){
							break;
						}else if((i<32 || i>126) && !(i==13 || i == 10)){//Special Character
					//		TODO Escape sequences need to be implemented.
//							System.out.println(i+ "=" + ((char)i));
							switch(i){
							
							case 8:
//								System.out.println("BACKup");
//								System.out.println(stringBuilder.toString());
//								stringBuilder = new StringBuilder(stringBuilder.toString().trim());
								stringBuilder = stringBuilder.deleteCharAt(stringBuilder.length()-1);
//								System.out.println(stringBuilder.toString());
								break;
							case 9:
								//stringBuilder.append(" ");
							case 10:
								stringBuilder.append((char)i);
								break;
							case 13:
								stringBuilder.append((char)i);
								break;
							case 27:
//								System.out.println("ecs seq");

								//Escape sequences, Esc[
								//ends with PL;Pch, Pcf, PnA, PnB, PnC, PnD, s,u,2J, K, Ps;...;Psm, =psh, code;string;...p
//								http://www.termsys.demon.co.uk/vtansi.htm
//								System.out.println("===============================");
								if((i = pout.read())=='['){
									while((i = pout.read())!='m' && i != -1 && i!='s' && i!='i' && i!='M' && i!='D'&& i!='r'&& i!='J'&& i!='K'&& i!='g' && i!='u' && i!='f' && i!='C' && i!='B' && i!='A' && i!='H' && i!='h' && i!='l'){
	//									System.out.println(i + "=" + ((char)i));
									}
									//while((i = pout.read())!=-1 && ((i<65 || i>122 || (i>90 && i <97)) && i!=';')){
								//		System.out.println(i + "=" + ((char)i));
								//	}
								}
//								System.out.println(i + "=" + ((char)i) + "\n===============================");
								
							}

						}else{
							stringBuilder.append((char)i);
						}
					}
					
					
				}else{
					if(!doublecheck){//Gives buffer a chance to fill back up incase end of response check is a false positive
						try {
							Thread.sleep(1500);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						doublecheck=true;
						continue;
					}
					
					if(startedReading && this.matchesRegEx(stringBuilder.toString(), REGEX_END_RESPONSE, true)){
						break;
					}

					
					if(this.channel.isClosed()){
						if(!stringBuilder.toString().toLowerCase().trim().endsWith("goodbye")){
							stringBuilder.append("\nERROR: Channel was closed.\n");
						}
						break;
					}else{
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
				
				if(System.currentTimeMillis() - startTime > timeOutMilli){
					stringBuilder.append("\nERROR: Timed Out("+ timeOutMilli +").\n");
					break;
				}

			
			}
		} catch (IOException e) {
			e.printStackTrace();
			this.errorMessage = e.getMessage();
			stringBuilder.append("\nERROR getting response: " + e.getMessage() + "\n");
		}
		
		this.response = stringBuilder.toString().replace("\r\n", "\n").replace("\r", "");
		this.responseBytes = this.response.getBytes().length;
		return this.response;
	}
	
	/**
	 * Returns the response to the provided command.
	 * @param command
	 * @return String
	 */
	public String getResponse(String command){
		if(command==null){return null;}
		if(this.sendCommand(command)){
			return this.getResponse();
		}else{
			return "ERROR: Unable to send the " + command +  " command.\n";
		}
		
	}
	 
	/**
	 * Returns the trimmed response to the provided command.
	 * @param command
	 * @return
	 */
	public String getResponseTrim(String command){
		if(command==null){return null;}
		if(this.sendCommand(command)){
			this.getResponse();
			return this.trimResponse();
		}else{
			return "ERROR: Unable to send the " + command +  " command.\n";
		}
	}
	
	/**
	 * Returns the response to the provided command.
	 * Specify time out in milliseconds
	 * @param command
	 * @param timeOutMilli
	 * @return
	 */
	public String getResponse(String command, int timeOutMilli){
		if(command == null || timeOutMilli < 1){return null;}
		if(this.sendCommand(command)){
			return this.getResponse(timeOutMilli);
		}else{
			return "ERROR: Unable to send the " + command +  " command.\n";
		}
	}
	
	/**
	 * Returns the response to the provide hex command
	 * @param command
	 * @param timeOutMilli
	 * @return
	 */
	public String getResponse(int command, int timeOutMilli){
		if(timeOutMilli < 1){return null;}
		if(this.sendCommand(command)){
			return this.getResponse(timeOutMilli);
		}else{
			return "ERROR: Unable to send the " + command +  " command.\n";
		}
	}
	
	/**
	 * Method to send commands to appliance.
	 * @param command:String
	 * @return boolean
	 */
	public boolean sendCommand(String command){
		if(command == null){return false;}
		this.lastCommand = command + "\n";
		if(this.channel != null && this.channel.isConnected()){
			try {
		
				pin.write(this.lastCommand.getBytes("UTF8"));
				pin.flush();
				return true;
			} catch (IOException e) {
				this.errorMessage = e.getMessage();
				e.printStackTrace();
			}
		}
		return false;
	}
	
	/**
	 * Send Ctrl type Commands using hex or int number code
	 * IE: Ctrl-C = 3
	 * Table of codes at http://www.nthelp.com/ascii.htm list
	 * @param n
	 * @return boolean
	 */
	public boolean sendCommand(int n){
		if(n<0){return false;}
		this.lastHexCommand = n ;
		if(this.channel != null && this.channel.isConnected()){
			try {
				pin.write(n);
				pin.flush();
				return true;
			} catch (IOException e) {
				this.errorMessage = e.getMessage();
				e.printStackTrace();
			}
		}
		return false;
	}
	
	/**
	 * Returns a array of Strings found in the response String that matched the provided regExp
	 * @param response
	 * @param regExp
	 * @return
	 */
	public ArrayList<String> getGroupsFromLastResponse(String regExp){
		if(regExp==null || regExp.equals("")){return null;}
		ArrayList<String> tmp = new ArrayList<>();
		Pattern p = Pattern.compile(regExp, Pattern.DOTALL);
		Matcher m = p.matcher(this.response);

		while(m.find()){
		   tmp.add(m.group(0));
		}
		return tmp;
	}

	/**
	 * Attempts to log in to a DP appliance
	 * @param domain
	 * @throws Exception
	 */
	public boolean loginDP(String domain){
		if(domain==null || domain.equals("")){
			this.errorMessage = "Error: Can not log in to DP appliance.  Invalid domain: " + domain;
			return false;}
		
		this.domain=domain;
		
		//Establish connection if not already
		if(this.channel ==null || !this.channel.isConnected()){
			if(!this.startSession()){
				this.errorMessage="Unable to establish ssh session." + this.errorMessage;
				System.out.println(this.errorMessage);
				return (this.established=this.loggedIn=false);
			}
		}
		
//System.out.println(this.userName);
//System.out.println(this.password);
//System.out.println(domain);
		
		//Attempt to log in
		if(!CLIVariables.loginPrompt.matcher(this.getResponse()).find() && !this.getLastResponse().equals("\nERROR: Get Response Timed Out("+ this.totalTimeOut +").\n")){
//System.out.println(this.response);
			this.errorMessage="Unable to access login prompt.  Expected: " + CLIVariables.loginPrompt.toString() + ", Recieved: " + this.response;
			//System.out.println(this.errorMessage);
			return (this.loggedIn=false);
		}else if(!CLIVariables.passwordPrompt.matcher(this.getResponse(this.userName)).find()){
//System.out.println(this.response);
			this.errorMessage="Unable to access password prompt.  Expected: " + CLIVariables.passwordPrompt.toString() + ", Recieved: " + this.response;
//			System.out.println(this.errorMessage);
			return (this.loggedIn=false);
		}else if(!CLIVariables.domainPrompt.matcher(this.getResponse(this.password)).find()){
//System.out.println(this.response);

			if(!CLIVariables.welcomeMessage.matcher(this.response).find()){
//System.out.println(this.response);
				this.errorMessage="Unable to access welcome prompt1.  Expected: " + CLIVariables.welcomeMessage.toString() + ", Recieved: " + this.response;
//				System.out.println(this.errorMessage);
				return (this.loggedIn=false);
			}else{

				this.getResponse("switch domain " + domain);
//System.out.println(this.response);

			}
			
		}else if(!CLIVariables.welcomeMessage.matcher(this.getResponse(domain)).find()){
//System.out.println(this.response);
			this.errorMessage="Unable to access welcome prompt2.  Expected: " + CLIVariables.welcomeMessage.toString() + ", Recieved: " + this.response;
//			System.out.println(this.errorMessage);
			return (this.loggedIn=false);
		}
		
		return (this.loggedIn=true);
	}
	
	/**
	 * Returns the number of bytes in the response
	 * @return
	 */
	public long getResponseBytes(){return this.responseBytes;}

	/**
	 * Returns the host key of the server
	 * @return
	 */
	public HostKey getServerHostKey(){

		return this.session.getHostKey();

	}
	
	public String getServerHostKeyFingerPrint(){
		return this.session.getHostKey().getFingerPrint(this.jsh);
	}
	
	public String getServerHostKeyAlgorithms(){
		return 	this.session.getConfig("server_host_key");
	}
	
	/**
	 * Returns the ssh version used by the server
	 * @return
	 */
	public String getServerSSHVersion(){
		return this.session.getServerVersion();
	}
	
	/**
	 * Returns the ssh version used by the client
	 * @return
	 */
	public String getClientSSHVersion(){
		return this.session.getClientVersion();
	}
	
	public String getServerCiphers(){
		return this.session.getConfig("cipher.s2c");
	}
	
	public String getKeyExchangeAlgorithms(){
		return this.session.getConfig("kex");
	}
	
	public String getClientCiphers(){
		return this.session.getConfig("cipher.c2s");
	}
	
	public String getClientMacs(){
		return this.session.getConfig("mac.c2s");

	}
	
	public String getServerMacs(){
		return this.session.getConfig("mac.s2c");

	}
	
	public String getClientCompression(){
		return this.session.getConfig("compression.c2s");
	}
	
	public String getServerCompression(){
		return this.session.getConfig("compression.s2c");
	}
	
	public String getClientLanguage(){
		return this.session.getConfig("lang.c2s");
	}
	
	public String getServerLanguage(){
		return this.session.getConfig("lang.s2c");
	}
	
	/**
	 * returns the exit status of the session
	 * @return
	 */
	public int getExitStatus(){
		return this.channel.getExitStatus();
	}

	/**
	 * Returns the input stream to allow users to read from it directly.<br/>
	 * Note: input stream is the buffer that the responses come in on
	 * @return
	 */
	public PipedInputStream getInputStream(){
		return this.pout;
	}
	
	/**
	 * Returns the output stream to allow users to write to it directly.<br/>
	 * Note: output steam is the buffer that the commands go out on.
	 * @return
	 */
	public PipedOutputStream getOutputStream(){
		return this.pin;
	}
}
