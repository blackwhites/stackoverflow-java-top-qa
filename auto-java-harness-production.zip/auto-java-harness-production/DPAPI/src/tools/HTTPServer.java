package tools;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class HTTPServer extends Thread{
	private int port; //port we are going to listen to
	public volatile static int requestCount = 0; //Total request sent to servers
	public  int  serverCount=0; //Total request this server has completed
	public String serverID = "";
	InetAddress client;
	public static boolean listen = true;
	public ServerSocket serversocket = null;

	
	public HTTPServer(int listenPort) {
		port = listenPort;
	}
	
	public static void main(String[] args) {
		System.out.println("SFDSFSF");

		if(args.length!=1){
			System.out.println("Invalid number of parameters, must include listening port.  Usage: javac HTTPServer <port>");
			System.exit(-1);
		}else{
			if(args[0].matches("[0-9]+")){
				HTTPServer server = new HTTPServer(Integer.valueOf(args[0]));
				server.start();
			}else{
				System.out.println("Invalid port parameter.  Must be an integer");
				System.exit(-1);
			}
		}

	}

	public int getServerCount(){return this.serverCount;}
	
	@Override
	public void run() {
	    
	    //Initialize server socket
		try {
		  serversocket = new ServerSocket(port);

		}catch (Exception e) { 
		      return;
		}

		Socket connectionsocket=null;

		//loop for connections
		while (listen) {
		
		    //Wait for connection
			try {
				connectionsocket = serversocket.accept();
				
				//Handle request
				new Thread(new http_handler(String.valueOf(++HTTPServer.requestCount), String.valueOf(++serverCount), connectionsocket, this.serverID, String.valueOf(this.port))).start();
			} catch (SocketException se){
				if(!se.getMessage().contains("socket closed")){
					se.printStackTrace();
				}else{
					System.out.println("Socket closed on server " + this.port + ".");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		}

		//Close socket
		try {
	    	if(serversocket != null){serversocket.close();}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public class http_handler extends Thread{
		String requestCount;
		String serverCount;
		BufferedReader input;
		DataOutputStream output;
		Socket connectionsocket;
		String serverID;
		String port;
		
		public http_handler(String requestCount, String serverCount, Socket connectionsocket, String serverID, String port) {
			this.requestCount = requestCount;
			this.serverCount = serverCount;
			this.connectionsocket = connectionsocket;
			this.port = port;
			this.serverID = serverID;
		}

		public void run(){
			String clientRequest = "";
			
			try {
				//Read the http request from the client from the socket interface
				this.input = new BufferedReader(new InputStreamReader(connectionsocket.getInputStream()));

				//Set up output stream
				this.output = new DataOutputStream(connectionsocket.getOutputStream());

				String tmp;
System.out.println("Request received.");
			    while(!this.input.ready()){}//wait for request
				int contentLength = -1;		  
//				String httpMethod = "";
				//GET HTTP METHOD
				tmp = this.input.readLine();
System.out.println(tmp);
	
//				httpMethod = tmp.split(" ")[0];
			    //GET HEADERS
				    while(this.input.ready()){
				    	  tmp=this.input.readLine();
System.out.println(tmp);
				    	  if(tmp.contains("requestnumber:")){
			    		  clientRequest = tmp.substring(14, tmp.length());
			    		  break;
			    	  }else if(tmp.isEmpty()){
			    		  break;
			    	  }else if(tmp.toLowerCase().contains("content-length")){
			    		  contentLength = Integer.valueOf(tmp.split(":")[1].trim());
			    	  }
			    } //Store request number
				    
System.out.println("Finished Reading Headers");
			    
			  
		    	for(int i=0;i<contentLength;i++){
		    		tmp += (char)this.input.read();
		    	}
		    	
		    	System.out.println(tmp);
		    

		    }catch (Exception e) {
		    	System.out.println("Error: " + e.getMessage());
		    	e.printStackTrace();
		}
			
//			try {
//				Thread.sleep(300000);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
			
System.out.println("Done Sleeping.  Sending response.");
		      try {
		    	 
				StringBuilder headers = new StringBuilder("HTTP/1.1 200 OK\r\n");
				headers.append("Connection: close\r\n");
				headers.append("Content-Length: 4\r\n");
				headers.append("Content-Type: text/html; charset=UTF-8\r\n");
				headers.append("ClientRequest: " + clientRequest + "\r\n");
				headers.append("ServerPort: " + this.port + "\r\n");
				headers.append("ServerID: " + this.serverID + "\r\n");
				headers.append("ServeCount: " + this.serverCount + "\r\n");
				headers.append("TotalServeCount: " + this.requestCount + "\r\n\r\nBODY");
				output.writeBytes(headers.toString());		
				output.flush();
System.out.println("Response sent");
		      } catch (Exception e) {
				e.printStackTrace();
			}finally{
					try {
						connectionsocket.shutdownInput();
					} catch (IOException e) {
						e.printStackTrace();
					}
				 try {
						connectionsocket.shutdownOutput();
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
		  }
	}

}
