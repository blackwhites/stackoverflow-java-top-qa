package tools;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import beans.RequestBean;

/**
 * Object to send HTTP request.  Each request returns a {@link } object.
 * <br
 * @author Nick Coble
 *
 */
public class HTTPClient extends URLClient {
	
	HttpURLConnection con = null;
	private boolean connected = false;

	public HTTPClient() {super();}
	
	/**
	 * Method to send HTTP request.
	 * User provides HTTP method to use and pay load to send.
	 * Common HTTP methods: GET,PUT,POST,DELETE,OPTIONS,HEAD
	 * Returns a RequestBean that contains response information.
	 * @param httpMethod:String
	 * @param payload:String
	 * @return RequestBean
	 */
	@Override
	public RequestBean sendRequest(String httpMethod, String payload){
		if(payload != null){
			return this.sendRequest(httpMethod, payload.getBytes(StandardCharsets.UTF_8), false);
		}else{
			return this.sendRequest(httpMethod, null, false);
		}
	}

	/**
	 * Method to send request over a persistent connection.<br/>
	 * User must use the {@link #closeConnection() closeConection} method after completing requests.
	 * 
	 * @param String:httpMethod
	 * @param String:payload
	 * @return
	 */
	public RequestBean sendRequestPersistent(String httpMethod, String payload){
		if(payload != null){
			return this.sendRequest(httpMethod, payload.getBytes(StandardCharsets.UTF_8), true);
		}else{
			return this.sendRequest(httpMethod, null, true);
		}		
	}

	/**
	 * Method to send multipart/form-data.  
	 * @param formEntries: HashMap<String, Object>,  key = form data key, object = String or File 
	 * @param charSet
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	public RequestBean sendMultipartFormData(HashMap<String, Object> formEntries,Charset charSet) throws UnsupportedEncodingException, IOException{
		return this.sendRequest(URLClient.HTTP_POST, this.buildFormPayload(formEntries, charSet), false);
	}
	
	@Override
	public void closeConnection(){
		if(con != null){con.disconnect();}
		super.closeConnection();
	}

	public RequestBean sendRequest(String httpMethod, byte[] payload, boolean persistent){

		RequestBean requestBean = new RequestBean();
		requestBean.setUrl(this.url + this.buildURLParametersString());
		requestBean.setError(false);
		if(payload != null){
			requestBean.setClientPayload(new String(payload, StandardCharsets.UTF_8));
		}else{
			requestBean.setClientPayload(null);
		}
		
		try{
			
			//Create Connection
			System.setProperty("http.keepAlive",String.valueOf(this.keepAlive));
			URL website = new URL(requestBean.getUrl().replace(" ", "%20"));
			requestBean.setURI(website.getPath());
			requestBean.setHostName(website.getHost());
			requestBean.setProtocol(website.getProtocol());
			
			//Set connection properties
			if(!persistent || (persistent && !connected)){
				con = (HttpURLConnection) website.openConnection();
			}	
			
			
			byte[] serverResponse = this.sendRequest(con, httpMethod, payload);
			
			//Store response data in RequestBean object
			requestBean.setServerPayloadBytes(serverResponse);
			requestBean.setServerHeaders(con.getHeaderFields());
			requestBean.setStatus(String.valueOf(con.getResponseCode()));
			requestBean.setStatusMessage(con.getResponseMessage());
			requestBean.setRequestMethod(con.getRequestMethod());
			requestBean.setReadTimeOut(String.valueOf(con.getReadTimeout()));
			requestBean.setConnectionTimeOut(String.valueOf(con.getConnectTimeout()));
			requestBean.setClientHeaders(this.headers);
			requestBean.setResponseContentLength(con.getContentLength());
			requestBean.setResponseContentType(con.getContentType());
		
	
		}catch (MalformedURLException e) {
			System.out.println("MalformedURLException Error: " + e.getMessage() + " doing " + httpMethod + " at " + this.url);
			requestBean.setUrl(this.url);
			requestBean.setServerPayLoad("MalformedURLException Error: " + e.getMessage() + " doing " + httpMethod + " at " + this.url + "\n");
			requestBean.setStatus(STATUS_CODE_EXCEPTION);
			requestBean.setError(true);
			requestBean.setException(e);

		} catch (IOException e) {
			System.out.println("IOException Error: " + e.getMessage() + " doing " +httpMethod + " at " + this.url);
			requestBean.setUrl(this.url);
			requestBean.setServerPayLoad("IOException Error: " + e.getMessage() + " doing " + httpMethod + " at " + this.url + ".  Connection Time Out: " + con.getConnectTimeout() + ", Read Time Out: " + con.getReadTimeout());
			requestBean.setStatus(STATUS_CODE_EXCEPTION);
			requestBean.setError(true);
			requestBean.setException(e);

		}finally{
			if(!persistent){
				this.closeConnection();
			}
		}
		
		this.lastResponse=requestBean;
		
		return requestBean;		
	}
	
}
