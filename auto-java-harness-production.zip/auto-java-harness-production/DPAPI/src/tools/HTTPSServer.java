package tools;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Simple HTTPS server that can be alter to fit your needs. <br/> This server is dependent on keystore.jks<br/><br/>
 * Use keytool to create a keystore.jks with command: keytool -genkey -keyalg RSA -alias selfsigned -keystore keystore.jks -storepass mercury1 -validity 360 -keysize 2048
 * <br/>Does not check request method or uri, always returns same response.<br/><br/>
 * To implement different request methods or uri responses, alter the handler inner class.
 * 
 * @author Nick Coble
 *
 */
public class HTTPSServer extends Thread {
	private int port; //port we are going to listen to
	public volatile static int requestCount = 0; //Total request sent to servers
	public  int  serverCount=0; //Total request this server has completed
	public String serverID = "";
	public static boolean listen = true;
	public SSLServerSocket serversocket = null;
	public String keyStorePW;
	public String pathToKeyStore;
	public String keyStoreFileName;
	
	public static void main(String[] args) {
		System.out.println("SFDSFSF");

		if(args.length!=1){
			System.out.println("Invalid number of parameters, must include listening port.  Usage: javac HTTPServer <port>");
			System.exit(-1);
		}else{
			if(args[0].matches("[0-9]+")){
				System.out.println("SFDSFSF");
				HTTPServer server = new HTTPServer(Integer.valueOf(args[0]));
				server.start();
			}else{
				System.out.println("Invalid port parameter.  Must be an integer");
				System.exit(-1);
			}
		}

	}
	public HTTPSServer(int listenPort, String keyStorePassword, String pathToKeyStore, String keyStoreFileName) {
		port = listenPort;
		this.keyStorePW = keyStorePassword;
		this.pathToKeyStore=pathToKeyStore;
		this.keyStoreFileName = keyStoreFileName;
	}
	
	SSLServerSocketFactory s;
	@Override
	public void run() {
		char[] keyPassword =  this.keyStorePW.toCharArray();
		try {
			InputStream keyFile = new FileInputStream(this.pathToKeyStore + this.keyStoreFileName); 
			TrustManager[] trustAllCerts = new TrustManager[] {
			        new X509TrustManager() {
			            public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			            }
			
			            public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			            }
			
			            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			                return null;
			            }
			        }
			};
			
			//// init keystore
			KeyStore keyStore = KeyStore.getInstance("JKS");
			keyStore.load(keyFile, keyPassword);

			// init KeyManagerFactory
			KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			keyManagerFactory.init(keyStore, keyPassword);
			
			// init KeyManager
			KeyManager keyManagers[] = keyManagerFactory.getKeyManagers();
			
			// init the SSL context
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(keyManagers, trustAllCerts, new SecureRandom());
			SSLContext.setDefault(sslContext);
			SSLServerSocketFactory sslserversocketfactory =  sslContext.getServerSocketFactory();// (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
			serversocket = (SSLServerSocket) sslserversocketfactory.createServerSocket(55222);

		}catch (Exception e) { 
			e.printStackTrace();
		}

		SSLSocket connectionsocket=null;

		//loop for connections
		while (listen) {
			
		
		    //Wait for connection
			try {

				connectionsocket = (SSLSocket) serversocket.accept();
				
				//Handle request
				new Thread(new http_handler(String.valueOf(++HTTPServer.requestCount), String.valueOf(++serverCount), connectionsocket, this.serverID, String.valueOf(this.port))).start();
			} catch (SocketException se){
				if(!se.getMessage().contains("socket closed")){
					se.printStackTrace();
				}else{
					System.out.println("Socket closed on server " + this.port + ".");
				}
			} catch (IOException e) {
	System.out.println("Error");
				e.printStackTrace();
			}
		
		}

		//Close socket
		try {
	    	if(serversocket != null){serversocket.close();}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

	public class http_handler extends Thread{
		String requestCount;
		String serverCount;
		BufferedReader input;
		DataOutputStream output;
		SSLSocket connectionsocket;
		String serverID;
		String port;
		
		public http_handler(String requestCount, String serverCount, SSLSocket connectionsocket, String serverID, String port) {
			this.requestCount = requestCount;
			this.serverCount = serverCount;
			this.connectionsocket = connectionsocket;
			this.port = port;
			this.serverID = serverID;
		}

		public void run(){
			String clientRequest = "";
			try {
				//initialize data streams
				this.input = new BufferedReader(new InputStreamReader(connectionsocket.getInputStream()));				
				this.output = new DataOutputStream(connectionsocket.getOutputStream());

				//Read request
				String temp = "";
				while((temp= this.input.readLine())!=null){
					System.out.println(temp);//Just prints request to console
					if(temp.equals("")){ //Assumes its a GET request with no pay load, need to alter this to accept pay loads
							break;
					}
				}

		    }catch (Exception e) {
		    	System.out.println(connectionsocket.getPort() + " port Error: " + e.getMessage());
		    	e.printStackTrace();
		}
		      try {
		    	
		    	//Implement new request methods and URI responses here
				String headers = "HTTP/1.1 200 OK\r\n";
				headers += "Connection: close\r\n";
				headers += "Content-Type: text/html; charset=UTF-8\r\n";
				headers += "ClientRequest: " + clientRequest + "\r\n";
				headers += "ServerPort: " + this.port + "\r\n";
				headers += "ServerID: " + this.serverID + "\r\n";
				headers += "ServeCount: " + this.serverCount + "\r\n";
				headers += "TotalServeCount: " + this.requestCount + "\r\n\r\n<HTML><BODY>HELLO WORLD</BODY></HTML>";
				output.writeBytes(headers);		
				output.flush();
		      } catch (IOException e) {
				e.printStackTrace();
			}finally{
				
				try{
					if(output != null){
						output.close();
					}
				}catch(Exception e){
					e.printStackTrace();
				}
				try{
					if(input != null){
						input.close();
					}
				}catch(Exception e){
					e.printStackTrace();
				}
				
				try {
					connectionsocket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
			}
		  }
	}
	public int getServerCount(){return this.serverCount;}

}
