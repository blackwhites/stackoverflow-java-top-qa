package tools;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import tools.CLIClient;
import tools.SSHClient;
import variables.DPVariables;

/**
 * Helper class to contain commonly used methods and variables in CC test automation.
 * 
 * 
 * @author nickCoble
 *TODO 
 */
public class CommonCriteria {
	//CLI Responses
	public final String SUCCESS_EXPORT_DISPLAY = "Unable to display '.+' - file is not printable";
	public final String SUCCESS_EXEC_FILE = "Executing script.+Finished script";
	public final String SUCCESS_COPY_SFTP ="File copy success";
	public final String SUCCESS_COPY_FILE = "File copy success \\([0-9]+ bytes copied\\)";
	public final String SUCCESS_DELETE_FILE = "File deletion successful";
	public final String SUCCESS_DELETE_DIR = "Directory '.+' successfully deleted.";
	public final String SUCCESS_CREATE_DIR = "Directory '.+' successfully created.";
	public final String SUCCESS_MOVE_FILE="\n((?!\n).)+\\(config\\)#";//Empty response, at check append this to command sent
	public final String SUCCESS_SHOW_DIR ="[ ]+File Name[ ]+Last Modified[ ]+Size";
	public final String SUCCESS_IMPORT_PACKAGE = "Import package is complete.";
	public final String SUCCESS_DOMAIN_DELETED = "Domain deleted successfully.";
	public final String SUCCESS_USER_DELETED ="User name deleted";
	public final String SUCCESS_OBJECT_DELETED = "Configuration deleted.";
	public final String SUCCESS_CONFIG_SAVED = "Configuration saved successfully.";
	public final String SUCCESS_CONFIG_MODIFIED ="Modify .+ configuration";
	
	public final String PERMISSION_DENIED_CREATE_DIR = "Cannot create directory '.*' - Permission denied";
	public final String PERMISSION_DENIED_SHOW_DIR = "Cannot list contents of directory";
	public final String PERMISSION_DENIED_DELETE_DIR ="Cannot delete '.+' - 'permission denied'";
	public final String PERMISSION_DENIED_DELETE_FILE ="[(No permission to delete)|(Unable to delete '.+' - permission denied)]";
	public final String PERMISSION_DENIED_SHOW_FILE ="Unable to display '.+' - permission denied";
	public final String PERMISSION_DENIED_COPY_FILE ="File '.+' permission denied";
	public final String PERMISSION_DENIED_MOVE_FILE ="No permission to move ";
	public final String PERMISSION_DENIED_EXEC_FILE ="Unable to exec .+ - permission denied";
	public final String PERMISSION_DENIED_SWITCH_DOMAIN ="Switching domain failed: Access Denied";

	public final String FAIL_CREATE_DIR = "Cannot create directory.*destination URL could not be opened";
	public final String FAIL_DELETE_DIR_NOT_FOUND = "Cannot delete .* directory not found";
	public final String FAIL_NO_FILE_DIR = "No such file or directory";
	public final String FAIL_SHOW = "[(Sorry, could not show that.)|(No such file or directory)]";
	public final String FAIL_SHOW_FILE = "File '.+' not found";
	public final String FAIL_COPY_CANNOT_READ_SCP = "URL.+destination URL could not be opened:.+File copy failed";
	public final String FAIL_COPY_CANNOT_READ = "((File copy failed.+[source|destination] URL could not be opened)|(No such file or directory)|(The file could not be found))";
	public final String FAIL_CANNOT_EXEC ="Unable to exec.+source URL could not be opened";
	public final String FAIL_CAN_NOT_FIND_OBJECT = "Cannot find configuration object";
	public final String FAIL_UNKNOWN_COMMAND_MACRO = "Unknown command or macro";
	
	public final String REG_LOG_TIMESTAMP_DP_ZULU = "^[\\d]{8}T[\\d]+";
	public final String REG_LOG_TIMESTAMP_DP_SYSLOG = "^[\\w]{3,4} [\\w]{3} [\\d]{1,2} [\\d]{4} [\\d]{2}:[\\d]{2}:[\\d]{2}";
	public final String REG_LOG_TIMESTAMP_DP_NUMERIC = "^[\\d]+ ";

	public final String REG_RESTART_SSH = "(Stopping sshd:.+OK.+\nStarting sshd:.+OK.+)|(\\Qssh stop/waiting\nssh start/running\\E)";
	//-a file
	//-d directory
	
	
	public int totalTestSteps=0;
	public int passedTestSteps=0;

	/**
	 * Attempts to create a SSHClient and log in to specified DP appliance.<br/>
	 * Returns a SSHClient if successful, null otherwise.  All events are logged.
	 * @param userName
	 * @param pw
	 * @param domain
	 * @param dpHostName
	 * @param sshPort
	 * @param log
	 * @return
	 */
	public SSHClient get_SSHClient(String userName,String pw, String domain, String dpHostName, int sshPort, Logger log){
		if(userName == null || pw == null || pw.equals("") || domain == null || domain.equals("") || dpHostName == null || dpHostName.equals("")|| log == null){
			if(log != null){
				log.severe("Error running get_SSHClient method.  Invalid parameter: Object was null or a String was empty");
			}
			return null;
		}
		SSHClient dpClient = null;
		try {
			dpClient = new SSHClient(dpHostName, sshPort, userName, pw);
			dpClient.setDomain(domain);
		} catch (Exception e) {
			e.printStackTrace();
			log.log(Level.SEVERE,"Error Creating SSHClient Object.  IP: "+ dpHostName +"User: " +  userName + ", Domain: " + dpHostName +".", e);
			return null;
		}
		
		try{
			if(!dpClient.loginDP(domain)){
				log.log(Level.SEVERE,"Unable to log in to DP appliance.  IP: " + dpHostName + ", User:" + userName + ", Domain: " + domain +".  DP Response: " + dpClient.errorMessage);
				dpClient.endSession();
				dpClient = null;
				return null;
			}else{
				log.info("Logged Into DP Appliance.  IP: " + dpHostName + ", User: " + userName + ", Domain: " + domain +".  DP Prompt: " + dpClient.getLastResponse().substring(dpClient.getLastResponse().indexOf("\n")));
			}
		}catch(Exception e){
			e.printStackTrace();
			log.log(Level.SEVERE,"Error Logging Into DP Appliance.  IP: " + dpHostName + ", User:" + userName + ", Domain: " + domain + ".", e);
			dpClient.endSession();
			dpClient = null;
			return null;
		}
		return dpClient;
	}
	
	public void resetTestCounters(){
		this.totalTestSteps = 0;
		this.passedTestSteps = 0;
	}
	
	public boolean verifyStep(String stepDescription, String response, SSHClient client, String command, String expectedRegEx, Level failedLevel, Level passLevel, Logger logger, boolean dotAll){
		if(stepDescription == null || stepDescription.equals("") || command == null || command.equals("") || expectedRegEx == null || expectedRegEx.equals("") || failedLevel == null || passLevel == null || logger == null){
			if(logger != null){
				logger.severe("Error running verifyStep method.  Invalid parameter: Object was null or a String was empty");
			}
			return false;
		}

	

		if(failedLevel.equals(Level.INFO) && passLevel.equals(Level.INFO)){++this.totalTestSteps;}
		
		StringBuilder logInfo=new StringBuilder();
		logInfo.append("[Description]: ");
		logInfo.append(stepDescription);
		logInfo.append("\n[Command]: ");
		logInfo.append(command.replace("\n", "\\n"));
		logInfo.append("\n[Response]: ");
		logInfo.append(response);
		logInfo.append("\n[Expected RegEx]: ");
		logInfo.append(expectedRegEx.replace("\n", "\\n"));		
		
		if(!client.containsRegEx(response, expectedRegEx, dotAll)){
			logInfo.append("\n[Not Found]:\n[Result]: Failed");
			logger.log(failedLevel, logInfo.toString());
			return false;
		}else{
			if(failedLevel.equals(Level.INFO)&& passLevel.equals(Level.INFO)){
				++this.passedTestSteps;
			}
			logInfo.append("\n[Found]:\n");
			logInfo.append(client.getRegEx(response, expectedRegEx, dotAll));
			logInfo.append("\n[Result]: Passed");
			logger.log(passLevel, logInfo.toString());
			return true;
		}
	}
	
	/**
	 * Helper method to verify a test step
	 * @param stepDescription
	 * @param client
	 * @param command
	 * @param expectedRegEx
	 * @param failedLevel
	 * @param passLevel
	 * @param logger
	 * @param dotAll: Include newline characters when using . in RegEx
	 * @return
	 */
	public boolean verifyStep(String stepDescription, CLIClient client, String command, String expectedRegEx, Level failedLevel, Level passLevel, Logger logger, boolean dotAll){
		if(stepDescription == null || stepDescription.equals("") || client == null || command == null || command.equals("") || expectedRegEx == null || expectedRegEx.equals("") || failedLevel == null || passLevel == null || logger == null){
			if(logger != null){
				logger.severe("Error running verifyStep method.  Invalid parameter: Object was null or a String was empty");
			}
			return false;
		}

		
		String tmpResponse = client.getResponse(command, 120000);//2 minute time outs
		if(tmpResponse.contains("[sudo] password for " + client.getUserName() + ":")){
			command += "\n"+client.getPassword();
			tmpResponse += client.getResponse(client.getPassword(), 60000);
		}
		
		//Trim Response
		tmpResponse = tmpResponse.substring(tmpResponse.indexOf("\n"));

		if(failedLevel.equals(Level.INFO) && passLevel.equals(Level.INFO)){++this.totalTestSteps;}
		
		StringBuilder logInfo=new StringBuilder();
		logInfo.append("[Description]: ");
		logInfo.append(stepDescription);
		logInfo.append("\n[Command]: ");
		logInfo.append(command.replace("\n", "\\n"));
		logInfo.append("\n[Response]: ");
		logInfo.append(tmpResponse);
		logInfo.append("\n[Expected RegEx]: ");
		logInfo.append(expectedRegEx.replace("\n", "\\n"));		
		if(tmpResponse.contains("not in the sudoers file")){
			logInfo.append("\n[Result]: Failed, user does not have sudo permissions.");
			logger.log(failedLevel, logInfo.toString() );
			return false;
		}
		if(!client.containsRegEx(tmpResponse, expectedRegEx, dotAll)){
			logInfo.append("\n[Not Found]:\n[Result]: Failed");
			logger.log(failedLevel, logInfo.toString());
			return false;
		}else{
			if(failedLevel.equals(Level.INFO)&& passLevel.equals(Level.INFO)){
				++this.passedTestSteps;
			}
			logInfo.append("\n[Found]:\n");
			logInfo.append(client.getRegEx(tmpResponse, expectedRegEx, dotAll));
			logInfo.append("\n[Result]: Passed");
			logger.log(passLevel, logInfo.toString());
			return true;
		}
	}
	
	/**
	 * Helper Method to verify test step
	 * @param stepDescription
	 * @param client
	 * @param command
	 * @param expectedRegEx
	 * @param failedLevel
	 * @param passLevel
	 * @param logger
	 * @return
	 */
	public boolean verifyStep(String stepDescription, CLIClient client, String command, ArrayList<String> expectedRegEx, Level failedLevel, Level passLevel, Logger logger){
		if(stepDescription == null || stepDescription.equals("") || client == null || command == null || command.equals("") || expectedRegEx == null || expectedRegEx.size()<1 || failedLevel == null || passLevel == null || logger == null){
			if(logger != null){
				logger.severe("Error running verifyStep method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		client.getResponse(command, 120000);//2 minute time outs
		if(failedLevel.equals(Level.INFO) && passLevel.equals(Level.INFO)){++this.totalTestSteps;}
		boolean pass = true;
		StringBuilder logInfo=new StringBuilder();
		logInfo.append("[Description]: ");
		logInfo.append(stepDescription);
		logInfo.append("\n[Command]: ");
		logInfo.append(client.lastCommand);
		logInfo.append("[Response]: ");
		logInfo.append(client.getLastResponse());
		
		
		for(String s: expectedRegEx){
			logInfo.append("\n[Expected RegEx]: ");
			logInfo.append(s.replace("\n", "\\n"));

			if(!client.responseContains(s, false)){
				logInfo.append("\n[Not Found]:\n[Result]: Failed");
				logger.log(failedLevel, logInfo.toString());
				pass = false;
			}else{
				if(failedLevel.equals(Level.INFO)&& passLevel.equals(Level.INFO)){
					++this.passedTestSteps;
				}
				logInfo.append("\n[Found]:\n");
				logInfo.append(client.getRegEx(client.getLastResponse().substring(client.getLastResponse().indexOf("\n")), s, false));
				logInfo.append("\n[Result]: Passed");
				logger.log(passLevel, logInfo.toString());
			}
		}
		return pass;

	}
	
	/**
	 * Helper method to restart a DP domain.<br/>
	 * Assumes client is already logged in.<br/>
	 * Returns false if invalid parameter is provided.
	 * @param domain
	 * @param dpClient
	 * @param log
	 * @return
	 */
	public boolean helper_RestartDomain(String domain, SSHClient dpClient, Logger log){
		if(dpClient == null || domain == null || domain.equals("") || log == null){
			if(log != null){
				log.severe("Error running helper_RestartDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running helper_RestartDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		String command = "top;co;restart domain " + domain + "\ny";
		return this.verifyStep("Restart Domain To Restore Logtemp files", dpClient, command,"Domain restarted successfully" , Level.SEVERE, Level.INFO, log, false);
	}
	
	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes SSHClient is already logged into appliance.<br/>
	 * Returns null if SSHClient is null or unable to find anchor point.  Use getLastResponse() to see log.
	 * @param dpClient
	 * @return
	 */
	public String getAuditAnchor(SSHClient dpClient){
		if(dpClient == null){
			return null;
		}
		
		
		dpClient.getResponse("top;co;show audit-log -np", 120000);
		
		String[] tmp = dpClient.getLastResponse().split("\n");
		int i=tmp.length-3;
		for(;i>=0;i--){
			if(dpClient.containsRegEx(tmp[i], "[\\d]{8}T[\\d]+")){
				break;
			}
		}
		return tmp[i];
	}
	
	public String getAuditLogFromAnchor(SSHClient dpClient, String anchorPoint){
		if(dpClient == null || anchorPoint == null || anchorPoint.equals("")){return null;}
		
		String tmp = dpClient.getResponse("top;co;show audit-log -np");		
	
		if(tmp.indexOf(anchorPoint)==-1){
			//Get cycled file
			dpClient.getResponse("top;co;show file audit:///audit-log.1");
			tmp = dpClient.trimResponse() + tmp;
		}
		
		if(tmp.indexOf(anchorPoint)==-1){
			return "Error: Unable to find anchor point.  Anchor: " + anchorPoint;
		}
		
		tmp = tmp.substring(tmp.indexOf(anchorPoint) + anchorPoint.length());
		return tmp;
	}
	
	/**
	 * Helper method to check the current audit log for cli commands.  
	 * Uses the auditAnchor variable as starting point and checks that all elements in the commandsSent list
	 * are present<br/>
	 * Substrings the log from each found regex, so make sure to have your commandsSent list in the order of which they appear in the log<br/>
	 * Assumse dpClient is already logged in to the proper domain.<br/>
	 * Returns false if any parameter is invalid or if one of the checks failed.  Results are logged either way.
	 * @param client
	 * @return
	 */
	public boolean auditCommands(SSHClient dpClient, ArrayList<String> commandsSent, String auditAnchor, Logger log){
		if(dpClient == null || auditAnchor == null || auditAnchor.equals("") || log == null){
			if(log != null){
				log.severe("Error running auditCommands method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running auditCommands method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		if(commandsSent==null||commandsSent.size()==0){
			log.info("Failed Audit Log Check.  The commandsSent list was empty.");
			return false;
		}

		boolean passed=true;
		dpClient.getResponse("top;co; show audit-log -np");
		log.info("[Anchor Point]: "+ auditAnchor + "\n[Audit Log]:\n" + dpClient.getLastResponse());
		String auditResponse = dpClient.getLastResponse().substring(dpClient.getLastResponse().indexOf(auditAnchor) + auditAnchor.length());

		for(String s: commandsSent){
			//Test counter
			this.totalTestSteps++;
			
			if(!dpClient.containsRegEx(auditResponse, s, false)){
				log.info("[Result]: Failed\n[Description]: Did not find RegEx in the audit log.\n[Expected RegEx]: "+  s.replace("\n", "\\n"));
				passed=false;
			}else{
				//Test counter
				this.passedTestSteps++;
				log.info("[Result]: Passed\n[Description]: Found RegEx in the audit log.\n[Expected RegEx]: " +  s.replace("\n", "\\n") + "\n[Found]:\n" + dpClient.getRegEx(auditResponse, s, false));
				auditResponse = dpClient.subStringFromFirstRegEx(auditResponse, s, false);
			}
		}
		
		return passed;
	
	
	}
	
	/**
	 * Helper method to check standard dp log for list of expected RegEx's.<br/>
	 * Substrings the log from each found regex, so make sure to have your expectedRegEx list in the order of which they appear in the log<br/>
	 * Assumes client is already logged in.<br/>
	 * Returns false any parameter is invalid.
	 * @param dpClient
	 * @param expectedRegEx
	 * @param logAnchor
	 * @param dotAll
	 * @param log
	 * @return
	 */
	public boolean checkLog(SSHClient dpClient, ArrayList<String> expectedRegEx, String logAnchor,  boolean dotAll, Logger log){
		if(dpClient == null || expectedRegEx == null || expectedRegEx.size()<1 || logAnchor == null || log == null){
			if(log != null){
				log.severe("Error running checkLog method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running checkLog method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		String tmp = dpClient.getResponse("top;show log");
		boolean pass = true;
		if(tmp.indexOf(logAnchor)==-1){
			//Get cycled file
			dpClient.getResponse("top;co;show file logtemp:///default-log.1");
			tmp = dpClient.trimResponse() + tmp;
		}
		
		log.finest("DP Log.\n[Log]:" + tmp);
		tmp = tmp.substring(tmp.indexOf(logAnchor) + logAnchor.length());

		StringBuilder logMessage = new StringBuilder();
		logMessage.append("Verifing DP Logs.\n[SubLog]:\n" + tmp);
		for(String expected: expectedRegEx){
			this.totalTestSteps++;
			logMessage.append("\n------------------------------\n");
			if(dpClient.containsRegEx(tmp, expected, dotAll)){
				logMessage.append("\n[Expected RegEx]: " + expected.replace("\n", "\\n") + "\n[Found]: " + dpClient.getRegEx(tmp, expected, dotAll));
				this.passedTestSteps++;
				tmp = dpClient.subStringFromFirstRegEx(tmp, expected, dotAll);
			}else{
				logMessage.append("\n[Expected RegEx]: " + expected.replace("\n", "\\n")  + "\n[Not Found]:");
				pass = false;
			}
		}
		
		if(pass){
			logMessage.append("\n[Result]: passed");
		}else{
			logMessage.append("\n[Result]: failed");

		}
		
		log.info(logMessage.toString());
		
		return pass;
	}
	
	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes SSHClient is already logged into appliance.<br/>
	 * Returns null if SSHClient is null or unable to find anchor point.  Use getLastResponse() to see log.
	 * @param dpClient
	 * @return
	 */
	public String getDPLogAnchor(SSHClient dpClient){
		if(dpClient == null){return null;}
		
		String[] tmp = dpClient.getResponse("top;co;show log").split("\n");
		int i=tmp.length-3;
		for(;i>=0;i--){
			if(dpClient.containsRegEx(tmp[i], DPVariables.REGEX_LOG_TIMESTAMPS_DP) ){
				break;
			}
		}
		if(i==-1){
			return null;
		}
		return tmp[i];
	}
	
	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes SSHClient is already logged into appliance.<br/>
	 * Returns null if SSHClient is null or unable to find anchor point.  Use getLastResponse() to see log. 
	 * @param dpClient
	 * @param pathToLog
	 * @param fileName
	 * @return
	 */
	public String getDPLogAnchor(SSHClient dpClient, String pathToLog, String fileName){
		if(dpClient == null || pathToLog==null || fileName == null){
			return null;
		}
		dpClient.getResponse("top;co;show file " + pathToLog + "/" + fileName);
		
		String[] tmp = dpClient.getLastResponse().split("\n");
		int i=tmp.length-2;
		for(;i>=0;i--){
			if(dpClient.containsRegEx(tmp[i], DPVariables.REGEX_LOG_TIMESTAMPS_DP) ){
				break;
			}
		}
		if(i==-1){
			return null;
		}
		return tmp[i];
	}
	
	/**
	 * Returns the DP logs that appear after the specified anchor point.<br/>
	 * Note: Anchor point should contain something unique like a time stamp.<br/>
	 * 
	 * @param dpClient
	 * @param anchorPoint
	 * @param pathToLog
	 * @param fileName
	 * @return
	 */
	public String getDPLogFromAnchorPoint(SSHClient dpClient, String anchorPoint, String pathToLog, String fileName){
		if(dpClient == null || pathToLog==null|| pathToLog.equals("") || fileName==null|fileName.equals("")){
			return null;
		}
		
		//Returns entire log if anchorpoint is invalid
		if(anchorPoint == null || anchorPoint.equals("")){
			 return dpClient.getResponse("top;co;show file " + pathToLog + "/" + fileName);
		}
		
		String tmp = dpClient.getResponse("top;co;show file " + pathToLog + "/" + fileName);		
	
		if(tmp.indexOf(anchorPoint)==-1){
			//Get cycled file
			dpClient.getResponse("top;show file " + pathToLog + "/" + fileName + ".1");
			tmp = dpClient.trimResponse() + tmp;
		}
		
		tmp = tmp.substring(tmp.indexOf(anchorPoint) + anchorPoint.length());
		return tmp;
	}
	
	/**
	 * Returns the DP logs that appear after the specified anchor point.<br/>
	 * Note: Anchor point should contain something unique like a time stamp.<br/>
	 * 
	 * @param dpClient
	 * @param anchorPoint
	 * @return
	 */
	public String getDPLogFromAnchorPoint(SSHClient dpClient, String anchorPoint){
		if(dpClient == null || anchorPoint == null || anchorPoint.equals("")){
			return null;
		}
		
		String tmp = dpClient.getResponse("top;show log");		
		
		//Returns entire log if anchorpoint is invalid
		if(anchorPoint == null || anchorPoint.equals("")){
			 return tmp;
		}
		
		if(tmp.indexOf(anchorPoint)==-1){
			//Get cycled file
			dpClient.getResponse("top;show file logtemp:///default-log.1");
			tmp = dpClient.trimResponse() + tmp;
		}
		
		tmp = tmp.substring(tmp.indexOf(anchorPoint) + anchorPoint.length());
		return tmp;
	}
	
	/**
	 * Attempts to create and execute an import-package. If return is false use dpClient.getLastResponse() to see last response from DP.
	 * @param domain
	 * @param dpClient
	 * @param packageName
	 * @param packageFileName
	 * @param pathToPackageFileOnDP
	 * @param log
	 * @return
	 */
	public boolean importDPPackage(String domain, SSHClient dpClient, String packageName, String packageFileName, String pathToPackageFileOnDP, Logger log){
		if(dpClient == null || domain == null || domain.equals("") || packageName == null  || packageName.equals("")  || packageFileName == null || packageFileName.equals("")  || pathToPackageFileOnDP == null || pathToPackageFileOnDP.equals("") || log == null){
			if(log != null){
				log.severe("Error running importDPPackage method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running importDPPackage method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		//Switch to test domain and create test objects
		String command = "top;switch "+domain+";co;import-package " + packageName +";source-url " + pathToPackageFileOnDP + "/"+ packageFileName+";exit;show import-package "+ packageName;
		if(!this.verifyStep("Create Import Package For File " + packageFileName + ".", dpClient, command, "import-package: " + packageName + " \\[up\\]", Level.SEVERE, Level.CONFIG, log, false)){
			return false;
		}
		
		command = "import-exec " + packageName;
		if(!this.verifyStep("Load Import Package.", dpClient, command, "Loading import-package '"+packageName +"'.\nImport package is complete.", Level.SEVERE, Level.CONFIG, log, false)){
			return false;
		}
		return true;
	}

	/**
	 * Attempts to get an anchor point from standard log by searching for a line with a time stamp.<br/>
	 * Assumes SSHClient is already logged into appliance.<br/>
	 * Returns null if SSHClient is null or unable to find anchor point.  Use getLastResponse() to see log.
	 * @param sshClient
	 * @return
	 */
	public String getLogAnchor(SSHClient sshClient){
		if(sshClient == null){return null;}
		String[] tmp = sshClient.getResponse("top;show log").split("\n");
		
		int i=tmp.length-3;//Minus three because length-1 is end of array index and response will contain empty line plus CLI prompt line
		for(;i>=0;i--){
			if(sshClient.containsRegEx(tmp[i], "(^[\\d]{8}T[\\d]+)|(^[\\w]{3,4} [\\w]{3} [\\d]{1,2} [\\d]{4} [\\d]{2}:[\\d]{2}:[\\d]{2})|(^[\\d]+ )") ){
				break;
			}
		}
		if(i==-1){
			return null;
		}
		return  tmp[i];

	}
	
	/**
	 * Removes domain by first disconnecting any active users then sending the no domain command.
	 * <br/>
	 * If returns false, check DP response by using the dpClient.getLastResponse() command.
	 * 
	 * @param dpClient
	 * @param domain
	 * @return boolean
	 */
	public boolean deleteDomain(SSHClient dpClient, String domain, Logger log){
		if(dpClient == null || domain == null || domain.equals("") || log == null){
			if(log != null){
				log.severe("Error running deleteDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}else{
				System.out.println("Error running deleteDomain method.  Invalid parameter: Object was null or a String/List was empty");
			}
			return false;
		}
		
		//Remove test domain
		dpClient.getResponse("top;switch domain default");
				
		//Disconnect Active Users in test domain
		//Loop to disconnect active users
		String[] tmp = dpClient.getResponse("top;co;show users").split("\n");
		log.config("Check For Active Users In Test Domain: " + domain+"\n" + dpClient.getLastResponse());
		for(String s: tmp){
			//Split by spaces
			if(s.trim().endsWith(domain)){
				String[] tmp2 = s.trim().split(" ");
				this.verifyStep("Disconnect Test Users In Test Domians.", dpClient, "disconnect " + tmp2[0], "Session [\\d]+ closed", Level.SEVERE, Level.CONFIG, log, false);
			}
		}
		
		
		return this.verifyStep("Remove Test Domain", dpClient, "top;co;no domain " + domain + "\ny", this.SUCCESS_DOMAIN_DELETED, Level.WARNING, Level.CONFIG, log, false);
				
	}
	
}
