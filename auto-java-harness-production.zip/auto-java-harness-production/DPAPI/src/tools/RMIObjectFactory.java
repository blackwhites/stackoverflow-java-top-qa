package tools;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Set;
import javax.json.*;
import javax.json.JsonValue.ValueType;
import variables.RMIVariables;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.ConfigDomain;
import xmlManagement.DmAsyncActionStatus;
import xmlManagement.DmRMIAsyncActionStatusState;
import xmlManagement.DmRMIAsyncActionStepProgress;
import xmlManagement.DmRMIConfigState;
import xmlManagement.DmRMIDirectoryDescription;
import xmlManagement.DmRMIFileDescription;
import xmlManagement.DmRMISubDirectoryDescription;
import xmlManagement.DmReference;
import xmlManagement.File;
import xmlManagement.RMIAsyncActionResult;
import xmlManagement.Response.Fault;
import xmlManagement.Response.Filestore;
import xmlManagement.ObjectFactory;
import xmlManagement.Response;
import xmlManagement.Response.Result;

/**
 * Object to generate xmlManagement objects from ROMA response payloads
 * @author Nick Coble
 *
 */
public class RMIObjectFactory  extends XMLManagementFactory{
	
	ObjectFactory factory = new ObjectFactory();

	/**
	 * Method generates a response object set with the object in the payload<br/>
	 * Possible Objects:  Config Object, Status Object, or Fault(Error)
	 * @param romaPayload
	 * @return Response
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	public Response getResponseObject(JsonObject romaPayload) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		if(romaPayload==null){return null;}
		//Check for error key
		Response response=new Response();
		if(romaPayload.containsKey(RMIVariables.KEY_ERROR)){//Error Response
			xmlManagement.Response.Fault fault = new Fault();
			fault.setFaultcode("Error");
			fault.setFaultstring(romaPayload.get(RMIVariables.KEY_ERROR).toString());
			response.setFault(fault);
			return response;
		
		}else if(romaPayload.containsKey(RMIVariables.KEY_RESULT)){//Results Response, 
			xmlManagement.Response.Result result = new Result();
			//Check if async status response
			if(romaPayload.containsKey(RMIVariables.KEY_STATUS)){

				DmAsyncActionStatus status = new DmAsyncActionStatus();
				status.setStatus(DmRMIAsyncActionStatusState.fromValue(romaPayload.getString(RMIVariables.KEY_STATUS)));
				
				//Check if results is for an export
				if(romaPayload.get(RMIVariables.KEY_RESULT).getValueType().equals(ValueType.OBJECT) && romaPayload.getJsonObject(RMIVariables.KEY_RESULT).containsKey(RMIVariables.KEY_FILE) ){
					File file = new File();
					file.setValue(converter.decodeBase64IntoBytes(romaPayload.getJsonObject(RMIVariables.KEY_RESULT).getString(RMIVariables.KEY_FILE)));
					response.getFile().add(file);
				}else{
					status.setResult(romaPayload.get(RMIVariables.KEY_RESULT).toString());
				}
				result.getContent().add(status);
			}else{
				result.getContent().add(romaPayload.get(RMIVariables.KEY_RESULT).toString());
			}
			
			response.setResult(result);
			return response;
		}else if((romaPayload.containsKey(RMIVariables.KEY_STATUS) && romaPayload.containsKey(RMIVariables.KEY_STEP_PROGRESS))){
			//Async Status Resposne
			xmlManagement.Response.Result result = new Result();
			
			//Get status
			DmAsyncActionStatus status = new DmAsyncActionStatus();
			status.setStatus(DmRMIAsyncActionStatusState.fromValue(romaPayload.getString(RMIVariables.KEY_STATUS)));
			
			//Get progress
			DmRMIAsyncActionStepProgress stepProgress = new DmRMIAsyncActionStepProgress();
			stepProgress.setTotal(romaPayload.getJsonObject(RMIVariables.KEY_STEP_PROGRESS).getInt(RMIVariables.KEY_TOTAL));
			stepProgress.setComplete(romaPayload.getJsonObject(RMIVariables.KEY_STEP_PROGRESS).getInt(RMIVariables.KEY_COMPLETE));
			status.setStepProgress(stepProgress);
			
			//Complete response object
			result.getContent().add(status);
			response.setResult(result);
			
			return response;

		}else if(romaPayload.containsKey(RMIVariables.KEY_FILE)){
			File file = new File();
			String selfURI=romaPayload.getJsonObject(RMIVariables.KEY_DISCOVERY).getJsonObject(RMIVariables.KEY_SELF_URI).getString(RMIVariables.KEY_URI);
			String[] s = selfURI.split("/");
			file.setName(s[RMIVariables.INDEX_URI_FILE_DIRECTORY]+":/"+selfURI.substring(selfURI.indexOf(s[RMIVariables.INDEX_URI_FILE_PATH])));
			file.setValue(converter.decodeBase64IntoBytes(romaPayload.getString(RMIVariables.KEY_FILE)));
			response.getFile().add(file);
			return response;
		}else if(romaPayload.containsKey(RMIVariables.KEY_FILESTORE)){
			xmlManagement.Response.Filestore filestore = new Filestore();
			DmRMIDirectoryDescription directory = new DmRMIDirectoryDescription();
			filestore.setDirectory(directory);
			JsonObject jsonFileStore = romaPayload.getJsonObject(RMIVariables.KEY_FILESTORE);
			
			//Top lvl directory
			if(jsonFileStore.get(RMIVariables.KEY_LOCATION).getValueType().equals(ValueType.ARRAY)){
				for(JsonValue j: jsonFileStore.getJsonArray(RMIVariables.KEY_LOCATION)){
					DmRMISubDirectoryDescription subDir = new DmRMISubDirectoryDescription();
					subDir.setName(((JsonObject)j).getString(RMIVariables.KEY_FILE_NAME));
					subDir.setLocation(((JsonObject)j).getString(RMIVariables.KEY_URI));
					filestore.getDirectory().getsubdirectories().add(subDir);
				}
			}else{//Specific directory
				//Get name
				directory.setName(jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).getString(RMIVariables.KEY_FILE_NAME));
				
				//Get location
				directory.setLocation(jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).getString(RMIVariables.KEY_URI));
				
				//Get files
				if(jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).containsKey(RMIVariables.KEY_FILE)){
					//Check if array
					if(jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).get(RMIVariables.KEY_FILE).getValueType().equals(ValueType.ARRAY)){
						for(JsonValue jsFile: jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).getJsonArray(RMIVariables.KEY_FILE)){
							DmRMIFileDescription file = new DmRMIFileDescription();
							file.setName(((JsonObject)jsFile).get(RMIVariables.KEY_FILE_NAME).toString().replace("\"", ""));
							file.setSize(String.valueOf(((JsonObject)jsFile).getInt(RMIVariables.KEY_FILE_SIZE)));
							file.setModified(((JsonObject)jsFile).getString(RMIVariables.KEY_FILE_MODIFIED));
							file.setLocation(((JsonObject)jsFile).getString(RMIVariables.KEY_URI));
							directory.getFiles().add(file);
						}
					}else{
						JsonObject jsFile = jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).getJsonObject(RMIVariables.KEY_FILE);
						DmRMIFileDescription file = new DmRMIFileDescription();
						file.setName(jsFile.getString(RMIVariables.KEY_FILE_NAME));
						file.setSize(String.valueOf(jsFile.getInt(RMIVariables.KEY_FILE_SIZE)));
						file.setModified(jsFile.getString(RMIVariables.KEY_FILE_MODIFIED));
						file.setLocation(jsFile.getString(RMIVariables.KEY_URI));
						directory.getFiles().add(file);
					}
				}
				
				//Get subdirs
				if(jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).containsKey(RMIVariables.KEY_DIRECTORY)){
					//Check if array
					if(jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).get(RMIVariables.KEY_DIRECTORY).getValueType().equals(ValueType.ARRAY)){
						for(JsonValue jsSubDir: jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).getJsonArray(RMIVariables.KEY_DIRECTORY)){
							DmRMISubDirectoryDescription subDir = new DmRMISubDirectoryDescription();
							subDir.setName(((JsonObject)jsSubDir).getString(RMIVariables.KEY_FILE_NAME));
							subDir.setLocation(((JsonObject)jsSubDir).getString(RMIVariables.KEY_URI));
							directory.getsubdirectories().add(subDir);
						}
					}else{
						JsonObject jsSubDir = jsonFileStore.getJsonObject(RMIVariables.KEY_LOCATION).getJsonObject(RMIVariables.KEY_DIRECTORY);
						DmRMISubDirectoryDescription subDir = new DmRMISubDirectoryDescription();
						subDir.setName(jsSubDir.getString(RMIVariables.KEY_FILE_NAME));
						subDir.setLocation(jsSubDir.getString(RMIVariables.KEY_URI));
						directory.getsubdirectories().add(subDir);
					}
				}
			}
			
			response.setFilestore(filestore);
			return response;

		}else{//Object paylaod
		
		
			//Grab links to determine type
			JsonObject links = romaPayload.getJsonObject(RMIVariables.KEY_DISCOVERY);
			if(links == null){
				return null;
			}
			String ObjectType = links.getJsonObject(RMIVariables.KEY_SELF_URI).getString(RMIVariables.KEY_URI).split("/")[RMIVariables.INDEX_URI_REQUEST_TYPE];
	
			switch(ObjectType){
			case "config":
				if(romaPayload.get(romaPayload.keySet().toArray()[1]).getValueType().equals(ValueType.STRING)){
						xmlManagement.Response.Result result = new Result();
						result.getContent().add(romaPayload.get(romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_OBJECT]).toString());
						response.setResult(result);
						return response;
				}
				response.setConfig(this.loadConfigObject(romaPayload));
				return response;
			case "status":
				response.setStatus(this.loadStatusObject(romaPayload));
				return response;
			case "actionqueue":
				Result value = new Result();
				if(romaPayload.keySet().toArray().length>1){
					
					//Check if async action
					if(romaPayload.getJsonObject(RMIVariables.KEY_DISCOVERY).containsKey(RMIVariables.KEY_LOCATION)){
						RMIAsyncActionResult a =  new RMIAsyncActionResult();
						a.setLocation(romaPayload.getJsonObject(RMIVariables.KEY_DISCOVERY).getJsonObject(RMIVariables.KEY_LOCATION).getString(RMIVariables.KEY_URI));
						String actionKey = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_OBJECT].toString();
						if(romaPayload.get(actionKey).getValueType().equals(ValueType.STRING)){
							a.setResult(romaPayload.getString(actionKey));
						}else{
							a.setResult(romaPayload.get(actionKey).toString());
						}
						
						value.getContent().add(a);
					}else{
						String actionKey = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_OBJECT].toString();
						if(romaPayload.get(actionKey).getValueType().equals(ValueType.STRING)){
							value.getContent().add(romaPayload.getString(actionKey));
						}else{
							value.getContent().add(romaPayload.get(actionKey).toString());
						}
					}
				}else{
					value.getContent().add(romaPayload.toString());
				}
				
				response.setResult(value);
				return response;
			case "domains":
				if(romaPayload.containsKey("domain")){
					AnyConfigElement c = new AnyConfigElement();

					if(romaPayload.get("domain").getValueType().equals(ValueType.ARRAY)){
						for(JsonValue j: romaPayload.getJsonArray("domain")){
							ConfigDomain tmp = new ConfigDomain();
							tmp.setName(((JsonObject)j).getString(RMIVariables.KEY_OBJECT_INSTANCE_NAME));
							c.getConfigObjects().add(tmp);
						}
					}else{
						ConfigDomain tmp = new ConfigDomain();
						tmp.setName(romaPayload.getJsonObject("domain").getString(RMIVariables.KEY_OBJECT_INSTANCE_NAME));
						c.getConfigObjects().add(tmp);
					}
					response.setConfig(c);
					return response;
				}else{
					return null;
				}

			default:
				System.err.println("RMIObjectFactory getResponseObject(JsonObject romaPayload): Invalid Object Type. Expected config, status, or action uri.  Recieved: " + links.toString());
				return null;
			}
		}
	}
	
	/**
	 * Method generates a response object set with the object in the payload and attempts to load the provided config list<br/>
	 * Possible Objects:  Config Object or Fault(Error)
	 * @param romaPayload
	 * @return Response
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	public Response getResponseObject(JsonObject romaPayload, AnyConfigElement anyConfig) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		if(romaPayload==null){return null;}
		//Check for error key
		Response response=new Response();
		if(romaPayload.containsKey(RMIVariables.KEY_ERROR)){//Error Response
			xmlManagement.Response.Fault fault = new Fault();
			fault.setFaultcode("Error");
			fault.setFaultstring(romaPayload.get(RMIVariables.KEY_ERROR).toString());
			response.setFault(fault);
			return response;
		
		}else if(romaPayload.containsKey(RMIVariables.KEY_RESULT)){//Results Response, 
			xmlManagement.Response.Result result = new Result();
			result.getContent().add(romaPayload.get(RMIVariables.KEY_RESULT).toString());
			response.setResult(result);
			return response;
		}else if(romaPayload.containsKey(RMIVariables.KEY_FILE)){
			File file = new File();
			file.setName(romaPayload.getJsonObject(RMIVariables.KEY_FILE).getString(RMIVariables.KEY_FILE_NAME));
			file.setValue(romaPayload.getJsonObject(RMIVariables.KEY_FILE).getString(RMIVariables.KEY_FILE_CONTENT).getBytes());
			response.getFile().add(file);
			return response;
		}else{//Object paylaod
		
		
			//Grab links to determine type
			response.setConfig(this.loadConfigObjects(romaPayload, anyConfig));
			return response;
			
		}
	}
	
	/**
	 * Loads the payload values into the config object.  Returns null if parameters are invalid.
	 * @param romaPayload: JsonObject, roma get response
	 * @param configObject: Config Object 
	 * @return 
	 */
	public ConfigConfigBase loadConfigObject(JsonObject romaPayload, ConfigConfigBase configObject){
		if(romaPayload==null || configObject==null ){return null;}
//System.out.println(romaPayload);
		String objectName = null;
		 
		if(romaPayload.keySet().toArray().length==1){
			objectName = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_LINKS].toString();
		}else{ 
			objectName = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_OBJECT].toString();
		}

		if(!objectName.equals(configObject.getClass().getSimpleName().substring(RMIVariables.LENGTH_OF_OBJECT_NAME_PREFIX))){
			return null;
		}
		
		JsonObject xmlObject = romaPayload.getJsonObject(objectName);
		ConfigConfigBase configObject2 = (ConfigConfigBase)this.loadObjectProperties(xmlObject, configObject);
		
		

		return configObject2;
	}

	public AnyConfigElement loadConfigObjects(JsonObject romaPayload, AnyConfigElement e) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException{
		if(romaPayload==null){return null;}
		String objectName = null;
		
		if(romaPayload.keySet().toArray().length==1){
			objectName = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_LINKS].toString();
		}else{ 
			//Since first object is the self discovery, index
			objectName = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_OBJECT].toString();
		}
		
		//Check for payload type.  Array or Single Object
		if(!romaPayload.containsKey(objectName)){
			return null;
		}else if(romaPayload.get(objectName).getValueType().equals(ValueType.ARRAY)){
			JsonArray configArray = romaPayload.getJsonArray(objectName);
			for(int i=0;i<configArray.size();i++){
				Object returnObject = factory.getClass().getMethod("createConfig" + objectName).invoke(factory);
				JsonObject xmlObject = configArray.getJsonObject(i);
				ConfigConfigBase configObject = (ConfigConfigBase)this.loadObjectProperties(xmlObject, returnObject);
				if(configObject != null){	
					e.getConfigObjects().add(configObject);
				}
			}
			
			if(e.getConfigObjects().size()>0){
				return e;
			}
			
		}else{
			Object returnObject = factory.getClass().getMethod("createConfig" + objectName).invoke(factory);
			JsonObject xmlObject = romaPayload.getJsonObject(objectName);
			ConfigConfigBase configObject = (ConfigConfigBase)this.loadObjectProperties(xmlObject, returnObject);
			if(configObject != null){	
				e.getConfigObjects().add(configObject);
				return e;
			}
		}
		

		return null;
	}
	
	/**
	 * Returns an AnyConfigElement loaded with the objects defined in the provided parameter
	 * @param romaPayload
	 * @return
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
 	public AnyConfigElement loadConfigObject(JsonObject romaPayload) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		if(romaPayload==null){return null;}
		String objectName = null;
//System.out.println(romaPayload);
		if(romaPayload.keySet().toArray().length==1){
			objectName = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_LINKS].toString();
		}else{ 
			//Since first object is the self discovery, index
			objectName = romaPayload.keySet().toArray()[RMIVariables.INDEX_RESPONSE_OBJECT].toString();
		}
		
		
		//Object to hold list of config objects
		AnyConfigElement e = new AnyConfigElement();
		
		//Check for payload type.  Array or Single Object
		if(!romaPayload.containsKey(objectName)){
			return null;
		}else if(romaPayload.get(objectName).getValueType().equals(ValueType.ARRAY)){
			JsonArray configArray = romaPayload.getJsonArray(objectName);
			for(int i=0;i<configArray.size();i++){
				Object returnObject = factory.getClass().getMethod("createConfig" + objectName).invoke(factory);
				JsonObject xmlObject = configArray.getJsonObject(i);
				ConfigConfigBase configObject = (ConfigConfigBase)this.loadObjectProperties(xmlObject, returnObject);
				if(configObject != null){	
					e.getConfigObjects().add(configObject);
				}
			}
			
			if(e.getConfigObjects().size()>0){
				return e;
			}
			
		}else{
			Object returnObject = factory.getClass().getMethod("createConfig" + objectName).invoke(factory);
			JsonObject xmlObject = romaPayload.getJsonObject(objectName);
			ConfigConfigBase configObject = (ConfigConfigBase)this.loadObjectProperties(xmlObject, returnObject);
			if(configObject != null){	
				e.getConfigObjects().add(configObject);
				return e;
			}
		}
		

		return null;
	}
	
	/**
	 * Sets the properties of the provided Object with the values in the provided JsonObject
	 * @param xmlObject
	 * @param returnObject
	 * @return
	 */
	public Object loadObjectProperties(JsonObject xmlObject, Object returnObject){

		
		try{
			for(String keyName: xmlObject.keySet()){

				if(keyName.equals(RMIVariables.KEY_DISCOVERY) ){continue;}

				//String Case
				if(xmlObject.get(keyName).getValueType().equals(ValueType.STRING)){//objectString.charAt(0)=='"'
//					//Check base field type
//					if(!keyName.equals("mAdminState")){
						this.buildSimpleField(this.getFieldFromAnnotation(returnObject, keyName), returnObject, xmlObject.getString(keyName));
//					}else{
//
//
//						((ConfigConfigBase) returnObject).setMAdminState(DmAdminState.fromValue(xmlObject.getString(keyName)));
//					}
				}
				//Complex Case
				else if(xmlObject.get(keyName).getValueType().equals(ValueType.OBJECT)){//objectString.charAt(0)=='{'
					Field f =this.getFieldFromAnnotation(returnObject, keyName);
					if(f==null){
						System.out.println("Unable to get property from class, might need to update object.  Looking for property: " + keyName);
						continue;
					}
					//Check if field object is a String or Enum, simple fields can be return as jsonobjects if they have an attribute set like read-only and users defines view=extended in the request.
//System.out.println(f.getType().getSimpleName());
//System.out.println(f.getType().isEnum());
					if(f.getType().isEnum() || f.getType().equals(String.class)){
//System.out.println(xmlObject.getJsonObject(keyName));
						this.buildSimpleField(this.getFieldFromAnnotation(returnObject, keyName), returnObject, xmlObject.getJsonObject(keyName).get(RMIVariables.KEY_PROPERTY_VALUE).toString().replace("\"",""));

					}else if(f.getType().getSimpleName().equals("List")){//When a vector only has one entry, RMI shows it just as an JsonObject.  Check field type for list object.
						
						//Convert to json array
						StringBuilder tmp = new StringBuilder("{\"");
						tmp.append(keyName);
						tmp.append("\":[");
						tmp.append(xmlObject.getJsonObject(keyName));
						tmp.append("]}");
						this.buildList(this.getFieldFromAnnotation(returnObject, keyName), returnObject, (this.converter.stringToJSON(tmp.toString())).getJsonArray(keyName));
						tmp = null;
					}else{
						this.buildComplexField(f, returnObject, xmlObject.getJsonObject(keyName));
					}

				}
				
				//Array Case
				else if(xmlObject.get(keyName).getValueType().equals(ValueType.ARRAY)){//objectString.charAt(0)=='['
					this.buildList(this.getFieldFromAnnotation(returnObject, keyName), returnObject, xmlObject.getJsonArray(keyName));
				}else{//Number and boolean
					this.buildSimpleField(this.getFieldFromAnnotation(returnObject, keyName), returnObject, xmlObject.get(keyName).toString());
				}
			}
			
			return returnObject;

		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}

	/**
	 * Sets the properties of the provided object with the values in the provided JsonObject
	 * @param romaPayload
	 * @param status
	 * @return
	 */
	public Object loadStatusObject(JsonObject romaPayload, Object status ){
		if(romaPayload==null || status==null){return null;}
		
		String objectName = null;
		
		if(romaPayload.keySet().toArray().length==1){
			objectName = romaPayload.keySet().toArray()[0].toString();
		}else{ 
			objectName = romaPayload.keySet().toArray()[1].toString();
		}
		
		
		JsonObject xmlObject = romaPayload.getJsonObject(objectName);
		Object statusObject = this.loadObjectProperties(xmlObject, status);
		
	
		return statusObject;
	}
	
	/**
	 * Converts a JsonObject from a roma Status payload into a list of Java Objects
	 * @param romaPayload
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public AnyStatusElement loadStatusObject(JsonObject romaPayload) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException{
		if(romaPayload==null){return null;}
		String objectName = null;
//System.out.println(romaPayload);
		//Look for Status Key
		if(romaPayload.keySet().toArray().length==1){
			objectName = romaPayload.keySet().toArray()[0].toString();
		}else{ 
			objectName = romaPayload.keySet().toArray()[1].toString();
		}
		
		//List to hold status objects
		AnyStatusElement e = new AnyStatusElement();

		//Check for payload type.  Array or Single Object
		if(!romaPayload.containsKey(objectName)){
			return null;
		}else if(romaPayload.get(objectName).getValueType().equals(ValueType.ARRAY)){
			
			JsonArray statusArray = romaPayload.getJsonArray(objectName);
			for(int i=0;i<statusArray.size();i++){
				//Generate Status Object
				Object returnObject = factory.getClass().getMethod("createStatus" + objectName).invoke(factory);
				
				//Get JsonObject from array
				JsonObject xmlObject = statusArray.getJsonObject(i);
				
				//Convert JsonObject to Java Object
				Object statusObject = this.loadObjectProperties(xmlObject, returnObject);
				
				//Add Status Object to list
				if(statusObject != null){
					e.getStatusObjects().add(statusObject);
				}
			}
			
			//Return list if not empty
			if(e.getStatusObjects().size()>0){
				return e;
			}
			
		}else{
			Object returnObject = factory.getClass().getMethod("createStatus" + objectName).invoke(factory);
			JsonObject xmlObject = romaPayload.getJsonObject(objectName);
			Object statusObject = this.loadObjectProperties(xmlObject, returnObject);
			if(statusObject != null){	
				e.getStatusObjects().add(statusObject);
				return e;
			}
		}

		return null;
	}

	private void buildComplexField(Field f, Object o, JsonObject value) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException {
		if(value==null || f==null){return;}
		f.setAccessible(true);
//System.out.println(value);
//System.out.println(f.getType().getSimpleName());

		 if(f.getType().getSimpleName().equals(DmReference.class.getSimpleName())){
			 f.set(o, getDmReference(value));
			 return;
		 }
		 
		 //get Complex object
		 Object complexField = (factory.getClass().getMethod("create"+f.getType().getSimpleName()).invoke(factory));
		
		 //Set complex object properties
		 Set<String> keys = value.keySet();
		 for(int i=0;i<keys.size();i++){
			
			 if(value.get(keys.toArray()[i].toString()).getValueType().equals(ValueType.OBJECT)){
				 Field f2 = this.getFieldFromAnnotation(complexField, keys.toArray()[i].toString());
				 if(f2.getType().isEnum() || f.getType().equals(String.class)){
					 this.buildSimpleField(f2, complexField, value.getJsonObject(keys.toArray()[i].toString()).get(RMIVariables.KEY_PROPERTY_VALUE).toString().replace("\"", ""));

				}else{				 
					this.buildComplexField(f2, complexField, value.getJsonObject(keys.toArray()[i].toString()));
				}
			 }else{
				 
				 this.buildSimpleField(this.getFieldFromAnnotation(complexField, keys.toArray()[i].toString()), complexField, value.get(keys.toArray()[i].toString()).toString().replace("\"", ""));
			 }
		 }
		 
		 f.set(o, complexField);

	 }

	private void buildList(Field f, Object o, JsonArray js) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException{
		if(js==null || js.size()<1){return;}
		f.setAccessible(true);
		String methodName = "get" + f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1);

		@SuppressWarnings("unchecked")
		List<Object> l = (List<Object>) o.getClass().getMethod(methodName).invoke(o) ;
        ParameterizedType stringListType = (ParameterizedType) f.getGenericType();
        Class<?> stringListClass = (Class<?>) stringListType.getActualTypeArguments()[0];

		for(int i=0;i<js.size();i++){
			if(js.get(i).getValueType().equals(ValueType.OBJECT)){//Complex Type
				
				//Create object type
				Object complexField = (factory.getClass().getMethod("create"+stringListClass.getSimpleName()).invoke(factory));
				
				//Set properties from payload
				JsonObject jsobject = js.getJsonObject(i);

				Set<String> jsObjectKeys = jsobject.keySet();
				for(int j=0;j<jsObjectKeys.size();j++){
					String keyName = jsObjectKeys.toArray()[j].toString();
					if(keyName.equals(RMIVariables.KEY_URI)||keyName.equals(RMIVariables.KEY_STATE)){continue;}
					Field complexFieldField=this.getFieldFromAnnotation(complexField, keyName);
					
//					System.out.println(keyName);
					complexFieldField.setAccessible(true);

					if(jsobject.get(keyName).getValueType().equals(ValueType.OBJECT)){
						JsonObject keyValue =jsobject.getJsonObject(keyName);
						this.buildComplexField(complexFieldField, complexField, keyValue);
					}else{
						String keyValue =jsobject.get(keyName).toString().replace("\"","");//get general object in case number or string
						this.buildSimpleField(complexFieldField, complexField, keyValue);
					}

				}

				 l.add(complexField);
				 
			}else{//String


		        if(stringListClass.getSimpleName().equals(DmReference.class.getSimpleName())){
		        	DmReference tmp = new DmReference();
		        	tmp.setValue(js.getString(i));
		        	l.add(tmp);
		        }else if (stringListClass.getSimpleName().equals(String.class.getSimpleName())){
		        	l.add(js.getString(i));
		        }else{//Unknown
		        	System.out.println("Unknown List Type");
		        }
			}
		}
	}
	
	private DmReference getDmReference(JsonObject value){
		 DmReference tmp = new DmReference();
		 tmp.setValue(value.getString(RMIVariables.KEY_DMREFERENCE_VALUE));
		 tmp.setUri(value.getString(RMIVariables.KEY_URI));
		 if(value.containsKey(RMIVariables.KEY_DMREFERENCE_CLASS)){
			 tmp.setClazz(value.getString(RMIVariables.KEY_DMREFERENCE_CLASS));
		 }
		 
		 if(value.containsKey(RMIVariables.KEY_STATE)){
			 value = value.getJsonObject(RMIVariables.KEY_STATE);
			 DmRMIConfigState s = new DmRMIConfigState();
			 s.setOpstate(value.getString(RMIVariables.KEY_STATE_OP));
			 s.setAdminstate(value.getString(RMIVariables.KEY_STATE_ADMIN));
			 s.setEventcode(value.getString(RMIVariables.KEY_STATE_EVENT));
			 s.setErrorcode(value.getString(RMIVariables.KEY_STATE_ERROR));
			 s.setConfigstate(value.getString(RMIVariables.KEY_STATE_CONFIG));
			 tmp.setState(s);
		 }
		 
		
		return tmp;
	}

}
