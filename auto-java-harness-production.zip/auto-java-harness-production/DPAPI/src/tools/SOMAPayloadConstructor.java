package tools;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlValue;
import xmlManagement.AnyActionElement;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyDeleteElement;
import xmlManagement.AnyModifyElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.DmDelConfig;
import xmlManagement.DmReference;
import xmlManagement.ModifyConfigBase;
import xmlManagement.Request;
import xmlManagement.Request.*;
import variables.*;

/**
 * Java Class to construct client payloads for SOMA requests.
 * 
 * New Version to resplace SOMAPayloadFactory.  Uses reflection to build payloads.
 * 
 * Under Construction
 * 
 * need to update once other request become avaialbe
 * @author Nick Coble
 *
 */
public class SOMAPayloadConstructor extends XMLManagementPayloadConstructor{


	public String buildObjectRequest(Request r, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(r==null || domain==null ){return null;}
		r.setDomain(domain);
		
		return this.buildObjectRequest(r);
	}
	
	public String buildObjectRequest(Request r) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(r==null){return null;}
		ArrayList<Object> objects = this.getAvaiableObjects(r);
		if(objects == null){ return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, r.getDomain()));
		for(Object object: objects){
			if(object==null){
				continue;
			}else if(object instanceof AnyActionElement){
				payload.append(SOMAVariables.actionRequestHeader);
				for(Object action: ((AnyActionElement)object).getActionObjects()){
					payload.append(this.buildPayloadBody(action));
				}
				payload.append(SOMAVariables.actionRequestFooter);
			}else if(object instanceof AnyConfigElement){
				payload.append(SOMAVariables.setConfigRequestHeader);
				for(ConfigConfigBase config: ((AnyConfigElement)object).getConfigObjects()){
					payload.append(this.buildPayloadBody(config));
				}
				payload.append(SOMAVariables.setConfigRequestFooter);
			}else if(object instanceof AnyModifyElement){
				payload.append(SOMAVariables.modifyConfigRequestHeader);
				for(ModifyConfigBase config: ((AnyModifyElement)object).getConfigObjects()){
					payload.append(this.buildPayloadBody(config));
				}
				payload.append(SOMAVariables.modifyConfigRequestFooter);
			}else if(object instanceof AnyDeleteElement){
				for(JAXBElement<DmDelConfig> config: ((AnyDeleteElement)object).getConfigObjects()){
					payload.append(SOMAVariables.getConfigRequest.replace(SOMAVariables.KEY_PAYLOAD_OBJECT_CLASS, config.getName().getLocalPart()).replace(SOMAVariables.KEY_PAYLOAD_OBJECT_NAME, config.getValue().getName()));
				}
			}else if(object instanceof AnyStatusElement){			
				for(Object status: ((AnyStatusElement)object).getStatusObjects()){
					payload.append(SOMAVariables.getStatusRequest.replace("{class}", ((GetStatus)status).getObjectClass()));
				}
			}else if(object instanceof GetFile){
				payload.append(SOMAVariables.getFileRequest.replace("{name}", ((GetFile)object).getName()));
			}else if(object instanceof SetFile){
				payload.append(SOMAVariables.setFileRequest.replace("{name}", ((SetFile)object).getName()).replace("{content}", new String(((SetFile)object).getValue())));
			}else if(object instanceof GetFilestore){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof GetSamlart){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof GetDiff){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof GetConformanceReport){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof GetLog){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof DoExport){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof DoImport){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof DoDeployPattern){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof DoBackup){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof DoRestore){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof GetAsyncResult){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof DoCpaImport){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof B2BQueryMetadata){
				payload.append(this.buildPayloadBody(object));
			}else if(object instanceof String){
				//Domain Property
			}else{
				System.err.println("Unknown Object Type: " + object);
//				payload.append(this.buildPayloadBody(object));

			}
			
						
		}
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectRequest(AnyActionElement a, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(a==null || a.getActionObjects().size()==0){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(SOMAVariables.actionRequestHeader);
		payload.append(this.buildPayloadBody(a.getActionObjects().get(0)));
		payload.append(SOMAVariables.actionRequestFooter);
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectRequest(AnyStatusElement s, String domain){
		if(s==null|| s.getStatusObjects().size()==0){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		for(Object status: s.getStatusObjects()){
			payload.append(SOMAVariables.getStatusRequest.replace("{class}", ((GetStatus)status).getObjectClass()));
		}
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectRequest(Object action, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(action==null){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(SOMAVariables.actionRequestHeader);
		payload.append(this.buildPayloadBody(action));
		payload.append(SOMAVariables.actionRequestFooter);
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectRequest(AnyConfigElement c, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(c==null|| c.getConfigObjects().size()==0){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(SOMAVariables.setConfigRequestHeader);
		for(ConfigConfigBase config: c.getConfigObjects()){
			payload.append(this.buildPayloadBody(config));
		}
		payload.append(SOMAVariables.setConfigRequestFooter);
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectRequest(ConfigConfigBase c, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(SOMAVariables.setConfigRequestHeader);
		payload.append(this.buildPayloadBody(c));
		payload.append(SOMAVariables.setConfigRequestFooter);
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildModifyObjectRequest(ConfigConfigBase c, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(SOMAVariables.modifyConfigRequestHeader);
		payload.append(this.buildPayloadBody(c));
		payload.append(SOMAVariables.modifyConfigRequestFooter);
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectRequest(AnyModifyElement m, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(m==null|| m.getConfigObjects().size()==0){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(SOMAVariables.modifyConfigRequestHeader);
		for(ModifyConfigBase config: m.getConfigObjects()){
			payload.append(this.buildPayloadBody(config));
		}
		payload.append(SOMAVariables.modifyConfigRequestFooter);
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildObjectReqeust(GetFilestore f, String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(f==null|| f.getLocation() == null){return null;}
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace(SOMAVariables.KEY_PAYLOAD_DOMAIN, domain));
		payload.append(this.buildPayloadBody(f));
		payload.append(SOMAVariables.somaRequestFooter);
		return payload.toString();
	}
	
	public String buildXMLPropSimple(String propName, String propValue){
		StringBuilder returnString = new StringBuilder(SOMAVariables.ELEMENT_TAG_OPEN_START);
		returnString.append(propName);
		returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE);
		returnString.append(propValue);
		returnString.append(SOMAVariables.ELEMENT_TAG_OPEN_END);
		returnString.append(propName);
		returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE);
		return returnString.toString();
	}
	
	public String buildXMLPropSimpleArray(String propName, ArrayList<String> contents){
		if(contents.size()==0){return SOMAVariables.ELEMENT_TAG_OPEN_START+propName+SOMAVariables.ELEMENT_TAG_CLOSE_EMPTY;}
		
		StringBuilder tmp= new StringBuilder();
		for(int i=0;i<contents.size();i++){
			tmp.append(SOMAVariables.ELEMENT_TAG_OPEN_START);
			tmp.append(propName);
			tmp.append(SOMAVariables.ELEMENT_TAG_CLOSE);
			tmp.append( contents.get(i));
			tmp.append(SOMAVariables.ELEMENT_TAG_OPEN_END);
			tmp.append(propName);
			tmp.append(SOMAVariables.ELEMENT_TAG_CLOSE);
		}
		
		return tmp.toString();
	}
	
	/**
	 * Use buildXMLPropSimple to construct contents
	 * @param propName
	 * @param contents
	 * @return
	 */
	public String buildXMLPropComplex(String propName, String contents){
		StringBuilder returnString = new StringBuilder(SOMAVariables.ELEMENT_TAG_OPEN_START);
		returnString.append(propName);
		returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE);
		returnString.append(contents);
		returnString.append(SOMAVariables.ELEMENT_TAG_OPEN_END);
		returnString.append(propName);
		returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE);
		return returnString.toString();	
	}
	
	/**
	 * Use buildXMLPropSimple to construct each array entry 
	 * @param propName
	 * @param contents
	 * @return
	 */
	public String buildXMLPropComplexArray(String propName, String attributes, ArrayList<String> contents){
		if(contents.size()==0){return SOMAVariables.ELEMENT_TAG_OPEN_START+propName+ attributes + SOMAVariables.ELEMENT_TAG_CLOSE_EMPTY;}

		StringBuilder tmp= new StringBuilder();
		for(int i=0;i<contents.size();i++){
			 tmp.append( SOMAVariables.ELEMENT_TAG_OPEN_START);
			 tmp.append(propName);
			 tmp.append(attributes);
			 tmp.append(SOMAVariables.ELEMENT_TAG_CLOSE);
			 tmp.append(contents.get(i));
			 tmp.append(SOMAVariables.ELEMENT_TAG_OPEN_END);
			 tmp.append(propName);
			 tmp.append(SOMAVariables.ELEMENT_TAG_CLOSE);
		}
		return tmp.toString();
	}
	
	public String buildObjectPayload(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildPayloadBody(o);
	}

	////////////////////////////////////////////////////////////////////////
	//  Private Helper Methods											 //
	//////////////////////////////////////////////////////////////////////
	
	/**
	 * Method to build an object payload.  IE ConfigXMLManager, StatusActiveUsersStatus, etc..
	 * @param Object:o
	 * @return String
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	private String buildPayloadBody(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		String tagName = this.getObjectKeyName(o);
		
		if(o instanceof GetFilestore){
			return buildPayloadBody(o, "dp:get-filestore");
		}else{
			return buildPayloadBody(o, tagName);
		}

	}

	/**
	 * Helper method to build object payloads using reflection
	 * @param o
	 * @param tagName
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	private String buildPayloadBody(Object o, String tagName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		StringBuilder payload= new StringBuilder();
		StringBuilder payloadHeader = new StringBuilder();
		payloadHeader.append(SOMAVariables.ELEMENT_TAG_OPEN_START + tagName);
		boolean first = true;

		//Cycle through all the fields of the object
		for (Field field : this.getAllFields(o.getClass())) {
			//Make field accessible incase its protected or private
			field.setAccessible(true);
			
			if(field.get(o)==null ){//Skip null fields
				continue;
			}else{
				
				String propName;
				
				//Get element name from field annotation
				if(field.getAnnotation(XmlElement.class) != null){//Check for element annotation
					propName = field.getAnnotation(XmlElement.class).name();
					payload.append(this.buildPayloadProperty(field, o, first));
				}else if(field.getAnnotation(XmlAttribute.class) != null){//Check for attribute annotation
					propName = field.getAnnotation(XmlAttribute.class).name();
					payloadHeader.append(" " + propName + "=\"");
					 if(field.getType().isEnum()){
						 try {
							 payloadHeader.append(((String)(field.get(o).getClass().getDeclaredMethod(ENUM_VALUE_METHOD).invoke(field.get(o)))));
							} catch (InvocationTargetException | NoSuchMethodException | SecurityException e) {
								e.printStackTrace();
							}
					 }else{
						 payloadHeader.append(field.get(o)); 
					 }
					 
					 payloadHeader.append("\"");
				}else if(field.getAnnotation(XmlValue.class) != null){//Check for value annotation
					if(field.getType().isArray()){
						payload.append(new String(((byte[])field.get(o))));
					}else{
						payload.append(field.get(o).toString());
					}
				}else{//Unknow field type, put in payload to force invalid.  //TODO might need to throw exception instead.
					payload.append("Unable To determine Property Name from annotation from field " + field.getName() + " from " + o.getClass().getSimpleName());
				}
				
			}
		}
		
		//Build payload string
		StringBuilder returnString = new StringBuilder(); 
		if(payload.toString().isEmpty()){
			returnString.append(payloadHeader);
			returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE_EMPTY); 
		}else{
			returnString.append(payloadHeader);
			returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE);
			returnString.append(payload);
			returnString.append(SOMAVariables.ELEMENT_TAG_OPEN_END);
			returnString.append(tagName);
			returnString.append(SOMAVariables.ELEMENT_TAG_CLOSE); 

		}
		
		return returnString.toString();
	}
	
	private String buildPayloadProperty(Field field, Object o, boolean first) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		StringBuilder payload = new StringBuilder();
		field.setAccessible(true);


		if(field.get(o)==null){
			return null;
		}else{
			//Grab the property name from annotation;
			String propName;
			if(field.getAnnotation(XmlElement.class) != null){
				propName = field.getAnnotation(XmlElement.class).name();
			}else if(field.getAnnotation(XmlAttribute.class) != null){
				propName = field.getAnnotation(XmlAttribute.class).name();
				return " " + propName + "=\"" + field.get(o) + "\"";
			}else if(field.getAnnotation(XmlValue.class) != null){
				if(field.getType().isArray()){
					return new String(((byte[])field.get(o)));
				}else{
					return field.get(o).toString();
				}
			}else{
				propName ="Unable To determine Property Name from annotation from field object " + field.getType().getSimpleName();
			}

			//If block to check what type of field it is.  Simple, List, or Complex
			if(field.getClass().isPrimitive() || (field.get(o) instanceof String) || field.getType().isEnum() || field.getType().equals(Boolean.class) || field.getType().equals(Long.class) || field.getType().equals(Integer.class)){//Is it a simple type
					payload.append(this.buildXMLFromSimpleField(field, o));

			}else if(field.get(o) instanceof List<?>){//List

				if(((List<?>)field.get(o)).size()>0){//Empty List?
					if((((List<?>)field.get(o)).get(0).getClass().isPrimitive()) || (((List<?>)field.get(o)).get(0) instanceof String)){//Simple list
						payload.append(this.buildXMLFromSimpleArray(propName,field.get(o)));
					}else{//complex list
						payload.append(this.buildXMLFromComplexArray(propName, field.get(o)));
					}
				}
			}else{//Complex Type
				if(field.get(o) instanceof DmReference){
						Field tmp = field.get(o).getClass().getDeclaredField(DMREFERENCE_VALUE_FIELD);
						tmp.setAccessible(true);
						return payload.append(this.buildXMLPropSimple(propName, (String) tmp.get(field.get(o)))).toString();
					
				}
				payload.append(this.buildPayloadBody(field.get(o), propName));
			}
		}
		
		return payload.toString();
	}
	
	private String buildXMLFromSimpleField(Field f, Object o) throws IllegalArgumentException, IllegalAccessException {
		//Get name
		String propName;
		if(f.getAnnotation(XmlElement.class) != null){
			propName = f.getAnnotation(XmlElement.class).name();
			 //Check if an enum
			 if(f.getType().isEnum()){
				 try {
					 	String propValue = ((String)(f.get(o).getClass().getDeclaredMethod(ENUM_VALUE_METHOD).invoke(f.get(o))));
						return this.buildXMLPropSimple(propName, propValue);
					} catch (InvocationTargetException | NoSuchMethodException | SecurityException e) {
						e.printStackTrace();
					}
					 return null;
			 }else{
			 	 String propValue = f.get(o).toString();
				 return this.buildXMLPropSimple(propName, propValue);
			 }
		}else if(f.getAnnotation(XmlAttribute.class) != null){
			propName = f.getAnnotation(XmlAttribute.class).name();
			return " " + propName + "=\"" + f.get(o) + "\"";
		}else if(f.getAnnotation(XmlValue.class) != null){
			if(f.getType().isArray()){
				return new String(((byte[])f.get(o)));
			}else{
				return f.get(o).toString();
			}
		}else{
			return "Unable To determine Property Name from Simple Field annotation";
		}

		
		
	}
	
	private String buildXMLFromSimpleArray(String propName, Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		ArrayList<String> values = new ArrayList<>();
		for(int i=0;i<((List<?>)o).size();i++){					                			
			values.add((String) ((List<?>)o).get(i));
		}

		return this.buildXMLPropSimpleArray(propName, values);
	}


	private String buildXMLFromComplexArray(String propName, Object object) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException {
	ArrayList<String> values = new ArrayList<>();
	
	boolean realComplex = true;
	for(int i=0;i<((List<?>)object).size();i++){
		Object listObject = ((List<?>)object).get(i);

		if(listObject instanceof DmReference){	
			values.add((String) listObject.getClass().getMethod(DMREFERENCE_VALUE_METHOD).invoke(listObject));
			realComplex = false;
		}else{
			values.add(this.buildPayloadBody(listObject, propName));
		}

	}
	
	StringBuilder returnString = new StringBuilder();

	if(realComplex){
		for(String v: values){
			returnString.append(v);
		}
		return returnString.toString();
	}else{
		return this.buildXMLPropSimpleArray(propName, values);
	}
	
	
}


}
