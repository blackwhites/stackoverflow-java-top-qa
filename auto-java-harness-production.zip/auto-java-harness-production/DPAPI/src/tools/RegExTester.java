package tools;
//https://dpvirt4a.dp.rtp.raleigh.ibm.com:5554/mgmt/filestore/default/temporary/error-report.0000000.20151124152430622EST.txt.gz
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExTester extends BaseClient{

	public static void main(String args[]){
		RegExTester t = new RegExTester();
		String expectedRegEx = ".+\\[error\\].+";
//		String expectedRegEx = ".+\\Q[gatewayscript-user][error]\\E.+";
		String response ="20160525T224805.853Z [0x8580005c][gatewayscript-user][error] mpgw(webapi): tid(396403)[request][65.190.14.51] gtid(396403): Headers Nick: {\"content-type\":\"application/json\",\"accept\":\"application/json\",\"customerid\":\"blah\",\"cache-control\":\"no-cache\",\"pragma\":\"no-cache\",\"user-agent\":\"Java/1.8.0\",\"host\":\"sjsldev161.dev.ciondemand.com\",\"content-length\":\"299\",\"via\":\"1.1 AQAAAFsSAAA-\",\"x-client-ip\":\"65.190.14.51\",\"x-global-transaction-id\":\"396403\"}";
//		String response =  "20160525T224805.897Z [0x85800007][gatewayscript][error] mpgw(webapi): tid(10674)[request][169.54.149.161] gtid(396403): GatewayScript processing Error 'SyntaxError: Unexpected token u";
		
		//		System.out.println(t.contains(response, expectedRegEx, false));
		System.out.println(t.matches(response, expectedRegEx, false));

 	}
//	System.out.println(t.matches("move -f audit:/move_command.txt temporary:/moveTest_admin_default_move_command.txt\n\n% audit:/move_command.txt - No such file or directory\n\n\nxi52(config)# ", "move -f audit:/move_command.txt temporary:/moveTest_admin_default_move_command.txt\n([\\w\\W]?!\n)+\\(config\\)#"));
//
	/**
	 * Checks if cliRespones String matches the provided regular expression
	 * @param expectedResponse
	 * @param actualResponse
	 * @return boolean
	 */
	public boolean matches(String cliResponse, String regExp){
		Pattern tmp = Pattern.compile(regExp, Pattern.DOTALL);
		return tmp.matcher(cliResponse).matches();
	}
	
	public boolean matches(String cliResponse, String regExp, boolean dotAll){
		Pattern tmp =null;
		if(dotAll){
			tmp= Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			tmp = Pattern.compile(regExp);
		}
		return tmp.matcher(cliResponse).matches();
	}
	
	/**
	 * Checks if  cliResponse String contains the provided regular expression
	 * @param cliResponse
	 * @param contains
	 * @return
	 */
	public boolean contains(String cliResponse, String regExp, boolean dotAll){
		
		Pattern tmp = Pattern.compile(regExp);
		if(dotAll){
			tmp= Pattern.compile(regExp, Pattern.DOTALL);
		}
		return tmp.matcher(cliResponse).find();
	}

	/**
	 * Returns a array of Strings found in the response String that matched the provided regExp
	 * @param response
	 * @param regExp
	 * @return
	 */
	public ArrayList<String> getGroups(String response, String regExp){
		ArrayList<String> tmp = new ArrayList<>();
		Pattern p = Pattern.compile(regExp, Pattern.DOTALL);
		Matcher m = p.matcher(response);

		while(m.find()){
		   tmp.add(m.group(0));
		}
		return tmp;
	}
	
	/**
	 * Returns the number of times the provided RegEx appears in the response
	 * @param response
	 * @param regExp
	 * @return
	 */
	public int count(String response, String regExp){
		int tmp=0;
		Pattern p = Pattern.compile(regExp, Pattern.DOTALL);
		Matcher m = p.matcher(response);

		while(m.find()){
		   tmp++;
		}
		return tmp;
	}  
}
