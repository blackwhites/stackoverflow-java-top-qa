package tools;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.json.JsonValue.ValueType;
import tools.Converter;
import tools.HTTPSClient;
import tools.RMIObjectFactory;
import tools.RMIPayloadConstructor;
import tools.URLClient;
import variables.DPVariables;
import variables.RMIVariables;
import xmlManagement.*;
import xmlManagement.Request.GetStatus;
import beans.RequestBean;

/**
 * Object to send ROMA request to a DP appliance.
 * All request methods handle constructing the proper URL
 * Contains methods that construct the payloads from an AnyConfigElement Objects
 * Each request returns a RequestBean object which contains information about the
 * request and response.  Both Get Config and Get Status will have a xmlManagement Response object loaded in the RequestBean.
 * @author Nick Coble
 *
 */
public class RMIClient extends DPManagement {
	
	final HTTPSClient requester = new HTTPSClient();//Object to send request
	public RMIPayloadConstructor payloadBuilder = new RMIPayloadConstructor();//Object to construct JSON payloads
	public RMIObjectFactory factory=new RMIObjectFactory();//Object to load response object in requestbeans
	public MetadataRequest metadata = new MetadataRequest();
	public ConfigRequest configRequest = this.new ConfigRequest();
	public ActionRequest action = this.new ActionRequest();//Object to send action request
	public FileStoreRequest filestore = this.new FileStoreRequest();//Object to send filestore request
	public StatusRequest status = this.new StatusRequest();//Object to hanlde status request
	public TypeRequest type = new TypeRequest();
	public BatchRequest batchPut = new BatchRequest();
	public Converter base64encoder = converter;//Object to handle encoding/decoding
	
	String statusURI;
	String configURL;
	String actionURL;
	String actionStatusURL;
	String typeURL; 
	String metaURL;
	String filestoreURI;
	String romaPort;
	String url;
	String lastURL=null;

	
	public RMIClient(String hostname, int port, String userName, String password, String domain){
		super(hostname, port, userName, password, domain);
		super.configRequest = this.configRequest;
		super.action = this.action;
		super.filestore = this.filestore;
		super.status = this.status;
		super.batchRequest = this.batchPut;
		this.romaPort = String.valueOf(port);
		
		
		//Object to send configuration request
		this.initializeURL();
		this.initializeURIS();
		this.initializeHeaders();
	}
	
	/**
	 * Sets the root URL using ip and port
	 */
	public void initializeURL(){this.url = "https://" + this.hostName + ":" + this.romaPort;}
	
	/**
	 * Sets the ROMA URI's using current domain
	 */
	public void initializeURIS(){
		this.statusURI = RMIVariables.URI_STATUS_OBJECT.replace("{domain}", this.domain);
		this.configURL =  RMIVariables.URI_CONFIG_OBJECT.replace("{domain}", this.domain);
		this.actionURL = RMIVariables.URI_ACTION_QUEUE.replace("{domain}", this.domain);
		this.actionStatusURL = RMIVariables.URI_ACTION_ASYNC_STATUS.replace("{domain}", this.domain);
		this.typeURL = RMIVariables.URI_TYPE_OBJECT.replace("{domain}", this.domain);
		this.metaURL = RMIVariables.URI_METADATA_OBJECT.replace("{domain}", this.domain);
		this.filestoreURI = RMIVariables.URI_FILESTORE.replace("{domain}", this.domain);
	}
	
	/**
	 * Sets the request headers using username and password
	 */
	public void initializeHeaders(){
		this.requester.getHeaders().clear();
		this.requester.addBasicAuthenticationHeader(this.userName, this.password);
		this.requester.addHeader(URLClient.HEADER_KEY_Connection, URLClient.HEADER_VALUE_Connection_Close);
		this.requester.addUserAgentHeader(URLClient.HEADER_VALUE_UserAgent_Java);
	}
	
	public String getURL(){return this.requester.getUrl();}
	
	@Override
	public void setUserName(String userName){
		this.userName=userName;
		this.initializeHeaders();
	}

	
	@Override
	public void setPassword(String password){
		this.password=password;
		this.initializeHeaders();
	}
	
	
	@Override
	public void setDomain(String domain){
		this.domain=domain;
		this.initializeURIS();
	}
	
	/**
	 * Sets max time for a connection
	 * @param timeOutMilli
	 */
	public void setConnectionTimeout(int timeOutMilli){
		this.requester.setConnectionTimeOut(timeOutMilli);
	}
	
	/**
	 * Sets the time limit to get a response to a request
	 * @param timeOutMilli
	 */
	public void setReadTimeOut(int timeOutMilli){
		this.requester.setReadTimeOut(timeOutMilli);
	}
	
	public void setIP(String ip){
		this.hostName=ip;
		this.initializeURL();
	}
	
	@Override
	public void setHostName(String hostName){
		this.hostName=hostName;
		this.initializeURL();
	}
	
	public void setRomaPort(String port){
		this.romaPort = port;
		this.initializeURL();
	}
	
	public String getRomaPort(){return this.romaPort;}
	
	/**
	 * Sends GET request to the specified url
	 * @param url
	 * @return
	 */
	public RequestBean sendGet(String url){
		this.requester.setURL(url);
		return this.requester.sendGet();
	}
	
	/**
	 * Sends GET request to the specified url
	 * @param url
	 * @return
	 */
	public RequestBean sendOption(String url){
		this.requester.setURL(url);
		return this.requester.sendOption();
		
	}
	
	/**
	 * Sends POST request to the specified url using the specified payload
	 * @param url
	 * @param payload
	 * @return
	 */
	public RequestBean sendPost(String url, String payload){
		this.requester.setURL(url);
		return this.requester.sendPost(payload);
	}
	
	/**
	 * Sends PUT request to the specified url using the specified payload
	 * @param url
	 * @param payload
	 * @return
	 */
	public RequestBean sendPut(String url, String payload){
		this.requester.setURL(url);
		return this.requester.sendPut(payload);
	}
	
	/**
	 * Sends delete request to the specified url
	 * @param url
	 * @return
	 */
	public RequestBean sendDelete(String url){
		this.requester.setURL(url);
		return this.requester.sendDelete();
	}
	
	/**
	 * Sends a request to the RMI interface to retrieve all domains that exist on the appliance
	 * @return
	 */
	public RequestBean getAllDomains(){ 
		this.requester.setUrl(this.url + "/mgmt/domains/config/");
		return (this.setRequestBeanObjects(this.requester.sendGet()));
	}
	
	/**
	 * Checks the provided string to see if it is valid JSON
	 * @param json
	 * @return
	 */
	public boolean validJSON(String json){
		if(this.base64encoder.stringToJSON(json) != null){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Returns the RequestBean for the last request made
	 * @return
	 */
	public RequestBean getLastResponse(){return this.requester.getLastResponse();}
	
	/**
	 * Returns true if the regEx is found in the last server response
	 * @param expectedRegEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	@Override
	public boolean lastResponseContains(String expectedRegEx, boolean dotAll){
		return this.requester.lastResponseContains(expectedRegEx, dotAll);
	}
	
	/**
	 * Returns true if the last server response matches the provided regex
	 * @param expectedRegEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	@Override
	public boolean lastResponseMatches(String expectedRegEx, boolean dotAll){
		return this.requester.lastResponseMatches(expectedRegEx, dotAll);
	}
	
	/**
	 * Returns the first regEx found in the last server response
	 * @param regEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	@Override
	public String lastResponseGetRegEx(String regEx, boolean dotAll){
		return this.requester.lastResponseGetRegEx(regEx, dotAll);
	}
	
	/**
	 * Returns all the regEx's found in the last server response
	 * @param regEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	@Override
	public ArrayList<String> lastResponseGetGroups(String regEx, boolean dotAll){
		return this.requester.lastResponseGetGroups(regEx, dotAll);
	}
	
	/**
	 * Returns the number of times the provided regEx was found in the last server response
	 * @param regEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	@Override
	public int lastResponseCountRegEx(String regEx, boolean dotAll){
		return this.requester.lastResponseCountRegEx(regEx, dotAll);
	}
	

	
	/**
	 * Converts a string into a JsonObject.  Returns null if string is not valid.
	 * @param json
	 * @return
	 */
	public JsonObject stringToJsonObject(String json){
		return this.base64encoder.stringToJSON(json);
	}
	
	public JsonObject getJSONObjectFromArray(JsonArray ja, String propertyName, String propertyValue){
		for (JsonValue v : ja){
			JsonObject o = null;
			if (v.getValueType().equals(ValueType.OBJECT)){
				o = (JsonObject)v;
				if (o.containsKey(propertyName) && o.getString(propertyName).equals(propertyValue))
					return o;
			}
		}
		return null;
	}
	
	
	private RequestBean setRequestBeanObjects(RequestBean bean){
		try{
			JsonObject tmp=base64encoder.stringToJSON(bean.getServerPayload());
			bean.setResponseObject(factory.getResponseObject(tmp));
			bean.setResponseAsJSON(tmp);
		}catch(Exception e){
			e.printStackTrace();
			bean.setError(true);
			bean.setErrorMessage("Error while loading RequestBean Response and JSON objects.  Check Exception property.  Server Response: " + bean.getServerPayload());
			bean.setException(e);
			return bean;
		}
		if(bean.getResponseObject()==null){bean.setError(true);bean.setErrorMessage("Unable to load response object");}
		return bean;
	}
	
	

	///////////////////////////////////////////////////////
	//                  INNER CLASSES                   //
	/////////////////////////////////////////////////////
	/**
	 * Inner class to send Configuration object request
	 * @author Nick Coble
	 *
	 */

	public class ConfigRequest extends DPManagement.ConfigRequest{
		
		/**
		 *Sends request to create configuration object
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws NoSuchMethodException 
		 * @throws InvocationTargetException 
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws Exception 
		 */
		public RequestBean createConfigObject(AnyConfigElement configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6)));
			RequestBean bean = requester.sendPost(payloadBuilder.buildObjectRequest(configObject));
			return setRequestBeanObjects(bean);
		}
				
		/**
		 * Sends a post request to create the specified configuraiton object.
		 * @param configObject
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 */
		public RequestBean createConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6)));
			RequestBean bean = requester.sendPost(payloadBuilder.buildObjectRequest(configObject));
			return setRequestBeanObjects(bean);
		}
	
		/**
		 * Sends request to create configuration object
		 * @param String: payload - JSON representation of the object
		 * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @return
		 */
		public RequestBean createConfigObject(String payload, String objectClass){
			requester.setURL(url + configURL.replace("{object}", objectClass));
			RequestBean bean = requester.sendPost(payload);
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Appends entries to a given vector.
		 * @param AnyConfigElement: configObject
		 * @param String: vectorName - name of the vector property
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean appendToConfigObjectVector(AnyConfigElement configObject, String vectorName) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+vectorName);
			RequestBean bean = requester.sendPost(payloadBuilder.buildPropertyRequest(configObject, vectorName));
			return setRequestBeanObjects(bean);
			
		}
		
		/**
		 * Sends request to modify configuration object
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws NoSuchMethodException 
		 * @throws InvocationTargetException 
		 * @throws Exception 
		 */
		public RequestBean modifyConfigObject(AnyConfigElement configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6)) +"/"+payloadBuilder.getObjectName(configObject));
			RequestBean bean = requester.sendPut(payloadBuilder.buildObjectRequest(configObject));
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to modify the configuration object using the values set in the provided parameter
		 * @param configObject
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 */
		public RequestBean modifyConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6)) +"/"+payloadBuilder.getObjectName(configObject));
			RequestBean bean = requester.sendPut(payloadBuilder.buildObjectRequest(configObject));
			return setRequestBeanObjects(bean);
		}
	
		/**
		 * Sends request to modify configuration object
		 * @param String: payload - JSON representation of the object
		 * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name given to the object
		 * @return RequestBean
		 */
		public RequestBean modifyConfigObject(String payload, String objectClass, String objectName){
			requester.setURL(url + configURL.replace("{object}", objectClass) + "/" + objectName);
			RequestBean bean = requester.sendPut(payload);
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to modify a configuration property
		 * @param AnyConfigElement: configObject
		 * @param String: propertyName - Name of the property to be modified IE UserSummary
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean modifyConfigProperty(AnyConfigElement configObject, String propertyName) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/" + payloadBuilder.getObjectName(configObject)+"/" +propertyName);
			RequestBean bean =  requester.sendPost(payloadBuilder.buildPropertyRequest(configObject, propertyName));
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to modify a configuration property
		 * @param String: payload - JSON representation of the object property
		 * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name given to the object
		 * @param String: propertyName  - Name of the property to be modified IE UserSummary
		 * @return RequestBean
		 */
		public RequestBean modifyConfigProperty(String payload, String objectClass, String objectName, String propertyName){
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName + "/" + propertyName);
			RequestBean bean =  requester.sendPut(payload);
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Send request to delete a configuration object
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean deleteConfigObject(AnyConfigElement configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject));
			RequestBean bean =  requester.sendDelete();
			
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to delete the specified configuration object.  Note object must have name set.
		 * @param configObject
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 */
		public RequestBean deleteConfigObject(ConfigConfigBase configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject));
			RequestBean bean =  requester.sendDelete();
			return setRequestBeanObjects(bean);

			}
		
		/**
		 * Sends request to delete a configuration object
	     * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name given to the object
		 * @return RequestBean
		 */
		public RequestBean deleteConfigObject(String objectClass, String objectName){
			requester.setURL(url + configURL.replace("{object}",objectClass) +"/"+ objectName);
			RequestBean bean =  requester.sendDelete();
			return setRequestBeanObjects(bean);
		}
	
		/**
		 * Sends request to delete/clear a vector.  
		 * Note: vectors only, to clear other properties set it to empty string
		 * @param AnyConfigElement: configObject
		 * @param String: vectorName - name of the vector property
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean deleteConfigVector(AnyConfigElement configObject, String vectorName) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject)+"/"+vectorName);
			RequestBean bean =  requester.sendDelete();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to delete/clear a vector.
		 * Note: vectors only, to clear a regualr property set it to an empty string
		 * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name given to the object
		 * @param String: vectorName - name of the vector property
		 * @return RequestBean
		 */
		public RequestBean deleteConfigVector(String objectClass, String objectName, String vectorName){
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+objectName+"/"+vectorName);
			RequestBean bean =  requester.sendDelete();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to get a configuration object
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws InstantiationException 
		 * @throws ClassNotFoundException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObject(AnyConfigElement configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject));
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends a get request for the configuration object passed.  Note the object passed must have the name property set.
		 * @param configObject
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 * @throws ClassNotFoundException
		 * @throws InstantiationException
		 */
		public RequestBean getConfigObject(ConfigConfigBase configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject));
			RequestBean bean = requester.sendGet();
			try{
				factory.loadConfigObject(requester.encoder.stringToJSON(bean.getServerPayload()), configObject);
			}catch(Exception e){
				
			}
			
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends a get request for the configuration object passed.  Note the object passed must have the name property set.
		 * @param configObject
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 * @throws ClassNotFoundException
		 * @throws InstantiationException
		 */
		public RequestBean getConfigObject(ConfigConfigBase configObject, String urlParamaters) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject) + "?" + urlParamaters);
			RequestBean bean = requester.sendGet();
			try{
				factory.loadConfigObject(requester.encoder.stringToJSON(bean.getServerPayload()), configObject);
			}catch(Exception e){
				
			}
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Loads the provided configuration object properties by doing a GET request to the RMI interface.
		 * @param configObject
		 * @param instanceName
		 * @return RequestBean
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 */
		public ConfigConfigBase loadConfigObject(ConfigConfigBase configObject, String instanceName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ instanceName);
			RequestBean bean = requester.sendGet();
			try{
				factory.loadConfigObject(requester.encoder.stringToJSON(bean.getServerPayload()), configObject);
			}catch(Exception e){
				bean.setError(true);
				bean.setErrorMessage("Error while loading RequestBean Response and JSON objects.  Check Exception property.  Server Response: " + bean.getServerPayload());
				bean.setException(e);
				return configObject;
			}
			
			return configObject;
		}
		
		public ConfigConfigBase loadConfigObject(ConfigConfigBase configObject, String instanceName, String urlParameters) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ instanceName + "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			try{
				factory.loadConfigObject(requester.encoder.stringToJSON(bean.getServerPayload()), configObject);
			}catch(Exception e){
				bean.setError(true);
				bean.setErrorMessage("Error while loading RequestBean Response and JSON objects.  Check Exception property.  Server Response: " + bean.getServerPayload());
				bean.setException(e);
				return configObject;
			}
			
			return configObject;
		}
		
		/**
		 * Sends request to get a configuration object
		 * @param AnyConfigElement: configObject
		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws InstantiationException 
		 * @throws ClassNotFoundException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObject(AnyConfigElement configObject, String urlParameters) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject)+"?"+urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);

		}
		
		/**
		 * Sends request to get a configuration object
		 * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name give to the object
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getConfigObject(String objectName, String objectClass) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to get a configuration object
		 * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name give to the object
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getConfigObject(String objectName, String objectClass, String urlParameters) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName + "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 Sends a recursive get-config request.  Returns the specified object as well as an embedded list of any object it may reference.
		 * Depth > 1 the embedded list will include any objects refereneced by the referenced objects within the specified object up to a max depth of 7
		 * @param configObject
		 * @param objectName
		 * @param objectClass
		 * @param depth:  Deteremines to what level of reference the embedded list will include
		 * @param viewOpState: Shows the operational state of the object
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 */
		public RequestBean getConfigObjectRecursive(String objectName, String objectClass, String depth, boolean viewOpState) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			String urlParameters = "?view=recursive";
			if(depth != null && !depth.equals("")){
				urlParameters += "&depth="+depth;
			}
			if(viewOpState){
				urlParameters += "&state=true";
			}
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+objectName+ urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends a recursive get-config request.  Returns the specified object as well as an embedded list of any object it may reference.
		 * Depth > 1 the embedded list will include any objects refereneced by the referenced objects within the specified object up to a max depth of 7
		 * @param configObject
		 * @param depth:  Deteremines to what level of reference the embedded list will include
		 * @param viewOpState: Shows the operational state of the object
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 */
		public RequestBean getConfigObjectRecursive(AnyConfigElement configObject, String depth, boolean viewOpState) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			String urlParameters = "?view=recursive";
			if(depth != null && !depth.equals("")){
				urlParameters += "&depth="+depth;
			}
			if(viewOpState){
				urlParameters += "&state=true";
			}
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject)+ urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends a recursive get-config request.  Returns the specified object as well as an embedded list of any object it may reference.
		 * Depth > 1 the embedded list will include any objects refereneced by the referenced objects within the specified object up to a max depth of 7
		 * @param configObject
		 * @param depth:  Deteremines to what level of reference the embedded list will include
		 * @param viewOpState: Shows the operational state of the object
		 * @return
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 */
		public RequestBean getConfigObjectRecursive(ConfigConfigBase configObject, String depth, boolean viewOpState) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			String urlParameters = "?view=recursive";
			if(depth != null && !depth.equals("")){
				urlParameters += "&depth="+depth;
			}
			if(viewOpState){
				urlParameters += "&state=true";
			}
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject)+ urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}

		/**
		 * Sends request to get a configuration object with the op-state parameter enabled
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws InstantiationException 
		 * @throws ClassNotFoundException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectWithState(AnyConfigElement configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject)+"?state=true");
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to get a configuration object with the op-state parameter enabled
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws InstantiationException 
		 * @throws ClassNotFoundException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectWithState(ConfigConfigBase configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+payloadBuilder.getObjectName(configObject)+"?state=true");
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		public RequestBean getConfigObjectWithState(String objectName, String objectClass){
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName + "?state=true");
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);

		}
		
		/**
		 * Sends request to get a configuration property
	     * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name give to the object
		 * @param String: propertyName - name of the property
		 * @return  RequestBean
		 */
		public RequestBean getConfigObjectProperty(String objectClass, String objectName, String propertyName){
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName + "/" + propertyName);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to get a configuration property with the state parameter.  Only valid for dmReference properties
	     * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name give to the object
		 * @param String: propertyName - name of the property
		 * @return  RequestBean
		 */
		public RequestBean getConfigObjectPropertyWithState(String objectClass, String objectName, String propertyName){
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName + "/" + propertyName + "?state=true");
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to get a configuration property
	     * @param String: objectClass - class name of the configuration object.  IE XMLManager
		 * @param String: objectName - name give to the object
		 * @param String: propertyName - name of the property
		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return  RequestBean
		 */
		public RequestBean getConfigObjectProperty(String objectClass, String objectName, String propertyName, String urlParameters){
			requester.setURL(url + configURL.replace("{object}", objectClass)+"/"+ objectName + "/" + propertyName + "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}

		/**
		 * Sends request to get a configuration property
		 * @param AnyConfigElement: configObject
		 * @param String: propertyName - name of the property
		 * @return RequestBean
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectProperty(AnyConfigElement configObject, String propertyName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ payloadBuilder.getObjectName(configObject) + "/" + propertyName);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to get a configuration property
		 * @param AnyConfigElement: configObject
		 * @param String: propertyName - name of the property
		 * @return RequestBean
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectProperty(ConfigConfigBase configObject, String propertyName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ payloadBuilder.getObjectName(configObject) + "/" + propertyName);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to get a configuration property
		 * @param AnyConfigElement: configObject
		 * @param String: propertyName - name of the property
		 * @return RequestBean
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectPropertyWithState(ConfigConfigBase configObject, String propertyName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ payloadBuilder.getObjectName(configObject) + "/" + propertyName + "?state=true");
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to get a configuration property
		 * @param AnyConfigElement: configObject
		 * @param String: propertyName - name of the property
		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectProperty(AnyConfigElement configObject, String propertyName, String urlParameters) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ payloadBuilder.getObjectName(configObject) + "/" + propertyName+"?"+urlParameters);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to get a configuration property
		 * @param AnyConfigElement: configObject
		 * @param String: propertyName - name of the property
		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getConfigObjectProperty(ConfigConfigBase configObject, String propertyName, String urlParameters) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			requester.setURL(url + configURL.replace("{object}", payloadBuilder.getClassName(configObject).substring(6))+"/"+ payloadBuilder.getObjectName(configObject) + "/" + propertyName+"?"+urlParameters);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}

		/**
		 * Sends request to get a list of available Configuration classes with in the defined domain
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean getAvailableConfigObjects(){
			requester.setURL(url + RMIVariables.URI_ROOT_CONFIG);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
	
		/**
		 * Sends request to get a list of existing objects of a Config class with in the defined domain
		 * IE: Returns all existing XMLMangers in the default domain 
		 * @param String: configClass - Class Name  ie: XMLManager
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean getExistingObjects(String configClass){
			requester.setURL(url + configURL.replace("{object}", configClass));
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to get a list of existing objects of a Config class with in the defined domain
		 * IE: Returns all existing XMLMangers in the default domain 
		 * @param String: configClass - Class Name  ie: XMLManager
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws Exception 
		 */
		public RequestBean getExistingObjects(String configClass, String urlParameters){
			requester.setURL(url + configURL.replace("{object}", configClass)+"?"+urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to get a list of existing objects of a Config class with in the defined domain
		 * IE: Returns all existing XMLMangers in the default domain 
		 * @param AnyConfigElement: configObject
		 * @return RequestBean
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getExistingObjects(AnyConfigElement configObject, String objectClass){
			requester.setURL(url + configURL.replace("{object}", objectClass));
			RequestBean bean = requester.sendGet();
			if(bean.getResponseObject() != null && bean.getResponseObject().getConfig() != null){
				configObject.getConfigObjects().addAll(bean.getResponseObject().getConfig().getConfigObjects());
			}
			
			return setRequestBeanObjects(bean);
		}

		/**
		 * Sends request to get a list of existing objects of a Config class with in the defined domain
		 * IE: Returns all existing XMLMangers in the default domain 
		 * @param AnyConfigElement: configObject
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean getExistingObjects(AnyConfigElement configObject, String objectClass, String urlParameters) throws IllegalArgumentException, IllegalAccessException{
			requester.setURL(url + configURL.replace("{object}",objectClass)+"?"+urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}

	}
	
	///////////////////////////////////////////////////
	//             Inner Class
	///////////////////////////////////////////////////
		
	/**
	 * Inner Class to send ROMA Action request
	 * @author Nick Coble
	 *
	 */
	public class ActionRequest extends DPManagement.ActionRequest{

		/**
		 * Sends do-action request
		 * @param AnyActionElement: a
		 * @return RequestBean
		 * @throws NoSuchMethodException 
		 * @throws InvocationTargetException 
		 * @throws SecurityException 
		 * @throws NoSuchFieldException 
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 * @throws Exception 
		 */
		public RequestBean postAction(AnyActionElement a) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + actionURL);
			RequestBean bean = requester.sendPost(payloadBuilder.buildObjectRequest(a));
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return setRequestBeanObjects(bean);
			
		}
		
		public RequestBean postAction(Object action) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			requester.setURL(url + actionURL);
			RequestBean bean = requester.sendPost(payloadBuilder.buildObjectRequest(action));
			return setRequestBeanObjects(bean);

		}
		
		/**
		 * Sends do-action request
		 * @param String: payload
		 * @return RequestBean
		 */
		public RequestBean postAction(String payload){
			requester.setURL(url + actionURL);
			RequestBean bean = requester.sendPost(payload);
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Sends request to retrieve the action queue
		 * @return RequestBean
		 */
		public RequestBean getActionQueue(){
			requester.setURL(url + actionURL);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to retrieve the action queue
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 */
		public RequestBean getActionQueue(String urlParameters){
			requester.setURL(url + actionURL + "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to retrieve the schema for an action operation
		 * @param String: objectName - name of the action object
		 * @return RequestBean
		 */
		public RequestBean getActionSchema(String objectName){
			requester.setURL(url + actionURL + "/operations/" + objectName);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to retrieve the schema for an action operation
		 * @param String: objectName - name of the action object
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 */
		public RequestBean getActionSchema(String objectName, String urlParameters){
			requester.setURL(url + actionURL + "/operations/" + objectName+ "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Sends request to retrieve a list of available action operations
		 * @return RequestBean
		 */
		public RequestBean getAvailableActions(){
			requester.setURL(url + actionURL + "/operations");
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
	

		/**
		 * Method to retrieve async action status
		 * @param actionID
		 * @return
		 */
		public RequestBean getAsyncActionStatus(String actionID){
			requester.setURL(url + actionStatusURL.replace("{id}", actionID));
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		public RequestBean getAsyncActionStatusFromURI(String uri){
			requester.setURL(url + uri);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}

		

		@Override
		public RequestBean action(Object action) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
			return this.postAction(action);
		}
	}
	
	
///////////////////////////////////////////////////
//             Inner Class
///////////////////////////////////////////////////

	/**
	 * Inner Class to send ROMA file store request
	 * Note: path should not include leading or trailing \
	 * IE: path to local:\\\subdir1\subdir2\subdir3\file.txt = local\subdir1\subdir2\subdir3
	 * @author Nick Coble
	 *
	 */
	public class FileStoreRequest extends DPManagement.FileStoreRequest{
		
		/**
		 * Creates a file on the dp appliance
		 * Base64 encodes the provided contents and uploads it to the appliance
		 * @param String: path - the directory where the file will be stored on appliance
		 * @param fileName - name the file will be saved as on the appliance
		 * @param contents - contents of the file.  Not encoded
		 * @return RequestBean
		 */
		public RequestBean createFile(String path, String fileName, String contents){
			requester.setURL(url + filestoreURI + "/" + path);
			RequestBean bean = (requester.sendPost(RMIVariables.PAYLOAD_CREATE_FILE.replace("{name}", fileName).replace("{content}", base64encoder.encodeBase64(contents))));
			return setRequestBeanObjects(bean);
		
		}
		
		/**
		 * Adds a file on the dp appliance
		 * String should already be encoded.  Use this method for binary files.
		 * @param String: path - the directory where the file will be stored on appliance
		 * @param fileName - name the file will be saved as on the appliance
		 * @param contents - contents of the file.  Not encoded
		 * @return RequestBean
		 */
		public RequestBean createEncodedFile(String path, String fileName, String contents){
			requester.setURL(url + filestoreURI + "/" + path);
			RequestBean bean = (requester.sendPost(RMIVariables.PAYLOAD_CREATE_FILE.replace("{name}", fileName).replace("{content}",(contents))));
			return setRequestBeanObjects(bean);
		}
		
		
		/**
		 * Modifies a file on the dp appliance
		 * Base64 encodes the provided contents and uploads it to the appliance
		 * @param String: path  - location to put file on the appliance
		 * @param String: fileName
		 * @param String: contents
		 * @return RequestBean
		 */
		public RequestBean modifyFile(String path, String fileName, String contents){
			requester.setURL(url + filestoreURI + "/" + path +"/"+fileName);
			RequestBean bean =(requester.sendPut(RMIVariables.PAYLOAD_CREATE_FILE.replace("{name}", fileName).replace("{content}", base64encoder.encodeBase64(contents))));
			return setRequestBeanObjects(bean);
		}
		
		@Override
		public RequestBean modifyEncodedFile(String path, String fileName, String contents) {
			requester.setURL(url + filestoreURI + "/" + path +"/"+fileName);
			RequestBean bean =(requester.sendPut(RMIVariables.PAYLOAD_CREATE_FILE.replace("{name}", fileName).replace("{content}", (contents))));
			return setRequestBeanObjects(bean);
		}
		
	

		/**
		 * Creates a directory on the dp appliance
		 * @param path - where the directory will be created
		 * @param dirName - name of the directory
		 * @return RequestBean
		 */
		public RequestBean createDirectory(String path, String dirName){
			requester.setURL(url + filestoreURI + "/" + path);
			RequestBean bean = (requester.sendPost(RMIVariables.PAYLOAD_CREATE_DIRECTORY.replace("{name}", dirName)));
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Deletes a file from the appliance
		 * @param path - location of the file on the appliance
		 * @param fileName - name of the file
		 * @return RequestBean
		 */
		public RequestBean deleteFile(String path, String fileName){
			requester.setURL(url + filestoreURI + "/" + path +"/"+fileName);
			RequestBean bean = (requester.sendDelete());
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Deletes a directory from the appliance
		 * @param path - location of the directory
		 * @param dirName - name of the directory
		 * @return
		 */
		public RequestBean deleteDirectory(String path, String dirName){
			requester.setURL(url + filestoreURI + "/" + path +"/"+dirName);
			RequestBean bean = (requester.sendDelete());
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Gets a file from the appliance.  The contents of the file will be base64 encoded
		 * @param path - location of the file
		 * @param fileName - name of the file
		 * @return RequestBean
		 */
		public RequestBean getFile(String path, String fileName){
			requester.setURL(url + filestoreURI + "/" + path +"/"+fileName);
			RequestBean bean = (requester.sendGet());
			return setRequestBeanObjects(bean);
		}
		
		
		public String getFileAsString(String path, String fileName){
			Response r =  this.getFile(path, fileName).getResponseObject();
			if(r.getFile().isEmpty() || r.getFile().get(0).getValueAsString() == null){
				return null;
			}
			return r.getFile().get(0).getValueAsString();
//			return converter.decodeBase64(this.getFile(path, fileName).getResponseAsJSON().getString(RMIVariables.KEY_FILE));
		}

		
		/**
		 * Gets a directory from the appliance.
		 * @param path - location of the directory
		 * @param dirName - name of the directory
		 * @return
		 */
		public RequestBean getDirectory(String path, String dirName){
			requester.setURL(url + filestoreURI + "/" + path +"/"+dirName);
			RequestBean bean = (requester.sendGet());
			return setRequestBeanObjects(bean);
		}
		
		public RequestBean getDirectory(String path){
			if(path.isEmpty()){
				requester.setURL(url + filestoreURI);
			}else{
				requester.setURL(url + filestoreURI + "/" + path);
			}
			RequestBean bean = (requester.sendGet());
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * returns cli-log file. "/mgmt/filestore/default/logtemp/cli-log"
		 * User must have access to default domain
		 * @param p
		 * @return boolean
		 */
		public String getCLILog(){
			requester.setURL("https://"+hostName+":"+ romaPort + RMIVariables.URI_FILESTORE_CLI_LOG);
			String fileContents = base64encoder.decodeBase64(base64encoder.stringToJSON(requester.sendGet().getServerPayload()).getString(RMIVariables.KEY_FILE));
			return fileContents;
		}
		
		/**
		 * Returns the default log.  "/mgmt/filestore/default/logtemp/default-log"
		 * @return
		 */
		public String getDefaultLog(){
			requester.setURL("https://"+hostName+":"+ romaPort + RMIVariables.URI_FILESTORE_DEFAULT_LOG);
			String fileContents = base64encoder.decodeBase64(base64encoder.stringToJSON(requester.sendGet().getServerPayload()).getString(RMIVariables.KEY_FILE));
			return fileContents;
		}
		
		/**
		 * Returns the users log. /logtemp/default-log
		 * @return
		 */
		public String getUserLog(){
			requester.setURL(url + filestoreURI + "/logtemp/default-log");
			String fileContents = base64encoder.decodeBase64(base64encoder.stringToJSON(requester.sendGet().getServerPayload()).getString(RMIVariables.KEY_FILE));
			return fileContents;
		}
		
		/**
		 * Returns the specified log
		 * @param pathToLog
		 * @param logName
		 * @return
		 */
		public String getLog(String pathToLog, String logName){
			requester.setURL("https://"+hostName+":"+ romaPort + filestoreURI + "/"  + pathToLog + "/"+ logName);
			RequestBean response = requester.sendGet();
			if(RMIVariables.STATUS_CODE_OK.equals(response.getStatus() + ":" + response.getStatusMessage())){
				String fileContents = base64encoder.decodeBase64(base64encoder.stringToJSON(response.getServerPayload()).getString(RMIVariables.KEY_FILE));
				return fileContents;
			}else{
				return response.getServerPayload();
			}
			
		}
	
		/**
		 * Returns the last line in the log that has a time stamp
		 * @param pathToLog
		 * @param logName
		 * @return
		 */
		public String getLogAnchor(String pathToLog, String logName){
			requester.setURL("https://"+hostName+":"+ romaPort + filestoreURI + "/"  + pathToLog + "/"+ logName);
			String fileContents = base64encoder.decodeBase64(base64encoder.stringToJSON(requester.sendGet().getServerPayload()).getString(RMIVariables.KEY_FILE));
			String[] logArray = fileContents.split("\n");
			
			for(int i=logArray.length-1; i>0;i--){
				if(requester.containsRegEx(logArray[i], DPVariables.REGEX_LOG_TIMESTAMPS_DP)){
					return logArray[i];
				}
			}
			
			return null;
		}
		
		public boolean downloadFile(String pathToFileOnDP, String fileNameOnDP, String pathToSaveFile, String fileNameLocal, String charEncoding) throws IOException{
			RequestBean response = this.getFile(pathToFileOnDP, fileNameOnDP);
			if(response == null || response.getResponseObject() == null || response.getResponseObject().getFile().size() == 0){
				return false;
			}
			
			converter.bytesToFile(response.getResponseObject().getFile().get(0).getValue(), pathToSaveFile + "/" + fileNameLocal, StandardOpenOption.CREATE);	
			return true;
		}

	
	}

///////////////////////////////////////////////////
//             Inner Class
///////////////////////////////////////////////////

	/**
	 * Inner Class to send ROMA get-status request
	 * @author Nick Coble
	 *
	 */
	public class StatusRequest extends DPManagement.StatusRequest{
		
		/**
		 * Method to retrieve DP Status providers
		 * @param String: statusName
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getStatus(String statusName) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + statusURI.replace("{object}", statusName));
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);

		}
		
		/**
		 * Method to retrieve DP Status providers
		 * @param String: statusName
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getStatus(String statusName, String urlParameters) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + statusURI.replace("{object}", statusName)+ "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);

		}
		
		/**
		 * Method to retrieve DP Status providers
		 * @param StatusEnum: statusName
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getStatus(StatusEnum statusName) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + statusURI.replace("{object}", statusName.value()));
			RequestBean bean = requester.sendGet();
			if(!bean.getStatus().equals("-1")){
				return setRequestBeanObjects(bean);
			}else{
				return bean;
			}
			
		}
		
		/**
		 * Method to retrieve DP Status providers
		 * @param StatusEnum: statusName
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getStatus(StatusEnum statusName, String urlParameters) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + statusURI.replace("{object}", statusName.value())+ "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);

		}
		
		/**
		 * Method to retrieve a DP status object
		 * @param GetStatus: status
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getStatus(GetStatus status) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + statusURI.replace("{object}", status.getObjectName()));
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Method to retrieve a DP status object
		 * @param GetStatus: status
 		 * @param String: urlParameters - parameters to append to the URL. IE: view=recursive&depth=5
		 * @return RequestBean
		 * @throws InvocationTargetException 
		 * @throws IllegalArgumentException 
		 * @throws InstantiationException 
		 * @throws IllegalAccessException 
		 * @throws ClassNotFoundException 
		 * @throws SecurityException 
		 * @throws NoSuchMethodException 
		 */
		public RequestBean getStatus(GetStatus status, String urlParameters) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
			requester.setURL(url + statusURI.replace("{object}", status.getObjectName())+ "?" + urlParameters);
			RequestBean bean = requester.sendGet();
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Loads status object properties from a GET request into the provided status object
		 * @param statusObject
		 * @param statusName
		 * @return
		 * @throws IllegalAccessException 
		 * @throws IllegalArgumentException 
		 */
		public RequestBean getStatus(Object statusObject, String statusName) throws IllegalArgumentException, IllegalAccessException{
			requester.setURL(url + statusURI.replace("{object}", payloadBuilder.getClassName(statusObject).substring(6)));
			RequestBean bean = requester.sendGet();
			
			return setRequestBeanObjects(bean);
		}
		
		/**
		 * Method to retrieve a list of DP status providers
		 * @return RequestBean
		 */
		public RequestBean getStatusProviders(){
			requester.setURL(url + RMIVariables.URI_ROOT_STATUS);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}

	}

///////////////////////////////////////////////////
//Inner Class
///////////////////////////////////////////////////		
		
	/**
	 * Inner class to send RMI get-metadata request
	 * @author nickCoble
	 *
	 */
	public class MetadataRequest {
		
		/**
		 * Sends at recursive get metadata requst for the specified object.
		 * Only valid for config objects, this returns the metadata for the specified object as well as an embedded list of 
		 * the metadata for each property and the properties of each property for a max depth of 7.
		 * @param objectName
		 * @return
		 */
		public RequestBean getMetadataObjectRecursive(String objectName, int depth){
			requester.setURL(url + metaURL.replace("{object}", objectName)+"?view=recursive"+"&depth="+depth);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}

		/**
		 * Sends a get-metadata request for the specified object.  Valid objects are action and config objects.
		 * @param objectName
		 * @return
		 */
		public RequestBean getMetadataObject(String objectName){
			requester.setURL(url + metaURL.replace("{object}", objectName));
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
		/**
		 * Gets the metadata for the specified property
		 * @param objectName
		 * @param propertyName
		 * @return
		 */
		public RequestBean getMetadataObject(String objectName, String propertyName){
			requester.setURL(url + metaURL.replace("{object}", objectName)+"/"+propertyName);
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
		
	}
	
///////////////////////////////////////////////////
//Inner Class
///////////////////////////////////////////////////
	
	public class TypeRequest{
		public RequestBean getType(String typeName){
			requester.setURL(url + typeURL.replace("{object}", typeName));
			RequestBean bean = requester.sendGet();
			bean.setResponseAsJSON(base64encoder.stringToJSON(bean.getServerPayload()));
			return bean;
		}
	}

///////////////////////////////////////////////////
//Inner Class
///////////////////////////////////////////////////
	/**
	 * Inner class to handle batch put request to the action queue
	 * @author nickCoble
	 *
	 */
	public class BatchRequest extends DPManagement.BatchRequest{
		ArrayList<String> payloadList = new ArrayList<>();
		
		/**
		 * Adds config object payload to list
		 * @param object
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 */
		public void addObjectToPayloadList(ConfigConfigBase object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			if(object == null){return;}
			String tmp = payloadBuilder.buildObjectRequest(object);
			this.payloadList.add(tmp.substring(1, tmp.length()-1));
		}
		
		/**
		 * Adds config object payload to list
		 * @param objectPayload
		 */
		public void addObjectToPayloadList(String objectPayload){
			if(objectPayload == null || objectPayload.equals("")){return;}
			this.payloadList.add(objectPayload);
		}
		
		/**
		 * Adds a file payload to list
		 * Note: pathToPutFile should include the file name. Example: local:///testfile.txt or local:///subdir/testfile.txt
		 * @param pathToGetFile
		 * @param fileName
		 * @param pathToPutFile
		 * @throws IOException
		 */
		public void addFileToPayloadList(String pathToGetFile, String fileName, String pathToPutFile) throws IOException{
			this.payloadList.add(RMIVariables.PAYLOAD_BATCH_PUT_FILE.replace("{content}", base64EncodeFile(pathToGetFile, fileName)).replace("{path}", pathToPutFile));
		}
		
		/**
		 * Adds a file payload to list that doesn't already exist on the local system.  Just define the contents of the file as a string and pass to fileContents.
		 * Note: pathToPutFile should include the file name. Example: local:///testfile.txt or local:///subdir/testfile.txt
		 * @param pathToGetFile
		 * @param fileName
		 * @param pathToPutFile
		 * @throws IOException
		 */
		public void addFileToPayloadList(String pathToPutFile,String fileContents) throws IOException{
			this.payloadList.add(RMIVariables.PAYLOAD_BATCH_PUT_FILE.replace("{content}", converter.encodeBase64(fileContents)).replace("{path}", pathToPutFile));
		}
		
		/**
		 * Clears all objects in the payload list
		 */
		public void clearPayloadList(){
			this.payloadList.clear();
		}
		
		/**
		 * Builds batch payload from list
		 * @return
		 */
		public String buildPayloadFromList(){
			
			StringBuilder payload = new StringBuilder();
			
			for(int i=0;i< this.payloadList.size();i++){
				if(i>0){payload.append(",");}
				payload.append(this.payloadList.get(i));
			}
			
			return RMIVariables.PAYLOAD_BATCH_PUT.replace("{body}", payload.toString());
			
		}
		
		/**
		 * Sends the batch put request using the payload list.  If list is empty method returns null.
		 * @return
		 */
		public RequestBean sendBatchPut(){
			if(this.payloadList.size()<1){return null;}

			(action).postAction(this.buildPayloadFromList());
			this.payloadList.clear();
			return setRequestBeanObjects(requester.getLastResponse());
//			requester.getLastResponse().setResponseAsJSON(base64encoder.stringToJSON(requester.getLastResponse().getServerPayload()));
//			return requester.getLastResponse();
			 
		}
		
		public RequestBean sendBatchRequestCustom(String payload){
			(action).postAction(payload);
			return setRequestBeanObjects(requester.getLastResponse());
		}

		@Override
		public RequestBean sendBatchRequest() {
			return this.sendBatchPut();
		}

		@Override
		public void addObjectToPayloadList(Object object)throws IllegalArgumentException, IllegalAccessException,	NoSuchFieldException, SecurityException,	InvocationTargetException, NoSuchMethodException {
			if(object == null){return;}
			String tmp = payloadBuilder.buildObjectRequest(object);
			this.payloadList.add(tmp.substring(1, tmp.length()-1));
		}
	}

	

}
