package tools;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import variables.SOMAVariables;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyStatusElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.DmReference;
import xmlManagement.File;
import xmlManagement.LogEntry;
import xmlManagement.Response;
import xmlManagement.Response.Fault;
import xmlManagement.Response.Filestore;
import xmlManagement.Response.Import;
import xmlManagement.Response.Log;
import xmlManagement.Response.Result;

/**
 * Class to generate xmlManagement objects from a SOMA payload.
 * 
 * @author Nick Coble
 *
 */
public class SOMAObjectFactory extends XMLManagementFactory {
	
	final String RESPONSE_TIME_STAMP_FORMAT = "yyyy-MM-dd hh:mm:ssX";

	/**
	 * Method generates a response object set with the object in the payload<br/>
	 * Possible Objects:  Config Object, Status Object, or Fault(Error)
	 * @param somaPayload
	 * @return Response
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	public Response getResponseObject(Document somaPayload) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
		if(somaPayload==null){return null;}
//		somaPayload.normalizeDocument();
		
		if(somaPayload.getElementsByTagName(SOMAVariables.KEY_RESPONSE).getLength()==0){
			return null;
		}
				
		ArrayList<Node> responseNodes = this.getSomaResponseNodes(somaPayload.getElementsByTagName(SOMAVariables.KEY_RESPONSE).item(0));

		Response response= new Response();
		
		//Load response object
		for(Node n: responseNodes){
			String bodyType = 	n.getNodeName();
			switch(bodyType){
				case SOMAVariables.KEY_RESPONSE_FAULT:
					xmlManagement.Response.Fault fault = new Fault();
					String faultCode = n.getChildNodes().item(0).getNodeValue();
					String faultString =n.getChildNodes().item(1).getNodeValue();
					fault.setFaultcode(faultCode);
					fault.setFaultstring(faultString);
					response.setFault(fault);
					break;
				case SOMAVariables.KEY_TIMESTAMP:
					//Load time stamp
					if(!n.getTextContent().isEmpty()){
						try {
							DateFormat dateF =new SimpleDateFormat(RESPONSE_TIME_STAMP_FORMAT);							
							Date date = dateF.parse(n.getTextContent().replace("T", " "));
							GregorianCalendar gcal = new GregorianCalendar();
							gcal.setTime(date);
							@SuppressWarnings("deprecation")
							XMLGregorianCalendar timeStamp = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal.get(Calendar.YEAR), gcal.get(Calendar.MONTH)+1, gcal.get(Calendar.DAY_OF_MONTH), date.getHours(),date.getMinutes(),date.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, TimeZone.SHORT).normalize();
							response.setTimestamp(timeStamp);
						} catch (DOMException | ParseException e) {
							e.printStackTrace();
						} catch (DatatypeConfigurationException e) {
							e.printStackTrace();
						}
					}
					break;
				case SOMAVariables.KEY_RESPONSE_CONFIG:
					if(response.getConfig()== null){
						response.setConfig(new AnyConfigElement());
					}
					
					NodeList configList =  this.getCleanNodeList(n);
					for(int index = 0; index < configList.getLength();index++){
						response.getConfig().getConfigObjects().add(this.loadConfigObject(configList.item(index)));
					}
					break;
				case SOMAVariables.KEY_RESPONSE_STATUS:
					if(response.getStatus()== null){
						response.setStatus(new AnyStatusElement());
					}
					
					NodeList statusList =  this.getCleanNodeList(n);
					for(int index = 0; index < statusList.getLength();index++){
						Object statusObject = this.loadStatusObject(statusList.item(index));
						if(statusObject != null){
							response.getStatus().getStatusObjects().add(statusObject);
						}
					}
					break;
				case SOMAVariables.KEY_RESPONSE_FILE:
					File file = new File();
					file.setName(n.getAttributes().getNamedItem("name").getNodeValue());
					file.setValue(converter.decodeBase64(n.getTextContent()).getBytes());
					response.getFile().add(file);
					break;
				case SOMAVariables.KEY_RESPONSE_RESULT:
					Result value = new Result();
					//if has child check for error log else assume string
					if(n.hasChildNodes() && n.getFirstChild().getNodeName().equals(SOMAVariables.KEY_RESPONSE_ERROR_LOG)){
						
						NodeList n2 = n.getFirstChild().getChildNodes();
						for(int n2Index=0;n2Index<n2.getLength();n2Index++){
							value.getContent().add(n2.item(n2Index).getAttributes().getNamedItem("level").getNodeValue() + " log: " +n2.item(n2Index).getTextContent().trim());
						}
					}else{
						value.getContent().add(n.getTextContent().trim());
					}
					
					response.setResult(value);
					break;
				
				case SOMAVariables.KEY_RESPONSE_LOG_EVENT:
					Response.Log log = new Log();
					LogEntry logEntry = new LogEntry();
					logEntry.getAny().add((Element) n);
					log.getLogEntry().add(logEntry);
					response.setLog(log);
					
					break;
				case SOMAVariables.KEY_RESPONSE_IMPORT:
					Response.Import importResponse = new Import();
					NodeList n3 = n.getChildNodes();
					n3 = n3.item(0).getChildNodes();
					for(int i=0;i<n3.getLength();i++){
						importResponse.getAny().add((Element) n3.item(i));
					}
					response.setImport(importResponse);
					break;
				case SOMAVariables.KEY_RESPONSE_FILESTORE:
					Response.Filestore fileStore = new Filestore();
					this.loadObjectProperties(n, fileStore);
					response.setFilestore(fileStore);
					break;
				default:
					System.out.println("Unexpected response type. Recieved: " + bodyType);
					return null;
				}
		}		
		return response;
	}
	
	
	public ArrayList<Node> getSomaResponseNodes(Node responseNode){
		NodeList nodes = responseNode.getChildNodes();
		ArrayList<Node> returnNodes = new ArrayList<>();
		for(int i=0;i<nodes.getLength();i++){
			if(nodes.item(i).getNodeType() == 1){
				returnNodes.add(nodes.item(i));
			}
		}
		return returnNodes;
	}
	
	public NodeList getCleanNodeList(Node responseNode){
		NodeList nodes = responseNode.getChildNodes();
		for(int i=0;i<nodes.getLength();i++){
			if(nodes.item(i).getNodeType() != 1){
				responseNode.removeChild(nodes.item(i));
			}
		}
		
		return responseNode.getChildNodes();
	}
	
	/**
	 * Loads the payload values into the config object.  Returns null if parameters are invalid.
	 * @param somaPayload: Node, roma get response
	 * @param configObject: Config Object 
	 * @return 
	 */
	public ConfigConfigBase loadConfigObject(Document somaPayload, ConfigConfigBase configObject){
		if(somaPayload==null || configObject==null){return null;}
		
		//Check for empty config node
		if(somaPayload.getElementsByTagName(SOMAVariables.KEY_RESPONSE_CONFIG).getLength()==0 || !somaPayload.getElementsByTagName(SOMAVariables.KEY_RESPONSE_CONFIG).item(0).hasChildNodes()){
			return null;
		}

		//Check for fault key
		String responseType = somaPayload.getChildNodes().item(0).getChildNodes().item(0).getChildNodes().item(0).getNodeName();
		Node responseBody = somaPayload.getChildNodes().item(0).getChildNodes().item(0).getChildNodes().item(0);

		if(responseType.equals(SOMAVariables.KEY_RESPONSE_FAULT)){return null;}

		NodeList itemsInResponse = responseBody.getChildNodes();

		String bodyType = itemsInResponse.item(1).getNodeName();

		switch(bodyType){
			case SOMAVariables.KEY_RESPONSE_CONFIG:
				return (ConfigConfigBase) this.loadObjectProperties(itemsInResponse.item(1).getFirstChild(), configObject);
			default:
				System.out.println("Unexpected response type. Expected: " + SOMAVariables.KEY_RESPONSE_CONFIG + ", Recieved: " + bodyType);
				return null;
		}
	
	}

	
	/**
	 * Returns an AnyConfigElement loaded with the objects defined in the provided parameter
	 * @param configObjectNode
	 * @return
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
 	public ConfigConfigBase loadConfigObject(Node configObjectNode) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{ 	
 		if(configObjectNode==null){return null;}
		
		//Get Configuration object name from node
		String objectName = configObjectNode.getNodeName();
			
		//Use xmlManagement factory to generate configuration object from node name
		Object returnObject = factory.getClass().getMethod("createConfig" + objectName).invoke(factory);
		
		//Call helper method to load object properties
		ConfigConfigBase configObject = (ConfigConfigBase)this.loadObjectProperties(configObjectNode, returnObject);
			
		return configObject;
	}
	
	/**
	 * Sets the properties of the provided Object with the values in the provided Node
	 * @param xmlObject
	 * @param returnObject
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Object loadObjectProperties(Node xmlObject, Object returnObject){
		//Find Object
		try{
			NodeList propList = this.getCleanNodeList(xmlObject);
			
			//Set Attributes
			if(xmlObject.hasAttributes()){
				
				for(int index=0;index<xmlObject.getAttributes().getLength();index++){
					String propName = xmlObject.getAttributes().item(index).getNodeName();
					String propValue = xmlObject.getAttributes().item(index).getNodeValue();					
					this.buildSimpleField(this.getFieldFromAnnotation(returnObject,propName), returnObject, propValue);

				}
			}
			
			//Load Properties
			for(int index=0;index<propList.getLength();index++){
				
				//Get property Name from node
				String propName = propList.item(index).getNodeName();

				//Simple property case
				if(propList.item(index).getChildNodes().getLength() < 2 && propList.item(index).getTextContent() != null ){//propList.item(index).getNodeType() == Node.TEXT_NODE

					//Get property field from object using node name
					Field objectProperty = this.getFieldFromAnnotation(returnObject,propName);
					
					if(objectProperty == null){
						continue;
					}
					//DmReference Case
					else if(objectProperty.getType().getSimpleName().equals(DmReference.class.getSimpleName())){
						 DmReference tmp = new DmReference();
						 tmp.setValue(propList.item(index).getTextContent());
						 if(propList.item(index).getAttributes().getNamedItem("class") != null){
							 tmp.setClazz(propList.item(index).getAttributes().getNamedItem("class").getNodeValue());
						 }
							 
						 
						 objectProperty.setAccessible(true);
						 objectProperty.set(returnObject, tmp);
					}else{
						this.buildSimpleField(objectProperty, returnObject, propList.item(index).getTextContent());
					}
				}
				//Complex property case
				else{
					Field f =this.getFieldFromAnnotation(returnObject, propName);
//					if(f==null){continue;}
					f.setAccessible(true);
					
					//Check if property is a list or object
					if(f.getType().getSimpleName().equals(List.class.getSimpleName())){
						//Get list type and make object
						ParameterizedType stringListType = (ParameterizedType) f.getGenericType();
					    Class<?> stringListClass = (Class<?>) stringListType.getActualTypeArguments()[0];
					    //Generate Object
					    Object complexField = (factory.getClass().getMethod("create"+stringListClass.getSimpleName()).invoke(factory));
			 			//Set Properties
					    this.loadObjectProperties(propList.item(index), complexField);
						//Add to list
					    ((List<Object>)returnObject.getClass().getMethod("get"+ propName).invoke(returnObject)).add(complexField);
					}else{
						//Generate Object
			 			Object complexField = (factory.getClass().getMethod("create"+f.getType().getSimpleName()).invoke(factory));
			 			//Set Properties
			 			this.loadObjectProperties(propList.item(index), complexField);
						//Set object property field to be the generated object
			 			f.set(returnObject, complexField);
					}
					
				}
			}
			
			return returnObject;

		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	/**
	 * Converts a Node from a roma Status payload into a list of Java Objects
	 * @param somaPayload
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public Object loadStatusObject(Node statusNode) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException{
		if(statusNode==null){return null;}
		
		//Get Configuration object name from node
		String objectName = statusNode.getNodeName();

		try{
			//Use xmlManagement factory to generate status object
			Object returnObject = factory.getClass().getMethod("createStatus" + objectName).invoke(factory);
					
			return this.loadObjectProperties(statusNode, returnObject);
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;

	}
	
}
