package tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TerminalClient extends CLIClient{
	final static private String REGEX_END_RESPONSE = ".+[:#>$\\)][ ]{0,1}";
//	final static private String COMMAND_START_WINDOWS_SHELL = "cmd.exe";
//	final static private String COMMAND_START_LINUX_SHELL = "sh";
	
	private Process p=null;
	private String cmdToStartTerminal=null;
	protected InputStream in=null;// =new PipedInputStream(100000);
	protected InputStream error=null;
	protected OutputStream out=null;// = new PipedOutputStream();
	
	public TerminalClient(String cmdToStartTerminal){
			this.cmdToStartTerminal=cmdToStartTerminal;
	}
	
	public boolean sendCommand(String command){
		this.lastCommand = command + "\n";
			try {
				out.write(this.lastCommand.getBytes());
				out.flush();
				return true;
			} catch (IOException e) {
				this.errorMessage = e.getMessage();
				e.printStackTrace();
			}
		
		return false;
	}
	
	public boolean sendCommand(int command){
		this.lastHexCommand = command;
			try {
				out.write(this.lastCommand.getBytes());
				out.flush();
				return true;
			} catch (IOException e) {
				this.errorMessage = e.getMessage();
				e.printStackTrace();
			}
		
		return false;
	}
	
	public String getResponse(int timeOut){
		this.response = "";
//		String tmpHolder="";
		StringBuilder stringBuilder= new StringBuilder();
		long startTime = System.currentTimeMillis();
		boolean startedReading = false;
		try {
			while(true){
//System.out.println(this.in.available());
//System.out.println(this.error.available());

				if((this.in.available()>0)){
					startedReading = true;
					int i=-1;
					while(this.in.available()>0){
						i = in.read();
//System.out.print(i +" = ");
//System.out.println(((char)i));
						if(i<0){
							break;
						}else{
							stringBuilder.append((char)i);
						}
					}

				}else if((this.error.available()>0)){
					startedReading = true;
					int i=-1;
					while(this.error.available()>0){
						i = error.read();
//System.out.print(i +" = ");
//System.out.println(((char)i));
						if(i<0){
							break;
						}else{
							stringBuilder.append((char)i);
						}
					}
				
					
				}else{

					if(startedReading){
//						tmpHolder = stringBuilder.toString();
						if(this.matchesRegEx(stringBuilder.toString(), REGEX_END_RESPONSE, true)){
							break;
						}
					}

					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
				}
				
				
				if((System.currentTimeMillis() - startTime > timeOut)){
					stringBuilder.append("\nERROR: Timed Out("+ timeOut +").\n");
					break;
				}
			
			}
		} catch (IOException e) {
			e.printStackTrace();
			this.errorMessage = e.getMessage();
			stringBuilder.append("\nERROR getting response: " + e.getMessage() + "\n");
		}
		
		this.response = stringBuilder.toString().replace("\r\n", "\n").replace("\r", "");
//System.out.println();
//System.out.println(this.response);
//System.out.println("==================================================================================================");
		return this.response;
	}

	public String getResponse(String command){
		if(this.sendCommand(command)){
			return this.getResponse(5000);
		}else{
			this.errorMessage = "Error Sending Command: " + command;
			return this.errorMessage;
		}
	}

	public boolean startSession(){
		try{
			
			p= Runtime.getRuntime().exec(this.cmdToStartTerminal);
			in = p.getInputStream();
			error=p.getErrorStream();
			out = p.getOutputStream();	
			
			return true;
		}catch(IOException e){
			this.errorMessage = "Error creating process: " + e.getMessage();
			this.endSession();
			return false;
		}
	}
	
	public boolean endSession(){
		if(p!=null){
			p.destroy();
			p = null;
		}
		
		try {
			in.close();
			in = null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			out.close();
			out = null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			error.close();
			error = null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

	public String getLastResponse(){return this.response;}
	public String getLastCommand(){return this.lastCommand;}

	@Override
	public boolean loginDP(String domain) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isConnected() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
