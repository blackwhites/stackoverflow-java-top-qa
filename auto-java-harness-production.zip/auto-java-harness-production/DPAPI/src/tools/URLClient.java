package tools;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;

import beans.RequestBean;

/**
 * Abstract Class to represent common variables and methods used for making HTTP request.
 * Extended by HTTPClient and HTTPSClient
 * @author Nick Coble
 *
 */
public abstract class URLClient extends BaseClient{
	public final static String HTTP_GET = "GET";
	public final static String HTTP_PUT = "PUT";
	public final static String HTTP_POST = "POST";
	public final static String HTTP_DELETE = "DELETE";
	public final static String HTTP_OPTIONS = "OPTIONS";
	public final static String HTTP_HEAD = "HEAD";
	public final static String HEADER_KEY_Accept = "Accept";
	public final static String HEADER_KEY_AcceptCharSet = "Accept-Charset";
	public final static String HEADER_KEY_AcceptEncoding = "Accept-Encoding";
	public final static String HEADER_KEY_AcceptLang = "Accept-Language";
	public final static String HEADER_KEY_Authorization = "Authorization";
	public final static String HEADER_KEY_CacheControl = "Cache-Control";
	public final static String HEADER_KEY_Connection = "Connection";
	public final static String HEADER_KEY_Cookie = "Cookie";
	public final static String HEADER_KEY_ContentLength = "Content-Length";
	public final static String HEADER_KEY_ContentType = "Content-Type";
	public final static String HEADER_KEY_Host = "Host";
	public final static String HEADER_KEY_UserAgent = "User-Agent";
	public final static String HEADER_KEY_Proxy_Via = "Via";
	public final static String HEADER_VALUE_UserAgent_Modzilla = "Modzilla/5.0";
	public final static String HEADER_VALUE_UserAgent_Java = "Java/1.6.0_26";
	public final static String HEADER_VALUE_Connection_Close = "Close";
	public final static String HEADER_VALUE_ContentType_JSON = "application/json";
	public final static String HEADER_VALUE_ContentType_XML = "application/xml";
	public final static String HEADER_VALUE_ContentType_PLAIN = "text/plain";
	public final static String HEADER_VALUE_Connection_KeepAlive = "Keep-Alive";
	public final static String HEADER_VALUE_AcceptedLang_Japanese = "ja";
	public final static String HEADER_VALUE_AcceptedLang_Russian = "ru";
	public final static String HEADER_VALUE_AcceptedLang_English = "en";
	public final static String HEADER_VALUE_AcceptedLang_French = "fr";
	public final static String HEADER_VALUE_AcceptedLang_Spanish = "es";
	public final static String HEADER_VALUE_AcceptedLang_Italian = "it";
	public final static String HEADER_VALUE_AcceptedLang_Chinese = "zh";
	public final static String HEADER_VALUE_AcceptedLang_German = "de";
	
	public final static String STATUS_CODE_NUMBER_OK = "200";
	public final static String STATUS_CODE_NUMBER_CREATED = "201";
	public final static String STATUS_CODE_NUMBER_ACCEPTED = "202";
	public final static String STATUS_CODE_NUMBER_NO_CONTENT = "204";
	public final static String STATUS_CODE_NUMBER_BADREQUEST = "400";
	public final static String STATUS_CODE_NUMBER_UNAUTH = "401";
	public final static String STATUS_CODE_NUMBER_FORBIDDEN = "403";
	public final static String STATUS_CODE_NUMBER_NOT_FOUND = "404";
	public final static String STATUS_CODE_NUMBER_METHOD_NOT_ALLOWED = "405";
	public final static String STATUS_CODE_NUMBER_CONFLICT = "409";
	public final static String STATUS_CODE_NUMBER_TOO_MANY_REQUEST = "429";
	public final static String STATUS_CODE_NUMBER_INTERNAL_ERROR = "500";
	public final static String STATUS_CODE_NUMBER_NOT_IMPLEMENTED = "501";
	public final static String STATUS_CODE_MESSAGE_OK = "OK";
	public final static String STATUS_CODE_MESSAGE_CREATED = "Created";
	public final static String STATUS_CODE_MESSAGE_ACCEPTED = "Accepted";
	public final static String STATUS_CODE_MESSAGE_BADREQUEST = "Bad Request";
	public final static String STATUS_CODE_MESSAGE_UNAUTH = "Unauthorized";
	public final static String STATUS_CODE_MESSAGE_FORBIDDEN = "Forbidden";
	public final static String STATUS_CODE_MESSAGE_NOT_FOUND = "Not Found";
	public final static String STATUS_CODE_MESSAGE_METHOD_NOT_ALLOWED = "Method Not Allowed";
	public final static String STATUS_CODE_MESSAGE_CONFLICT = "conflict";
	public final static String STATUS_CODE_MESSAGE_INTERNAL_ERROR = "Internal Server Error";
	public final static String STATUS_CODE_MESSAGE_NOT_IMPLEMENTED = "Not Implemented";
	public final static String STATUS_CODE_MESSAGE_TOO_MANY_REQUEST = "Too Many Requests";
	public final static String STATUS_CODE_MESSAGE_NO_CONTENT = "No Content";

	public final static String STATUS_CODE_EXCEPTION = "-2";
	protected final static String HTTP_LINE_FEED = "\r\n";
	
	protected String url;
	protected String uri;
	public final Converter encoder = new Converter();
	protected boolean useCached = false;
	protected boolean keepAlive = false;
	protected boolean followRedirect = false;
	protected ArrayList<String> headers = new ArrayList<>();
	protected HashMap<String, String> uriParameters = new HashMap<>();
	protected int connectionTimeOut = 120000; //0 means no time out, default is 2  minutes
	protected int readTimeOut = 20000;//0 means no time out	
	protected int bufferSize = 10000;
	protected RequestBean lastResponse = null;
	
	public boolean keepOpen = true;
	protected boolean connected = false;
//	BufferedReader in = null;
	OutputStream out = null;
	InputStream in = null;
	
	public URLClient(){
		System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
	}
	
	public boolean isConnected() {
		return connected;
	}
	
//	public abstract void closeConnection();

	public void addURIParameter(String key, String value){
		this.uriParameters.put(key, value);
	}
	
	public void removeURIParameter(String key){
		this.uriParameters.remove(key);
	}

	public void clearURIParameters(){
		this.uriParameters.clear();
	}
	
	public String buildURLParametersString(){
		String tmp = "";
		if(!this.uriParameters.isEmpty()){
			tmp += "?";
			int i=0;
			for(String key: this.uriParameters.keySet()){
				if(i>0){tmp += "&";}
				try {
					tmp += URLEncoder.encode(key,"UTF-8") + "=" + URLEncoder.encode(this.uriParameters.get(key), StandardCharsets.UTF_8.name());
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				i++;
			}
		}
		
		return tmp;
	}
	
	public boolean lastResponseContains(String expectedRegEx, boolean dotAll){
		if(expectedRegEx == null || this.getLastResponse()==null|| this.getLastResponse().getServerPayload() == null){return false;}
		return this.containsRegEx(this.getLastResponse().getServerPayload(), expectedRegEx, dotAll);
	}
	
	public boolean lastResponseMatches(String expectedRegEx, boolean dotAll){
		if(expectedRegEx == null || this.getLastResponse()==null|| this.getLastResponse().getServerPayload() == null){return false;}
		return this.matchesRegEx(this.getLastResponse().getServerPayload(), expectedRegEx, dotAll);
	}
	
	public String lastResponseGetRegEx(String regEx, boolean dotAll){
		if(regEx == null || this.getLastResponse()==null|| this.getLastResponse().getServerPayload() == null){return null;}
		return this.getRegEx(this.getLastResponse().getServerPayload(), regEx, dotAll);
	}
	
	public ArrayList<String> lastResponseGetGroups(String regEx, boolean dotAll){
		if(regEx == null || this.getLastResponse()==null || this.getLastResponse().getServerPayload() == null){return null;}
		return this.getGroups(this.lastResponse.getServerPayload(), regEx, dotAll);
	}

	public int lastResponseCountRegEx(String regEx, boolean dotAll){
		if(regEx == null || this.getLastResponse()==null || this.getLastResponse().getServerPayload() == null){return -1;}
		return this.count(this.lastResponse.getServerPayload(), regEx, dotAll);
	}
	
	public String lastResponseSubStringFromRegExIndex(String regEx, int index, boolean dotAll){
		if(regEx == null || this.getLastResponse()==null || this.getLastResponse().getServerPayload() == null){return null;}
		return this.subStringFromRegExAt(this.lastResponse.getServerPayload(), regEx, index, dotAll);
	}
	
	/**
	 * @return the lastResponse
	 */
	public RequestBean getLastResponse() {
		return lastResponse;
	}

	public int getBufferSize() {
		return bufferSize;
	}

	public void setBufferSize(int bufferSize) {
		this.bufferSize = bufferSize;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {return url;}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {this.url = url;}

	public void setURI(String uri){this.uri=uri;}
	
	public String getURI(){return this.uri;}
	/**
	 * @return the encoder
	 */
	public Converter getEncoder() {return encoder;}

	/**
	 * @return the useCached
	 */
	public boolean isUseCached() {return useCached;}

	/**
	 * @param useCached the useCached to set
	 */
	public void setUseCached(boolean useCached) {
		this.useCached = useCached;
	}

	/**
	 * @return the keepAlive
	 */
	public boolean isKeepAlive() {return keepAlive;}

	/**
	 * @param keepAlive the keepAlive to set
	 */
	public void setKeepAlive(boolean keepAlive) {
		this.keepAlive = keepAlive;
		if(!System.getProperty("http.keepAlive").equals(String.valueOf(this.keepAlive))){
			System.setProperty("http.keepAlive",String.valueOf(this.keepAlive));
		}
	}

	/**
	 * @return the followRedirect
	 */
	public boolean isFollowRedirect() {
		return followRedirect;
	}

	/**
	 * @param followRedirect the followRedirect to set
	 */
	public void setFollowRedirect(boolean followRedirect) {
		this.followRedirect = followRedirect;
	}

	/**
	 * @return the connectionTimeOut
	 */
	public int getConnectionTimeOut() {
		return connectionTimeOut;
	}

	/**
	 * @param connectionTimeOut the connectionTimeOut to set
	 */
	public void setConnectionTimeOut(int connectionTimeOut) {
		this.connectionTimeOut = connectionTimeOut;
	}

	/**
	 * @return the readTimeOut
	 */
	public int getReadTimeOut() {
		return readTimeOut;
	}

	/**
	 * @param readTimeOut the readTimeOut to set
	 */
	public void setReadTimeOut(int readTimeOut) {
		this.readTimeOut = readTimeOut;
	}



	//methods to be implemented by inheriting class
	public abstract RequestBean sendRequest(String httpMethod, String payload);


	protected byte[] sendRequest(HttpURLConnection connection, String httpMethod, byte[] payload) throws IOException{

		//Create Connection
		System.setProperty("http.keepAlive",String.valueOf(this.keepAlive));
		
		//Set connection properties
		connection.setConnectTimeout(this.connectionTimeOut);			
		connection.setReadTimeout(this.readTimeOut);
		connection.setInstanceFollowRedirects(this.followRedirect);
		connection.setUseCaches(this.useCached);
		connection.setDoInput(true);
		connection.setDoOutput((payload != null));
		connection.setRequestMethod(httpMethod);
		
		
		//Set headers
		for(int i=0;i<this.headers.size();i++){
			String key = this.headers.get(i).substring(0,this.headers.get(i).indexOf(":"));
			String value = this.headers.get(i).substring(this.headers.get(i).indexOf(":") +1);
			connection.setRequestProperty(key, value);
		}
		
		//Connect to server
		connection.connect();
		connected = true;

		//Send request pay load to server
		if(payload != null){
			out = connection.getOutputStream();
			out.write(payload);
			out.flush();
		}

//		//Get Response Stream
//		if(connection.getResponseCode()<400){
//			in = new BufferedReader(new InputStreamReader(connection.getInputStream()), this.bufferSize);
//		}else{
//			in = new BufferedReader(new InputStreamReader(connection.getErrorStream()), this.bufferSize);
//		}
		
		//Get Response Stream
		if(connection.getResponseCode()<400){
			in = ((connection.getInputStream()));
		}else{
			in = ((connection.getErrorStream()));
		}
		
		//Get server response body
		byte[] serverResponse = new byte[0];
		int tmp=0;
		byte[] sr = new byte[bufferSize];
		while((tmp = in.read(sr)) > -1){
			if(tmp>0){
				serverResponse = addBytes(serverResponse, sr, tmp);
			}
		}
		
		return serverResponse;
		
	}
	
	private byte[] addBytes(byte[] finalArray, byte[] tmp, int numberOfBytes){
		byte[] c = new byte[finalArray.length + numberOfBytes];
		for(int i=0;i<finalArray.length;i++){
			c[i] = finalArray[i];
		}
		
		for(int i=0;i<numberOfBytes;i++){
			c[i + finalArray.length] = tmp[i];
		}
		
		return c;

	}
	
//	private byte[] addByte(byte[] b, byte a){
//		byte[] c = new byte[b.length + 1];
//		ByteBuffer byteBuffer = ByteBuffer.allocate(b.length + 4);
//		byteBuffer.put(b);
//		IntBuffer intBuffer = byteBuffer.asIntBuffer();
//		intBuffer.put(a);
//		return byteBuffer.array();
//		
//		for(int i=0;i<b.length;i++){
//			c[i]=b[i];
//		}
//		
//		c[b.length] = a;
//		
//		return c;
//	}
//	
//	private int[] addInt(int[] b, int a){
////		IntBuffer intBuffer = ;
////		intBuffer.put(a);
//		return IntBuffer.allocate(b.length + 1).put(a).array();
//
//	}
	
	/**
	 * Method to send multipart/form-data.  
	 * @param formEntries: key = form data key, object = String or File 
	 * @param charSet
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	public abstract RequestBean sendMultipartFormData(HashMap<String, Object> formEntries,Charset charSet) throws UnsupportedEncodingException, IOException;
	public byte[] buildFormPayload(HashMap<String, Object> formEntries, Charset charSet) throws UnsupportedEncodingException, IOException{
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		
		//Add Content type header
		String boundary = "----WebKitFormBoundaryBbXCJsx8dA95"+ System.currentTimeMillis()%10000;
		this.addHeader(URLClient.HEADER_KEY_ContentType, "multipart/form-data; boundary=" + boundary);
		boundary = "--" + boundary;
		
		charSet.name();

		for(String key: formEntries.keySet()){
			if(formEntries.get(key) instanceof String){
				byteStream.write((boundary + HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write(("Content-Disposition: form-data; name=\"" + key + "\"" + HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write(("Content-Type: text/plain; charset=" + charSet.name() + "\"" + HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write((HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write(((String)(formEntries.get(key))).getBytes(charSet.name()));
				byteStream.write((HTTP_LINE_FEED).getBytes(charSet.name()));
			}else if(formEntries.get(key) instanceof File){
				
				byteStream.write((boundary + HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write(("Content-Disposition: form-data; name=\"" + key + "\"; filename=\""+ ((File)formEntries.get(key)).getName() + "\"" + HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write(("Content-Type: application/octet-stream" + HTTP_LINE_FEED).getBytes(charSet.name()));
				byteStream.write((HTTP_LINE_FEED).getBytes(charSet.name()));
			
				//Add file
				FileInputStream inputStream = null;
				boolean exceptionThrown = false;
				try{
					inputStream = new FileInputStream((File)formEntries.get(key));
			        int bytesRead = -1;
			        while((bytesRead = inputStream.read())!=-1){
			        	byteStream.write(bytesRead);
			        }
				}catch(Exception e){
					e.printStackTrace();
					exceptionThrown = true;
			    }finally{
			    	if(inputStream != null){
				    	try {
							inputStream.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
			    	}
			    	
			    	if(exceptionThrown){
			    		byteStream.close();
			    		return null;
			    	}
			    }

				byteStream.write(HTTP_LINE_FEED.getBytes(charSet.name()));
				
			}else{
				byteStream.close();
				return null;
			}

		}
		

		byteStream.write((boundary+ "--").getBytes(charSet.name()));
		byteStream.write(HTTP_LINE_FEED.getBytes(charSet.name()));
		byteStream.write(HTTP_LINE_FEED.getBytes(charSet.name()));

		byte[] payload = byteStream.toByteArray();
		byteStream.close();
		return payload;
	}
	

	
	//Shared methods
	public RequestBean sendGet(){return this.sendRequest(HTTP_GET, null);}
	public RequestBean sendPut(String payload){return this.sendRequest(HTTP_PUT, payload);}
	public RequestBean sendPost(String payload){return this.sendRequest(HTTP_POST, payload);}
	public RequestBean sendDelete(){return this.sendRequest(HTTP_DELETE, null);}
	public RequestBean sendOption(){return this.sendRequest(HTTP_OPTIONS, null);}
	public String getURL(){

		return this.url;
	}
	public void setURL(String url){this.url=url;}
	
	public RequestBean sendPostFromFile(String path, String fileName) throws IOException{
		
		
		return this.sendPost(this.readFile(path, fileName));
	}
	
	public RequestBean sendPutFromFile(String path, String fileName) throws IOException{
		return this.sendPut(this.readFile(path, fileName));
	}

	public void closeConnection(){

		//Close streams
		try{
			if(in!=null){in.close();}
		}catch (Exception e){
			System.out.println("Closing Input BufferStream Error.");
			e.printStackTrace();
		}	

		try{
			if(out!=null){out.close();}
		}catch (Exception e){
			System.out.println("Closing OutputStream Error.");
			e.printStackTrace();
		}
		
		connected=false;

	}
	
	/**
	 * Adds base64 encoded Basic Authentication header to client
	 * @param userName:String
	 * @param pw:String
	 */
	public void addBasicAuthenticationHeader(String userName, String pw){this.addHeader(HEADER_KEY_Authorization, "Basic " +encoder.encodeBase64(userName + ":"+ pw));}
	
	/**
	 * Adds Content Type Header to the client
	 * @param contentType
	 */
	public void addContentTypeHeader(String contentType){this.addHeader(HEADER_KEY_ContentType, contentType);}
	
	/**
	 * Adds User Agent Header to the client
	 * @param userAgent
	 */
	public void addUserAgentHeader(String userAgent){this.addHeader(HEADER_KEY_UserAgent, userAgent);}
	
	/**
	 * Adds Connection header to the client
	 * @param connectionType
	 */
	public void addConnectionHeader(String connectionType){this.addHeader(HEADER_KEY_Connection, connectionType);}
	
	/**
	 * Adds a header to the client.  
	 * @param key:String
	 * @param value:String
	 */
	public void addHeader(String key, String value){this.headers.add(key + ":" + value);}
	
	/**
	 * Adds a header to the requester
	 * parameter should be in the form headerKey:headerValue. ie: Connection:Close
	 * @param header:String
	 */
	public void addHeader(String header){
		this.headers.add(header);
	}
	
	/**
	 * Returns an array of headers that the client will use when sending request
	 * @return ArrayList<String>
	 */
	public ArrayList<String> getHeaders() {return headers;}

	/**
	 * Sets the headers array the client will use when sending request.
	 * Each index should contain a key:value pair. IE:  Content-Type: text/xml
	 * @param ArrayList<String>:headers
	 */
	public void setHeaders(ArrayList<String> headers) {this.headers = headers;}
}
