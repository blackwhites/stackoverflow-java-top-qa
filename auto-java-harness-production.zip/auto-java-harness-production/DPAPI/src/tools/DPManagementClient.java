package tools;


/**
 * Java object able to manage a DP appliance through the ROMA, SOMA, Telnet, and SSH interfaces.  
 * <br/>Before using the clients the user must use the init methods or initialize the clients manually.  
 * <br/>IE: {@link  #initROMA(int) initROMA}
 * <br/><br/>Also contains HTTP and HTTPS clients.
 * 
 * <br/><br/>Extends the abstract class {@link CLIClient}
 * 
 * @author Nick Coble
 */
public class DPManagementClient extends BaseClient {
	public RMIClient roma = null;
	public SOMAClient soma = null;
	public SSHClient ssh = null;
	public TelnetClient telnet = null;
	public HTTPClient http = new HTTPClient();
	public HTTPSClient https = new HTTPSClient();
	
	public DPManagementClient(String ip, String userName, String password, String domain){
		this.userName = userName;
		this.password = password;
		this.hostName = ip;
		this.domain = domain;
	}
	
	/**
	 * Method to initialize the SOMA client 
	 * @param port
	 * @return
	 */
	public boolean initROMA(int port){
		try{
			this.roma = new RMIClient( hostName, port, userName, password, domain);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	/**
	 * Method to initialize the SOMA client 
	 * @param port
	 * @return
	 */
	public boolean initSOMA(int port){
		try{
			this.soma = new SOMAClient(hostName, port, userName, password, domain);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	/**
	 * Method to initialize the SSH client 
	 * @param port
	 * @return
	 */
	public boolean initSSH(int port){
		try{
			this.ssh = new SSHClient(hostName, port,userName,password);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	/**
	 * Method to initialize the Telnet client 
	 * @param port
	 * @return
	 */
	public boolean initTelnet(int port){
		try{
			this.telnet = new TelnetClient(hostName, port,userName,password);
			return true;
		}catch(Exception e){
			return false;
		}
	}

	
	

}
