package tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import task.ProcessTask;
import task.TaskResult;


/**
 * Object to launch a local process such as curl request or SoapUI test
 * @author Nick Coble
 *
 */
public class TaskLauncher extends BaseClient{
	private Process p=null;
	private InputStream in=null;
	private InputStream error=null;
	private OutputStream out=null;
	private String stdOut ="";
	private String errOut ="";
	private String errorMessage="";
	private String exitStatus="";

	private void getResponse(int timeOut){
		StringBuilder stringBuilder = new StringBuilder();
		StringBuilder errorStream = new StringBuilder();
		long startTime = System.currentTimeMillis();
		boolean startedReading = false;
		boolean doubleCheck = false;
		try {
			while(true){
//System.out.println(this.in.available());
//System.out.println(this.error.available());

				if((this.in.available()>0)){
					startedReading = true;
					doubleCheck = false;
					int i=-1;
					while(this.in.available()>0){
						i = in.read();
//System.out.print(i +" = ");
//System.out.println(((char)i));
						if(i<0){
							break;
						}else{
							stringBuilder.append((char)i);
						}
					}

				}else if((this.error.available()>0)){
					startedReading = true;
					int i=-1;
					while(this.error.available()>0){
						i = error.read();
//System.out.print(i +" = ");
//System.out.println(((char)i));
						if(i<0){
							break;
						}else{
							errorStream.append((char)i);
						}
					}
					
				}else{
					if(startedReading && doubleCheck){break;}else if(!doubleCheck){doubleCheck = true;}
				}
				
				
				if((System.currentTimeMillis() - startTime > timeOut)){
					stringBuilder.append("\nERROR: Timed Out("+ timeOut +").\n");
					break;
				}
			
			}
		} catch (IOException e) {
			e.printStackTrace();
			this.errorMessage = e.getMessage();
			stringBuilder.append("\nERROR getting response: " + e.getMessage() + "\n");
		}
		
		this.errOut = errorStream.toString();
		this.stdOut = stringBuilder.toString();
	}
	
	public TaskResult launchProcess( ArrayList<String> task, int timeOutMilli){
		
		try{
//			List<String> command = new ArrayList<>();
			ProcessBuilder pb = new ProcessBuilder(task);
			System.out.println(pb.environment().toString());
//			pb.redirectErrorStream(true);
//			p= Runtime.getRuntime().exec(task);
			p=pb.start();
			
			in = p.getInputStream();
			error=p.getErrorStream();
			out = p.getOutputStream();	
			
			try {

				//				p.waitFor();
				p.waitFor(timeOutMilli, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			this.getResponse(timeOutMilli);

			this.exitStatus=String.valueOf(p.exitValue());

			return new TaskResult(this.stdOut, this.errOut, p.exitValue(), task.toString());
		}catch(IOException e){
			this.errorMessage = "Error creating process returning null: " + e.getMessage();
			System.out.println(this.errorMessage);
			e.printStackTrace();
			return null;
		}finally{
			this.endSession();
		}
	}

	public TaskResult launchProcess(ProcessTask task, int timeOutMilli){
		try{
			if(!task.validateCommand()){
				this.errorMessage = "ERROR: ProcessTask command not valid.  Command: " + task.buildCommand();
				return null;
			}
//			ProcessBuilder pb = new ProcessBuilder(task.getCommands());
//			System.out.println(pb.environment().toString());
//			pb.redirectErrorStream(true);
			p= Runtime.getRuntime().exec(task.buildCommand());
//			p=pb.start();
			in = p.getInputStream();
			error=p.getErrorStream();
			out = p.getOutputStream();	
			
			try {

				//				p.waitFor();
				p.waitFor(timeOutMilli, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			this.getResponse(timeOutMilli);
			this.exitStatus=String.valueOf(p.exitValue());
			return new TaskResult(this.stdOut, this.errOut, p.exitValue(), task.buildCommand());
		}catch(IOException e){
			this.errorMessage = "Error creating process returning null: " + e.getMessage();
			System.out.println(this.errorMessage);
			e.printStackTrace();
			return null;
		}finally{
			this.endSession();
		}
	}
	private boolean endSession(){
		if(p!=null){
			p.destroy();
			p = null;
		}
		
		if(in != null){
			try {
				in.close();
				in = null;
		
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(out != null){
			try {
				out.close();
				out = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		if(error != null){
			try {
				error.close();
				error = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
	public String getExitStatus(){return exitStatus;}
	public String getErrorMessage(){return errorMessage;}
}
