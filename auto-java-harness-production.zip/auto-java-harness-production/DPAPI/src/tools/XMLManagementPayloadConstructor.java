package tools;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

import xmlManagement.AnyActionElement;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyDeleteElement;
import xmlManagement.AnyModifyElement;

public abstract class XMLManagementPayloadConstructor {
	
	public final static String DMREFERENCE_VALUE_METHOD = "getValue";
	public final static String DMREFERENCE_VALUE_FIELD = "value";
	public final static String ENUM_VALUE_METHOD = "value";
	
	/**
	 * @param o
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	protected Object getAvaiableObject(Object o) throws IllegalArgumentException, IllegalAccessException  {
		for(Field q: o.getClass().getDeclaredFields()){
			q.setAccessible(true);
			if(q.get(o)==null){
				continue;
			}else{
				return q.get(o);
			}
		}
		return null;
	}
	
	
	/**
	 * @param o
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	protected ArrayList<Object> getAvaiableObjects(Object o) throws IllegalArgumentException, IllegalAccessException  {
		ArrayList<Object> ol = new ArrayList<>();
		for(Field q: o.getClass().getDeclaredFields()){
			q.setAccessible(true);
			if(q.get(o)==null){
				continue;
			}else{
				ol.add(q.get(o));
			}
		}
		if(ol.size()==0){
			return null;
		}else{
			return ol;
		}
	}
	
	
	public String getClassName(Object a) throws IllegalArgumentException, IllegalAccessException{
		return a.getClass().getAnnotation(XmlType.class).name();
    }
	
	
	protected boolean isSimpleType(Field field, Object o) throws IllegalArgumentException, IllegalAccessException{
		return field.getType().isPrimitive() || (field.get(o) instanceof String) || field.getType().isEnum() || field.get(o).getClass().equals(Boolean.class) || field.get(o).getClass().equals(Long.class) || field.get(o).getClass().equals(Integer.class);
	}

	protected String getObjectKeyName(Object o){
		String objectName="";
		if(o.getClass().getAnnotation(XmlType.class) != null && !o.getClass().getAnnotation(XmlType.class).name().isEmpty()){
			objectName = o.getClass().getAnnotation(XmlType.class).name();
			if(!objectName.matches("(Action|Config|Status|Modify|Dm|dm).+")){
				return objectName;
			}
		}else{
			objectName = o.getClass().getSimpleName();
		}
			
			
		if(objectName.length()<7){
			return objectName;
		}
//System.out.println("Here: " + objectName);
		switch(objectName.substring(0, 6)){
			default:
				return o.getClass().getSimpleName();
			case "Config":
				return o.getClass().getSimpleName().substring(6);
			case "Action":
				return o.getClass().getSimpleName().substring(6);
			case "Status":
				return o.getClass().getSimpleName().substring(6);
			case "Modify":
				return o.getClass().getSimpleName().substring(6);
		
		}
	}
	
	
	
	protected List<Field> getAllFields(Class<?> superClass){
		List<Field> fields = new ArrayList<Field>();
//System.out.println("Getting Fields for " + superClass.getSimpleName());
        for (Class<?> c = superClass; c != null ; c = c.getSuperclass()) {
            fields.addAll(0,Arrays.asList(c.getDeclaredFields()));
        }
      
        try{
      
        //Check for jacoco fields when running code coverage
        for(int i=0; i<fields.size();i++){
        	if(fields.get(i).getName().startsWith("$")){
        		fields.remove(i);
        		i--;
        	}
        }
        }catch(Exception e){
        	e.printStackTrace();
        }
//System.out.println("Done with " + superClass.getSimpleName());
//System.out.println("After :" + fields.toString());
        
        return fields;
	}
	
	
	/**
	 * Method to get class name from first object in list.
	 * @param c:AnyConfigElement - 
	 * @return String
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws Exception
	 */
	public String getClassName(AnyConfigElement c) throws IllegalArgumentException, IllegalAccessException  {
		if(c==null){return null;}
		return this.getClassName((Object)c.getConfigObjects().get(0));
	}
	
	public String getClassName(AnyActionElement a) throws IllegalArgumentException, IllegalAccessException {
		if(a==null){return null;}
		return this.getClassName((Object)a.getActionObjects().get(0));
	}
	
	public String getObjectName(AnyConfigElement c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		if(c==null){return null;}
		return this.getObjectName(c.getConfigObjects().get(0));
	}
	
	public String getObjectName(AnyModifyElement c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		if(c==null){return null;}
		return this.getObjectName(c.getConfigObjects().get(0));
	}
	
	public String getObjectName(AnyDeleteElement c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		if(c==null){return null;}
		return this.getObjectName(c.getConfigObjects().get(0));
	}
		
	public String getObjectName(Object c) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
		if(c==null){return null;}
		Field f = c.getClass().getDeclaredField("name");
		f.setAccessible(true);
		
		if(f.get(c)==null){
			return null;
		}
		return f.get(c).toString();
	}
	
	public String getElementName(Field field){
		if(field.getAnnotation(XmlElement.class) != null){
			return field.getAnnotation(XmlElement.class).name();
		}else if(field.getAnnotation(XmlAttribute.class) != null){
			return field.getAnnotation(XmlAttribute.class).name();
		}else if(field.getAnnotation(XmlValue.class)!=null){
			return null;
		}else{
			return null;
		}
	}
	
}
