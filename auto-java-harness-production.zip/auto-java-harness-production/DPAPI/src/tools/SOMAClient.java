package tools;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPException;

import org.w3c.dom.Document;

import beans.RequestBean;
import variables.DPVariables;
import variables.SOMAVariables;
import xmlManagement.ActionDeleteFile;
import xmlManagement.ConfigConfigBase;
import xmlManagement.FilestoreLocation;
import xmlManagement.Request;
import xmlManagement.Request.B2BQueryMetadata;
import xmlManagement.Request.DoBackup;
import xmlManagement.Request.DoDeployPattern;
import xmlManagement.Request.DoExport;
import xmlManagement.Request.DoImport;
import xmlManagement.Request.DoRestore;
import xmlManagement.Request.GetAsyncResult;
import xmlManagement.Request.GetConformanceReport;
import xmlManagement.Request.GetDiff;
import xmlManagement.Request.GetFilestore;
import xmlManagement.Request.GetSamlart;
import xmlManagement.Request.GetStatus;
import xmlManagement.Response;
import xmlManagement.StatusEnum;

/**
 * Object to handle SOMA request.  Each request returns a {@link RequestBean} which contains a {@link Response} object.
 * The {@link RequestBean} error properties will be set if there was a problem converting the servers response payload into
 * a {@link xmlManagement.Response} object.  The client will also set the ResponseAsXML property of the RequestBean.  
 * The SOMA URI is initialized to  /system/current but can be set by the user.
 * 
 * @author Nick Coble
 *
 */
public class SOMAClient extends DPManagement{
	//Objects needed to make request
	private final HTTPSClient httpsClient = new HTTPSClient();
	public SOMAPayloadConstructor payloadBuilder = new SOMAPayloadConstructor();
	public SOMAObjectFactory factory = new SOMAObjectFactory();//TODO
	public ConfigRequest configRequest = new ConfigRequest();
	public ActionRequest action = new ActionRequest();//Object to send action request
	public FileStoreRequest filestore = new FileStoreRequest();//Object to send filestore request
	public StatusRequest status = new StatusRequest();//Object to hanlde status request
	public BatchRequest batchRequest = new BatchRequest();
	private RequestBean lastResponse = null;
	
	
	
	//Request variables
	public String uri = SOMAVariables.SOMA_URI_Current;
	
	public SOMAClient(String hostname, String somaPort, String userName, String password, String domain){	
		super(hostname, Integer.valueOf(somaPort), userName, password, domain);
		super.configRequest = this.configRequest;
		super.action = this.action;
		super.filestore = this.filestore;
		super.status = this.status;
		super.batchRequest=this.batchRequest;
		this.initializeURL();
		this.initializeHeaders();
	}
	
	public SOMAClient( String hostname, int somaPort, String userName, String password, String domain){
		super(hostname, somaPort, userName, password, domain);	
		super.configRequest = this.configRequest;
		super.action = this.action;
		super.filestore = this.filestore;
		super.status = this.status;
		this.initializeURL();
		this.initializeHeaders();
	}
	
	public void initializeURL(){this.httpsClient.setURL("https://" + this.hostName + ":" + this.port + this.uri);}
	
	public void initializeHeaders(){
		this.httpsClient.getHeaders().clear();
		this.httpsClient.addBasicAuthenticationHeader(this.userName, this.password);
		this.httpsClient.addHeader(URLClient.HEADER_KEY_Connection, URLClient.HEADER_VALUE_Connection_Close);
		this.httpsClient.addUserAgentHeader(URLClient.HEADER_VALUE_UserAgent_Java);
	}
	
	
	public void setURIToCurrent(){this.uri = SOMAVariables.SOMA_URI_Current;}
	
	public void setURITo2004(){this.uri = SOMAVariables.SOMA_URI_Default;}
	
	public void setURIToEmpty(){this.uri = "";}
	
	/**
	 * Sets the time limit to get a response to a request
	 * @param timeOutMilli
	 */
	public void setReadTimeOut(int timeOutMilli){
		this.httpsClient.setReadTimeOut(timeOutMilli);
	}
	

	/**
	 * Sets max time for a connection
	 * @param timeOutMilli
	 */
	public void setConnectionTimeout(int timeOutMilli){
		this.httpsClient.setConnectionTimeOut(timeOutMilli);
	}
	
	
	public RequestBean getLastResponse(){return this.lastResponse;}

	public String getUri() {return uri;}

	public void setUri(String uri) {this.uri = uri;}

	/**
	 * Returns true if the regEx is found in the last server response
	 * @param expectedRegEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	public boolean lastResponseContains(String expectedRegEx, boolean dotAll){
		return this.httpsClient.lastResponseContains(expectedRegEx, dotAll);
	}
	
	/**
	 * Returns true if the last server response matches the provided regex
	 * @param expectedRegEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	public boolean lastResponseMatches(String expectedRegEx, boolean dotAll){
		return this.httpsClient.lastResponseMatches(expectedRegEx, dotAll);
	}
	
	/**
	 * Returns the first regEx found in the last server response
	 * @param regEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	public String lastResponseGetRegEx(String regEx, boolean dotAll){
		return this.httpsClient.lastResponseGetRegEx(regEx, dotAll);
	}
	
	/**
	 * Returns all the regEx's found in the last server response
	 * @param regEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	public ArrayList<String> lastResponseGetGroups(String regEx, boolean dotAll){
		return this.httpsClient.lastResponseGetGroups(regEx, dotAll);
	}
	
	/**
	 * Returns the number of times the provided regEx was found in the last server response
	 * @param regEx
	 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
	 * @return
	 */
	public int lastResponseCountRegEx(String regEx, boolean dotAll){
		return this.httpsClient.lastResponseCountRegEx(regEx, dotAll);
	}
	
	/**
	 * Sends request r to the SOMA interface.  Expects domain property to already be set.
	 * @param r
	 * @return
	 * @throws NoSuchMethodException 
	 * @throws InvocationTargetException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws IOException 
	 * @throws SOAPException 
	 * @throws JAXBException 
	 * @throws ParserConfigurationException 
	 * @throws Exception
	 */
	public RequestBean sendRequest(Request r) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		this.initializeURL();
		this.initializeHeaders();
		return this.buildRequestBean(this.httpsClient.sendPost(this.payloadBuilder.buildObjectRequest(r)));
	}
	
	/**
	 * Sends request r to the SOMA interface
	 * @param r
	 * @return
	 * @throws JAXBException 
	 */
	public RequestBean sendRequest(String r){
		this.initializeURL();
		this.initializeHeaders();
		return this.buildRequestBean(this.httpsClient.sendPost(r));
	}
	
	/**
	 * Uses the specified file's contents as the payload for a SOMA request
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public RequestBean sendRequestFromFile(String path, String fileName) throws IOException{
		this.initializeURL();
		this.initializeHeaders();
		String payload= this.httpsClient.readFile(path, fileName);
		
		if(payload.length()==0){
			throw new IOException("Error: Empty file. File: " + path + File.separatorChar + fileName);
		}
		
		return this.buildRequestBean(this.httpsClient.sendPost(payload));
	}
	
	private RequestBean buildRequestBean(RequestBean r) {
//		try {
//		System.out.println(r.getServerPayload());
			try {
				r.setResponseObject(factory.getResponseObject(this.converter.stringToXML(r.getServerPayload())));//this.getResponseObject(r.getServerPayload()));
				r.setResponseAsXML(this.httpsClient.encoder.stringToXML(r.getServerPayload()));
			} catch (Exception e) {
				r.setError(true);
				r.setResponseObject(null);
				r.setErrorMessage("Error while loading the RequestBeans Response and JSON objects.  Check the RequestBean's Exception property for more details.");
				r.setException(e);
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//		} catch (JAXBException e) {
			
//		}
		this.lastResponse=r;
		return r;
	}
	
	private RequestBean loadConfigObjects(RequestBean r, ConfigConfigBase o){
		if(!r.getStatus().equals(SOMAVariables.STATUS_CODE_GOOD)){
			r.setError(true);
			r.setErrorMessage("Error: Unable to load configuration object, response status was not " + SOMAVariables.STATUS_CODE_GOOD);
			return r;
		}
		try {
			Document somaResponse = this.converter.stringToXML(r.getServerPayload());
			r.setResponseObject(factory.getResponseObject(somaResponse));//this.getResponseObject(r.getServerPayload()));
			factory.loadConfigObject(somaResponse, o);
			r.setResponseAsXML(this.httpsClient.encoder.stringToXML(r.getServerPayload()));
		} catch (NoSuchMethodException | SecurityException | ClassNotFoundException | IllegalAccessException | InstantiationException | IllegalArgumentException | InvocationTargetException e) {
			r.setError(true);
			r.setResponseObject(null);
			r.setErrorMessage("Error while loading the RequestBeans Response and XML objects.  Check the RequestBean's Exception property for more details.");
			r.setException(e);
			e.printStackTrace();
		}

	this.lastResponse=r;
	return r;
	}
	
	public void setBufferSize(int size){
		this.httpsClient.setBufferSize(size);
	}
	
	public void getBufferSize(){
		this.httpsClient.getBufferSize();
	}

	////////////////////////////////////////////////////////////////
	//                   Inner Classes                           //
	//////////////////////////////////////////////////////////////
	public class ConfigRequest extends DPManagement.ConfigRequest{

		
	
		@Override
		public RequestBean createConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payloadBuilder.buildObjectRequest(configObject, domain)));
		}

		
		@Override
		public RequestBean modifyConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payloadBuilder.buildModifyObjectRequest(configObject, domain)));
		}

		
		@Override
		public RequestBean deleteConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException{
			return deleteConfigObject( payloadBuilder.getClassName(configObject).substring(6), payloadBuilder.getObjectName(configObject));
		}
		
		@Override
		public RequestBean deleteConfigObject(String objectClass, String objectName) {
			initializeURL();
			initializeHeaders();
			String payload = SOMAVariables.somaRequestHead.replace("{domain}", domain);
			payload += SOMAVariables.deleteConfigRequest.replace("{class}",objectClass).replace("{name}", objectName);
			payload += SOMAVariables.somaRequestFooter;
			return buildRequestBean(httpsClient.sendPost(payload));

		}


		@Override
		public RequestBean getConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException { 
			initializeURL();
			initializeHeaders();
			String payload = SOMAVariables.somaRequestHead.replace("{domain}", domain);
			payload += SOMAVariables.getConfigRequest.replace("{class}", payloadBuilder.getClassName(configObject).substring(6)).replace("{name}",payloadBuilder.getObjectName(configObject));
			payload += SOMAVariables.somaRequestFooter;
			return loadConfigObjects(httpsClient.sendPost(payload), configObject);
		}

		@Override
		public ConfigConfigBase loadConfigObject(ConfigConfigBase configObject, String instanceName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException { 
			initializeURL();
			initializeHeaders();
			String payload = SOMAVariables.somaRequestHead.replace("{domain}", domain);
			payload += SOMAVariables.getConfigRequest.replace("{class}", payloadBuilder.getClassName(configObject).substring(6)).replace("{name}",instanceName);
			payload += SOMAVariables.somaRequestFooter;
			loadConfigObjects(httpsClient.sendPost(payload), configObject);
			return configObject;
		}
	
	}
	
	public class FileStoreRequest extends DPManagement.FileStoreRequest{

		public RequestBean createFile(String localPath, String fileName, String dpPath, String dpFileName) throws IOException{
			String tmp = readFile(localPath, fileName);
//			StringBuilder payload= new StringBuilder();
//			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
//			payload.append(SOMAVariables.setFileRequestHeader.replace("{name}", dpPath +"/"+ dpFileName));
//			payload.append((httpsClient.encoder.encodeBase64(tmp)));
//			payload.append(SOMAVariables.somaRequestFooter);
//			initializeURL();
//			initializeHeaders();
//			return buildRequestBean(httpsClient.sendPost(payload.toString()));
			return createFile(dpPath, dpFileName, tmp);
		}
		
		public RequestBean getFilestore(GetFilestore f) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payloadBuilder.buildObjectReqeust(f, domain)));
		}

		@Override
		public RequestBean createFile(String path, String fileName, String contents) {
			if(path.contains("/")){
				path = path.substring(0, path.indexOf("/")) + ":" + path.substring(path.indexOf("/"), path.length());
			}else{
				path += ":";
			}
			StringBuilder payload= new StringBuilder();
			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
			payload.append(SOMAVariables.setFileRequestHeader.replace("{name}", path +"/"+ fileName));
			payload.append((httpsClient.encoder.encodeBase64(contents)));
			payload.append(SOMAVariables.setFileRequestFooter);
			payload.append(SOMAVariables.somaRequestFooter);
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payload.toString()));
		}
		

		@Override
		public RequestBean createEncodedFile(String path, String fileName, String contents) {
			if(path.contains("/")){
				path = path.substring(0, path.indexOf("/")) + ":" + path.substring(path.indexOf("/"), path.length());
			}else{
				path += ":";
			}
			StringBuilder payload= new StringBuilder();
			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
			payload.append(SOMAVariables.setFileRequestHeader.replace("{name}", path +"/"+ fileName));
			payload.append(contents);
			payload.append(SOMAVariables.setFileRequestFooter);
			payload.append(SOMAVariables.somaRequestFooter);
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payload.toString()));
		}

		@Override
		public RequestBean modifyEncodedFile(String path, String fileName, String contents) {
			if(path.contains("/")){
				path = path.substring(0, path.indexOf("/")) + ":" + path.substring(path.indexOf("/"), path.length());
			}else{
				path += ":";
			}
			StringBuilder payload= new StringBuilder();
			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
			payload.append(SOMAVariables.setFileRequestHeader.replace("{name}", path +"/"+ fileName));
			payload.append(contents);
			payload.append(SOMAVariables.setFileRequestFooter);
			payload.append(SOMAVariables.somaRequestFooter);
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payload.toString()));
		}

		@Override
		public RequestBean modifyFile(String path, String fileName, String contents) {
			if(path.contains("/")){
				path = path.substring(0, path.indexOf("/")) + ":" + path.substring(path.indexOf("/"), path.length());
			}else{
				path += ":";
			}
			StringBuilder payload= new StringBuilder();
			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
			payload.append(SOMAVariables.setFileRequestHeader.replace("{name}", path +"/"+ fileName));
			payload.append((httpsClient.encoder.encodeBase64(contents)));
			payload.append(SOMAVariables.setFileRequestFooter);
			payload.append(SOMAVariables.somaRequestFooter);
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payload.toString()));
		}

		/**
		 * Will send action request to delete the specified file.
		 */
		@Override
		public RequestBean deleteFile(String path, String fileName) {
			if(path.contains("/")){
				path = path.substring(0, path.indexOf("/")) + ":" + path.substring(path.indexOf("/"), path.length());
			}else{
				path += ":";
			}
			ActionDeleteFile df = new ActionDeleteFile();
			df.setFile(path + "/" + fileName);
			try {
				return action.action(df);
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException | InvocationTargetException | NoSuchMethodException e) {
				e.printStackTrace();
				return null;
			}
			
		}

		@Override
		public RequestBean getFile(String path, String fileName) {
			StringBuilder payload = new StringBuilder();
			if(path.contains("/")){
				path = path.substring(0, path.indexOf("/")) + ":" + path.substring(path.indexOf("/"), path.length());
			}else{
				path += ":";
			}
			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
			payload.append(SOMAVariables.getFileRequest.replace("{name}", path +"/"+ fileName));
			payload.append(SOMAVariables.somaRequestFooter);
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payload.toString()));
		}
		
		public String getFileAsString(String path, String fileName){
			RequestBean response = this.getFile(path, fileName);
			if(response.getResponseObject().getFile().size()==0){
				return null;
			}
			return response.getResponseObject().getFile().get(0).getValueAsString();
//			Document d = this.getFile(path, fileName).getResponseAsXML();
//			return converter.decodeBase64(d.getElementsByTagName(SOMAVariables.KEY_RESPONSE_FILE).item(0).getTextContent());
		}

		/**
		 * Note: SOMA Does not have the functionality to get subdirectories by themselves.
		 * Use the getFileStore method
		 * @return null
		 */
		@Override
		public RequestBean getDirectory(String path, String dirName) {
			String rootDir = path.substring(0, path.indexOf(':')+1);
			GetFilestore g = new GetFilestore();
			g.setLocation(FilestoreLocation.valueOf(rootDir));
			
		
			
			
			return null;
		}
		
		/**
		 * Note: SOMA Does not have the functionality to get subdirectories by themselves.
		 * Use the getFileStore method
		 * @return null
		 */
		@Override
		public RequestBean getDirectory(String fullPath){
			return null;
		}

		@Override
		public String getCLILog() {
			RequestBean r = this.getFile("logtemp", "cli-log");
			if(r.getResponseObject().getFile().size()==0){
				return null;
			}
			return r.getResponseObject().getFile().get(0).getValueAsString();
			
//			Document d = converter.stringToXML(r.getServerPayload());
//			return converter.decodeBase64(d.getElementsByTagName("dp:file").item(0).getFirstChild().getNodeValue());
			
		}

		@Override
		public String getDefaultLog() {
			String tmpDomain = domain;
			domain = "default";
			RequestBean r = this.getFile("logtemp", "default-log");
			domain = tmpDomain;
			if(r.getResponseObject().getFile().size()==0){
				return null;
			}
			return r.getResponseObject().getFile().get(0).getValueAsString();
			
//			Document d = converter.stringToXML(r.getServerPayload());
//			return converter.decodeBase64(d.getElementsByTagName("dp:file").item(0).getFirstChild().getNodeValue());
		}
		
		public Document getDefaultLogAsXML(){
			return null;
		}

		@Override
		public String getUserLog() {
			RequestBean r = this.getFile("logtemp", "default-log");
			if(r.getResponseObject().getFile().size()==0){
				return null;
			}
			return r.getResponseObject().getFile().get(0).getValueAsString();
//			Document d = converter.stringToXML(r.getServerPayload());
//			return converter.decodeBase64(d.getElementsByTagName("dp:file").item(0).getFirstChild().getNodeValue());
		}

		@Override
		public String getLog(String pathToLog, String logName) {
			RequestBean r = this.getFile(pathToLog, logName);
			if(r.getResponseObject().getFile().size()==0){
				return null;
			}
			return r.getResponseObject().getFile().get(0).getValueAsString();
//System.out.println(r.getServerPayload());
//System.out.println(r.getClientPayload());
//			Document d = converter.stringToXML(r.getServerPayload());
//			try{
//				return converter.decodeBase64(d.getElementsByTagName("dp:file").item(0).getFirstChild().getNodeValue());
//			}catch(Exception e){
//				e.printStackTrace();
//				return null;
//			}
		}

		@Override
		public String getLogAnchor(String pathToLog, String logName) {
			String log = this.getLog(pathToLog, logName);
			String[] logArray = log.split("\n");
			for(int i=logArray.length-1; i>0;i--){
				if(containsRegEx(logArray[i], DPVariables.REGEX_LOG_TIMESTAMPS_DP, false)){
					return logArray[i];
				}
			}
			
			return null;
		}

		
	}
	
	public class StatusRequest extends DPManagement.StatusRequest{

		@Override
		public RequestBean getStatus(String statusName) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException {
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(SOMAVariables.somaRequestHead.replace("{domain}", domain)+ SOMAVariables.getStatusRequest.replace("{class}",statusName ) + SOMAVariables.somaRequestFooter));
		}

		@Override
		public RequestBean getStatus(GetStatus status) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException {
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(SOMAVariables.somaRequestHead.replace("{domain}", domain)+ SOMAVariables.getStatusRequest.replace("{class}",status.getObjectName()) + SOMAVariables.somaRequestFooter));
		}

		@Override
		public RequestBean getStatus(StatusEnum status) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException {
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(SOMAVariables.somaRequestHead.replace("{domain}", domain)+ SOMAVariables.getStatusRequest.replace("{class}",status.value()) + SOMAVariables.somaRequestFooter));

		}

		
	
	}
	
	public class ActionRequest extends DPManagement.ActionRequest{

		@Override
		public RequestBean action(Object action) throws IllegalArgumentException, IllegalAccessException,  NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
			initializeURL();
			initializeHeaders();
			return buildRequestBean(httpsClient.sendPost(payloadBuilder.buildObjectRequest(action, domain)));
		}

//		@Override
//		public ArrayList<StatusActiveUsers> disconnectActiveUsers(String domain) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
//			// TODO Auto-generated method stub
//			return null;
//		}
	}
	

	/**
	 * Allows a user to send a batch request through the SOMA interface.<br/>
	 * A batch request is when you send multiple object in one request.  IE: one soma request that contained 2 set-configuration objects
	 * and a save do-action object.  It uses the 2004 URI to send request because the current restricts users to 1 object per request.
	 * @author nickCoble
	 *
	 */
	public class BatchRequest extends DPManagement.BatchRequest{
		ArrayList<String> payloadList = new ArrayList<>();
		
		/**
		 * Adds config object payload to list
		 * @param object
		 * @throws IllegalArgumentException
		 * @throws IllegalAccessException
		 * @throws NoSuchFieldException
		 * @throws SecurityException
		 * @throws InvocationTargetException
		 * @throws NoSuchMethodException
		 */
		public void addObjectToPayloadList(Object object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
			if(object == null){return;}
			String tmp = payloadBuilder.buildObjectPayload(object);
			this.payloadList.add(tmp);
		}
		
		/**
		 * Adds config object payload to list
		 * @param objectPayload
		 */
		public void addObjectToPayloadList(String objectPayload){
			if(objectPayload == null || objectPayload.equals("")){return;}
			this.payloadList.add(objectPayload);
		}
		
		/**
		 * Adds a file payload to list
		 * @param pathToGetFile
		 * @param fileName
		 * @param pathToPutFile
		 * @throws IOException
		 */
		public void addFileToPayloadList(String pathToGetFile, String fileName, String pathToPutFile) throws IOException{
			if(pathToGetFile == null){
				throw new IOException("");
			}else if(fileName == null){
				throw new IOException("");
			}else if(fileName.equals("")){
				throw new IOException("");
			}else if(pathToPutFile == null){
				throw new IOException("");
			}else if( pathToPutFile.equals("")){
				throw new IOException("");
			}

			this.payloadList.add(SOMAVariables.setFileRequest.replace("{content}", base64EncodeFile(pathToGetFile, fileName)).replace("{name}", pathToPutFile + "/" + fileName));
		}
		
		/**
		 * Clears all objects in the payload list
		 */
		public void clearPayloadList(){
			this.payloadList.clear();
		}
		
		/**
		 * Builds batch payload from list
		 * @return
		 */
		public String buildPayloadFromList(){
			
			StringBuilder payload = new StringBuilder();
			payload.append(SOMAVariables.somaRequestHead.replace("{domain}", domain));
			for(String s: this.payloadList){
				payload.append(s);
			}
			payload.append(SOMAVariables.somaRequestFooter);

			
			return payload.toString();
		}
		
		/**
		 * Sends the batch put request using the payload list.  If list is empty method returns null. Clears list once request is completed.
		 * @return
		 */
		public RequestBean sendBatchRequest(){
			if(this.payloadList.size()<1){
				return null;
			}
			
			String uriTemp = uri;
			
			setURITo2004();
			sendRequest(this.buildPayloadFromList());
			uri = uriTemp;
			
			this.payloadList.clear();
			return httpsClient.getLastResponse();
			 
		}

		
	}
	

	private RequestBean buildObjectRequest(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		initializeURL();
		initializeHeaders();
		StringBuilder payload = new StringBuilder(SOMAVariables.somaRequestHead.replace("{domain}", domain));
		payload.append(payloadBuilder.buildObjectPayload(o));
		payload.append(SOMAVariables.somaRequestFooter);
		RequestBean response = httpsClient.sendPost(payload.toString());
		return buildRequestBean(response);
	}
	
	public RequestBean getSamlart(GetSamlart value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);
	}
	
	public RequestBean getDiff(GetDiff value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}
	
	public RequestBean getConformanceReport(GetConformanceReport value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}

	public RequestBean doImport(DoImport value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}
	
	public RequestBean doExport(DoExport value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}
	
	public RequestBean doDeployPattern(DoDeployPattern value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}
	
	public RequestBean doBackup(DoBackup value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}
	
	public RequestBean doRestore(DoRestore value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}

	public RequestBean getAsyncResult(GetAsyncResult value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);

	}
	
	public RequestBean getb2bQueryMetadata(B2BQueryMetadata value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		return this.buildObjectRequest(value);
	}
	
}
