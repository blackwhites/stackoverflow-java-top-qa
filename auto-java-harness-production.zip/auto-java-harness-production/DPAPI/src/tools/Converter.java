package tools;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Base64;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.xml.sax.InputSource;



public class Converter {

	public String encodeBase64(String messageToEncode){
		return new String(Base64.getEncoder().encode(messageToEncode.getBytes()));
	}
	
	public String encodeBase64(String messageToEncode, String charEncoding) throws UnsupportedEncodingException{
		return new String(Base64.getEncoder().encode(messageToEncode.getBytes(charEncoding)), charEncoding);
	}
	
	public byte[] decodeBase64IntoBytes(String messageToDecode){
		return Base64.getDecoder().decode(messageToDecode);

	}
	
	public String decodeBase64(String messageToDecode){
		return new String(Base64.getDecoder().decode(messageToDecode));
	}
	
	public String decodeBase64(String messageToDecode, String charEncoding) throws UnsupportedEncodingException{
		return new String(Base64.getDecoder().decode(messageToDecode.getBytes(charEncoding)), charEncoding);
	}

	
	public JsonObject stringToJSON(String j){
		InputStream	stream = new ByteArrayInputStream(j.getBytes());
		JsonReader reader =  Json.createReader(stream);
		JsonObject tempOptions = null;
		try{
			
			tempOptions = reader.readObject();
		}catch(Exception e){
			tempOptions = (Json.createObjectBuilder()).add("Error", e.getMessage()).build();
		}finally{
			try {
				stream.close();
			} catch (IOException e) {
				System.out.println("Closing Input Stream Error: ");
				e.printStackTrace();
			}
			reader.close();
			
		}	
		return tempOptions;
	}
	
	public JsonArray stringToJSONArray(String j){
		InputStream	stream = new ByteArrayInputStream(j.getBytes());
		JsonReader reader =  Json.createReader(stream);
		JsonArray tempOptions = null;
		try{
			
			tempOptions = reader.readArray();
		}catch(Exception e){
			tempOptions = (Json.createArrayBuilder().add("Error: " + e.getMessage()).build());
		}finally{
			try {
				stream.close();
			} catch (IOException e) {
				System.out.println("Closing Input Stream Error: ");
				e.printStackTrace();
			}
			reader.close();
			
		}	
		return tempOptions;
	}
	public void stringToFile(String content, String path, StandardOpenOption fileOption, String characterEncoding) throws IOException{
			Files.write( Paths.get(path), content.getBytes(characterEncoding), fileOption);
	}
	
	public void bytesToFile(byte[] fileContent, String path, StandardOpenOption fileOption) throws IOException{
		Files.write(Paths.get(path), fileContent, fileOption);
	}
	
	public void stringToFile(String content, String path) throws IOException{
		Files.write( Paths.get(path), content.getBytes());
	}
	
	public Document stringToXML(String j){

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try{
			builder = factory.newDocumentBuilder();
			Document doc = (Document) builder.parse(new InputSource(new StringReader(j)));
			return doc;
		}catch(Exception e){
			e.printStackTrace();
		}

		return null;
	}
	
	public String xmlToString(Document d) throws TransformerException{
		if(d==null){return null;}
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		StringWriter writer = new StringWriter();
		transformer.transform(new DOMSource(d), new StreamResult(writer));
		return writer.getBuffer().toString().replaceAll("\n|\r", "");
	}


}
