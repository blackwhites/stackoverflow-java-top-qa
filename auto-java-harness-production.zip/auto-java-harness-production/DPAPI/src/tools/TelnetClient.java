package tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import variables.CLIVariables;

/**
 * Not finished, need to implement telnet codes<br/>
 * Seems to work with DP anyways
 * @author cncoble
 *
 */
public class TelnetClient extends CLIClient{
	long responseBytes = 0;//TODO figure out how to find this value
	long charTimeOut = 10000;//milliseconds.  Used to time out from last character read during getResponse()
	long totalTimeOut = 60000;//Total time to get response, default 1 min
	int bufferSize = 100000;//Default buffer for the read from stream pipe
	Socket socket = null;
	protected InputStream in;// =new PipedInputStream(100000);
	protected OutputStream out;// = new PipedOutputStream();
	
	//Telnet Command Codes
	public final static int SE = 240;
	public final static int NOP = 241;
	public final static int DM = 242;
	public final static int BRK = 243;
	public final static int IP = 244;
	public final static int AO = 245;
	public final static int AYT = 246;
	public final static int EC = 247;
	public final static int EL = 248;
	public final static int GA = 249;
	public final static int SB = 250;
	public final static int WILL = 251;
	public final static int WONT = 252;
	public final static int DO = 253;
	public final static int DONT = 254;
	public final static int IAC = 255;
	
	//Telnet Option Codes
	public final static int TransmitBinary = 0;
	public final static int Echo = 1;
	public final static int Reconnection = 2;
	public final static int SuppressGoAhead = 3;
	public final static int ApproxMessageSizeNeg = 4;
	public final static int Status = 5;
	public final static int TimingMark = 6;
	public final static int RemoteTransAndEcho = 7;
	public final static int OutputLineWidth = 8;
	public final static int OutputPageSize = 9;
//	public final static int Negotiate About Output Carriage-Return Disposition	 = 10;
//	public final static int Negotiate About Output Horizontal Tabstops	 = 11;
//	public final static int NAOHTD, Negotiate About Output Horizontal Tab Disposition	 = 12;
//	public final static int Negotiate About Output Formfeed Disposition	 = 13;
//	public final static int Negotiate About Vertical Tabstops	 = 14;
//	public final static int Negotiate About Output Vertcial Tab Disposition	 = 15;
//	public final static int Negotiate About Output Linefeed Disposition	 = 16;
//	public final static int Extended ASCII.	 = 17;
//	public final static int Logout.	 = 18;
//	public final static int Byte Macro	 = 19;
//	public final static int Data Entry Terminal	 = 20;
//	public final static int SUPDUP = 21;
//	public final static int SUPDUP Output	 = 22;
//	public final static int Send Location	 = 23;
//	public final static int TerminalType = 24;
//	public final static int End of Record	 = 25;
//	public final static int TACACS User Identification	 = 26;
//	public final static int Output Marking	 = 27;
//	public final static int TTYLOC, Terminal Location Number.	 = 28;
//	public final static int Telnet 3270 Regime	 = 29;
//	public final static int X.3 PAD.	 = 30;
//	public final static int WindowSize = 31;
//	public final static int TerminalSpeed = 32;
//	public final static int Remote Flow Control	 = 33;
//	public final static int Linemode = 34;
//	public final static int X Display Location.	 = 35;
//	public final static int Environment = 36;
//	public final static int Authentication = 37;
//	public final static int Encryption Option	 = 38;
//	public final static int New Environment	 = 39;
//	public final static int TN3270E = 40;
//	XAUTH	 
//	42	CHARSET	2066
//	43	RSP, Telnet Remote Serial Port	 
//	44	Com Port Control	2217
//	45	Telnet Suppress Local Echo	 
//	46	Telnet Start TLS	 
//	47	KERMIT	2840
//	48	SEND-URL	 
//	49	FORWARD_X
//	138 TELOPT PRAGMA LOGON	 
//	139	TELOPT SSPI LOGON	 
//	140	TELOPT PRAGMA HEARTBEAT
//	255	Extended-Options-List
//
//	ArrayList<Integer> commands = new ArrayList<>();//used to build telnet command/request

	public TelnetClient(String hostName, int port, String userName, String  password) throws InvalidParameterException{
		if(hostName==null || hostName.equals("")){throw new InvalidParameterException("Error Instantiating Telnet, Invalid IP: " + hostName);}
		if(port < 0){throw new InvalidParameterException("Error Instantiating Telnet Client, Invalid Port: " + port);}
		this.hostName = hostName;
		this.port = port;
		this.userName =userName;
		this.password = password;
	}

	/**
	 * Method to establish a telnet session
	 * Handles logging into remote host
	 * @return boolean
	 */
	public boolean startSession(){
        try {
			socket = new Socket(this.hostName, this.port);	
			in = socket.getInputStream();
			out = socket.getOutputStream();
			return true;
		} catch (IOException e) {
			this.errorMessage = e.getMessage();
			return false;
		}
	
		
	}
	
	/**
	 * Establishes an telnet session and logs in to the remote host
	 * Note: use the logInDP method to log into a DP appliance
	 * @return boolean
	 */
	public boolean logIn(){
		
		this.startSession();
		String rsp="";
		rsp += this.getResponse(this.userName);
	    rsp += this.getResponse(this.password);
		
	    System.out.println(rsp);
	    //TODO check if logged in
	
	    return true;
	}
	
	public boolean setBufferSize(int size){
		this.bufferSize=size;
		try {
			this.socket.setReceiveBufferSize(size);
			return true;
		} catch (SocketException e) {
			this.errorMessage = e.getMessage();
			return false;
		}
	}
		
	/**
	 * Method to close the telnet session
	 * @return boolean
	 */
	public boolean endSession(){
		boolean allClosed = true;
		this.errorMessage="";

		if(this.socket!=null){
			try {
				this.socket.shutdownInput();
				this.socket.shutdownOutput();
				this.socket.close();
			} catch (IOException e) {
				this.errorMessage+=e.getMessage();
				allClosed = false;
			}}
		
		
		if(this.in!=null){
			try {
				this.in.close();
			} catch (IOException e) {
				this.errorMessage+=e.getMessage();
				allClosed = false;
			}}
		if(this.out!=null){
			try {
				this.out.close();
			} catch (IOException e) {
				this.errorMessage+=e.getMessage();
				allClosed = false;
			}
		}
		return allClosed;
	}
	
	/**
	 * Method to get cli response from remote service.
	 * Times out according to global variable totalTimeOut
	 * @return String
	 */
	public String getResponse(){return this.getResponse((int)this.totalTimeOut);}
	
	/**
	 * Gets response 
	 * Specify time out in milliseconds
	 * @param timeOut
	 * @return
	 */
	public String getResponse(int timeOut){
		this.response = "";
		String tmpHolder="";
		StringBuilder stringBuilder= new StringBuilder();
		long startTime = System.currentTimeMillis();
		boolean startedReading = false;
		boolean doublecheck =false;
		this.responseTrimed = false;

		if(this.socket.isClosed()){return "ERROR: Unable to get response, socket is closed.\n";}
		try {
			while(true){
				if((this.in.available()>0)){
					startedReading = true;
					doublecheck =false;

					while(this.in.available()>0){
						int i = in.read();
//System.out.println(i);
						if(i<0){
							break;
						}else if((i>31 && i<127)||(i==10)){
							stringBuilder.append((char)i);
						}else{
							//TODO interpret telnet command
//							this.commands.clear();
							this.telNetCommand(i);
						}
					}

				}else{
					
					if(!doublecheck){//Gives buffer a chance to fill back up incase end of response check is a false positive
//						System.out.println("Double Check Wait");
//						System.out.println(stringBuilder.toString());
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
	//System.out.println("Double Check Wait Finished");

							doublecheck=true;
							continue;
					}

					if(startedReading){
						tmpHolder = stringBuilder.toString();
						if((tmpHolder.endsWith(": ") || tmpHolder.endsWith("# ") || tmpHolder.endsWith("> ") || tmpHolder.endsWith("$ ") || tmpHolder.endsWith(") ")|| tmpHolder.endsWith("? "))){
							break;
						}
					}
					
					if(this.socket.isClosed()){
						stringBuilder.append("\nERROR: Socket was closed.\n");
						break;
					}else{
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
				
				if(System.currentTimeMillis() - startTime > timeOut){
					stringBuilder.append("\nERROR: Get Response Timed Out("+ timeOut +").\n");
					break;
				}
			
			}
		} catch (IOException e) {
			e.printStackTrace();
			this.errorMessage = e.getMessage();
			stringBuilder.append("\nERROR getting response: " + e.getMessage() + "\n");
		}
		
		this.response = stringBuilder.toString().replace("\r\n", "\n");
		this.responseBytes = this.response.getBytes().length;

		return this.response;
	}
	
	/**
	 * Returns the response to the provided command.
	 * @param command
	 * @return String
	 */
	public String getResponse(String command){
		if(this.sendCommand(command)){
			return this.getResponse();
		}else{
			return "ERROR: Unable to send the " + command +  " command.\n";
		}
	}
	
	/**
	 * Returns the response to the provided command.
	 * Specify time out in milliseconds
	 * @param command
	 * @param timeOut
	 * @return
	 */
	public String getResponse(String command, int timeOut){
		if(this.sendCommand(command)){
			return this.getResponse(timeOut);
		}else{
			return "ERROR: Unable to send the " + command +  " command.\n";
		}
	}
	
	/**
	 * Method to send commands to appliance.
	 * @param command:String
	 * @return boolean
	 */
	public boolean sendCommand(String command){
		this.lastCommand = command + "\n";
		if(this.socket.isConnected()){
			try {
				out.write(this.lastCommand.getBytes());
				out.flush();
				return true;
			} catch (IOException e) {
				this.errorMessage = e.getMessage();
				e.printStackTrace();
			}
		}
		return false;
	}
	
	/**
	 * Send Ctrl type Commands using hex or int number code
	 * IE: Ctrl-C = 3
	 * Table of codes at http://www.nthelp.com/ascii.htm list
	 * @param n
	 * @return
	 */
	public boolean sendCommand(int n){
		this.lastHexCommand = n ;
		if(this.socket.isConnected()){
			try {
				out.write(n);
				out.flush();
				return true;
			} catch (IOException e) {
				this.errorMessage = e.getMessage();
				e.printStackTrace();
			}
		}
		return false;
	}
		
	public boolean lastResponseMatches(String regExp){
		Pattern tmp = Pattern.compile(regExp, Pattern.DOTALL);
		return tmp.matcher(this.getLastResponse()).matches();
	}

	public boolean lastResponseContains(String regExp){
		Pattern tmp = Pattern.compile(regExp, Pattern.DOTALL);
		return tmp.matcher(this.getLastResponse()).find();
	}
	
	/**
	 * Returns a array of Strings found in the response String that matched the provided regExp
	 * @param response
	 * @param regExp
	 * @return
	 */
	public ArrayList<String> getGroupsFromLastResponse(String regExp){
		ArrayList<String> tmp = new ArrayList<>();
		Pattern p = Pattern.compile(regExp, Pattern.DOTALL);
		Matcher m = p.matcher(this.response);

		while(m.find()){
		   tmp.add(m.group(0));
		}
		return tmp;
	}
	
	public int countLastResponse(String regEx){return this.count(this.response, regEx);}
	
	
	/**
	 * Attempts to log in to a DP appliance
	 * @param domain
	 * @throws Exception
	 */
	public boolean loginDP(String domain){

		//Establish connection if not already
		if(this.socket ==null || !this.socket.isConnected()){
			if(!this.startSession()){
				this.errorMessage="Unable to establish telnet session." + this.errorMessage;
				System.out.println(this.errorMessage);
				return false;
			}
		}
		
		//Attempt to log in
		if(!CLIVariables.loginPrompt.matcher(this.getResponse()).find() && !this.getLastResponse().equals("\nERROR: Get Response Timed Out("+ this.totalTimeOut +").\n")){
			this.errorMessage="Unable to access login prompt.  Expected: " + CLIVariables.loginPrompt.toString() + ", Recieved: " + this.response;
			System.out.println(this.errorMessage);
			return false;
		}else if(!CLIVariables.passwordPrompt.matcher(this.getResponse(this.userName)).find()){
			this.errorMessage="Unable to access password prompt.  Expected: " + CLIVariables.passwordPrompt.toString() + ", Recieved: " + this.response;
			System.out.println(this.errorMessage);
			return false;
		}else if(!CLIVariables.domainPrompt.matcher(this.getResponse(this.password)).find()){
			if(!CLIVariables.welcomeMessage.matcher(this.response).find()){
				this.errorMessage="Unable to access welcome prompt.  Expected: " + CLIVariables.welcomeMessage.toString() + ", Recieved: " + this.response;
				System.out.println(this.errorMessage);
				return false;
			}else{
				this.getResponse("switch domain " + domain);
			}
			
		}else if(!CLIVariables.welcomeMessage.matcher(this.getResponse(domain)).find()){
			this.errorMessage="Unable to access welcome prompt.  Expected: " + CLIVariables.welcomeMessage.toString() + ", Recieved: " + this.response;
			System.out.println(this.errorMessage);
			return false;
		}
		
		return true;
	}

	public String getLastResponse(){return this.response;}
	
	public long getResponseBytes(){return this.responseBytes;}

	//TODO not implemented
	private boolean telNetCommand(int i){
//		commands.add(new Integer(i));
		//Interpret initial command
		switch(i){
			case SE:
			case NOP: 
			case DM: 
			case BRK: 
			case IP: 
			case AO: 
			case AYT: 
			case EC: 
			case EL: 
			case GA: 
			case SB: 
			case WILL: 
			case WONT: 
			case DO: 
			case DONT: 
			case IAC:
			case TransmitBinary:
			case Echo: 
			case Reconnection:
			case SuppressGoAhead:
			case ApproxMessageSizeNeg:
			case Status:
			case TimingMark:
			case RemoteTransAndEcho:
			case OutputLineWidth:
			case OutputPageSize:
		}
		
		return false;
	}
	
//	/**
//	 * Helper method for do telnet
//	 * @return
//	 */
//	private int getNextCommand(){
//		try {
//			if(in.available()>0){
//				return in.read();
//			}else{
//				return -1;
//			}
//		} catch (IOException e) {
//			this.errorMessage=e.getMessage();
//			return -2;
//		}
//	}
	
//	//TODO
//	private String getCodeString(int code){
//		String codeString="";
//		switch(code){
//		case SE:
//			return "(SE)";
//		case NOP: 
//		case DM: 
//		case BRK: 
//		case IP: 
//		case AO: 
//		case AYT: 
//		case EC: 
//		case EL: 
//		case GA: 
//		case SB: 
//		case WILL: 
//		case WONT: 
//		case DO: 
//		case DONT: 
//		case IAC:
//		
//		//Telnet Option Codes
//		case TransmitBinary:
//		case Echo: 
//		case Reconnection:
//		case SuppressGoAhead:
//		case ApproxMessageSizeNeg:
//		case Status:
//		case TimingMark:
//		case RemoteTransAndEcho:
//		case OutputLineWidth:
//		case OutputPageSize:
//		
//		
//		}
//		return codeString;
//	}

	@Override
	public boolean isConnected() {
		// TODO Auto-generated method stub
		return false;
	}
}
