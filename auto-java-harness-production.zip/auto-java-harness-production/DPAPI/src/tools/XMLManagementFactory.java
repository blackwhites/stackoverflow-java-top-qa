package tools;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import xmlManagement.DmReference;
import xmlManagement.ObjectFactory;

/**
 * Abstract class to hold common methods for creating xml management objects from the dp responses<br/>
 * IE: Convertering a SOMA get config response into a xml management configuration object.
 * @author Nick Coble
 *
 */
public abstract class XMLManagementFactory {
	
	protected ObjectFactory factory = new ObjectFactory();
	protected Converter converter = new Converter();
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected void buildSimpleField(Field f, Object o, String value) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, SecurityException {

		if(f==null||o==null||value==null){return;}
		f.setAccessible(true);
		String fieldClassName = f.getType().getSimpleName();
		
		 //Check if an enum
		 if(f.getType().isEnum()){
			 //Generate the enum value
			f.set(o, Enum.valueOf((Class<Enum>) f.getType().asSubclass(Enum.class), value.toUpperCase().replace("/", "_").replace(".", "_")));
		 }else if(fieldClassName.equals(DmReference.class.getSimpleName())){
			 DmReference tmp = new DmReference();
			 tmp.setValue(value);
			 f.set(o, tmp);
		 }else if(fieldClassName.equals(String.class.getSimpleName())){
			 f.set(o, value);
		 }else if(fieldClassName.equals(Boolean.class.getSimpleName())){
			 Boolean tmp = new Boolean(value);
			 f.set(o, tmp);
		 }else if(fieldClassName.equals(Integer.class.getSimpleName())){
			 Integer tmp = new Integer(value);
			 f.set(o, tmp);
		 }else if(fieldClassName.equals(Long.class.getSimpleName())){
			 Long tmp = new Long(value);
			 f.set(o, tmp);
		 }else if(fieldClassName.equals(List.class.getSimpleName())){
			String methodName = "get" + f.getName().substring(0, 1).toUpperCase() + f.getName().substring(1);
			List<Object> l = (List<Object>) o.getClass().getMethod(methodName).invoke(o) ;
	        ParameterizedType stringListType = (ParameterizedType) f.getGenericType();
	        Class<?> stringListClass = (Class<?>) stringListType.getActualTypeArguments()[0];
	        if(stringListClass.getClass().isInstance(DmReference.class)){
	        	DmReference tmp = new DmReference();
	        	tmp.setValue(value);
	        	l.add(tmp);
	        }else if (stringListClass.getClass().isInstance(String.class)){
	        	l.add(value);
	        }else{//Unknown
//	        	System.out.println("Unknown List Type");
				 throw new IllegalAccessException("Unknown List type: " + fieldClassName);

	        }
		 
		 
		 }else{
			 //Unknown Object type
//			 System.out.println("Unknown object type: " + fieldClassName);
			 throw new IllegalAccessException("Unknown object type: " + fieldClassName);
		 }
	}

	
	/**
	 * Tries to find field from annotation
	 * @param o
	 * @param fieldName
	 * @return
	 */
	protected Field getFieldFromAnnotation(Object o, String fieldName){
		List<Field> fields = this.getAllFields(o.getClass()); 
//System.out.println(o.getClass().getSimpleName());
//System.out.println(fieldName);
//System.out.println("\t" + fields.toString());
		//Get field
		for(Field f: fields){
//System.out.println("\t" +f.getName());
			if(f.getAnnotation(XmlElement.class) != null){
				if(f.getAnnotation(XmlElement.class).name().equals(fieldName)){
					return f;
				}
			}else if(f.getAnnotation(XmlAttribute.class) != null){
				if(f.getAnnotation(XmlAttribute.class).name().equals(fieldName)){
						return f;
				}
			}else{
				if(f.getName().toLowerCase().equals(fieldName.toLowerCase())){
					return f;
				}
			}
		}
		
		return null;
	}
	
	/**
	 * Method to retrieve all fields used by the object
	 * @param superClass
	 * @return
	 */
	protected List<Field> getAllFields(Class<?> superClass){
		List<Field> fields = new ArrayList<Field>();
        for (Class<?> c = superClass; c != null; c = c.getSuperclass()) {
            fields.addAll(Arrays.asList(c.getDeclaredFields()));
        }
        return fields;
	}

	
	
}
