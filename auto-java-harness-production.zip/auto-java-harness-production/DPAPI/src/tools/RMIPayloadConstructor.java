package tools;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlValue;
import variables.RMIVariables;
import xmlManagement.AnyActionElement;
import xmlManagement.AnyConfigElement;
import xmlManagement.AnyModifyElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.DmReference;
import xmlManagement.Request;



/**
 * Java Class to construct client payloads for ROMA requests.
 * 
 * Current Types:
 * AnyConfigElement
 * AnyStatusElement
 * AnyModifyElement
 * Request.setFile
 * Request.{previous objects}
 * 
 * need to update once other request become avaialbe
 * @author Nick Coble
 *
 */
public class RMIPayloadConstructor  extends XMLManagementPayloadConstructor{
	
	public String buildObjectRequest(Request r) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(r==null){return null;}
		Object object = this.getAvaiableObject(r);
		
		if(object==null){
			return null;
		}else if(object instanceof AnyActionElement){
			return this.buildObjectRequest((AnyActionElement) object);
		}else if(object instanceof AnyConfigElement){
			return this.buildObjectRequest((AnyConfigElement) object);
		}else if(object instanceof AnyModifyElement){
			return this.buildObjectRequest((AnyModifyElement) object);
		}			
		
		System.out.println("Invalid Object Type.  Expected AnyConfigElement or AnyActionElement");
		return null;
	}
	
	public String buildObjectRequest(AnyActionElement a) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(a==null || a.getActionObjects().size()==0){return null;}
		return this.buildRequest(a.getActionObjects().get(0));
	}
	
	public String buildObjectRequest(Object action) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(action==null){return null;}
		return this.buildRequest(action);
	}
	
	public String buildObjectRequest(AnyConfigElement c) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(c==null|| c.getConfigObjects().size()==0){return null;}
		return this.buildRequest(c.getConfigObjects().get(0));
	}
	
	public String buildObjectRequest(ConfigConfigBase c) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null){return null;}
		return this.buildRequest(c);
	}

	public String buildObjectRequest(AnyModifyElement m) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		if(m==null|| m.getConfigObjects().size()==0){return null;}
		return this.buildRequest(m.getConfigObjects().get(0));
	}

	public String buildObjectRequest(Request.SetFile s){
		if(s==null){return null;}
		
		StringBuilder b = new StringBuilder();
		b.append(s.getValue());
		
		return RMIVariables.PAYLOAD_CREATE_FILE.replace("{name}", s.getName()).replace("{content}", b.toString());
	}
	
	public String buildPropertyRequest(AnyConfigElement c, String propertyName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null|| c.getConfigObjects().size()==0 || propertyName==null){return null;}

		//Get property
		Object object = c.getConfigObjects().get(0);
		//Make first letter lower case
		propertyName = propertyName.substring(0,1).toLowerCase() + propertyName.substring(1);
		Field field = object.getClass().getDeclaredField(propertyName);
		field.setAccessible(true);
		
		StringBuilder payload= new StringBuilder("{");

		if(field.get(object) != null){
			payload.append(this.buildPayloadProperty(field, object, true));
		}else{
			return null;
		}
			
		payload.append("}");
		return payload.toString();
	}	
	
	public String buildPropertyRequest(ConfigConfigBase c, String propertyName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(c==null|| propertyName==null || propertyName.equals("")){return null;}

		//Get property
		//Make first letter lower case
		propertyName = propertyName.substring(0,1).toLowerCase() + propertyName.substring(1);
		Field field = c.getClass().getDeclaredField(propertyName);
		field.setAccessible(true);
		
		StringBuilder payload= new StringBuilder("{");

		if(field.get(c) != null){
			payload.append(this.buildPayloadProperty(field, c, true));
		}else{
			return null;
		}
			
		payload.append("}");
		return payload.toString();
	}	
	
	public String buildPropertyRequest(AnyModifyElement m, String propertyName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		if(m==null|| m.getConfigObjects().size()==0 || propertyName==null){return null;}
		
		//Get property
		Object object = m.getConfigObjects().get(0);
		//Make first letter lower case
		propertyName = propertyName.substring(0,1).toLowerCase() + propertyName.substring(1);
		Field field = object.getClass().getDeclaredField(propertyName);
		field.setAccessible(true);
		
		StringBuilder payload= new StringBuilder("{");

		if(field.get(object) != null){
			payload.append(this.buildPayloadProperty(field, object, true));
		}else{
			return null;
		}
			
		payload.append("}");
		return payload.toString();
	}	

	public String buildJSONPropSimple(String propName, String propValue){
		StringBuilder returnString = new StringBuilder("\"");
		returnString.append(propName);
		returnString.append("\":\"");
		returnString.append(propValue);
		returnString.append("\"");
		return returnString.toString();
	}
	
	public String buildJSONPropSimpleArray(String propName, ArrayList<String> contents){
		StringBuilder tmp = new StringBuilder("\"");
		tmp.append(propName);
		tmp.append("\":[");

		for(int i=0;i<contents.size();i++){
			if(i>0){tmp.append(",");}
			tmp.append("\"");
			tmp.append(contents.get(i));
			tmp.append("\"");
		}
		tmp.append("]");
		return tmp.toString();
	}
	
	/**
	 * Use buildJSONPropSimple to construct contents
	 * @param propName
	 * @param contents
	 * @return
	 */
	public String buildJSONPropComplex(String propName, String contents){
		StringBuilder returnString = new StringBuilder("\"");
		returnString.append(propName);
		returnString.append("\":{");
		returnString.append(contents);
		returnString.append("}");
		return returnString.toString();
	}
	
	/**
	 * Use buildJSONPropSimple to construct each array entry 
	 * @param propName
	 * @param contents
	 * @return
	 */
	public String buildJSONPropComplexArray(String propName, ArrayList<String> contents){
		StringBuilder tmp = new StringBuilder("\"");
		tmp.append(propName);
		tmp.append("\":[");
		
		for(int i=0;i<contents.size();i++){
			if(i>0){tmp.append(",");}
			tmp.append("{");
			tmp.append(contents.get(i));
			tmp.append("}");
		}
		tmp.append("]");
		return tmp.toString();
	}

	////////////////////////////////////////////////////////////////////////
	//  Private Helper Methods											 //
	//////////////////////////////////////////////////////////////////////
	
	/**
	 * Method to build and object payload.  IE ConfigXMLManager, StatusActiveUsersStatus, etc..
	 * @param Object:o
	 * @return String
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	private String buildRequest(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
				
		//Get name of object
		String objectName = this.getObjectKeyName(o);
		

		//Place object reqeust name in payload
		StringBuilder payload = new StringBuilder("{\"");
		payload.append(objectName);
		payload.append("\":{");

		//Build object contents
		payload.append(this.buildPayloadBody(o));
		payload.append("}}");
		
		return payload.toString();
	}

	private String buildPayloadBody(Object o) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException {
		StringBuilder payload= new StringBuilder();
		boolean first = true;
//		if(o instanceof ConfigConfigBase && ((ConfigConfigBase) o).getMAdminState()!=null){
//			//Grab the property name from annotation;
//			String[] propertyNames = ConfigConfigBase.class.getAnnotation(XmlType.class).propOrder();
//			payload += this.buildJSONPropSimple(propertyNames[0],((ConfigConfigBase) o).getMAdminState().toString().toLowerCase());
//			first=false;
//		}
		
		for (Field field : this.getAllFields(o.getClass())) {
			field.setAccessible(true);
			if(field.get(o)==null ){//|| field.get(o) instanceof DmAdminState
				continue;
			}else{
				payload.append(this.buildPayloadProperty(field, o, first));
				first = false;
			}
		}
		return payload.toString();
	}
	
	private String buildPayloadProperty(Field field, Object o, boolean first) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
		StringBuilder payload= new StringBuilder();
		field.setAccessible(true);
//System.out.println("Field: " + field.getName());

		if(field.get(o)==null){
			return null;
		}else{
			//Grab the property name from annotation;
			String propName;
			if(field.getAnnotation(XmlElement.class) != null){
				propName = field.getAnnotation(XmlElement.class).name();
			}else if(field.getAnnotation(XmlAttribute.class) != null){
				propName = field.getAnnotation(XmlAttribute.class).name();
			}else if(field.getAnnotation(XmlValue.class)!=null && !(o instanceof DmReference)){
//				System.out.println(o.getClass().getSimpleName());
				if(field.getType().isArray()){
					return "\""+ new String(((byte[])field.get(o))) +"\"";
				}else{
					return "\""+ field.get(o).toString() +"\"";
				}
				
			}else{
				propName =	"Unable To determine Property Name from annotation from field: " + field.getName() + " in object: " + o.getClass().getSimpleName();
			}
//			System.out.println("Field Type: " + field.get(o).getClass().getSimpleName());

			
			if(this.isSimpleType(field,o)){//Is it a simple type
//System.out.println("Simple Type: " + field.getType().getSimpleName());
					if(!first){payload.append(",");}
					payload.append(this.buildJSONFromSimpleField(field, o));
					
			}else if(field.get(o) instanceof List<?>){//List

				if(((List<?>)field.get(o)).size()>0){//Empty List?
					if(!first){payload.append(",");}
					if((((List<?>)field.get(o)).get(0).getClass().isPrimitive()) || (((List<?>)field.get(o)).get(0) instanceof String)){//Simple list
						payload.append(this.buildJSONFromSimpleArray(propName,field.get(o)));
					}else{//complex list
						payload.append(this.buildJSONFromComplexArray(propName, field.get(o)));
					}
				}
				
			}else{//complex Type

				if(!first){payload.append(",");}
				
				if(field.get(o) instanceof DmReference){	
//					System.out.println("dmField Type: " + field.get(o).getClass().getSimpleName());

					Field tmp = field.get(o).getClass().getDeclaredField("value");
					tmp.setAccessible(true);
					payload.append(this.buildJSONPropSimple(propName, (String) tmp.get(field.get(o))));
				}else{
//					System.out.println("Complex Type: " + field.get(o).getClass().getSimpleName());

					 payload.append("\"");
					 payload.append(propName);
					 payload.append("\":{");
					 payload.append(this.buildPayloadBody(field.get(o)));
					 payload.append("}");
				}
			}
		}
		
		return payload.toString();
	}
	
	private String buildJSONFromSimpleField(Field f, Object o) throws IllegalArgumentException, IllegalAccessException {
		
		//Get name
		String propName;
		if(f.getAnnotation(XmlElement.class) != null){
			propName = f.getAnnotation(XmlElement.class).name();
		}else if(f.getAnnotation(XmlAttribute.class) != null){
			propName = f.getAnnotation(XmlAttribute.class).name();
		}else if(f.getAnnotation(XmlValue.class)!=null){
			if(f.getType().isArray()){
				return "\""+ new String(((byte[])f.get(o))) + "\"";
			}else{
				return "\""+f.get(o).toString() + "\"";
			}
		}else{
			propName ="Unable To determine Property Name from annotation";
		}
		
		 //Check if an enum
		 if(f.getType().isEnum()){
			 try {
				return this.buildJSONPropSimple(propName, ((String)(f.get(o).getClass().getDeclaredMethod("value").invoke(f.get(o)))));
			} catch (InvocationTargetException | NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
			}
			 return null;
		 }else{
			 return this.buildJSONPropSimple(propName, f.get(o).toString());
		 }
	}
	
	private String buildJSONFromComplexArray(String propName, Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException {
		ArrayList<String> values = new ArrayList<>();
		boolean realComplex = true;
		for(int i=0;i<((List<?>)o).size();i++){					                			

			//if simpleType else complex
			if(((List<?>)o).get(i) instanceof DmReference){	
				
				values.add((String) ((List<?>)o).get(i).getClass().getMethod("getValue").invoke(((List<?>)o).get(i)));
				realComplex = false;
			}else{
				 StringBuilder value = new StringBuilder();
    			 boolean firstField=true;
				 for (Field field : getAllFields(((List<?>)o).get(i).getClass())) {
					 field.setAccessible(true);
					 if(field.get(((List<?>)o).get(i))!=null){
						 if(!firstField){value.append(",");}
						 firstField = false;
						 
 						if(this.isSimpleType(field, ((List<?>)o).get(i))){
 							if(field.getType().isEnum()){
								 try {
									value.append(this.buildJSONPropSimple(this.getElementName(field), ((String)(field.get(((List<?>)o).get(i)).getClass().getDeclaredMethod("value").invoke(field.get(((List<?>)o).get(i)))))));
								} catch (InvocationTargetException | NoSuchMethodException | SecurityException e) {
									e.printStackTrace();
									return null;
								}
								 
							}else{
								value.append(this.buildJSONPropSimple(this.getElementName(field), field.get(((List<?>)o).get(i)).toString()));
							}
 						}else{
 							
 							if(field.get(((List<?>)o).get(i)) instanceof DmReference){	
// 								System.out.println("dmField Type: " + field.get(o).getClass().getSimpleName());

 								Field tmp = field.get(((List<?>)o).get(i)).getClass().getDeclaredField("value");
 								tmp.setAccessible(true);
 								value.append(this.buildJSONPropSimple(this.getElementName(field), (String) tmp.get(field.get(((List<?>)o).get(i)))));
 							}else{
 								value.append(this.buildPayloadBody(field.get(((List<?>)o).get(i))));
 							}

 						}
					 }
				 }
				 values.add(value.toString());
			}
		}
		
		if(realComplex){
			return this.buildJSONPropComplexArray(propName, values);
		}else{
			return this.buildJSONPropSimpleArray(propName, values);
		}
	}
	
	private String buildJSONFromSimpleArray(String propName, Object o) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		ArrayList<String> values = new ArrayList<>();
		for(int i=0;i<((List<?>)o).size();i++){					                			
			values.add((String) ((List<?>)o).get(i));
		}

		return this.buildJSONPropSimpleArray(propName, values);
	}
	
}
