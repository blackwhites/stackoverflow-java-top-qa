package tools;

import java.util.ArrayList;

/**
 * Abstract Class to hold the common variables and methods of the CLI Clients
 * @author Nick Coble
 *
 */
public abstract class CLIClient extends BaseClient{

	public String lastCommand;
	public int lastHexCommand=-1;
	public String errorMessage;
	public String response;
	protected boolean responseTrimed = false;

	/**
	 * Finalize method to appempt to close connection
	 */
	protected void finalize() throws Throwable {
		this.endSession();
	}

	public abstract boolean startSession();
	public abstract boolean endSession();
	public abstract boolean sendCommand(String command);
	public abstract boolean sendCommand(int hexCommand);
	public abstract String getResponse(int timeOut);
	public abstract boolean loginDP(String domain);
	public abstract boolean isConnected();

	/**
	 * Method to get the cli response to a command
	 * @param command
	 * @param timeOut
	 * @return
	 */
	public String getResponse(String command, int timeOut){
		if(this.sendCommand(command)){
			return this.getResponse(timeOut);
		}else{
			return "Error sending command " + command + ".  ERROR: " + this.errorMessage;
		}
	}

	/**
	 * Returns the last response retrieved by the cli client
	 * @return
	 */
	public String getLastResponse(){return this.response;}

	/**
	 * Checks if last response matches regEx
	 * dotAll on by default
	 * returns false if parameters are invalid
	 * @param regExp
	 * @return
	 */
	public boolean responseMatches(String regExp){return this.matchesRegEx(this.response, regExp);}
	
	/**
	 * Checks if last response match regEx
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * returns false if parameters are invalid
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public boolean responseMatches(String regExp, boolean dotAll){return this.matchesRegEx(this.response, regExp, dotAll);}

	/**
	 * Checks if last cli response String contains the provided regular expression<br/>
	 * dotAll is on by default<br/>
	 * Returns false if parameters are invalid
	 * @param response 
	 * @param regExp
	 * @return
	 */
	public boolean responseContains(String regExp){return this.containsRegEx(this.response, regExp);}

	/**
	 * Checks if last cli response String contains the provided regular expression<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns false if parameters are invalid
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public boolean responseContains(String regExp, boolean dotAll){return this.containsRegEx(this.response, regExp, dotAll);}

	/**
	 * Returns a array of Strings found in the response String that matched the provided regExp<br/>
 	 * Returns null if parameters are invalid. <br/>
 	 * dotAll on by default
	 * @param regExp
	 * @return
	 */
	public ArrayList<String> responseGetGroups(String regExp){return this.getGroups(this.response, regExp);}
	
	/**
	 * Returns a array of Strings found in the last cli response String that matched the provided regExp<br/>
 	 * Returns null if parameters are invalid. <br/>
 	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public ArrayList<String> responseGetGroups(String regExp, boolean dotAll){return this.getGroups(this.response, regExp, dotAll);}

	/**
	 * Returns the string found in the last response that matches the provided regular expression.
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public String responseGetRegEx(String regExp, boolean dotAll){
		return this.getRegEx(this.getLastResponse(), regExp, dotAll);
	}
	
	/**
	 * Returns the number of times the RegEx is found in the last cli response
	 * Dotall on by default
	 * @param regExp
	 * @return
	 */
	public int responseCount(String regExp){return this.count(this.response, regExp);}
	
	/**
	 * Returns the number of times the RegEx is found in the last cli response
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public int responseCount(String regExp, boolean dotAll){return this.count(this.response, regExp, dotAll);}
	
	/**
	 * Method to trim off the command sent and command line prompt of the last response
	 * @return String
	 */
	public String trimResponse(){
		if(this.response == null){
			return null;
		}else if(this.response.equals("")){
			return this.response;
		}else if(this.responseTrimed){
			return this.response;
		}else{
			
			String tmp="";		
			//Trim off command sent back in response
			if(this.response.contains(this.lastCommand)){
				tmp = this.replaceFirst(this.response, "\\Q"+this.lastCommand +"\\E", "", false);//this.response.replace(this.lastCommand +"\n", "");//.substring(this.lastCommand.length());//
			}else{//counts number of \n in command string and substrings from last one
//				int subCount = this.count(this.lastCommand, "\n", false);
//				tmp = this.subStringFromRegExAt(this.response, "\n", subCount, false);
				if(this.response.contains("\n")){
					tmp = this.response.substring(this.response.indexOf("\n"));
				}
			}
			
			//Trims off the command promt
			if(tmp.contains("\n")){
				tmp = tmp.substring(0, tmp.lastIndexOf("\n"));
			}
			
			this.responseTrimed=true;

			return this.response = tmp;
		}
	}

	/**
	 * Method to grab the provide regEx from the response
	 * @param regExp
	 * @param dotAll
	 * @return: regExp found in the last response
	 */
	public String responseGetRegExp(String regExp, boolean dotAll){
		return this.getRegEx(this.response, regExp, dotAll);
	}
}
