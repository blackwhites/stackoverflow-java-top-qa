package tools;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import beans.RequestBean;

/**
 * Object to send http request over ssl
 * 
 * @author Nick Coble
 *
 */
public class HTTPSClient extends URLClient {	
//	private boolean connected = false;
	HttpsURLConnection con = null;
	TrustManager[] trustManager=null;
	SSLContext ssl_ctx=null;
	String errorMessage="";
	boolean variablesSet=true;
	
	public HTTPSClient(){
		super();
		this.initRequestVariablesInsecure();
	}
	
	/**
	 * Sets request to ignores server certs when making request.
	 * @return
	 */
	public boolean initRequestVariablesInsecure(){
		trustManager = getInsecureTrustManager();
		
		try {
			ssl_ctx = SSLContext.getInstance("TLS");
			ssl_ctx.init(null, trustManager,  new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(ssl_ctx.getSocketFactory());
			return (this.variablesSet=true);
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
			this.errorMessage=e1.getMessage();
			return (this.variablesSet=false);
		} catch (KeyManagementException e) {
			e.printStackTrace();
			this.errorMessage=e.getMessage();
			return (this.variablesSet=false);
		}
	}

	/**
	 * Sets request to validate server certs with trust store when making request.
	 * @param userTrustManager
	 * @return
	 */
	public boolean initRequestVariables(TrustManager[] userTrustManager){
		this.trustManager = userTrustManager;
		
		try {
			ssl_ctx = SSLContext.getInstance("TLS");
			ssl_ctx.init(null, trustManager,  new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(ssl_ctx.getSocketFactory());
			return (this.variablesSet=true);
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
			this.errorMessage=e1.getMessage();
			return (this.variablesSet=false);
		} catch (KeyManagementException e) {
			e.printStackTrace();
			this.errorMessage=e.getMessage();
			return (this.variablesSet=false);
		}
	}

	/**
	 * Method to send HTTPS request.
	 * User provides HTTP method to use and pay load to send.
	 * Common HTTP methods: GET,PUT,POST,DELETE,OPTIONS,HEAD
	 * Can be used to send pay loads with any HTTP method. IE test sending a GET request with a payload
	 * Returns a RequestBean that contains response information.
	 * @param httpMethod:String
	 * @param payload:String
	 * @return RequestBean
	 */
	@Override
	public RequestBean sendRequest(String httpMethod, String payload){

		if(!this.variablesSet){
			RequestBean requestBean = new RequestBean();
			requestBean.setError(true);
			requestBean.setErrorMessage("Error: Unable to send the request.  There was an error initializing global variables.  Error Message: " + this.errorMessage);
			return requestBean;
		}
		
		if(payload != null){
			return this.sendRequest(httpMethod, payload.getBytes(StandardCharsets.UTF_8), false);
		}else{
			return this.sendRequest(httpMethod, null, false);
		}
	}
	
	/**
	 * Method to send multipart/form-data.  
	 * @param formEntries: HashMap&#60;String, Object&#62;,  key = form data key, object = String or File 
	 * @param charSet
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	public RequestBean sendMultipartFormData(HashMap<String, Object> formEntries,Charset charSet) throws UnsupportedEncodingException, IOException{
		return this.sendRequest(URLClient.HTTP_POST, this.buildFormPayload(formEntries, charSet), false);
	}
	

	/**
	 * Method to send multipart/form-data.  
	 * @param formEntries: HashMap&#60;String, Object&#62;,  key = form data key, object = String or File 
	 * @param charSet
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	public RequestBean sendMultipartFormDataPersistent(HashMap<String, Object> formEntries,Charset charSet) throws UnsupportedEncodingException, IOException{
		return this.sendRequest(URLClient.HTTP_POST, this.buildFormPayload(formEntries, charSet), true);
	}
	
	

	public RequestBean sendRequest(String httpMethod, byte[] payload, boolean persistent){

		RequestBean requestBean = new RequestBean();
		requestBean.setUrl(this.url + this.buildURLParametersString());
		requestBean.setError(false);
		if(payload != null){
			requestBean.setClientPayload(new String(payload, StandardCharsets.UTF_8));
		}else{
			requestBean.setClientPayload(null);
		}
		
		try{
			
			//Create Connection
			URL website = new URL(requestBean.getUrl().replace(" ", "%20"));
			requestBean.setURI(website.getPath());
			requestBean.setHostName(website.getHost());
			requestBean.setProtocol(website.getProtocol());
			
			//Set connection properties
//			if(!persistent || (persistent && !connected)){
			con = (HttpsURLConnection)website.openConnection();

			//Ignore HostNameVerifier
			con.setHostnameVerifier(new HostnameVerifier() {
				@Override
				public boolean verify(String host, SSLSession sess){
					return true;
				}
			});
				
//			}	
			
			byte[] serverResponse = this.sendRequest(con, httpMethod, payload);
			
			//Store response data in RequestBean object
//			requestBean.setServerPayLoad(new String(serverResponse));
			requestBean.setServerPayloadBytes(serverResponse);
			requestBean.setServerHeaders(con.getHeaderFields());
			requestBean.setStatus(String.valueOf(con.getResponseCode()));
			requestBean.setStatusMessage(con.getResponseMessage());
			requestBean.setRequestMethod(con.getRequestMethod());
			requestBean.setReadTimeOut(String.valueOf(con.getReadTimeout()));
			requestBean.setConnectionTimeOut(String.valueOf(con.getConnectTimeout()));
			requestBean.setClientHeaders(this.headers);
			requestBean.setResponseContentLength(con.getContentLength());
			requestBean.setResponseContentType(con.getContentType());
			try{
				requestBean.setCertificates(con.getServerCertificates());
				requestBean.setCipherSuite(con.getCipherSuite());
				requestBean.setClientPrincipal(con.getLocalPrincipal());
				requestBean.setServerPrincipal(con.getPeerPrincipal());
			}catch(Exception e){
				
			}
		}catch (MalformedURLException e) {
			System.out.println("MalformedURLException Error: " + e.getMessage() + " doing " + httpMethod + " at " + this.url);
			requestBean.setUrl(this.url);
			requestBean.setServerPayLoad("MalformedURLException Error: " + e.getMessage() + " doing " + httpMethod + " at " + this.url + "\n");
			requestBean.setStatus(STATUS_CODE_EXCEPTION);
			requestBean.setError(true);
			requestBean.setException(e);

		} catch (IOException e) {
			System.out.println("IOException Error: " + e.getMessage() + " doing " +httpMethod + " at " + this.url);
			requestBean.setUrl(this.url);
			requestBean.setServerPayLoad("IOException Error: " + e.getMessage() + " doing " + httpMethod + " at " + this.url + ".  Connection Time Out: " + con.getConnectTimeout() + ", Read Time Out: " + con.getReadTimeout());
			requestBean.setStatus(STATUS_CODE_EXCEPTION);
			requestBean.setError(true);
			requestBean.setException(e);

		}finally{
			if(!persistent){
				this.closeConnection();
			}
		}
		
		this.lastResponse=requestBean;
		
		return requestBean;		
	}
	
	/**
	 * Returns a TrustManager that accepts all server certs.
	 * @return TrustManager[]
	 */
	private static TrustManager[] getInsecureTrustManager(){
		TrustManager[] trustManager = new TrustManager[]{
				new X509TrustManager(){
					@Override
					public X509Certificate[] getAcceptedIssuers(){return null;}

					@Override
					public void checkClientTrusted(X509Certificate[] arg0,
							String arg1) throws CertificateException {
						
					}
					@Override
					public void checkServerTrusted(X509Certificate[] arg0,
							String arg1) throws CertificateException {
						
					}
				}
		};
		return trustManager;
	}

	/**
	 * Method to send request over a persistent connection.<br/>
	 * User must use the {@link #closeConnection() closeConection} method after completing requests.
	 * 
	 * @param String:httpMethod
	 * @param String:payload
	 * @return
	 */
	public RequestBean sendRequestPersistent(String httpMethod, String payload){
		if(!this.variablesSet){
			RequestBean requestBean = new RequestBean();
			requestBean.setError(true);
			requestBean.setErrorMessage("Error: Unable to send the request.  There was an error initializing global variables.  Error Message: " + this.errorMessage);
			return requestBean;
		}
		
		if(payload != null){
			return this.sendRequest(httpMethod, payload.getBytes(StandardCharsets.UTF_8), true);
		}else{
			return this.sendRequest(httpMethod, null, true);
		}
	}

	public boolean isConnected() {return connected;}

	public void closeConnection(){
		if(con != null){con.disconnect();}
		super.closeConnection();
//		//Close streams
//		try{
//			if(in!=null){in.close();}
//		}catch (Exception e){
//			System.out.println("Closing Input BufferStream Error.");
//			e.printStackTrace();
//		}	
//
//		try{
//			if(out!=null){out.close();}
//		}catch (Exception e){
//			System.out.println("Closing OutputStream Error.");
//			e.printStackTrace();
//		}	
//		this.connected=false;

	}
}
