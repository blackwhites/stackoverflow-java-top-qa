package tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Abstract Class to hold common methods for testing clients
 * @author cncoble
 *
 */
public abstract class BaseClient {
	public String hostName;
	public int port;
	public String userName;
	public String password;
	public String domain;
	protected Pattern p;
	
	
	/**
	 * Reads a file and returns the contents as a String
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public String readFile(String path, String fileName) throws IOException{
		StringBuilder payload= new StringBuilder();
		
		FileInputStream fstream = null;
		BufferedReader br = null;
		
		try{
			fstream = new FileInputStream(path + File.separatorChar + fileName);
			br = new BufferedReader(new InputStreamReader(fstream));
			//Read File Line By Line
			int tmp = -1;
			while(br.ready() && (tmp = br.read()) != -1){
				payload.append((char)tmp);
			}

		}catch(IOException e){
			e.printStackTrace();
			throw e;
		}finally{
			//Close streams
			br.close();
			fstream.close();
		}	
		
		if(payload.length()==0){
			throw new IOException("Error: Empty file. File: " + path + File.separatorChar + fileName);
		}
		
		return (payload.toString());
	}

	public String readFile(File f) throws IOException{
		StringBuilder payload= new StringBuilder();
		
		FileInputStream fstream = null;
		BufferedReader br = null;
		String line;
		
		try{
			fstream = new FileInputStream(f);
			br = new BufferedReader(new InputStreamReader(fstream));
			//Read File Line By Line
			while ((line = br.readLine()) != null)   {
				payload.append(line+ System.lineSeparator());
			}
		}catch(IOException e){
			e.printStackTrace();
			throw e;
		}finally{
			//Close streams
			br.close();
			fstream.close();
		}	
		
		if(payload.length()==0){
			throw new IOException("Error: Empty file. File: " + f.getPath());
		}
		
		return (payload.toString());
	}
	/**
	 * Checks if response String matches the provided regular expression.<br/>
	 * DotAll is on by default
	 * Returns false if parameters are invalid
	 * @param expectedResponse
	 * @param actualResponse
	 * @return boolean
	 */
	public boolean matchesRegEx(String response, String regExp){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return false;
		}
		p = Pattern.compile(regExp, Pattern.DOTALL);
		return p.matcher(response).matches();
	}
	
	/**
	 * Checks if response String matches the provided regular expression.<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns false if parameters are invalid
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public boolean matchesRegEx(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return false;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		return p.matcher(response).matches();
	}
	
	/**
	 * Checks if  response String contains the provided regular expression<br/>
	 * Returns false if parameters are invalid
	 * @param response
	 * @param contains
	 * @return
	 */
	public boolean containsRegEx(String response, String regExp){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return false;
		}
		p = Pattern.compile(regExp, Pattern.DOTALL);
		return p.matcher(response).find();
	}
		
	/**
	 * Checks if  response String contains the provided regular expression<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns false if parameters are invalid
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public boolean containsRegEx(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return false;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		return p.matcher(response).find();
	}
	
	/**
	 * Returns the matching regExp string found in the response<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns null if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public String getRegEx(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		Matcher m = p.matcher(response);

		if (m.find()) {
		    return m.group(0);
		}
		
		return null;
	}
	
	/**
	 * Returns the first index of matching regExp string found in the response and the length of the matched string.<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns null if parameters are invalid or if regEx is not found in String<br/>
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return  int[]: int[0] = index, int[1] = length
	 */
	public int[] getRegExFirstIndex(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		Matcher m = p.matcher(response);
		
		if (m.find()) {
			int[] tmp = new int[2];
			tmp[0] = m.start();
			tmp[1] =  m.group(0).length();
		    return tmp;
		}
//		else{
//			tmp[0] = -1;
//			tmp[1] =  -1;
//		    return tmp;
//		}
		
		return null;
	}
	
	/**
	 * Returns the last index of matching regExp string found in the response and the length of the matched string.<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns null if parameters are invalid or if regEx is not found in String<br/>
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return  int[]: int[0] = index, int[1] = length
  	 */
	public int[] getRegExLastIndex(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		Matcher m = p.matcher(response);
		int[] tmp = new int[2];
		tmp[0] = -1;
		tmp[1] =  -1;
		while(m.find()){
			tmp[0] = m.start();
			tmp[1] =  m.group(0).length();
		}
		
		return tmp;
	}
	
	/**
	 * Returns a array of Strings found in the response String that matched the provided regExp<br/>
 	 * Returns null if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @return
	 */
	public ArrayList<String> getGroups(String response, String regExp){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}
		ArrayList<String> tmp = new ArrayList<>();
		p = Pattern.compile(regExp, Pattern.DOTALL);
		Matcher m = p.matcher(response);

		while(m.find()){tmp.add(m.group(0));}
		
		return tmp;
	}

	/**
 	 * Returns a array of Strings found in the response String that matched the provided regExp<br/>
 	 * Returns null if parameters are invalid. <br/>
 	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public ArrayList<String> getGroups(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}
		ArrayList<String> tmp = new ArrayList<>();
		
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}		Matcher m = p.matcher(response);

		while(m.find()){tmp.add(m.group(0));}
		
		return tmp;
	}
	/**
	 * Returns the number of times the provided RegEx appears in the response<br/>
	 * Returns -1 if parameters are invalid
	 * @param response
	 * @param regExp
	 * @return
	 */
	public int count(String response, String regExp){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return -1;
		}
		int tmp=0;
		p = Pattern.compile(regExp, Pattern.DOTALL);
		Matcher m = p.matcher(response);
	
		while(m.find()){tmp++;}
		
		return tmp;
	}
	
	
	/**
	 * Returns the number of times the provided RegEx appears in the response<br/>	 
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns -1 if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @param dotAll
	 * @return
	 */
	public int count(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return -1;
		}
		int tmp=0;
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		Matcher m = p.matcher(response);
		while(m.find()){tmp++;}
		
		return tmp;
	}
	/**
	 * Replaces all instances of the  provided regex<br/>
	 * dotAll true if you want the . to include new line characters like \n<br/>
	 * Returns null if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @param replacement
	 * @return String
	 */
	public String replaceAll(String response, String regExp, String replacement, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("") || replacement == null){
			return null;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		return p.matcher(response).replaceAll(replacement);
	}
	
	/**
	 * Replaces first instance of the provided regex<br/>
 	 * dotAll true if you want the . to include new line characters like \n<br/>
 	 * Returns null if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @param replacement
	 * @return String
	 */
	public String replaceFirst(String response, String regExp, String replacement, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("") || replacement == null){
			return null;
		}
		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		return p.matcher(response).replaceFirst(replacement);
	}
	
	/**
	 * Creates a substring from the response using the first found instance of the regExp<br/>
 	 * dotAll true if you want the . to include new line characters like \n<br/>
 	 * Returns null if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @param replacement
	 * @return String
	 */
	public String subStringFromFirstRegEx(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}

		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		Matcher m = p.matcher(response);
		m.find();
			
		return response.substring(m.start() + m.group(0).length());
	}
	
	/**
	 * Replaces using the String replace method instead of regExp.  Do not use regEx.
	 * @param response
	 * @param stringToReplace
	 * @param replacement
	 * @return
	 */
	public String replaceString(String response, String stringToReplace, String replacement){
		return response.replace(stringToReplace, replacement);
	}
	
	
	/**
	 * Creates a substring from the response using the last found instance of the regExp<br/>
 	 * dotAll true if you want the . to include new line characters like \n<br/>
 	 * Returns null if parameters are invalid.<br/>
	 * @param response
	 * @param regExp
	 * @param replacement
	 * @return String
	 */
	public String subStringFromLastRegEx(String response, String regExp, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("")){
			return null;
		}

		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		Matcher m = p.matcher(response);
		int tmp =-1;
		int tmpLength = -1;
		while(m.find()){tmp=m.start(); tmpLength= m.group(0).length();}
		
		if(tmp<0||tmpLength<0){return null;}
		
		return response.substring(tmp + tmpLength);
	}
	
	/**
	 * Returns a substring of the provided response from the nth regEx found in the response.<br/>
	 * IE: subStringFromRegEx("blah\nblah2\nblah3\nblah4","\n",2,false) would return "blah3\n"blah4
	 * @param response
	 * @param regExp
	 * @param regExIndex
	 * @param dotAll
	 * @return
	 */
	public String subStringFromRegExAt(String response, String regExp, int regExIndex, boolean dotAll){
		if(response == null || response.equals("") || regExp == null || regExp.equals("") || regExIndex < 1){
			return null;
		}

		if(dotAll){
			p = Pattern.compile(regExp, Pattern.DOTALL);
		}else{
			p = Pattern.compile(regExp);
		}
		
		Matcher m = p.matcher(response);
		int tmp =-1;
		int tmpLength = -1;
		int i =0;
		boolean found = true;
		while(i< regExIndex-1 && (found =m.find())){
			i++;
		}

		if(found && m.find()){
			tmp=m.start(); 
			tmpLength= m.group(0).length();
		}else{
			return "Error: RegExp only has " + i + " matches.  Index " + regExIndex + " is not valid.  RegExp: "+ regExp;
		}
		
		if(tmp<0||tmpLength<0){return null;}
		
		return response.substring(tmp + tmpLength);
	}
	
	/**
	 * <p>Recursive Method That Compares two Objects fields using reflection.,br/>
	 * If either object is null then InvalidParameterException is thrown.</p>
	 * If an object has a field that is private then that field will be skipped<br/>//TODO check if private field has getter method first, if not then throw exception. Modifier.isPrivate(field.getModifiers())
	 * Works well for the xmlManagement Objects or JavaBeans.
	 * @param o1:Object
	 * @param o2:Object
	 * @return boolean
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws InvalidParameterException
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 * @throws InvocationTargetException 
	 */
	public boolean isEqual(Object o1, Object o2) throws IllegalArgumentException, IllegalAccessException, InvalidParameterException, InvocationTargetException, NoSuchMethodException, SecurityException{
//System.out.println("====================================================");//Use to separate recursions for debug
		//TODO consider attempting to invoke getter method for private fields
		if(o1 == null){
			throw new InvalidParameterException("Error: Object o1 was null");
		}else if(o2 == null){
			throw new InvalidParameterException("Error: Object o2 was null");
		}else if(!(o1.getClass().getSimpleName().equals(o2.getClass().getSimpleName()))){
			return false;
		}else if(o1.equals(o2)){
			return true;
		}else{
			
			//Check object fields
			List<Field> o1fields = this.getAllFields(o1.getClass());
			List<Field> o2fields = this.getAllFields(o2.getClass());

			int i=0;
			for(Field f: o1fields){
				
				//Enable access
				f.setAccessible(true);
				o2fields.get(i).setAccessible(true);
//System.out.println("Comparing: " +f.getName()+" and " + o2fields.get(i).getName());

				if(f.get(o1)==null){			
					if(o2fields.get(i).get(o2) != null){
//System.out.println("Fail 0");
						return false;
					}
				}else if(o2fields.get(i).get(o2) == null){
//System.out.println("Fail 1");
					return false;
				}else if(f.getType().isPrimitive()){
					if(f.get(o1)!=o2fields.get(i).get(o2)){
//System.out.println("Fail 2");
						return false;
						}
				}else if(f.get(o1) instanceof String){
//System.out.println("Fail 3");
					if(!f.get(o1).equals(o2fields.get(i).get(o2))){return false;}
				}else if(f.getType().isEnum()){
//System.out.println("ENUM:  " + (String)f.get(o1).getClass().getDeclaredMethod("value").invoke(f.get(o1)));
					if(!((String)f.get(o1).getClass().getDeclaredMethod("value").invoke(f.get(o1))).equals((String)o2fields.get(i).get(o2).getClass().getDeclaredMethod("value").invoke(o2fields.get(i).get(o2)))){return false;}
				}else if(f.get(o1) instanceof List<?>){
					
					if(((List<?>)f.get(o1)).size() != ((List<?>)o2fields.get(i).get(o2)).size() ){return false;}
					
					for(int j=0;j<((List<?>)f.get(o1)).size() ;j++){
						if(!this.isEqual(((List<?>)f.get(o1)).get(j), ((List<?>)o2fields.get(i).get(o2)).get(j))){
							return false;
						}
					}
				}else if(f.getType().isArray()){
					
//					System.out.println(f.getType().getSimpleName());

					if(f.getType().getSimpleName().equals(int[].class.getSimpleName())){
						
						int[] tmp = (int[])f.get(o1);
						int[] tmp2 = (int[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
						
					}else if(f.getType().getSimpleName().equals(char[].class.getSimpleName())){
						
						char[] tmp = (char[])f.get(o1);
						char[] tmp2 = (char[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else if(f.getType().getSimpleName().equals(double[].class.getSimpleName())){
						double[] tmp = (double[])f.get(o1);
						double[] tmp2 = (double[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else if(f.getType().getSimpleName().equals(long[].class.getSimpleName())){
						long[] tmp = (long[])f.get(o1);
						long[] tmp2 = (long[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else if(f.getType().getSimpleName().equals(float[].class.getSimpleName())){
						float[] tmp = (float[])f.get(o1);
						float[] tmp2 = (float[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else if(f.getType().getSimpleName().equals(byte[].class.getSimpleName())){
						byte[] tmp = (byte[])f.get(o1);
						byte[] tmp2 = (byte[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else if(f.getType().getSimpleName().equals(short[].class.getSimpleName())){
						short[] tmp = (short[])f.get(o1);
						short[] tmp2 = (short[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else if(f.getType().getSimpleName().equals(boolean[].class.getSimpleName())){
						boolean[] tmp = (boolean[])f.get(o1);
						boolean[] tmp2 = (boolean[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(tmp[index]!=tmp2[index]){
								return false;
							}
						}
					}else{
						//assume array of objects
						Object[] tmp = (Object[])f.get(o1);
						Object[] tmp2 = (Object[])o2fields.get(i).get(o2);
						
						if(tmp.length!=tmp2.length){return false;}
						
						for(int index=0;index<tmp.length;index++){
							if(!this.isEqual(tmp[index], tmp2[index])){
								return false;
							}
						}
					}
				}else{
					if(!this.isEqual(f.get(o1), o2fields.get(i).get(o2))){
						return false;
					}
				}
				i++;
			}
			
			return true;
		}
	
	}
	
	protected List<Field> getAllFields(Class<?> superClass){
		List<Field> fields = new ArrayList<Field>();
        for (Class<?> c = superClass; c != null; c = c.getSuperclass()) {
            fields.addAll(0,Arrays.asList(c.getDeclaredFields()));
        }
        return fields;
	}
	
	
	////////////////////////////////////////////////////////////////////
	//                 Getters And Setters 
	///////////////////////////////////////////////////////////////////
	public String getHostName() {return hostName;}

	public void setHostName(String hostName) {this.hostName = hostName;}

	public int getPort() {return port;}

	public void setPort(int port) {this.port = port;}

	public String getUserName() {return userName;}

	public void setUserName(String userName) {this.userName = userName;}

	public String getPassword() {return password;}

	public void setPassword(String password) {this.password = password;}

	public String getDomain() {return domain;}

	public void setDomain(String domain) {this.domain = domain;}
	
}
