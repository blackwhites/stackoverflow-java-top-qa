package tools;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Filter;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
public class DPLogger extends Logger{

//    private Logger LOGGER; 
	private Handler fileHandlerDebug  = null;
	private Handler fileHandlerInfo = null;
	private Handler consoleHandler = null;	
	public boolean lastTestResult=false;
	protected static int configLog = 0;
	protected static int testStepLog = 0;
	protected static int testCase = 0;
	private String fileName_Debug = null;
	private String fileName_Info = null;
//	private LinkedList<String> logQueue = new LinkedList<>();

	public DPLogger(String className, String logFilePath) throws SecurityException, IOException{
		super(className, null);
		this.setUseParentHandlers(false);
		this.fileName_Debug = logFilePath + "/"+className+"_Log_Debug.txt";
		this.fileName_Info = logFilePath + "/"+className+"_Log_Info.txt";
		fileHandlerDebug  = new FileHandler(fileName_Debug, 524288000, 5);
		fileHandlerInfo  = new FileHandler(fileName_Info, 524288000, 5);
		consoleHandler = new ConsoleHandler();
		this.addHandler(consoleHandler);
		this.addHandler(fileHandlerInfo);
		this.addHandler(fileHandlerDebug);
		consoleHandler.setLevel(Level.INFO);
		consoleHandler.setFormatter(new MyFormatter());
        fileHandlerDebug.setLevel(Level.ALL);
        fileHandlerInfo.setLevel(Level.INFO);
        fileHandlerInfo.setFormatter(new MyFormatter());
        fileHandlerDebug.setFormatter(new MyFormatter());
        this.setLevel(Level.ALL);
	}
	
	public DPLogger(String className, String logFilePath, boolean multipleLogs, boolean printInConsole) throws SecurityException, IOException{
		super(className, null);
		this.setUseParentHandlers(false);
		if(multipleLogs){
			this.fileName_Debug = logFilePath + "/"+className+"_Log_Debug.txt";
			this.fileName_Info = logFilePath + "/"+className+"_Log_Info.txt";
			fileHandlerInfo  = new FileHandler(fileName_Info, 524288000, 5);
			fileHandlerDebug  = new FileHandler(fileName_Debug, 524288000, 5);
			this.addHandler(fileHandlerInfo);
			fileHandlerInfo.setLevel(Level.INFO);
		    fileHandlerInfo.setFormatter(new MyFormatter());
		}else{
			this.fileName_Debug = logFilePath + "/"+className+"_Log.txt";
			fileHandlerDebug  = new FileHandler(fileName_Debug, 524288000, 5);
		}
		
		if(printInConsole){
			consoleHandler = new ConsoleHandler();
			this.addHandler(consoleHandler);
			consoleHandler.setLevel(Level.INFO);
			consoleHandler.setFormatter(new MyFormatter());
		}
		
		this.addHandler(fileHandlerDebug);
        fileHandlerDebug.setLevel(Level.ALL);
        fileHandlerDebug.setFormatter(new MyFormatter());
        this.setLevel(Level.ALL);
	}
	
	public String getDebugFileName(){
		return this.fileName_Debug;
	}
	
	public String getInfoFileName(){
		return this.fileName_Info;
	}

	public void exception(String message, Exception e){this.log(Level.SEVERE, message , e);}
	
	public void testResult(boolean passed, String message){
		lastTestResult=passed;
		if(passed){
			this.log(Level.INFO, "Passed: " + message);
		}else{
			this.log(Level.INFO, "Failed: " + message);
		}
	}
	
	public boolean closeLogger(){
		for(Handler h:this.getHandlers()){
			h.close();   //must call h.close or a .LCK file will remain.
		}
		return true;
	}
	
	public static class MyFormatter extends Formatter {
	    //
	    // Create a DateFormat to format the logger timestamp.
	    //
	    static final DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
	 
	    public String format(LogRecord record) {
	    	String logType="";
	    	if(record.getLevel().equals(Level.CONFIG)){
	    		logType = "Configuration Step";
	    	}else if(record.getLevel().equals(Level.SEVERE)){
	    		logType = "ERROR";
	    	}else{
	    		logType = "Test Step";
	    	}
	    	
	        StringBuilder builder = new StringBuilder(1000);
	        builder.insert(0, "================  " + logType + " - Log Record " + record.getSequenceNumber() + "  ================" + System.lineSeparator());
//	        if(record.getLevel().equals(Level.CONFIG)){
	        builder.append(df.format(new Date(record.getMillis()))).append(" - ");
//	        }
	        builder.append("[").append(record.getLevel()).append("] - ");
	        builder.append("[").append(record.getSourceClassName()).append(".");
	        builder.append(record.getSourceMethodName()).append("]"+ System.lineSeparator());

	        builder.append(formatMessage(record));
	        builder.append("\n================  " + logType + " - Log Record " + record.getSequenceNumber() + "   ================"+ System.lineSeparator()+ System.lineSeparator());

	        return builder.toString();
	    }
	 
	    public String getHead(Handler h) {
	        return super.getHead(h);
	    }
	 
	    public String getTail(Handler h) {
	        return super.getTail(h);
	    }
	}
	
	public static class MyFilter implements Filter{

		@Override
		public boolean isLoggable(LogRecord record) {
			if(record.getLevel().equals(Level.FINEST)){
				return false;
			}
			return true;
		}
		
	}

	protected void finalize() throws Throwable {this.closeLogger();}
	
}
