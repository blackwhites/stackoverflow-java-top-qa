package tools;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.json.JsonObject;
import org.w3c.dom.Document;
import tools.BaseClient;
import tools.Converter;
import variables.RMIVariables;
import xmlManagement.ActionDisconnect;
import xmlManagement.ActionSaveConfig;
import xmlManagement.AnyActionElement;
import xmlManagement.AnyConfigElement;
import xmlManagement.ConfigConfigBase;
import xmlManagement.ConfigDomain;
import xmlManagement.StatusActiveUsers;
import xmlManagement.StatusEnum;
import xmlManagement.Request.GetStatus;
import beans.RequestBean;

/**
 * Abstract class to hold common methods and variables between the different DP Management clients.
 * @author Nick Coble
 *
 */
public abstract class DPManagement extends BaseClient{
		
		public ConfigRequest configRequest;
		public ActionRequest action;
		public FileStoreRequest filestore;
		public StatusRequest status;
		public BatchRequest batchRequest;
		public Converter converter = new Converter();

		public DPManagement(String hostname, int port, String userName, String password, String domain){
			super();
			this.hostName=hostname;
			this.port= port;
			this.userName=userName;
			this.password=password;
			this.domain=domain;
		}
		
		/**
		 * Returns true if the regEx is found in the last server response
		 * @param expectedRegEx
		 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
		 * @return
		 */
		public abstract boolean lastResponseContains(String expectedRegEx, boolean dotAll);
		
		/**
		 * Returns true if the last server response matches the provided regex
		 * @param expectedRegEx
		 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
		 * @return
		 */
		public abstract boolean lastResponseMatches(String expectedRegEx, boolean dotAll);
		
		/**
		 * Returns the first regEx found in the last server response
		 * @param regEx
		 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
		 * @return
		 */
		public abstract String lastResponseGetRegEx(String regEx, boolean dotAll);
		
		/**
		 * Returns all the regEx's found in the last server response
		 * @param regEx
		 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
		 * @return
		 */
		public abstract ArrayList<String> lastResponseGetGroups(String regEx, boolean dotAll);
		
		/**
		 * Returns the number of times the provided regEx was found in the last server response
		 * @param regEx
		 * @param dotAll: boolean - controls if the wildcard(.) includes newline characters
		 * @return
		 */
		public abstract int lastResponseCountRegEx(String regEx, boolean dotAll);
		
		/**
		 * Returns the contents of the file base64 encoded
		 * @param path
		 * @param fileName
		 * @return
		 * @throws IOException
		 */
		public String base64EncodeFile(String path, String fileName) throws IOException{
			if(path == null || fileName == null || fileName.equals("")){return null;}
			return this.converter.encodeBase64(this.readFile(path, fileName));
		}
		
		/**
		 * Reads file into a json object.  Note: file contents must already be valid JSON
		 * @param path
		 * @param fileName
		 * @return
		 */
		public JsonObject readFileAsJsonObject(String path, String fileName){
			if(path == null || fileName == null || fileName.equals("")){return null;}
			try {
				return this.converter.stringToJSON(this.readFile(path, fileName));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			return null;
		}
		
		/**
		 * Reads file into a XML Document object.  Note: file contents must already be valid XML
		 * @param path
		 * @param fileName
		 * @return
		 */
		public Document readFileAsXMLObject(String path, String fileName){
			if(path == null || fileName == null || fileName.equals("")){return null;}
			try {
				return this.converter.stringToXML(this.readFile(path, fileName));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			return null;
		}
		
		
		///////////////////////////////////////////////////////
		//                  INNER CLASSES                   //
		/////////////////////////////////////////////////////
		/**
		 * Inner class to send Configuration request
		 * @author Nick Coble
		 *
		 */
		public abstract class ConfigRequest{
			
			/**
			 *Sends request to create configuration object
			 * @param AnyConfigElement: configObject
			 * @return RequestBean
			 * @throws IllegalAccessException 
			 * @throws IllegalArgumentException 
			 * @throws NoSuchMethodException 
			 * @throws InvocationTargetException 
			 * @throws SecurityException 
			 * @throws NoSuchFieldException 
			 * @throws Exception 
			 */
			public ArrayList<RequestBean> createConfigObjects(AnyConfigElement configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
				ArrayList<RequestBean> responses = new ArrayList<>();
				for(ConfigConfigBase a1: configObject.getConfigObjects()){
					responses.add(this.modifyConfigObject((a1)));
				}
				return responses;
			}
					
			/**
			 * Sends a post request to create the specified configuraiton object.
			 * @param configObject
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 */
			public abstract RequestBean createConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException;
		
		
			/**
			 * Sends request to modify configuration object
			 * @param AnyConfigElement: configObject
			 * @return RequestBean
			 * @throws SecurityException 
			 * @throws NoSuchFieldException 
			 * @throws IllegalAccessException 
			 * @throws IllegalArgumentException 
			 * @throws NoSuchMethodException 
			 * @throws InvocationTargetException 
			 * @throws Exception 
			 */
			public ArrayList<RequestBean> modifyConfigObjects(AnyConfigElement configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
				ArrayList<RequestBean> responses = new ArrayList<>();
				for(ConfigConfigBase a1: configObject.getConfigObjects()){
					responses.add(this.modifyConfigObject((a1)));
				}
				return responses;
			}
			
			/**
			 * Sends request to modify the configuration object using the values set in the provided parameter
			 * @param configObject
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 */
			public abstract RequestBean modifyConfigObject(ConfigConfigBase configObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException;
		
		
			/**
			 * Send request to delete a configuration object
			 * @param AnyConfigElement: configObject
			 * @return RequestBean
			 * @throws Exception 
			 */
			public ArrayList<RequestBean> deleteConfigObjects(AnyConfigElement configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
				ArrayList<RequestBean> responses = new ArrayList<>();
				for(ConfigConfigBase a1: configObject.getConfigObjects()){
					responses.add(this.deleteConfigObject((a1)));
				}
				return responses;
			}
			
			/**
			 * Sends request to delete the specified configuration object.  Note object must have name set.
			 * @param configObject
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 */
			public abstract RequestBean deleteConfigObject(ConfigConfigBase configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException;
			
			public abstract RequestBean deleteConfigObject(String objectClass, String objectName);

			/**
			 * Sends request to get a configuration object
			 * @param AnyConfigElement: configObject
			 * @return RequestBean
			 * @throws InstantiationException 
			 * @throws ClassNotFoundException 
			 * @throws Exception 
			 */
			public ArrayList<RequestBean> getConfigObjects(AnyConfigElement configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
				ArrayList<RequestBean> responses = new ArrayList<>();
				for(ConfigConfigBase a1: configObject.getConfigObjects()){
					responses.add(this.createConfigObject(a1));
				}
				return responses;
			}
			
			/**
			 * Sends a get request for the configuration object passed.  Note the object passed must have the name property set.
			 * @param configObject
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 * @throws ClassNotFoundException
			 * @throws InstantiationException
			 */
			public abstract RequestBean getConfigObject(ConfigConfigBase configObject) throws  IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException;
			
			
			/**
			 * Loads the provided configuration object properties by doing a GET request to the RMI interface.
			 * @param configObject
			 * @param instanceName
			 * @return RequestBean
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 */
			public abstract ConfigConfigBase loadConfigObject(ConfigConfigBase configObject, String instanceName) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException;
			
			
			
			
		
		}
		
		///////////////////////////////////////////////////
		//             Inner Class
		///////////////////////////////////////////////////
			
		/**
		 * Inner Class to send Action request
		 * @author Nick Coble
		 *
		 */
		public abstract class ActionRequest{
			
			/**
			 * Sends do-action request one at a time.
			 * @param AnyActionElement: a
			 * @return RequestBean
			 * @throws NoSuchMethodException 
			 * @throws InvocationTargetException 
			 * @throws SecurityException 
			 * @throws NoSuchFieldException 
			 * @throws IllegalAccessException 
			 * @throws IllegalArgumentException 
			 * @throws Exception 
			 */
			public ArrayList<RequestBean> actions(AnyActionElement a) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
				ArrayList<RequestBean> responses = new ArrayList<>();
				for(Object a1: a.getActionObjects()){
					responses.add(this.action((a1)));
				}
				return responses;
			}
			
			/**
			 * Sends the provided do-action request to the appliance and loads the response into the returned RequestBean.
			 * @param action
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 */
			public abstract RequestBean action(Object action) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException;
			
			/**
			 * Helper method to send save configuration action to DP appliance.
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 */
			public RequestBean saveConfig() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException{
				return this.action(new ActionSaveConfig());
			}
			
//			/**
//			 * Disconnects any active users from the specified domain.  Returns an array list of the users that were disconnected.
//			 * @param domain
//			 * @return
//			 * @throws NoSuchMethodException
//			 * @throws SecurityException
//			 * @throws ClassNotFoundException
//			 * @throws IllegalAccessException
//			 * @throws InstantiationException
//			 * @throws IllegalArgumentException
//			 * @throws InvocationTargetException
//			 * @throws NoSuchFieldException
//			 */
//			public abstract ArrayList<StatusActiveUsers> disconnectActiveUsers(String domain) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException;
//			
			
			/**
			 * Disconnects any active uses in the specified domain.  Returns a list of active users that were disconnected.
			 * @param domain
			 * @return
			 * @throws NoSuchMethodException
			 * @throws SecurityException
			 * @throws ClassNotFoundException
			 * @throws IllegalAccessException
			 * @throws InstantiationException
			 * @throws IllegalArgumentException
			 * @throws InvocationTargetException
			 * @throws NoSuchFieldException
			 */
			public ArrayList<StatusActiveUsers> disconnectActiveUsers(String domain) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException{

				ArrayList<StatusActiveUsers> disconnectedList = new ArrayList<>();
				RequestBean response = status.getStatus(StatusEnum.ACTIVE_USERS.value());
				List<Object> statusList = response.getResponseObject().getStatus().getStatusObjects();
				ActionDisconnect disconnect = new ActionDisconnect();
				for(Object activeUser: statusList){
					StatusActiveUsers user = (StatusActiveUsers)activeUser;
					
					if(user.getDomain().equals(domain)){
						disconnect.setId(user.getSession());
						disconnect.setConnection(user.getConnection());
						response = this.action(disconnect);
						if(!RMIVariables.STATUS_CODE_OK.contains(response.getStatus())){
							System.out.println("ERROR: Unable to disconnect user " + user.getName() + ".\nServer Response: " + response.getServerPayload() +"\nClient Payload: " + response.getClientPayload());
						}else{
							disconnectedList.add(user);
						}
					}

				}
						
				return disconnectedList;
			}
		
			/**
			 * Method to delete a domain.  Starts by disconnecting any active users then sends a delete request.
			 * @param domain
			 * @return
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 * @throws ClassNotFoundException
			 * @throws InstantiationException
			 */
			public RequestBean deleteDomain(String domain) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException{
				this.disconnectActiveUsers(domain);
				ConfigDomain d = new ConfigDomain();
				d.setName(domain);
				return configRequest.deleteConfigObject(d);
			}

			
		
		}
		
		
	///////////////////////////////////////////////////
//	             Inner Class
	///////////////////////////////////////////////////

		/**
		 * Inner Class to send file store request
		 * @author Nick Coble
		 *
		 */
		public abstract class FileStoreRequest{
			
			/**
			 * Creates a file on the dp appliance.
			 * Base64 encodes the provided contents and uploads it to the appliance.
			 * This method will not work for binary files.
			 * @param String: path - the directory where the file will be stored on appliance
			 * @param fileName - name the file will be saved as on the appliance
			 * @param contents - contents of the file.  Not encoded
			 * @return RequestBean
			 */
			public abstract RequestBean createFile(String path, String fileName, String contents);
			
			/**
			 * Adds a file on the dp appliance
			 * String should already be encoded.  Use this method for binary files.
			 * @param String: path - the directory where the file will be stored on appliance
			 * @param fileName - name the file will be saved as on the appliance
			 * @param contents - contents of the file.  Not encoded
			 * @return RequestBean
			 */
			public abstract RequestBean createEncodedFile(String path, String fileName, String contents);
			
			/**
			 * Modifies a file on the dp appliance
			 * Base64 encodes the provided contents and uploads it to the appliance
			 * @param String: path  - location to put file on the appliance
			 * @param String: fileName
			 * @param String: contents
			 * @return RequestBean
			 */
			public abstract RequestBean modifyFile(String path, String fileName, String contents);

			/**
			 * 
			 * @param path
			 * @param fileName
			 * @param contents
			 * @return
			 */
			public abstract RequestBean modifyEncodedFile(String path, String fileName, String contents);
			
			/**
			 * Deletes a file from the appliance
			 * @param path - location of the file on the appliance
			 * @param fileName - name of the file
			 * @return RequestBean
			 */
			public abstract RequestBean deleteFile(String path, String fileName);

			/**
			 * Gets a file from the appliance.  The contents of the file will be base64 encoded
			 * @param path - location of the file
			 * @param fileName - name of the file
			 * @return RequestBean
			 */
			public abstract RequestBean getFile(String path, String fileName);
			
			/**
			 * Gets the file using a SOMA command and returns the file contents as a base64 Decoded string
			 * @param path
			 * @param fileName
			 * @return
			 */
			public abstract String getFileAsString(String path, String fileName);

			/**
			 * Gets a directory from the appliance.
			 * @param path - location of the directory
			 * @param dirName - name of the directory
			 * @return
			 */
			public abstract RequestBean getDirectory(String path, String dirName);
			
			
			/**
			 * Gets a directory from the appliance.
			 * @param path - location of the directory
			 * @param dirName - name of the directory
			 * @return
			 */
			public abstract RequestBean getDirectory(String fullPath);
			
			/**
			 * returns cli-log file. "/mgmt/filestore/default/logtemp/cli-log"
			 * User must have access to default domain
			 * @param p
			 * @return boolean
			 */
			public abstract String getCLILog();
			
			/**
			 * Returns the default log.  "/mgmt/filestore/default/logtemp/default-log"
			 * @return
			 */
			public abstract String getDefaultLog();
			
			/**
			 * Returns the users log. /logtemp/default-log
			 * @return
			 */
			public abstract String getUserLog();
			
			/**
			 * Returns the specified log
			 * @param pathToLog
			 * @param logName
			 * @return
			 */
			public abstract String getLog(String pathToLog, String logName);
		
			/**
			 * Returns the last line in the log that has a time stamp
			 * @param pathToLog
			 * @param logName
			 * @return
			 */
			public abstract String getLogAnchor(String pathToLog, String logName);
		
			/**
			 * Returns the specified log substringed from the provided anchorPoint.
			 * If anchorPoint is not found in log, the cycled log file is checked.
			 * @param pathToLog
			 * @param logName
			 * @param anchorPoint
			 * @return
			 */
			public String getLogFromAnchor(String pathToLog, String logName, String anchorPoint){
				if(pathToLog == null ||  logName == null || logName.equals("") || anchorPoint == null || anchorPoint.equals("")){return null;}
				
				String tmp = this.getLog(pathToLog, logName);	
			
				if(tmp.indexOf(anchorPoint)==-1){
					//Get cycled file
					tmp = this.getLog(pathToLog, logName + ".1") + tmp;
					
				}
				
				if(tmp.indexOf(anchorPoint)==-1){
					return "Error: Unable to find anchor point in the log. Anchor: " + anchorPoint + "," + System.lineSeparator() +"Log: " + tmp;
				}
				
				tmp = tmp.substring(tmp.indexOf(anchorPoint) + anchorPoint.length());
				return tmp;
			}
		
		}

	///////////////////////////////////////////////////
	//	             Inner Class
	///////////////////////////////////////////////////

		/**
		 * Inner Class to send get-status request
		 * @author Nick Coble
		 *
		 */
		public abstract class StatusRequest{
			
			/**
			 * Method to retrieve a DP Status provider
			 * @param String: statusName
			 * @return RequestBean
			 * @throws InvocationTargetException 
			 * @throws IllegalArgumentException 
			 * @throws InstantiationException 
			 * @throws IllegalAccessException 
			 * @throws ClassNotFoundException 
			 * @throws SecurityException 
			 * @throws NoSuchMethodException 
			 */
			public abstract RequestBean getStatus(String statusName) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException;
			
			/**
			 * Method to retrieve a DP status object
			 * @param GetStatus: status
			 * @return RequestBean
			 * @throws InvocationTargetException 
			 * @throws IllegalArgumentException 
			 * @throws InstantiationException 
			 * @throws IllegalAccessException 
			 * @throws ClassNotFoundException 
			 * @throws SecurityException 
			 * @throws NoSuchMethodException 
			 */
			public  abstract RequestBean getStatus(GetStatus status) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException;
			
			public abstract RequestBean getStatus(StatusEnum status) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException;
			
			public ArrayList<RequestBean> getStatuses(ArrayList<GetStatus> s) throws NoSuchMethodException, SecurityException, ClassNotFoundException, IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException{
				ArrayList<RequestBean> responses = new ArrayList<>();
				for(GetStatus a1: s){
					responses.add(this.getStatus((a1)));
				}
				return responses;
			}
		}

	
		public abstract class BatchRequest{
			
			/**
			 * Adds config object payload to list
			 * @param object
			 * @throws IllegalArgumentException
			 * @throws IllegalAccessException
			 * @throws NoSuchFieldException
			 * @throws SecurityException
			 * @throws InvocationTargetException
			 * @throws NoSuchMethodException
			 */
			public abstract void addObjectToPayloadList(Object object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, InvocationTargetException, NoSuchMethodException;
			
			/**
			 * Adds config object payload to list
			 * @param objectPayload
			 */
			public abstract  void addObjectToPayloadList(String objectPayload);
			
			/**
			 * Adds a file payload to list
			 * @param pathToGetFile
			 * @param fileName
			 * @param pathToPutFile
			 * @throws IOException
			 */
			public abstract void addFileToPayloadList(String pathToGetFile, String fileName, String pathToPutFile) throws IOException;
			
			/**
			 * Clears all objects in the payload list
			 */
			public abstract void clearPayloadList();
			
			/**
			 * Builds batch payload from list
			 * @return
			 */
			public abstract String buildPayloadFromList();
			
			/**
			 * Sends the batch put request using the payload list.  If list is empty method returns null.
			 * @return
			 */
			public abstract RequestBean sendBatchRequest();
		}
			
		

}
