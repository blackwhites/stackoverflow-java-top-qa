package beans;

import java.io.StringReader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import xmlManagement.Response;

/**
 * Bean to hold request/response information
 * @author Nick Coble
 *
 */
public class RequestBean {
	private String url;
	private String uri;
	private String port;
	private String hostName;
	private String protocol;
	private String httpVersion;
	private String status = "-1";
	private String statusMessage="-1";
	private String domain="-1";
	private Certificate[] certs;
	private String cipherSuite = "-1";
//	private String serverPayload="-1";
	private byte[] serverPayload = null;
	private String clientPayload = "-1";
	private Principal clientPrincipal;
	private Principal serverPrincipal;
	private String requestMethod;
	private String readTimeOut;
	private String connectionTimeOut;
	private ArrayList<String> clientHeaders=null;
	private Map<String, List<String>> serverHeaders=null;
	private boolean error=false;
	private Response responseObject;
	private String errorMessage;
	private String contentLength;
	private String contentType;
	private JsonObject responseAsJSON;
	private JsonArray responseAsJSONArray;
	private Document responseAsXML;
	private Exception e;
	private Map<String, List<String>> requestProperties;

	/**
	 * @return the e
	 */
	public Exception getException() {
		return e;
	}

	/**
	 * @param e the e to set
	 */
	public void setException(Exception e) {
		this.e = e;
	}
	
	

	/**
	 * @return the responseAsJSONArray
	 */
	public JsonArray getResponseAsJSONArray() {
		if(responseAsJSONArray == null){
			if(this.getServerPayloadBytes() != null){
				responseAsJSONArray = Json.createReader(new StringReader(this.getServerPayload())).readArray();
			}
		}
		return responseAsJSONArray;
	}

	/**
	 * @param responseAsJSONArray the responseAsJSONArray to set
	 */
	public void setResponseAsJSONArray(JsonArray responseAsJSONArray) {
		this.responseAsJSONArray = responseAsJSONArray;
	}

	/**
	 * @return the responseAsJSON
	 */
	public JsonObject getResponseAsJSON() {
		if(responseAsJSON == null){
			if(this.getServerPayload() != null){
				responseAsJSON = Json.createReader(new StringReader(this.getServerPayload())).readObject();
			}
		}
		return responseAsJSON;
	}

	/**
	 * @param responseAsJSON the responseAsJSON to set
	 */
	public void setResponseAsJSON(JsonObject responseAsJSON) {
		this.responseAsJSON = responseAsJSON;
	}

	/**
	 * @return the responseAsXML
	 */
	public Document getResponseAsXML() {
		if(responseAsXML == null){
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder;
			try{
				builder = factory.newDocumentBuilder();
				responseAsXML = (Document) builder.parse(new InputSource(new StringReader(this.getServerPayload())));
			}catch(Exception e){
			}
		}
		return responseAsXML;
	}

	/**
	 * @param responseAsXML the responseAsXML to set
	 */
	public void setResponseAsXML(Document responseAsXML) {
		this.responseAsXML = responseAsXML;
	}

	public void setProtocol(String protocol){this.protocol = protocol;}
	
	public String getProtocol(){return this.protocol;}
	
	public void setHostName(String hostName){this.hostName = hostName;}
	
	public String getHostName(){return this.hostName;}
	
	public void setURI(String uri){this.uri = uri;}
	
	public String getURI(){return this.uri;}
	
	/**
	 * Sets the cipher suite used in HTTPS request
	 * @param c:String
	 */
	public void setCipherSuite(String c){this.cipherSuite = c;}
	
	
	/**
	 * Returns cipher suite used in HTTPS request
	 * @return String
	 */
	public String getCipherSuite(){return this.cipherSuite;}
	
	
	/**
	 * Returns headers used in server response
	 * @return the headers2
	 */
	public Map<String, List<String>> getServerHeaders() {
		return serverHeaders;
	}

	/**
	 * Sets the server response headers
	 * @param headers:Map<String, List<String>> 
	 */
	public void setServerHeaders(Map<String, List<String>> headers) {
		this.serverHeaders = headers;
	}
	
	/**
	 * Method to store web site certificates
	 * @param certs[]: Array of certificates to store
	 */
	public void setCertificates(Certificate[] certs){
		this.certs = certs;
	}
	
	/**
	 * Method to retrieve website certificates
	 * @return Certificate[]: Array of certificates
	 */
	public Certificate[] getCertificates(){
		return this.certs;
	}
	
	
	/**
	 * Method to set the http response status message
	 * @param String: http status message
	 */
	public void setStatusMessage(String message){
		this.statusMessage = message;
	}
	
	/**
	 * Method to retrieve the http response status message
	 * @return String:http status message
	 */
	public String getStatusMessage(){return this.statusMessage;}
	
	/**
	 * Returns server response HTTP status code 
	 * @return String: http status
	 */
	public String getStatus(){
		return this.status;
	}
	
	/**
	 * Sets the servers HTTP response status code
	 * @param status
	 */
	public void setStatus(String status){
		this.status = status;
	}
	

	/**
	 * Sets domain used in HTTP request
	 * @param domain:String
	 */
	public void setDomain(String domain){
		this.domain=domain;
	}
	
	/**
	 * Returns domain used in HTTP request
	 * @return String
	 */
	public String getDomain(){
		return this.domain;
	}

	
	/**
	 * Sets server HTTP response body
	 * @param payload:String
	 */
	public void setServerPayLoad(String payload){
		this.serverPayload = payload.getBytes(StandardCharsets.UTF_8);
	}
	
	/**
	 * Method to retrieve payload as string, must have used setPayLoadAsString
	 * @return String: URI payload
	 */
	public String getServerPayload(){
		if(this.getServerPayloadBytes() != null){

			return new String(this.getServerPayloadBytes(), StandardCharsets.UTF_8);
		}else{
			return null;
		}
	}
	
	/**
	 * Returns the pay load sent to server by client
	 * @return String
	 */
	public String getClientPayload(){
		return this.clientPayload;
	}
	
	/**
	 * Sets the client pay load sent to server
	 * @param payload:String
	 */
	public void setClientPayload(String payload){
		this.clientPayload = payload;
	}
	
	/**
	 * Returns the URL used in request
	 * @return String
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Sets the URL used in request
	 * @param url:String
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Returns port used in request 
	 * @return String
	 */
	public String getPort() {
		return port;
	}

	/**
	 * Sets port used in request
	 * @param ip:String
	 */
	public void setPort(String ip) {
		this.port = ip;
	}

	/**
	 * Returns HTTP version used in request
	 * @return String
	 */
	public String getHttpVersion() {
		return httpVersion;
	}

	/**
	 * Sets HTTP version used in request
	 * @param httpVersion:String
	 */
	public void setHttpVersion(String httpVersion) {
		this.httpVersion = httpVersion;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public Principal getClientPrincipal() {
		return clientPrincipal;
	}

	public void setClientPrincipal(Principal clientPrincipal) {
		this.clientPrincipal = clientPrincipal;
	}

	public Principal getServerPrincipal() {
		return serverPrincipal;
	}

	public void setServerPrincipal(Principal serverPrincipal) {
		this.serverPrincipal = serverPrincipal;
	}

	public String getReadTimeOut() {
		return readTimeOut;
	}

	public void setReadTimeOut(String readTimeOut) {
		this.readTimeOut = readTimeOut;
	}

	public String getConnectionTimeOut() {
		return connectionTimeOut;
	}

	public void setConnectionTimeOut(String connectionTimeOut) {
		this.connectionTimeOut = connectionTimeOut;
	}

	public ArrayList<String> getClientHeaders() {
		return clientHeaders;
	}

	public void setClientHeaders(ArrayList<String> clientHeaders) {
		this.clientHeaders = clientHeaders;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public Response getResponseObject() {
		return responseObject;
	}

	public void setResponseObject(Response responseObject) {
		this.responseObject = responseObject;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {this.errorMessage = errorMessage;}
	
	public List<String> getResponseHeader(String key){return this.serverHeaders.get(key);}

	public void setResponseContentLength(int contentLength) {this.contentLength = String.valueOf(contentLength);}
	
	public String getResponseContentLength(){
		if(this.contentLength==null){return "0";}
		return this.contentLength;}

	public void setResponseContentType(String contentType) {this.contentType =contentType;}
	
	public String getResponseContentType() {return this.contentType;}
	
	public String getRequestContentLength(){
		if(this.clientPayload==null){return "0";}
		return String.valueOf(this.clientPayload.length());
	}
	/**
	 * Method to print Object variable values
	 */
	@SuppressWarnings("unchecked")
	public String toString(){
		Field[] fields = this.getClass().getDeclaredFields();
		String tmp="";
		boolean first=true;
		for(Field f: fields){
			f.setAccessible(true);
			try {
				Object o = f.get(this); 
				if(o==null){
					continue;
					//Field Not Set, Do Nothing
				}else if(o instanceof String && !((String)o).equals("")){
					tmp += f.getName() + " = " + f.get(this).toString().replace("\n", "").replace("\r", "");
					first=false;
				}else if(f.getType().isPrimitive()){
					tmp += f.getName() + " = " + o.toString().replace("\n", "").replace("\r", "");
				}else if(o instanceof Properties){
					tmp += f.getName() + " = " + ((Properties)o).toString().replace("\n", "").replace("\r", "");
				}else if(o instanceof ArrayList<?>){
					tmp += f.getName() + " = " + ((ArrayList<String>)(o)).toString().replace("\n", "").replace("\r", "");
				}else if (o instanceof Map<?,?>){
					tmp += f.getName() + " = " + ((Map<String,List<String>>)(o)).toString().replace("\n", "").replace("\r", "");
				}else if (o instanceof Certificate[]){
					tmp += f.getName() + " = " + Arrays.toString((Certificate[])o).replace("\n", "").replace("\r", "");
				}else if(o instanceof Exception){
					tmp += f.getName() + " = " +((Exception)o).toString().replace("\n", "").replace("\r", "");
				}else if(o instanceof byte[]){
					tmp += f.getName() + " = " + this.getServerPayload().replace("\n", "").replace("\r", "");
				}else{
					
					tmp += f.getName() + " = " + o.toString().replace("\n", "").replace("\r", "");
				}
				
				if(!first){tmp+= System.lineSeparator();}
				first = false;
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		
		return tmp;
	}

	public void setRequestProperties(Map<String, List<String>> requestProperties) {
		this.requestProperties = requestProperties;
		
	}
	
	public Map<String, List<String>>  setRequestProperties() {
		return this.requestProperties;
		
	}

	public byte[] getServerPayloadBytes() {
		return serverPayload;
	}

	public void setServerPayloadBytes(byte[] serverPayloadBytes) {
		this.serverPayload = serverPayloadBytes;
	}
	
	
}
