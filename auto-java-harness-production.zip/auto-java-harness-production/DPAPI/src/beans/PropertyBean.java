package beans;


public class PropertyBean<T> {
	public T propertyValue;
	public void setValue(T t){this.propertyValue=t;}
	public T getValue(){return this.propertyValue;}
}


